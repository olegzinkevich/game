import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Static-hosting friendly build (no server runtime dependency). [NFR-COMPAT-004]
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    target: 'es2018',
    sourcemap: false,
  },
});
