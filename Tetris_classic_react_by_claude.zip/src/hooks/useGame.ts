import { useCallback, useEffect, useReducer, useRef } from 'react';
import { createInitialState, reducer } from '../game/engine';
import { loadHighScore, saveHighScore } from '../game/storage';
import { sound } from '../audio/sound';
import type { GameState } from '../game/types';

/** Delayed Auto Shift / Auto Repeat Rate for held Left/Right. [FR-CTRL-003] */
const DAS_MS = 160;
const ARR_MS = 45;

export interface GameApi {
  state: GameState;
  start: () => void;
  restart: () => void;
  togglePause: () => void;
  move: (dir: -1 | 1) => void;
  rotate: (dir: 1 | -1) => void;
  hardDrop: () => void;
  hold: () => void;
  /** Touch soft-drop press/release. */
  setSoftDrop: (on: boolean) => void;
  /** Touch directional press/release with DAS auto-repeat. */
  pressDir: (dir: -1 | 1) => void;
  releaseDir: (dir: -1 | 1) => void;
  toggleSound: () => boolean;
  soundEnabled: () => boolean;
}

export function useGame(): GameApi {
  const [state, dispatch] = useReducer(reducer, undefined, () =>
    createInitialState(loadHighScore(), 0x2545f491),
  );

  const statusRef = useRef(state.status);
  statusRef.current = state.status;

  const softRef = useRef(false);
  const dasDirRef = useRef<-1 | 0 | 1>(0);
  const dasChargeRef = useRef(0);
  const dasPhaseRef = useRef<'das' | 'arr'>('das');
  const lastSfxTag = useRef(state.sfx.tag);
  const lastHigh = useRef(state.highScore);

  // --- Audio reacts to engine sfx events. [FR-AUDIO-*] ------------------
  useEffect(() => {
    if (state.sfx.tag !== lastSfxTag.current) {
      lastSfxTag.current = state.sfx.tag;
      sound.play(state.sfx.event);
    }
  }, [state.sfx]);

  // --- Persist high score when it grows. [FR-SCORE-005] -----------------
  useEffect(() => {
    if (state.highScore !== lastHigh.current) {
      lastHigh.current = state.highScore;
      saveHighScore(state.highScore);
    }
  }, [state.highScore]);

  const setDir = useCallback((dir: -1 | 0 | 1) => {
    dasDirRef.current = dir;
    dasChargeRef.current = 0;
    dasPhaseRef.current = 'das';
  }, []);

  // --- Main loop: rAF with time delta. [FR-ARCH-001][FR-LIFE-003] -------
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const frame = (now: number) => {
      const dt = now - last;
      last = now;
      if (statusRef.current === 'running') {
        if (dasDirRef.current !== 0) {
          dasChargeRef.current += dt;
          if (dasPhaseRef.current === 'das') {
            if (dasChargeRef.current >= DAS_MS) {
              dasPhaseRef.current = 'arr';
              dasChargeRef.current = 0;
              dispatch({ type: dasDirRef.current === -1 ? 'left' : 'right' });
            }
          } else {
            while (dasChargeRef.current >= ARR_MS) {
              dasChargeRef.current -= ARR_MS;
              dispatch({ type: dasDirRef.current === -1 ? 'left' : 'right' });
            }
          }
        }
        dispatch({ type: 'tick', dt, soft: softRef.current });
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, []);

  // --- Auto-pause on tab hide / window blur. [FR-LIFE-008] --------------
  useEffect(() => {
    const pauseIfRunning = () => {
      if (statusRef.current === 'running') dispatch({ type: 'pause' });
    };
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') pauseIfRunning();
    };
    window.addEventListener('blur', pauseIfRunning);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('blur', pauseIfRunning);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, []);

  // --- Keyboard. [FR-CTRL-001][FR-CTRL-005][FR-LIFE-005][FR-OVER-003] ---
  useEffect(() => {
    const GAMEPLAY_KEYS = new Set([
      'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' ', 'Spacebar',
      'x', 'X', 'z', 'Z', 'c', 'C', 'Shift', 'Control',
    ]);

    const onKeyDown = (e: KeyboardEvent) => {
      const key = e.key;
      const status = statusRef.current;

      // Prevent page scroll / zoom for game keys during play. [FR-CTRL-005]
      if (GAMEPLAY_KEYS.has(key) || key === 'Escape' || key === 'p' || key === 'P' || key === 'r' || key === 'R') {
        if (key === ' ' || key === 'Spacebar' || key.startsWith('Arrow')) e.preventDefault();
      }

      // Pause / resume — always available. [FR-LIFE-004][FR-LIFE-005][FR-LIFE-006]
      if (key === 'Escape' || key === 'p' || key === 'P') {
        e.preventDefault();
        dispatch({ type: 'togglePause' });
        return;
      }

      // Restart from game over. [FR-LIFE-007][FR-OVER-003]
      if (key === 'r' || key === 'R') {
        if (status === 'gameover') {
          sound.resume();
          dispatch({ type: 'restart' });
        }
        return;
      }

      // Start from the ready screen. [FR-LIFE-002]
      if (status === 'ready') {
        if (key === 'Enter' || key === ' ' || key === 'Spacebar') {
          sound.resume();
          dispatch({ type: 'start' });
        }
        return;
      }

      // While paused, ignore everything except resume (handled above). [FR-LIFE-005]
      // While game over, ignore gameplay input (only R restarts). [FR-OVER-003][FR-OVER-004]
      if (status !== 'running') return;

      switch (key) {
        case 'ArrowLeft':
          if (!e.repeat) { setDir(-1); dispatch({ type: 'left' }); }
          break;
        case 'ArrowRight':
          if (!e.repeat) { setDir(1); dispatch({ type: 'right' }); }
          break;
        case 'ArrowDown':
          softRef.current = true;
          break;
        case ' ':
        case 'Spacebar':
          if (!e.repeat) dispatch({ type: 'hardDrop' });
          break;
        case 'ArrowUp':
        case 'x':
        case 'X':
          if (!e.repeat) dispatch({ type: 'rotateCW' });
          break;
        case 'z':
        case 'Z':
        case 'Control':
          if (!e.repeat) dispatch({ type: 'rotateCCW' });
          break;
        case 'c':
        case 'C':
        case 'Shift':
          if (!e.repeat) dispatch({ type: 'hold' });
          break;
        default:
          break;
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const key = e.key;
      if (key === 'ArrowDown') softRef.current = false;
      if (key === 'ArrowLeft' && dasDirRef.current === -1) setDir(0);
      if (key === 'ArrowRight' && dasDirRef.current === 1) setDir(0);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [setDir]);

  const start = useCallback(() => {
    sound.resume();
    dispatch({ type: 'start' });
  }, []);
  const restart = useCallback(() => {
    sound.resume();
    dispatch({ type: 'restart' });
  }, []);
  const togglePause = useCallback(() => dispatch({ type: 'togglePause' }), []);
  const move = useCallback((dir: -1 | 1) => dispatch({ type: dir === -1 ? 'left' : 'right' }), []);
  const rotate = useCallback((dir: 1 | -1) => dispatch({ type: dir === 1 ? 'rotateCW' : 'rotateCCW' }), []);
  const hardDrop = useCallback(() => dispatch({ type: 'hardDrop' }), []);
  const hold = useCallback(() => dispatch({ type: 'hold' }), []);
  const setSoftDrop = useCallback((on: boolean) => {
    softRef.current = on;
  }, []);
  const pressDir = useCallback((dir: -1 | 1) => {
    setDir(dir);
    dispatch({ type: dir === -1 ? 'left' : 'right' });
  }, [setDir]);
  const releaseDir = useCallback((dir: -1 | 1) => {
    if (dasDirRef.current === dir) setDir(0);
  }, [setDir]);
  const toggleSound = useCallback(() => {
    const next = !sound.isEnabled();
    sound.setEnabled(next);
    if (next) sound.resume();
    return next;
  }, []);
  const soundEnabled = useCallback(() => sound.isEnabled(), []);

  return {
    state,
    start,
    restart,
    togglePause,
    move,
    rotate,
    hardDrop,
    hold,
    setSoftDrop,
    pressDir,
    releaseDir,
    toggleSound,
    soundEnabled,
  };
}
