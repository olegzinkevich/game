import { useEffect, useState } from 'react';
import { Board } from './components/Board';
import { SidePanel } from './components/SidePanel';
import { Overlay } from './components/Overlay';
import { TouchControls } from './components/TouchControls';
import { useGame } from './hooks/useGame';

export default function App() {
  const game = useGame();
  const [soundOn, setSoundOn] = useState(game.soundEnabled());
  const [isTouch, setIsTouch] = useState(false);

  // Show on-screen controls on coarse-pointer (touch) devices. [FR-CTRL-004]
  useEffect(() => {
    const mq = window.matchMedia('(pointer: coarse)');
    const update = () => setIsTouch(mq.matches || 'ontouchstart' in window);
    update();
    mq.addEventListener?.('change', update);
    return () => mq.removeEventListener?.('change', update);
  }, []);

  const onToggleSound = () => setSoundOn(game.toggleSound());

  return (
    <div className="app">
      <main className="game-shell">
        <div className="board-wrap">
          <Board state={game.state} />
          <Overlay game={game} />
        </div>
        <SidePanel game={game} soundOn={soundOn} onToggleSound={onToggleSound} />
      </main>
      {isTouch && <TouchControls game={game} />}
    </div>
  );
}
