import type { PieceType } from './types';

/** Playfield dimensions. [FR-GRID-001] */
export const COLS = 10;
export const ROWS = 20;

/** Base drop interval at the starting level (level 0). [FR-CFG-001] */
export const BASE_DROP_MS = 500;

/** Minimum gravity interval; never faster than this. [FR-CFG-002] */
export const MIN_DROP_MS = 50;

/** Lines required to advance one level. [FR-CFG-003][FR-LEVEL-001] */
export const LINES_PER_LEVEL = 10;

/** Starting level. Level 0 keeps gravity at 500ms via max(50, 500/(level+1)). [FR-CFG-001][FR-LEVEL-002] */
export const START_LEVEL = 0;

/** Bounded lock delay. [FR-LOCK-002] */
export const LOCK_DELAY_MS = 500;

/** Maximum number of move/rotate lock-delay resets before a forced lock. [FR-LOCK-002] */
export const MAX_LOCK_RESETS = 15;

/** Soft-drop multiplier relative to current gravity. [FR-MOVE-004] */
export const SOFT_DROP_FACTOR = 20;

/** Duration of the line-clear flash animation. [UI-HUD-003] */
export const CLEAR_ANIM_MS = 220;

/** localStorage key for the persisted high score. [FR-SCORE-005] */
export const HIGH_SCORE_KEY = 'tetris.classic.highscore.v1';

/** Score awarded per cleared-line count, multiplied by level. [FR-SCORE-002] */
export const LINE_CLEAR_SCORE: Record<number, number> = {
  1: 100,
  2: 300,
  3: 500,
  4: 800,
};

/** Points per cell for soft and hard drop. [FR-SCORE-004] */
export const SOFT_DROP_POINTS = 1;
export const HARD_DROP_POINTS = 2;

/**
 * Standard tetromino colors. [FR-PIECE-002]
 * I=cyan, O=yellow, T=purple, S=green, Z=red, L=orange, J=blue.
 * Index 0 is the empty cell.
 */
export const PIECE_COLORS: Record<PieceType, string> = {
  I: '#22d3ee', // cyan
  O: '#facc15', // yellow
  T: '#a855f7', // purple
  S: '#22c55e', // green
  Z: '#ef4444', // red
  L: '#f97316', // orange
  J: '#3b82f6', // blue
};

/** Numeric id (1..7) for each piece type, used in the board array. [FR-ARCH-002] */
export const PIECE_ID: Record<PieceType, number> = {
  I: 1,
  O: 2,
  T: 3,
  S: 4,
  Z: 5,
  L: 6,
  J: 7,
};

/** Reverse map: numeric id -> color, for rendering locked cells. */
export const ID_TO_COLOR: Record<number, string> = {
  1: PIECE_COLORS.I,
  2: PIECE_COLORS.O,
  3: PIECE_COLORS.T,
  4: PIECE_COLORS.S,
  5: PIECE_COLORS.Z,
  6: PIECE_COLORS.L,
  7: PIECE_COLORS.J,
};

/** Reverse map: numeric id -> piece type label, for the non-color a11y signal. [NFR-A11Y-002] */
export const ID_TO_TYPE: Record<number, PieceType> = {
  1: 'I',
  2: 'O',
  3: 'T',
  4: 'S',
  5: 'Z',
  6: 'L',
  7: 'J',
};

export const ALL_PIECES: PieceType[] = ['I', 'O', 'T', 'S', 'Z', 'L', 'J'];
