// Core domain types for the Tetris engine.

/** Piece type identifiers. Numeric ids 1..7 are used in the board array. [FR-ARCH-002] */
export type PieceType = 'I' | 'O' | 'T' | 'S' | 'Z' | 'L' | 'J';

/** Cell value: 0 = empty, 1..7 = occupying piece color id. [FR-GRID-002][FR-ARCH-002] */
export type Cell = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;

/** A row of the board. */
export type Row = Cell[];

/** The 10x20 playfield. board[y][x], y from top (0) to bottom (ROWS-1). */
export type Board = Row[];

/** Rotation state index: 0 = spawn, 1 = R (CW), 2 = 180, 3 = L (CCW). */
export type RotationState = 0 | 1 | 2 | 3;

/** A single occupied coordinate offset within a piece's matrix. */
export interface Coord {
  x: number;
  y: number;
}

/** The active falling piece. */
export interface ActivePiece {
  type: PieceType;
  /** Top-left position of the piece's bounding matrix on the board. */
  x: number;
  y: number;
  rotation: RotationState;
}

export type GameStatus = 'ready' | 'running' | 'paused' | 'gameover';

export type ClearKind = 0 | 1 | 2 | 3 | 4;

/** Full serializable game state. */
export interface GameState {
  board: Board;
  active: ActivePiece | null;
  nextQueue: PieceType[];
  hold: PieceType | null;
  canHold: boolean;
  status: GameStatus;
  score: number;
  level: number;
  lines: number;
  highScore: number;
  /** Bag of remaining pieces for the 7-bag randomizer. */
  bag: PieceType[];
  /** PRNG state (mulberry32) for deterministic, reproducible shuffles. */
  rngState: number;
  /** Accumulated gravity time in ms since last gravity step. */
  gravityAccumulatorMs: number;
  /** Lock-delay countdown in ms while the piece is resting; null when airborne. */
  lockTimerMs: number | null;
  /** Number of lock-delay resets used (bounds infinite stalling). [FR-LOCK-002] */
  lockResets: number;
  /** Rows currently animating a clear (for visual feedback). [UI-HUD-003] */
  clearingRows: number[];
  /** Remaining clear-animation time in ms. */
  clearAnimMs: number;
  /** Kind of the most recent line clear (drives Tetris vs normal feedback/audio). */
  lastClearKind: ClearKind;
  /** Monotonic event tag bumped whenever an audio-worthy event happens. */
  sfx: { event: SfxEvent; tag: number };
}

export type SfxEvent =
  | 'none'
  | 'move'
  | 'rotate'
  | 'lock'
  | 'clear'
  | 'tetris'
  | 'gameover'
  | 'levelup';
