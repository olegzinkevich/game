import { ALL_PIECES } from './constants';
import type { PieceType } from './types';

/**
 * mulberry32 PRNG — small, fast, deterministic. Returns the next state and a
 * float in [0,1). Keeping the state in game state makes shuffles reproducible
 * and avoids Math.random() nondeterminism. [FR-SPAWN-001]
 */
export function nextRandom(state: number): { state: number; value: number } {
  let t = (state + 0x6d2b79f5) | 0;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  const value = ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  return { state: t >>> 0, value };
}

/**
 * Produce a freshly shuffled 7-bag (Fisher–Yates), each tetromino exactly once.
 * [FR-SPAWN-001]
 */
export function makeBag(rngState: number): { bag: PieceType[]; rngState: number } {
  const bag = ALL_PIECES.slice();
  let state = rngState;
  for (let i = bag.length - 1; i > 0; i--) {
    const r = nextRandom(state);
    state = r.state;
    const j = Math.floor(r.value * (i + 1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  return { bag, rngState: state };
}

/**
 * Pull the next piece, refilling the bag from a new shuffle when empty. Also
 * keeps the visible Next queue topped up so previews always have lookahead.
 * [FR-SPAWN-001][FR-SPAWN-002]
 */
export function drawNext(
  queue: PieceType[],
  bag: PieceType[],
  rngState: number,
  minQueue = 5,
): { piece: PieceType; queue: PieceType[]; bag: PieceType[]; rngState: number } {
  let q = queue.slice();
  let b = bag.slice();
  let state = rngState;

  const fill = () => {
    while (q.length < minQueue + 1) {
      if (b.length === 0) {
        const made = makeBag(state);
        b = made.bag;
        state = made.rngState;
      }
      q.push(b.shift() as PieceType);
    }
  };

  fill();
  const piece = q.shift() as PieceType;
  fill();
  return { piece, queue: q, bag: b, rngState: state };
}
