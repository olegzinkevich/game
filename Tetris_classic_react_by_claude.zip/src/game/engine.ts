import {
  BASE_DROP_MS,
  CLEAR_ANIM_MS,
  COLS,
  HARD_DROP_POINTS,
  LINE_CLEAR_SCORE,
  LINES_PER_LEVEL,
  LOCK_DELAY_MS,
  MAX_LOCK_RESETS,
  MIN_DROP_MS,
  PIECE_ID,
  ROWS,
  SOFT_DROP_FACTOR,
  SOFT_DROP_POINTS,
  START_LEVEL,
} from './constants';
import { drawNext, makeBag } from './bag';
import {
  cellsOf,
  kickTableFor,
  spawnTopOffset,
  spawnWidth,
} from './tetrominoes';
import type {
  ActivePiece,
  Board,
  Cell,
  ClearKind,
  GameState,
  PieceType,
  RotationState,
} from './types';

/** Smallest interval the soft-drop accelerator will produce. */
const SOFT_DROP_FLOOR_MS = 25;
/** Hard cap on a single tick delta to prevent gravity avalanche. [FR-LIFE-008][FR-LIFE-003] */
export const MAX_TICK_MS = 100;

export function createEmptyBoard(): Board {
  return Array.from({ length: ROWS }, () => Array<Cell>(COLS).fill(0));
}

/** Gravity interval for a level. [FR-CFG-001][FR-CFG-002][FR-LEVEL-002] */
export function gravityIntervalMs(level: number): number {
  return Math.max(MIN_DROP_MS, BASE_DROP_MS / (level + 1));
}

/** Level derived from total cleared lines. [FR-LEVEL-001][FR-CFG-003] */
export function levelForLines(lines: number): number {
  return START_LEVEL + Math.floor(lines / LINES_PER_LEVEL);
}

/**
 * True if placing `type` at (x,y)/rotation collides with a wall, the floor, or
 * an occupied cell. Cells above the top (y<0) are allowed (spawn buffer).
 * [FR-COL-001]
 */
export function collidesAt(
  board: Board,
  type: PieceType,
  x: number,
  y: number,
  rotation: RotationState,
): boolean {
  for (const c of cellsOf(type, rotation)) {
    const bx = x + c.x;
    const by = y + c.y;
    if (bx < 0 || bx >= COLS || by >= ROWS) return true; // left/right/bottom bounds
    if (by >= 0 && board[by][bx] !== 0) return true; // occupied cell
  }
  return false;
}

/** Absolute board coordinates occupied by the active piece. */
export function activeCells(active: ActivePiece): { x: number; y: number }[] {
  return cellsOf(active.type, active.rotation).map((c) => ({
    x: active.x + c.x,
    y: active.y + c.y,
  }));
}

/** Lowest y the active piece can hard-drop to (its landing row). [FR-GHOST-001] */
export function ghostY(board: Board, active: ActivePiece): number {
  let y = active.y;
  while (!collidesAt(board, active.type, active.x, y + 1, active.rotation)) {
    y += 1;
  }
  return y;
}

function isResting(board: Board, active: ActivePiece): boolean {
  return collidesAt(board, active.type, active.x, active.y + 1, active.rotation);
}

/** Build the spawn placement for a piece type. [FR-PIECE-004][FR-SPAWN-002] */
function makeActive(type: PieceType): ActivePiece {
  const x = Math.floor(COLS / 2) - Math.floor(spawnWidth(type) / 2);
  const y = spawnTopOffset(type);
  return { type, x, y, rotation: 0 };
}

/** Initial state before Start is pressed. [FR-LIFE-002] */
export function createInitialState(highScore = 0, seed = 1): GameState {
  const first = makeBag(seed);
  return {
    board: createEmptyBoard(),
    active: null,
    nextQueue: [],
    hold: null,
    canHold: true,
    status: 'ready',
    score: 0,
    level: START_LEVEL,
    lines: 0,
    highScore: Math.max(0, highScore | 0),
    bag: first.bag,
    rngState: first.rngState,
    gravityAccumulatorMs: 0,
    lockTimerMs: null,
    lockResets: 0,
    clearingRows: [],
    clearAnimMs: 0,
    lastClearKind: 0,
    sfx: { event: 'none', tag: 0 },
  };
}

function emitSfx(state: GameState, event: GameState['sfx']['event']): GameState['sfx'] {
  return { event, tag: state.sfx.tag + 1 };
}

/** Draw a piece and place it; flags game over on block-out. [FR-OVER-001][FR-LOCK-001] */
function spawnNext(state: GameState): GameState {
  const draw = drawNext(state.nextQueue, state.bag, state.rngState);
  const active = makeActive(draw.piece);
  const next: GameState = {
    ...state,
    active,
    nextQueue: draw.queue,
    bag: draw.bag,
    rngState: draw.rngState,
    canHold: true,
    gravityAccumulatorMs: 0,
    lockTimerMs: null,
    lockResets: 0,
  };
  if (collidesAt(next.board, active.type, active.x, active.y, active.rotation)) {
    // Block-out: piece can't be placed. [FR-OVER-001]
    return { ...next, active, status: 'gameover', sfx: emitSfx(state, 'gameover') };
  }
  return next;
}

/** Merge the active piece into the board as locked cells. */
function mergeActive(board: Board, active: ActivePiece): Board {
  const id = PIECE_ID[active.type] as Cell;
  const next = board.map((r) => r.slice());
  for (const c of activeCells(active)) {
    if (c.y >= 0 && c.y < ROWS && c.x >= 0 && c.x < COLS) {
      next[c.y][c.x] = id;
    }
  }
  return next;
}

/** Indices of fully-filled rows. [FR-CLEAR-006] */
function fullRows(board: Board): number[] {
  const rows: number[] = [];
  for (let y = 0; y < ROWS; y++) {
    if (board[y].every((cell) => cell !== 0)) rows.push(y);
  }
  return rows;
}

/**
 * Remove the given rows and let everything above fall, preserving gaps in the
 * surviving rows. [FR-CLEAR-001..005]
 */
function removeRows(board: Board, rows: number[]): Board {
  const remove = new Set(rows);
  const kept = board.filter((_, y) => !remove.has(y));
  const cleared = rows.length;
  const empty = Array.from({ length: cleared }, () => Array<Cell>(COLS).fill(0));
  return [...empty, ...kept];
}

/**
 * Lock the active piece. If rows fill, start the clear animation; the rows are
 * removed and scored when the animation completes (resolveClears). Otherwise
 * spawn the next piece immediately. [FR-LOCK-001][FR-CLEAR-*]
 */
function lockActive(state: GameState): GameState {
  if (!state.active) return state;
  const board = mergeActive(state.board, state.active);
  const rows = fullRows(board);

  if (rows.length > 0) {
    const kind = rows.length as ClearKind;
    return {
      ...state,
      board,
      active: null,
      clearingRows: rows,
      clearAnimMs: CLEAR_ANIM_MS,
      lastClearKind: kind,
      lockTimerMs: null,
      lockResets: 0,
      sfx: emitSfx(state, kind === 4 ? 'tetris' : 'clear'),
    };
  }

  const locked: GameState = { ...state, board, active: null, sfx: emitSfx(state, 'lock') };
  return spawnNext(locked);
}

/** Apply score/lines/level after the clear animation, then spawn next. */
function resolveClears(state: GameState): GameState {
  const cleared = state.clearingRows.length;
  if (cleared === 0) return spawnNext(state);

  const board = removeRows(state.board, state.clearingRows);
  const gained = (LINE_CLEAR_SCORE[cleared] ?? 0) * state.level; // [FR-SCORE-002]
  const newScore = state.score + gained;
  const newLines = state.lines + cleared; // [FR-SCORE-003]
  const newLevel = levelForLines(newLines); // [FR-LEVEL-001][FR-LEVEL-002]
  const leveledUp = newLevel > state.level;

  const cleen: GameState = {
    ...state,
    board,
    clearingRows: [],
    clearAnimMs: 0,
    score: newScore,
    lines: newLines,
    level: newLevel,
    highScore: Math.max(state.highScore, newScore), // [FR-SCORE-001][FR-SCORE-005]
    sfx: leveledUp ? emitSfx(state, 'levelup') : state.sfx,
  };
  return spawnNext(cleen);
}

/** Try to move the active piece by (dx,dy). Returns updated state (or same). [FR-MOVE-001][FR-MOVE-002] */
function tryMove(state: GameState, dx: number, dy: number): { state: GameState; moved: boolean } {
  if (!state.active) return { state, moved: false };
  const a = state.active;
  if (collidesAt(state.board, a.type, a.x + dx, a.y + dy, a.rotation)) {
    return { state, moved: false }; // rejected, unchanged [FR-MOVE-002][FR-COL-001]
  }
  const active = { ...a, x: a.x + dx, y: a.y + dy };
  return { state: { ...state, active }, moved: true };
}

/** Reset/maintain lock delay after a successful grounded action. [FR-LOCK-002] */
function refreshLockDelay(state: GameState): GameState {
  if (!state.active) return state;
  if (!isResting(state.board, state.active)) {
    return { ...state, lockTimerMs: null };
  }
  if (state.lockResets >= MAX_LOCK_RESETS) {
    return state; // bounded: stop refreshing to prevent infinite stalling
  }
  return {
    ...state,
    lockTimerMs: LOCK_DELAY_MS,
    lockResets: state.lockResets + 1,
  };
}

function horizontalMove(state: GameState, dir: -1 | 1): GameState {
  if (state.status !== 'running' || !state.active) return state;
  const res = tryMove(state, dir, 0);
  if (!res.moved) return state;
  return refreshLockDelay({ ...res.state, sfx: emitSfx(res.state, 'move') });
}

/** Rotate using SRS kicks. [FR-ROT-001][FR-ROT-002][FR-ROT-003] */
function rotate(state: GameState, dir: 1 | -1): GameState {
  if (state.status !== 'running' || !state.active) return state;
  const a = state.active;
  const from = a.rotation;
  const to = (((from + dir) % 4) + 4) % 4 as RotationState;
  const kicks = kickTableFor(a.type)[`${from}-${to}`];
  for (const k of kicks) {
    const nx = a.x + k.x;
    const ny = a.y + k.y;
    if (!collidesAt(state.board, a.type, nx, ny, to)) {
      const active = { ...a, x: nx, y: ny, rotation: to };
      return refreshLockDelay({ ...state, active, sfx: emitSfx(state, 'rotate') });
    }
  }
  return state; // no valid kick -> rejected, unchanged [FR-ROT-003]
}

function hold(state: GameState): GameState {
  if (state.status !== 'running' || !state.active || !state.canHold) return state;
  const current = state.active.type;
  if (state.hold == null) {
    const withHold: GameState = { ...state, hold: current, canHold: false };
    const spawned = spawnNext(withHold);
    return { ...spawned, canHold: false };
  }
  const swapType = state.hold;
  const active = makeActive(swapType);
  if (collidesAt(state.board, active.type, active.x, active.y, active.rotation)) {
    return { ...state, active, hold: current, canHold: false, status: 'gameover', sfx: emitSfx(state, 'gameover') };
  }
  return {
    ...state,
    active,
    hold: current,
    canHold: false,
    gravityAccumulatorMs: 0,
    lockTimerMs: null,
    lockResets: 0,
  };
}

function hardDrop(state: GameState): GameState {
  if (state.status !== 'running' || !state.active) return state;
  const a = state.active;
  const landingY = ghostY(state.board, a);
  const distance = landingY - a.y;
  const dropped: GameState = {
    ...state,
    active: { ...a, y: landingY },
    score: state.score + distance * HARD_DROP_POINTS, // [FR-SCORE-004]
  };
  const scored: GameState = { ...dropped, highScore: Math.max(dropped.highScore, dropped.score) };
  return lockActive(scored); // [FR-MOVE-005]
}

/** Advance the simulation by dt ms. `soft` = soft-drop key held. [FR-MOVE-003][FR-MOVE-004] */
function tick(state: GameState, dtMsRaw: number, soft: boolean): GameState {
  if (state.status !== 'running') return state;
  const dt = Math.min(dtMsRaw, MAX_TICK_MS); // [FR-LIFE-003][FR-LIFE-008]

  // Line-clear animation in progress: count it down, then resolve. [UI-HUD-003]
  if (state.clearingRows.length > 0) {
    const remaining = state.clearAnimMs - dt;
    if (remaining > 0) return { ...state, clearAnimMs: remaining };
    return resolveClears(state);
  }

  if (!state.active) return state;

  const baseInterval = gravityIntervalMs(state.level);
  const interval = soft
    ? Math.max(SOFT_DROP_FLOOR_MS, baseInterval / SOFT_DROP_FACTOR)
    : baseInterval;

  let s: GameState = { ...state, gravityAccumulatorMs: state.gravityAccumulatorMs + dt };
  let guard = 0;

  // Gravity: descend one cell per elapsed interval while airborne. [FR-MOVE-003][FR-MOVE-004]
  while (s.active && s.gravityAccumulatorMs >= interval && guard < 64) {
    guard += 1;
    if (isResting(s.board, s.active)) {
      // Can't descend; stop draining gravity — locking is handled by the
      // real-time lock-delay clock below.
      s = { ...s, gravityAccumulatorMs: 0 };
      break;
    }
    s = { ...s, gravityAccumulatorMs: s.gravityAccumulatorMs - interval };
    const res = tryMove(s, 0, 1);
    if (res.moved) {
      s = { ...res.state, lockTimerMs: null, lockResets: 0 }; // descended -> airborne
      if (soft) {
        const sc = s.score + SOFT_DROP_POINTS; // [FR-SCORE-004]
        s = { ...s, score: sc, highScore: Math.max(s.highScore, sc) };
      }
    }
  }

  // Lock delay: counts down in real time (dt), independent of gravity speed, so
  // there is always a bounded ~500 ms window to move/rotate. [FR-LOCK-001][FR-LOCK-002]
  if (s.active) {
    if (isResting(s.board, s.active)) {
      const timer = (s.lockTimerMs ?? LOCK_DELAY_MS) - dt;
      if (timer <= 0) {
        s = lockActive(s);
      } else {
        s = { ...s, lockTimerMs: timer };
      }
    } else if (s.lockTimerMs != null) {
      s = { ...s, lockTimerMs: null };
    }
  }
  return s;
}

export type Action =
  | { type: 'start' }
  | { type: 'restart' }
  | { type: 'tick'; dt: number; soft: boolean }
  | { type: 'left' }
  | { type: 'right' }
  | { type: 'rotateCW' }
  | { type: 'rotateCCW' }
  | { type: 'hardDrop' }
  | { type: 'hold' }
  | { type: 'pause' }
  | { type: 'resume' }
  | { type: 'togglePause' }
  | { type: 'setHighScore'; value: number };

/** The single source of truth for state transitions. Pure. */
export function reducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case 'start':
    case 'restart': {
      const fresh = createInitialState(state.highScore, (state.rngState ^ 0x9e3779b9) >>> 0);
      return spawnNext({ ...fresh, status: 'running' });
    }
    case 'tick':
      return tick(state, action.dt, action.soft);
    case 'left':
      return horizontalMove(state, -1);
    case 'right':
      return horizontalMove(state, 1);
    case 'rotateCW':
      return rotate(state, 1);
    case 'rotateCCW':
      return rotate(state, -1);
    case 'hardDrop':
      return hardDrop(state);
    case 'hold':
      return hold(state);
    case 'pause':
      // Only an active game can be paused. [FR-LIFE-004]
      if (state.status !== 'running') return state;
      return { ...state, status: 'paused' };
    case 'resume':
      // Resume restores the identical pre-pause state. [FR-LIFE-006]
      if (state.status !== 'paused') return state;
      return { ...state, status: 'running', gravityAccumulatorMs: 0 };
    case 'togglePause':
      if (state.status === 'running') return { ...state, status: 'paused' };
      if (state.status === 'paused') return { ...state, status: 'running', gravityAccumulatorMs: 0 };
      return state;
    case 'setHighScore':
      return { ...state, highScore: Math.max(state.highScore, action.value | 0) };
    default:
      return state;
  }
}
