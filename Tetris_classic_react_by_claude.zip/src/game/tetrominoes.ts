import type { Coord, PieceType, RotationState } from './types';

/**
 * Tetromino geometry. Each piece has four rotation states (0=spawn, 1=CW,
 * 2=180, 3=CCW). Coordinates are {x,y} offsets within the piece's bounding box,
 * with y increasing downward (matching the board). [FR-PIECE-001][FR-PIECE-003]
 *
 * Spawn-state occupied cells always begin at column 0 so the horizontal
 * centering formula in spawnPiece() lands them correctly. [FR-PIECE-004]
 */
export const SHAPES: Record<PieceType, Coord[][]> = {
  I: [
    [{ x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }, { x: 3, y: 1 }],
    [{ x: 2, y: 0 }, { x: 2, y: 1 }, { x: 2, y: 2 }, { x: 2, y: 3 }],
    [{ x: 0, y: 2 }, { x: 1, y: 2 }, { x: 2, y: 2 }, { x: 3, y: 2 }],
    [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 1, y: 2 }, { x: 1, y: 3 }],
  ],
  O: [
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }],
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }],
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }],
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }],
  ],
  T: [
    [{ x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }],
    [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 2, y: 1 }, { x: 1, y: 2 }],
    [{ x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }, { x: 1, y: 2 }],
    [{ x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 1, y: 2 }],
  ],
  S: [
    [{ x: 1, y: 0 }, { x: 2, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }],
    [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 2, y: 1 }, { x: 2, y: 2 }],
    [{ x: 1, y: 1 }, { x: 2, y: 1 }, { x: 0, y: 2 }, { x: 1, y: 2 }],
    [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 1, y: 2 }],
  ],
  Z: [
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 2, y: 1 }],
    [{ x: 2, y: 0 }, { x: 1, y: 1 }, { x: 2, y: 1 }, { x: 1, y: 2 }],
    [{ x: 0, y: 1 }, { x: 1, y: 1 }, { x: 1, y: 2 }, { x: 2, y: 2 }],
    [{ x: 1, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 0, y: 2 }],
  ],
  L: [
    [{ x: 2, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }],
    [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 1, y: 2 }, { x: 2, y: 2 }],
    [{ x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }, { x: 0, y: 2 }],
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 1, y: 2 }],
  ],
  J: [
    [{ x: 0, y: 0 }, { x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }],
    [{ x: 1, y: 0 }, { x: 2, y: 0 }, { x: 1, y: 1 }, { x: 1, y: 2 }],
    [{ x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }, { x: 2, y: 2 }],
    [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 0, y: 2 }, { x: 1, y: 2 }],
  ],
};

/**
 * SRS wall-kick offsets, keyed by "from->to" rotation transition. [FR-ROT-002]
 * Standard tables are published with y pointing up; here y is negated so it
 * matches the board's downward y axis. The first entry (0,0) is the naive
 * in-place rotation; subsequent entries are the kick candidates tried in order.
 */
type KickTable = Record<string, Coord[]>;

// Main pieces: J, L, S, T, Z.
export const KICKS_JLSTZ: KickTable = {
  '0-1': [{ x: 0, y: 0 }, { x: -1, y: 0 }, { x: -1, y: -1 }, { x: 0, y: 2 }, { x: -1, y: 2 }],
  '1-0': [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 0, y: -2 }, { x: 1, y: -2 }],
  '1-2': [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 0, y: -2 }, { x: 1, y: -2 }],
  '2-1': [{ x: 0, y: 0 }, { x: -1, y: 0 }, { x: -1, y: -1 }, { x: 0, y: 2 }, { x: -1, y: 2 }],
  '2-3': [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: -1 }, { x: 0, y: 2 }, { x: 1, y: 2 }],
  '3-2': [{ x: 0, y: 0 }, { x: -1, y: 0 }, { x: -1, y: 1 }, { x: 0, y: -2 }, { x: -1, y: -2 }],
  '3-0': [{ x: 0, y: 0 }, { x: -1, y: 0 }, { x: -1, y: 1 }, { x: 0, y: -2 }, { x: -1, y: -2 }],
  '0-3': [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: -1 }, { x: 0, y: 2 }, { x: 1, y: 2 }],
  // 180-degree transitions (not produced by single rotations, included for safety).
  '0-2': [{ x: 0, y: 0 }],
  '2-0': [{ x: 0, y: 0 }],
  '1-3': [{ x: 0, y: 0 }],
  '3-1': [{ x: 0, y: 0 }],
};

// I piece has its own kick table.
export const KICKS_I: KickTable = {
  '0-1': [{ x: 0, y: 0 }, { x: -2, y: 0 }, { x: 1, y: 0 }, { x: -2, y: 1 }, { x: 1, y: -2 }],
  '1-0': [{ x: 0, y: 0 }, { x: 2, y: 0 }, { x: -1, y: 0 }, { x: 2, y: -1 }, { x: -1, y: 2 }],
  '1-2': [{ x: 0, y: 0 }, { x: -1, y: 0 }, { x: 2, y: 0 }, { x: -1, y: -2 }, { x: 2, y: 1 }],
  '2-1': [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: -2, y: 0 }, { x: 1, y: 2 }, { x: -2, y: -1 }],
  '2-3': [{ x: 0, y: 0 }, { x: 2, y: 0 }, { x: -1, y: 0 }, { x: 2, y: -1 }, { x: -1, y: 2 }],
  '3-2': [{ x: 0, y: 0 }, { x: -2, y: 0 }, { x: 1, y: 0 }, { x: -2, y: 1 }, { x: 1, y: -2 }],
  '3-0': [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: -2, y: 0 }, { x: 1, y: 2 }, { x: -2, y: -1 }],
  '0-3': [{ x: 0, y: 0 }, { x: -1, y: 0 }, { x: 2, y: 0 }, { x: -1, y: -2 }, { x: 2, y: 1 }],
  '0-2': [{ x: 0, y: 0 }],
  '2-0': [{ x: 0, y: 0 }],
  '1-3': [{ x: 0, y: 0 }],
  '3-1': [{ x: 0, y: 0 }],
};

/** O piece never needs to kick (rotation is a visual no-op). */
export const KICKS_O: KickTable = {
  '0-1': [{ x: 0, y: 0 }],
  '1-0': [{ x: 0, y: 0 }],
  '1-2': [{ x: 0, y: 0 }],
  '2-1': [{ x: 0, y: 0 }],
  '2-3': [{ x: 0, y: 0 }],
  '3-2': [{ x: 0, y: 0 }],
  '3-0': [{ x: 0, y: 0 }],
  '0-3': [{ x: 0, y: 0 }],
  '0-2': [{ x: 0, y: 0 }],
  '2-0': [{ x: 0, y: 0 }],
  '1-3': [{ x: 0, y: 0 }],
  '3-1': [{ x: 0, y: 0 }],
};

export function kickTableFor(type: PieceType): KickTable {
  if (type === 'I') return KICKS_I;
  if (type === 'O') return KICKS_O;
  return KICKS_JLSTZ;
}

/** Cells of a piece in a given rotation state. */
export function cellsOf(type: PieceType, rotation: RotationState): Coord[] {
  return SHAPES[type][rotation];
}

/** Width (in columns) of a piece's occupied cells in its spawn state. [FR-PIECE-004] */
export function spawnWidth(type: PieceType): number {
  const cells = SHAPES[type][0];
  const maxX = Math.max(...cells.map((c) => c.x));
  const minX = Math.min(...cells.map((c) => c.x));
  return maxX - minX + 1;
}

/** Vertical offset so the topmost occupied cell of the spawn state sits at board row 0. */
export function spawnTopOffset(type: PieceType): number {
  const cells = SHAPES[type][0];
  return -Math.min(...cells.map((c) => c.y));
}
