import { HIGH_SCORE_KEY } from './constants';

/**
 * High-score persistence. All access is guarded so that unavailable, blocked,
 * quota-exceeded, or private-mode localStorage never crashes the game, and
 * corrupt values fall back to a safe default.
 * [FR-SCORE-005][FR-ERR-005][FR-ERR-006][NFR-COMPAT-003]
 */

function safeStorage(): Storage | null {
  try {
    const s = window.localStorage;
    const probe = '__tetris_probe__';
    s.setItem(probe, '1');
    s.removeItem(probe);
    return s;
  } catch {
    return null;
  }
}

export function loadHighScore(): number {
  const s = safeStorage();
  if (!s) return 0;
  try {
    const raw = s.getItem(HIGH_SCORE_KEY);
    if (raw == null) return 0;
    const value = Number.parseInt(raw, 10);
    if (!Number.isFinite(value) || Number.isNaN(value) || value < 0) {
      return 0; // corrupt/invalid -> default [FR-ERR-006]
    }
    return Math.floor(value);
  } catch {
    return 0;
  }
}

export function saveHighScore(value: number): void {
  const s = safeStorage();
  if (!s) return; // degrade gracefully [FR-ERR-005]
  try {
    s.setItem(HIGH_SCORE_KEY, String(Math.max(0, Math.floor(value))));
  } catch {
    /* quota exceeded / blocked — ignore, game stays playable [FR-ERR-005] */
  }
}
