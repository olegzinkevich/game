import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { ErrorBoundary } from './components/ErrorBoundary';
import './styles.css';

// Last-resort guards so unhandled errors never spin the console. [FR-ERR-008]
window.addEventListener('error', (e) => {
  console.warn('[Tetris] window error:', e.message);
});
window.addEventListener('unhandledrejection', (e) => {
  console.warn('[Tetris] unhandled rejection:', e.reason);
});

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>,
  );
}
