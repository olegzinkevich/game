import type { SfxEvent } from '../game/types';

/**
 * Tiny WebAudio synth — no audio asset files (keeps the bundle small) and
 * degrades silently when WebAudio is unavailable or blocked.
 * [FR-AUDIO-001..005][NFR-COMPAT-003][NFR-PERF-003]
 */
class SoundEngine {
  private ctx: AudioContext | null = null;
  private enabled = true;
  private supported = true;

  setEnabled(on: boolean) {
    this.enabled = on;
  }

  isEnabled() {
    return this.enabled;
  }

  isSupported() {
    return this.supported;
  }

  /** Must be called from a user gesture to satisfy autoplay policies. */
  resume() {
    const ctx = this.ensure();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  }

  private ensure(): AudioContext | null {
    if (this.ctx) return this.ctx;
    try {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) {
        this.supported = false;
        return null;
      }
      this.ctx = new Ctor();
      return this.ctx;
    } catch {
      this.supported = false;
      return null;
    }
  }

  private blip(freq: number, durMs: number, type: OscillatorType, gain = 0.08) {
    if (!this.enabled) return;
    const ctx = this.ensure();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, now);
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(gain, now + 0.005);
      g.gain.exponentialRampToValueAtTime(0.0001, now + durMs / 1000);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + durMs / 1000 + 0.02);
    } catch {
      /* ignore — audio is non-essential */
    }
  }

  private chord(freqs: number[], durMs: number, type: OscillatorType, gain = 0.06) {
    freqs.forEach((f) => this.blip(f, durMs, type, gain));
  }

  play(event: SfxEvent) {
    switch (event) {
      case 'move':
        this.blip(220, 40, 'square', 0.04); // [FR-AUDIO-001]
        break;
      case 'rotate':
        this.blip(330, 45, 'square', 0.045); // [FR-AUDIO-001]
        break;
      case 'lock':
        this.blip(150, 70, 'triangle', 0.07); // [FR-AUDIO-002]
        break;
      case 'clear':
        this.chord([523, 659], 160, 'triangle', 0.06); // [FR-AUDIO-003]
        break;
      case 'tetris':
        this.chord([523, 659, 784, 1047], 280, 'sawtooth', 0.05); // [FR-AUDIO-004] brighter
        break;
      case 'levelup':
        this.chord([392, 523, 659], 220, 'triangle', 0.05);
        break;
      case 'gameover':
        this.blip(140, 500, 'sine', 0.09); // [FR-AUDIO-005] low signal
        break;
      default:
        break;
    }
  }
}

export const sound = new SoundEngine();
