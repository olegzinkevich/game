import { useEffect, useRef } from 'react';
import { PIECE_COLORS } from '../game/constants';
import { cellsOf } from '../game/tetrominoes';
import type { PieceType } from '../game/types';

/** Renders a single tetromino centered in a small canvas. [FR-SPAWN-002][UI-LAYOUT-001] */
export function PiecePreview({ type, label }: { type: PieceType | null; label: string }) {
  const ref = useRef<HTMLCanvasElement>(null);

  const draw = () => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const cssW = canvas.clientWidth;
    const cssH = canvas.clientHeight;
    if (cssW === 0 || cssH === 0) return;
    canvas.width = Math.round(cssW * dpr);
    canvas.height = Math.round(cssH * dpr);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!type) return;

    const cells = cellsOf(type, 0);
    const xs = cells.map((c) => c.x);
    const ys = cells.map((c) => c.y);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);
    const w = maxX - minX + 1;
    const h = maxY - minY + 1;

    const cell = Math.min(canvas.width / (w + 1), canvas.height / (h + 1));
    const offX = (canvas.width - w * cell) / 2;
    const offY = (canvas.height - h * cell) / 2;
    const color = PIECE_COLORS[type];

    for (const c of cells) {
      const px = offX + (c.x - minX) * cell;
      const py = offY + (c.y - minY) * cell;
      const pad = Math.max(1, cell * 0.06);
      ctx.fillStyle = color;
      ctx.fillRect(px + pad, py + pad, cell - pad * 2, cell - pad * 2);
      const bevel = Math.max(1, cell * 0.12);
      ctx.fillStyle = 'rgba(255,255,255,0.3)';
      ctx.fillRect(px + pad, py + pad, cell - pad * 2, bevel);
      ctx.fillStyle = 'rgba(0,0,0,0.28)';
      ctx.fillRect(px + pad, py + cell - pad - bevel, cell - pad * 2, bevel);
    }
  };

  useEffect(() => {
    draw();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ro = new ResizeObserver(() => draw());
    ro.observe(canvas);
    return () => ro.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <canvas
      ref={ref}
      className="preview-canvas"
      role="img"
      aria-label={type ? `${label}: ${type} piece` : `${label}: empty`}
    />
  );
}
