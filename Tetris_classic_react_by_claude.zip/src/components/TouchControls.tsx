import type { GameApi } from '../hooks/useGame';

/**
 * On-screen controls for touch devices. Every must-have action is reachable and
 * each touch target is at least 44x44 px (enforced in CSS). [FR-CTRL-004]
 */
export function TouchControls({ game }: { game: GameApi }) {
  const noContext = (e: React.MouseEvent) => e.preventDefault();

  const hold = (fn: () => void) => ({
    onTouchStart: (e: React.TouchEvent) => {
      e.preventDefault();
      fn();
    },
    onContextMenu: noContext,
  });

  return (
    <div className="touch-controls" aria-label="Touch controls">
      <div className="touch-row">
        <button
          type="button"
          className="touch-btn"
          aria-label="Move left"
          onTouchStart={(e) => { e.preventDefault(); game.pressDir(-1); }}
          onTouchEnd={(e) => { e.preventDefault(); game.releaseDir(-1); }}
          onContextMenu={noContext}
        >◀</button>
        <button
          type="button"
          className="touch-btn"
          aria-label="Soft drop"
          onTouchStart={(e) => { e.preventDefault(); game.setSoftDrop(true); }}
          onTouchEnd={(e) => { e.preventDefault(); game.setSoftDrop(false); }}
          onContextMenu={noContext}
        >▼</button>
        <button
          type="button"
          className="touch-btn"
          aria-label="Move right"
          onTouchStart={(e) => { e.preventDefault(); game.pressDir(1); }}
          onTouchEnd={(e) => { e.preventDefault(); game.releaseDir(1); }}
          onContextMenu={noContext}
        >▶</button>
      </div>
      <div className="touch-row">
        <button type="button" className="touch-btn" aria-label="Rotate counter-clockwise" {...hold(() => game.rotate(-1))}>⟲</button>
        <button type="button" className="touch-btn" aria-label="Rotate clockwise" {...hold(() => game.rotate(1))}>⟳</button>
        <button type="button" className="touch-btn" aria-label="Hold piece" {...hold(game.hold)}>⇩H</button>
      </div>
      <div className="touch-row">
        <button type="button" className="touch-btn wide" aria-label="Hard drop" {...hold(game.hardDrop)}>Hard Drop</button>
        <button type="button" className="touch-btn" aria-label="Pause" {...hold(game.togglePause)}>⏸</button>
      </div>
    </div>
  );
}
