import { PiecePreview } from './PiecePreview';
import type { GameApi } from '../hooks/useGame';

/**
 * Side panel: score, level, lines, Next preview, Hold, New Game/Restart, sound
 * toggle, and a Game Over indicator. [UI-LAYOUT-001][UI-HUD-001]
 */
export function SidePanel({ game, soundOn, onToggleSound }: {
  game: GameApi;
  soundOn: boolean;
  onToggleSound: () => void;
}) {
  const { state } = game;
  const next = state.nextQueue[0] ?? null;

  return (
    <aside className="side-panel" aria-label="Game information and controls">
      <div className="stats" aria-live="polite">
        <div className="stat">
          <span className="stat-label">Score</span>
          <span className="stat-value" data-testid="score">{state.score.toLocaleString()}</span>
        </div>
        <div className="stat">
          <span className="stat-label">High</span>
          <span className="stat-value">{state.highScore.toLocaleString()}</span>
        </div>
        <div className="stat">
          <span className="stat-label">Level</span>
          <span className="stat-value">{state.level}</span>
        </div>
        <div className="stat">
          <span className="stat-label">Lines</span>
          <span className="stat-value">{state.lines}</span>
        </div>
      </div>

      <div className="preview-group">
        <div className="preview-box">
          <span className="preview-title">Next</span>
          <PiecePreview type={next} label="Next piece" />
        </div>
        <div className="preview-box">
          <span className="preview-title">Hold</span>
          <PiecePreview type={state.hold} label="Held piece" />
        </div>
      </div>

      {state.status === 'gameover' && (
        <div className="game-over-indicator" role="status">
          Game Over
        </div>
      )}

      <div className="panel-actions">
        <button type="button" className="btn primary" onClick={game.restart}>
          {state.status === 'ready' ? 'New Game' : 'Restart'}
        </button>
        {state.status === 'running' || state.status === 'paused' ? (
          <button type="button" className="btn" onClick={game.togglePause}>
            {state.status === 'paused' ? 'Resume' : 'Pause'}
          </button>
        ) : null}
        <button
          type="button"
          className="btn"
          onClick={onToggleSound}
          aria-pressed={soundOn}
        >
          Sound: {soundOn ? 'On' : 'Off'}
        </button>
      </div>

      <details className="help">
        <summary>Controls</summary>
        <ul>
          <li><kbd>←</kbd> <kbd>→</kbd> Move</li>
          <li><kbd>↓</kbd> Soft drop</li>
          <li><kbd>Space</kbd> Hard drop</li>
          <li><kbd>↑</kbd>/<kbd>X</kbd> Rotate CW</li>
          <li><kbd>Z</kbd>/<kbd>Ctrl</kbd> Rotate CCW</li>
          <li><kbd>C</kbd>/<kbd>Shift</kbd> Hold</li>
          <li><kbd>Esc</kbd>/<kbd>P</kbd> Pause</li>
          <li><kbd>R</kbd> Restart</li>
        </ul>
      </details>
    </aside>
  );
}
