import { useEffect, useRef } from 'react';
import { COLS, ID_TO_COLOR, PIECE_COLORS, ROWS } from '../game/constants';
import { activeCells, ghostY } from '../game/engine';
import type { GameState } from '../game/types';

const prefersReducedMotion = () =>
  typeof window !== 'undefined' &&
  window.matchMedia &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function roundedCell(
  ctx: CanvasRenderingContext2D,
  px: number,
  py: number,
  size: number,
  color: string,
  variant: 'locked' | 'active' | 'ghost',
) {
  const pad = Math.max(1, Math.floor(size * 0.06));
  const x = px + pad;
  const y = py + pad;
  const s = size - pad * 2;

  if (variant === 'ghost') {
    // Outline only — distinct by shape/style, not just color. [UI-HUD-002][NFR-A11Y-002]
    ctx.lineWidth = Math.max(1.5, size * 0.08);
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.55;
    ctx.strokeRect(x + 1, y + 1, s - 2, s - 2);
    ctx.globalAlpha = 1;
    return;
  }

  ctx.fillStyle = color;
  ctx.fillRect(x, y, s, s);

  // Inner highlight (top-left) + shadow (bottom-right) gives a beveled 3D look.
  const bevel = Math.max(1, size * 0.12);
  ctx.fillStyle = 'rgba(255,255,255,0.30)';
  ctx.fillRect(x, y, s, bevel);
  ctx.fillRect(x, y, bevel, s);
  ctx.fillStyle = 'rgba(0,0,0,0.28)';
  ctx.fillRect(x, y + s - bevel, s, bevel);
  ctx.fillRect(x + s - bevel, y, bevel, s);

  if (variant === 'active') {
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = Math.max(1, size * 0.05);
    ctx.strokeRect(x + 0.5, y + 0.5, s - 1, s - 1);
  }
}

export function Board({ state }: { state: GameState }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // HiDPI: size backing store to CSS size * devicePixelRatio. [NFR-COMPAT-005]
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const cssW = canvas.clientWidth;
    const cssH = canvas.clientHeight;
    if (cssW === 0 || cssH === 0) return;
    const bw = Math.round(cssW * dpr);
    const bh = Math.round(cssH * dpr);
    if (canvas.width !== bw || canvas.height !== bh) {
      canvas.width = bw;
      canvas.height = bh;
    }

    const cell = Math.min(canvas.width / COLS, canvas.height / ROWS);
    const offsetX = (canvas.width - cell * COLS) / 2;
    const offsetY = (canvas.height - cell * ROWS) / 2;

    const s = stateRef.current;

    // Background.
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#0b0e17';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Grid lines.
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    ctx.lineWidth = 1;
    for (let c = 0; c <= COLS; c++) {
      const x = Math.round(offsetX + c * cell) + 0.5;
      ctx.beginPath();
      ctx.moveTo(x, offsetY);
      ctx.lineTo(x, offsetY + ROWS * cell);
      ctx.stroke();
    }
    for (let r = 0; r <= ROWS; r++) {
      const y = Math.round(offsetY + r * cell) + 0.5;
      ctx.beginPath();
      ctx.moveTo(offsetX, y);
      ctx.lineTo(offsetX + COLS * cell, y);
      ctx.stroke();
    }

    const cx = (gx: number) => offsetX + gx * cell;
    const cy = (gy: number) => offsetY + gy * cell;

    // Locked cells.
    for (let y = 0; y < ROWS; y++) {
      for (let x = 0; x < COLS; x++) {
        const id = s.board[y][x];
        if (id !== 0) {
          roundedCell(ctx, cx(x), cy(y), cell, ID_TO_COLOR[id], 'locked');
        }
      }
    }

    // Ghost + active piece. [FR-GHOST-001][UI-HUD-002]
    if (s.active && s.status === 'running') {
      const gy = ghostY(s.board, s.active);
      const color = PIECE_COLORS[s.active.type];
      for (const c of activeCells({ ...s.active, y: gy })) {
        if (c.y >= 0) roundedCell(ctx, cx(c.x), cy(c.y), cell, color, 'ghost');
      }
      for (const c of activeCells(s.active)) {
        if (c.y >= 0) roundedCell(ctx, cx(c.x), cy(c.y), cell, color, 'active');
      }
    } else if (s.active) {
      // Paused/over: show the piece in place (no ghost).
      const color = PIECE_COLORS[s.active.type];
      for (const c of activeCells(s.active)) {
        if (c.y >= 0) roundedCell(ctx, cx(c.x), cy(c.y), cell, color, 'active');
      }
    }

    // Line-clear flash. [UI-HUD-003][NFR-A11Y-005]
    if (s.clearingRows.length > 0) {
      const reduce = prefersReducedMotion();
      const alpha = reduce ? 0.5 : 0.3 + 0.5 * (s.clearAnimMs / 220);
      ctx.fillStyle = `rgba(255,255,255,${Math.max(0, Math.min(0.85, alpha))})`;
      for (const ry of s.clearingRows) {
        ctx.fillRect(offsetX, cy(ry), COLS * cell, cell);
      }
    }
  };

  // Redraw whenever state changes.
  useEffect(() => {
    draw();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  });

  // Redraw on resize / orientation change without losing state. [FR-ERR-004][UI-RESP-001]
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ro = new ResizeObserver(() => draw());
    ro.observe(canvas);
    window.addEventListener('orientationchange', draw);
    return () => {
      ro.disconnect();
      window.removeEventListener('orientationchange', draw);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="board-canvas"
      role="img"
      aria-label={`Tetris playfield, ${COLS} columns by ${ROWS} rows. Score ${state.score}, level ${state.level}, lines ${state.lines}.`}
    />
  );
}
