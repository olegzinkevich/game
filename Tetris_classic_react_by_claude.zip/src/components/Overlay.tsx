import type { GameApi } from '../hooks/useGame';

/**
 * Modal overlays for ready / paused / game-over states. The game-over overlay
 * shows the final score and a Restart action. [FR-OVER-002][UI-HUD-003][FR-LIFE-006]
 */
export function Overlay({ game }: { game: GameApi }) {
  const { state } = game;
  if (state.status === 'running') return null;

  if (state.status === 'ready') {
    return (
      <div className="overlay" role="dialog" aria-modal="true" aria-label="Start game">
        <div className="overlay-card">
          <h1 className="overlay-title">TETRIS</h1>
          <p className="overlay-text">Classic block-stacking. Clear lines, level up, beat your high score.</p>
          <button type="button" className="btn primary big" onClick={game.start} autoFocus>
            New Game
          </button>
          <p className="overlay-hint">Press Enter or Space to start</p>
        </div>
      </div>
    );
  }

  if (state.status === 'paused') {
    return (
      <div className="overlay" role="dialog" aria-modal="true" aria-label="Paused">
        <div className="overlay-card">
          <h2 className="overlay-title">Paused</h2>
          <button type="button" className="btn primary big" onClick={game.togglePause} autoFocus>
            Resume
          </button>
          <p className="overlay-hint">Press Esc or P to resume</p>
        </div>
      </div>
    );
  }

  // game over
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label="Game over">
      <div className="overlay-card">
        <h2 className="overlay-title danger">Game Over</h2>
        <p className="overlay-score">Final score: <strong>{state.score.toLocaleString()}</strong></p>
        <p className="overlay-text">High score: {state.highScore.toLocaleString()}</p>
        <button type="button" className="btn primary big" onClick={game.restart} autoFocus>
          Restart
        </button>
        <p className="overlay-hint">Press R to restart</p>
      </div>
    </div>
  );
}
