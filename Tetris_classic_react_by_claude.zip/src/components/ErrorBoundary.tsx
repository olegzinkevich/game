import { Component, type ErrorInfo, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}
interface State {
  hasError: boolean;
  message: string;
}

/**
 * Catches unhandled render/runtime errors and surfaces them gracefully instead
 * of a white screen or an infinite console-error loop. [FR-ERR-008]
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, message: '' };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error?.message ?? 'Unexpected error' };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Log once; no rethrow, so no infinite loop. [FR-ERR-008]
    console.warn('[Tetris] Recovered from an error:', error?.message, info?.componentStack);
  }

  private handleReload = () => {
    this.setState({ hasError: false, message: '' });
    try {
      window.location.reload();
    } catch {
      /* ignore */
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-screen" role="alert">
          <div className="overlay-card">
            <h2 className="overlay-title danger">Something went wrong</h2>
            <p className="overlay-text">{this.state.message}</p>
            <button type="button" className="btn primary big" onClick={this.handleReload}>
              Reload game
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
