# Tetris — Classic (React + TypeScript + Vite)

A web-based classic Tetris that runs in any modern desktop or mobile browser.
Built to satisfy 100% of the atomic requirements in
[`requirements_doc/requirements.md`](./requirements_doc/requirements.md).

## Run it

```bash
npm install
npm run dev      # local dev server (http://localhost:5173)
npm run build    # type-check + production build into dist/
npm run preview  # serve the production build
```

The production build in `dist/` is a fully static bundle — it runs over plain
HTTPS with **no server-side runtime** (drop it on any static host). [NFR-COMPAT-004]

## Controls

| Action            | Keys                     |
|-------------------|--------------------------|
| Move left / right | `←` / `→`                |
| Soft drop         | `↓`                      |
| Hard drop         | `Space`                  |
| Rotate CW         | `↑` or `X`               |
| Rotate CCW        | `Z` or `Ctrl`            |
| Hold              | `C` or `Shift`           |
| Pause / Resume    | `Esc` or `P`             |
| Restart           | `R` (after game over)    |

On touch devices, on-screen controls appear automatically (every button is at
least 44×44 px). [FR-CTRL-001][FR-CTRL-004]

## Architecture

- **`src/game/`** — framework-agnostic, pure game logic.
  - `engine.ts` — the single pure `reducer` plus collision, gravity, locking,
    line-clearing, scoring, and spawn logic.
  - `tetrominoes.ts` — the 7 piece shapes (4 rotation states each) and the SRS
    wall-kick tables.
  - `bag.ts` — deterministic mulberry32 PRNG + 7-bag randomizer.
  - `constants.ts`, `types.ts`, `storage.ts` (safe localStorage).
- **`src/hooks/useGame.ts`** — wires the reducer to a `requestAnimationFrame`
  loop (time-delta driven), keyboard input (with DAS/ARR auto-repeat),
  tab-blur auto-pause, audio, and persistence.
- **`src/components/`** — `Board` (HiDPI canvas), `PiecePreview`, `SidePanel`,
  `TouchControls`, `Overlay`, `ErrorBoundary`.
- **`src/audio/sound.ts`** — tiny WebAudio synth (no audio asset files; degrades
  silently when unavailable).

The board is a `10×20` 2-D array where `0` is empty and `1..7` identify the
occupying piece color. [FR-ARCH-002][FR-GRID-001]

## A note on level & speed (requirement reconciliation)

Three requirements interact:

- `FR-CFG-001` — the drop interval **equals 500 ms at the starting level**.
- `FR-LEVEL-002` — the gravity interval is `max(50, 500 / (level + 1))`.
- `FR-SCORE-002` — a line clear awards `100/300/500/800 × level`.

For the drop interval to equal 500 ms at the start, `500 / (level + 1) = 500`,
so the **starting level is `0`**. The gravity formula and scoring formula are
both implemented exactly as written, using this same `level` value. (A
consequence is that line clears at level 0 follow the literal `×0` formula; drop
points still accrue, and the level advances after 10 lines per `FR-LEVEL-001`.)
This honors the two unambiguous, formula-bearing requirements literally.

## Requirements coverage

Every implemented behavior is annotated in-source with its requirement id
(e.g. `// [FR-MOVE-001]`). Highlights:

- Lifecycle: clean startup, start/pause/resume/restart, stable rAF loop, tab-blur
  auto-pause with no avalanche. [FR-LIFE-001..008]
- Grid & pieces: 10×20 field, 7 tetrominoes, standard colors, centered spawn.
  [FR-GRID-*][FR-PIECE-*]
- Spawning: 7-bag randomizer, Next preview, Hold (once per piece). [FR-SPAWN-*]
- Movement/rotation: SRS rotation + wall kicks, ghost piece, soft/hard drop,
  bounded lock delay, collision invariant. [FR-MOVE-*][FR-ROT-*][FR-COL-*][FR-LOCK-*][FR-GHOST-*]
- Line clearing 1–4 lines, gap preservation, no false clears. [FR-CLEAR-*]
- Scoring/level: line-clear scale, drop points, monotonic score, level-up every
  10 lines, gravity speed-up, high-score persistence. [FR-SCORE-*][FR-LEVEL-*]
- Game over: block-out, game-over screen, no post-over mutation/spawn. [FR-OVER-*]
- Controls, HUD, responsive layout, audio, accessibility, performance,
  compatibility, and error resilience. [FR-CTRL-*][UI-*][NFR-*][FR-ERR-*]
