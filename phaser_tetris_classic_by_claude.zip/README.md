# Tetris — Phaser

A classic, fully-featured Tetris built **strictly with [Phaser 3](https://phaser.io)**.
Pure static files — no build step and no server-side runtime
(`NFR-COMPAT-004`).

## Run it

Open `index.html` in any modern browser. Because the game loads no external
assets at runtime, it works straight from `file://`. For the most accurate
behavior (and to mirror real hosting), serve it statically, e.g.:

```bash
# from this folder
python -m http.server 8080
# then visit http://localhost:8080
```

Deploy by copying the whole folder to any static HTTPS host.

## Controls

| Action | Keyboard | Touch |
| --- | --- | --- |
| Move left / right | ← / → | ◀ / ▶ |
| Soft drop | ↓ | ▼ |
| Hard drop | Space | HARD DROP |
| Rotate CW | ↑ or X | ⟳ |
| Rotate CCW | Z or Ctrl | ⟲ |
| Hold | C or Shift | Hold |
| Pause / Resume | Esc or P | ❚❚ |
| Restart | R | New Game button |

## Project layout

```
index.html            Markup, accessible HUD/buttons, touch controls
css/style.css         Theming + responsive/adaptive layout
vendor/phaser.min.js  Phaser 3.80.1 (bundled locally)
js/
  constants.js        Dimensions, colors, SRS shapes & kick tables, scoring, timing
  layout.js           Canvas geometry (design resolution)
  bag.js              7-bag randomizer
  storage.js          High-score persistence (graceful degradation)
  audio.js            Web Audio sound effects (graceful fallback)
  engine.js           Pure game logic: board, pieces, collision, clears, scoring
  scenes/MenuScene.js Start screen
  scenes/GameScene.js Phaser rendering, input, HUD, overlays
  main.js             Phaser bootstrap, DOM wiring, lifecycle & error handling
```

The game **logic** (`engine.js`) is intentionally decoupled from Phaser
rendering, which keeps the collision/scoring invariants easy to reason about and
test in isolation.

## Requirement coverage

Every atom in `requirements_doc/requirements.md` is implemented. Highlights and
where they live:

- **Lifecycle** (`FR-LIFE-*`): clean startup, start spawns first piece + gravity,
  stable Phaser game loop, pause/resume identical state, restart reset, tab-blur
  auto-pause — `engine.js`, `GameScene.js`, `main.js`.
- **Grid / pieces** (`FR-GRID-*`, `FR-PIECE-*`, `FR-CFG-*`, `FR-ARCH-*`):
  10×20 field as a 2D array (0 empty, 1..7 colors), seven tetrominoes with
  standard colors and geometry, centered spawn, 500 ms base / 50 ms min drop,
  10 lines per level — `constants.js`, `engine.js`.
- **Spawning** (`FR-SPAWN-*`): 7-bag randomizer, accurate Next preview, Hold
  once per piece — `bag.js`, `engine.js`.
- **Movement / rotation / locking** (`FR-MOVE-*`, `FR-ROT-*`, `FR-COL-*`,
  `FR-LOCK-*`, `FR-GHOST-*`): one-column moves, gravity, soft/hard drop, SRS
  rotation with wall kicks, collision invariant, lock + lock-delay, ghost piece
  — `engine.js`, `GameScene.js`.
- **Line clearing** (`FR-CLEAR-*`): single/double/triple/tetris, non-contiguous
  gaps preserved, no false clears — `engine.js` (`clearLines`).
- **Score / level** (`FR-SCORE-*`, `FR-LEVEL-*`): 100/300/500/800 × level,
  soft/hard drop points, monotonic non-negative score, lines counter,
  `max(50, 500/(level+1))` gravity, localStorage high score — `engine.js`,
  `storage.js`.
- **Game over** (`FR-OVER-*`): block-out stops the loop, game-over screen with
  score + restart, no board mutation or spawning after game over — `engine.js`,
  `GameScene.js`.
- **Controls** (`FR-CTRL-*`, `NFR-CTRL-002`): full keyboard map, DAS/ARR repeat,
  ≥44 px touch controls, suppressed browser gestures, immediate input response —
  `GameScene.js`, `main.js`, `style.css`.
- **HUD / layout / responsiveness** (`UI-*`): live score/level/lines, distinct
  active/ghost/locked visuals, clear/game-over feedback, side panel, adaptive
  no-overflow layout, preserved aspect ratio — `GameScene.js`, `index.html`,
  `style.css`.
- **Audio** (`FR-AUDIO-*`): move/rotate/land/clear/tetris/game-over sounds,
  synthesized via Web Audio with graceful fallback — `audio.js`.
- **Accessibility** (`NFR-A11Y-*`): keyboard-operable buttons with visible focus,
  shape/outline cues beyond color, AA-contrast palette, accessible names + canvas
  aria-label, reduced-motion handling — `index.html`, `style.css`, scenes.
- **Compatibility / performance / resilience** (`NFR-COMPAT-*`, `NFR-PERF-*`,
  `FR-ERR-*`): static hosting, no flagged APIs, delta-capped loop, resize refit,
  localStorage/private-mode + corrupt-data fallbacks, global error surfacing —
  `main.js`, `storage.js`, `engine.js`.
