/*
 * engine.js — Pure Tetris game logic, independent of Phaser rendering.
 *
 * Owns the board, the active piece, scoring, levelling and all the rules.
 * The Phaser scene reads this state and renders it, and forwards input to the
 * action methods below. Keeping logic separate makes the collision/scoring
 * invariants easy to reason about and verify.
 *
 * Covers: FR-GRID-001/002, FR-PIECE-004, FR-SPAWN-001/002/003,
 *         FR-MOVE-001..005, FR-ROT-001/002/003, FR-COL-001,
 *         FR-LOCK-001/002, FR-CLEAR-001..006, FR-SCORE-001..004,
 *         FR-LEVEL-001/002, FR-OVER-001..004, FR-ARCH-002, FR-GHOST-001.
 */
(function (global) {
  'use strict';

  var C = global.TetrisConst;

  function GameEngine() {
    this.reset();
  }

  // Fresh game state (FR-LIFE-007).
  GameEngine.prototype.reset = function () {
    // 2D array field: rows × cols, 0 = empty, 1..7 = piece color id (FR-ARCH-002).
    // We include HIDDEN_ROWS above the visible field as a spawn buffer.
    this.totalRows = C.ROWS + C.HIDDEN_ROWS;
    this.grid = [];
    for (var r = 0; r < this.totalRows; r++) {
      var row = [];
      for (var col = 0; col < C.COLS; col++) row.push(0);
      this.grid.push(row);
    }

    this.bag = new global.SevenBag();
    this.active = null;       // { type, rot, x, y }
    this.holdType = null;     // held piece type (FR-SPAWN-003)
    this.holdUsed = false;    // hold allowed once per piece (FR-SPAWN-003)

    this.score = 0;           // (FR-SCORE-001)
    this.lines = 0;           // total cleared lines
    this.level = 0;           // 0-based; displayed as level (FR-LEVEL-001)
    this.status = 'ready';    // ready | playing | paused | gameover

    // Lock-delay bookkeeping (FR-LOCK-002).
    this.lockTimer = 0;       // ms accumulated while grounded
    this.lockResets = 0;      // number of move/rotate resets used
    this.grounded = false;

    this.dropAccumulator = 0; // ms accumulated toward next gravity step

    // Transient events for the renderer/audio to consume each frame.
    this.events = [];
  };

  GameEngine.prototype.emit = function (name, data) {
    this.events.push({ name: name, data: data || null });
  };
  GameEngine.prototype.drainEvents = function () {
    var e = this.events;
    this.events = [];
    return e;
  };

  // --- Geometry helpers -------------------------------------------------

  // Absolute cells [{x,y}] occupied by a piece in a given state.
  GameEngine.prototype.cellsFor = function (type, rot, x, y) {
    var shape = C.SHAPES[type][((rot % 4) + 4) % 4];
    var out = [];
    for (var i = 0; i < shape.length; i++) {
      out.push({ x: x + shape[i][0], y: y + shape[i][1] });
    }
    return out;
  };

  GameEngine.prototype.activeCells = function () {
    if (!this.active) return [];
    var a = this.active;
    return this.cellsFor(a.type, a.rot, a.x, a.y);
  };

  /*
   * Core collision test (FR-COL-001): a placement is valid only if every cell
   * is within the left/right/bottom bounds and not overlapping a filled cell.
   * Cells above the top (y < 0) are permitted so pieces can spawn/rotate in the
   * buffer, but never below the floor or through walls.
   */
  GameEngine.prototype.collides = function (type, rot, x, y) {
    var cells = this.cellsFor(type, rot, x, y);
    for (var i = 0; i < cells.length; i++) {
      var cx = cells[i].x, cy = cells[i].y;
      if (cx < 0 || cx >= C.COLS) return true;       // left/right walls
      if (cy >= this.totalRows) return true;          // bottom floor
      if (cy >= 0 && this.grid[cy][cx] !== 0) return true; // locked cell
    }
    return false;
  };

  // --- Spawning (FR-PIECE-004, FR-SPAWN-001/002, FR-OVER-001) -----------

  GameEngine.prototype.typeId = function (type) {
    return C.TYPES.indexOf(type) + 1; // 1..7
  };

  GameEngine.prototype.spawn = function (type) {
    type = type || this.bag.next();
    // Horizontal centering: x = floor(COLS/2) - floor(pieceWidth/2) (FR-PIECE-004).
    var boxW = C.PIECE_BOX_WIDTH[type];
    var x = Math.floor(C.COLS / 2) - Math.floor(boxW / 2);
    // Place so the visible cells sit at the very top of the field.
    var y = C.HIDDEN_ROWS - this.topOffset(type);

    this.active = { type: type, rot: 0, x: x, y: y };
    this.holdUsed = false;
    this.grounded = false;
    this.lockTimer = 0;
    this.lockResets = 0;

    // Block-out: if the spawned piece immediately collides -> game over
    // (FR-OVER-001). Try nudging up into the buffer once before declaring it.
    if (this.collides(type, 0, x, y)) {
      this.active.y -= 1;
      if (this.collides(type, 0, this.active.x, this.active.y)) {
        this.active = { type: type, rot: 0, x: x, y: y };
        this.status = 'gameover';
        this.emit('gameover');
        return false;
      }
    }
    this.emit('spawn', { type: type });
    return true;
  };

  // Smallest local y among a piece's spawn-state cells (to seat it at the top).
  GameEngine.prototype.topOffset = function (type) {
    var shape = C.SHAPES[type][0];
    var min = Infinity;
    for (var i = 0; i < shape.length; i++) min = Math.min(min, shape[i][1]);
    return min;
  };

  // --- Start / control --------------------------------------------------

  GameEngine.prototype.start = function () {
    this.reset();
    this.status = 'playing';
    this.spawn();                  // first piece + gravity (FR-LIFE-002)
    this.emit('start');
  };

  GameEngine.prototype.pause = function () {
    if (this.status !== 'playing') return;
    this.status = 'paused';        // (FR-LIFE-004/005)
    this.emit('pause');
  };

  GameEngine.prototype.resume = function () {
    if (this.status !== 'paused') return;
    this.status = 'playing';       // identical state restored (FR-LIFE-006)
    this.emit('resume');
  };

  // --- Movement (FR-MOVE-001/002) ---------------------------------------

  GameEngine.prototype.move = function (dx) {
    if (this.status !== 'playing' || !this.active) return false;
    var a = this.active;
    if (!this.collides(a.type, a.rot, a.x + dx, a.y)) {
      a.x += dx;
      this.onPieceMoved();
      this.emit('move');
      return true;                 // moved exactly one column (FR-MOVE-001)
    }
    return false;                  // blocked -> unchanged (FR-MOVE-002)
  };

  // Step down one cell. Returns true if it descended (FR-MOVE-003).
  GameEngine.prototype.stepDown = function (isSoft) {
    if (this.status !== 'playing' || !this.active) return false;
    var a = this.active;
    if (!this.collides(a.type, a.rot, a.x, a.y + 1)) {
      a.y += 1;
      this.grounded = false;
      this.lockTimer = 0;
      if (isSoft) { this.score += C.SOFT_DROP_POINTS; this.emit('score'); } // FR-SCORE-004
      return true;
    }
    // Cannot move down -> become grounded; lock delay handles the rest.
    this.grounded = true;
    return false;
  };

  // Soft drop: one accelerated step (FR-MOVE-004).
  GameEngine.prototype.softDrop = function () {
    return this.stepDown(true);
  };

  // Hard drop: fall to landing, award 2/cell, lock instantly (FR-MOVE-005, FR-SCORE-004).
  GameEngine.prototype.hardDrop = function () {
    if (this.status !== 'playing' || !this.active) return;
    var a = this.active;
    var dist = 0;
    while (!this.collides(a.type, a.rot, a.x, a.y + 1)) { a.y += 1; dist++; }
    if (dist > 0) { this.score += dist * C.HARD_DROP_POINTS; this.emit('score'); }
    this.lockPiece();
  };

  // --- Rotation with SRS kicks (FR-ROT-001/002/003) ---------------------

  GameEngine.prototype.rotate = function (dir) {
    if (this.status !== 'playing' || !this.active) return false;
    var a = this.active;
    var from = a.rot;
    var to = ((from + dir) % 4 + 4) % 4;
    var table = C.kickTable(a.type);
    var key = '' + from + to;
    var kicks = table[key] || [[0, 0]];
    for (var i = 0; i < kicks.length; i++) {
      var nx = a.x + kicks[i][0];
      var ny = a.y + kicks[i][1];
      if (!this.collides(a.type, to, nx, ny)) {
        a.rot = to; a.x = nx; a.y = ny;   // first valid kick wins (FR-ROT-002)
        this.onPieceMoved();
        this.emit('rotate');
        return true;
      }
    }
    return false;                          // no valid kick -> rejected (FR-ROT-003)
  };

  // Hold swap, at most once per piece (FR-SPAWN-003).
  GameEngine.prototype.hold = function () {
    if (this.status !== 'playing' || !this.active || this.holdUsed) return false;
    var cur = this.active.type;
    if (this.holdType === null) {
      this.holdType = cur;
      this.spawn();
    } else {
      var swap = this.holdType;
      this.holdType = cur;
      this.spawn(swap);
    }
    this.holdUsed = true;
    this.emit('hold');
    return true;
  };

  // Movement/rotation while grounded refreshes the lock delay, but only up to
  // a bounded number of resets to prevent indefinite stalling (FR-LOCK-002).
  GameEngine.prototype.onPieceMoved = function () {
    var a = this.active;
    var nowGrounded = this.collides(a.type, a.rot, a.x, a.y + 1);
    if (nowGrounded && this.grounded && this.lockResets < C.LOCK_RESET_LIMIT) {
      this.lockTimer = 0;
      this.lockResets++;
    }
    this.grounded = nowGrounded;
  };

  // --- Locking & line clears (FR-LOCK-001, FR-CLEAR-001..006) -----------

  GameEngine.prototype.lockPiece = function () {
    var a = this.active;
    var id = this.typeId(a.type);
    var cells = this.activeCells();
    for (var i = 0; i < cells.length; i++) {
      var c = cells[i];
      if (c.y >= 0 && c.y < this.totalRows) this.grid[c.y][c.x] = id;
    }
    this.emit('lock');

    var cleared = this.clearLines();
    if (cleared > 0) {
      this.applyClearScore(cleared);
    }
    this.active = null;

    // Spawn next piece (FR-LOCK-001). Spawn may declare game over (FR-OVER-001).
    if (this.status === 'playing') {
      this.spawn();
    }
  };

  /*
   * Remove every fully-filled row and shift everything above down (FR-CLEAR-*).
   * Rebuilding the grid top-down naturally preserves gaps in partial rows and
   * handles non-contiguous clears (FR-CLEAR-005). Rows with any empty cell are
   * never removed (FR-CLEAR-006).
   */
  GameEngine.prototype.clearLines = function () {
    var kept = [];
    var clearedRows = [];
    for (var r = 0; r < this.totalRows; r++) {
      var full = true;
      for (var col = 0; col < C.COLS; col++) {
        if (this.grid[r][col] === 0) { full = false; break; }
      }
      if (full) clearedRows.push(r);
      else kept.push(this.grid[r]);
    }
    var cleared = clearedRows.length;
    if (cleared === 0) return 0;

    // Prepend empty rows to restore height.
    while (kept.length < this.totalRows) {
      var empty = [];
      for (var k = 0; k < C.COLS; k++) empty.push(0);
      kept.unshift(empty);
    }
    this.grid = kept;
    this.emit('clear', { count: cleared, rows: clearedRows });
    return cleared;
  };

  // --- Scoring & levelling (FR-SCORE-002/003, FR-LEVEL-001) -------------

  GameEngine.prototype.applyClearScore = function (cleared) {
    var gained = (C.LINE_SCORE[cleared] || 0) * (this.level + 1); // ×level (FR-SCORE-002)
    this.score += gained;
    this.lines += cleared;                                        // exact count (FR-SCORE-003)

    var newLevel = Math.floor(this.lines / C.LINES_PER_LEVEL);    // every 10 lines (FR-LEVEL-001)
    if (newLevel > this.level) {
      this.level = newLevel;
      this.emit('levelup', { level: this.level });
    }
    this.emit('score');
  };

  // Current gravity interval (FR-LEVEL-002).
  GameEngine.prototype.dropInterval = function () {
    return C.dropIntervalForLevel(this.level);
  };

  // --- Ghost piece (FR-GHOST-001) ---------------------------------------

  GameEngine.prototype.ghostY = function () {
    if (!this.active) return null;
    var a = this.active;
    var y = a.y;
    while (!this.collides(a.type, a.rot, a.x, y + 1)) y++;
    return y;
  };

  // --- Per-frame update (FR-LIFE-003, FR-MOVE-003, FR-LOCK-002) ---------
  // delta = ms since last update. softHeld accelerates gravity (FR-MOVE-004).
  GameEngine.prototype.update = function (delta, softHeld) {
    if (this.status !== 'playing' || !this.active) return;

    // Guard against huge deltas (tab refocus) so we never avalanche gravity
    // ticks (FR-LIFE-008). Cap the simulated time to one interval.
    var interval = this.dropInterval();
    if (softHeld) interval = Math.max(C.MIN_DROP_MS / 2,
      Math.floor(interval / C.SOFT_DROP_FACTOR));
    var dt = Math.min(delta, Math.max(interval, 100));

    this.dropAccumulator += dt;
    var steps = 0;
    while (this.dropAccumulator >= interval && steps < 4) {
      this.dropAccumulator -= interval;
      this.stepDown(softHeld);
      steps++;
    }

    // Lock delay: once grounded, count up and lock when the delay elapses,
    // or immediately if reset budget is spent (FR-LOCK-002).
    if (this.grounded && this.active) {
      this.lockTimer += dt;
      if (this.lockTimer >= C.LOCK_DELAY_MS ||
          this.lockResets >= C.LOCK_RESET_LIMIT &&
          this.collides(this.active.type, this.active.rot,
                        this.active.x, this.active.y + 1)) {
        // Re-verify still grounded (a late move may have freed it).
        if (this.collides(this.active.type, this.active.rot,
                          this.active.x, this.active.y + 1)) {
          this.lockPiece();
        } else {
          this.grounded = false;
          this.lockTimer = 0;
        }
      }
    }
  };

  global.GameEngine = GameEngine;
})(window);
