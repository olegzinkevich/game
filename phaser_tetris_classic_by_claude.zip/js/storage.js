/*
 * storage.js — High-score persistence via localStorage (FR-SCORE-005).
 * Degrades gracefully when storage is unavailable / private mode / quota
 * exceeded (FR-ERR-005) and validates corrupt data, falling back to 0
 * (FR-ERR-006).
 */
(function (global) {
  'use strict';

  var KEY = global.TetrisConst.STORAGE_KEY;

  function available() {
    try {
      var t = '__tetris_probe__';
      global.localStorage.setItem(t, '1');
      global.localStorage.removeItem(t);
      return true;
    } catch (e) {
      return false; // private mode, disabled, or quota (FR-ERR-005)
    }
  }

  var ok = available();

  function loadHighScore() {
    if (!ok) return 0;
    try {
      var raw = global.localStorage.getItem(KEY);
      if (raw === null) return 0;
      var n = parseInt(raw, 10);
      // Validate: finite, non-negative integer (FR-ERR-006).
      if (!isFinite(n) || isNaN(n) || n < 0) return 0;
      return n;
    } catch (e) {
      return 0;
    }
  }

  function saveHighScore(score) {
    if (!ok) return false; // stays playable without persistence (FR-ERR-005)
    try {
      global.localStorage.setItem(KEY, String(Math.max(0, Math.floor(score))));
      return true;
    } catch (e) {
      return false;
    }
  }

  global.TetrisStorage = {
    available: ok,
    loadHighScore: loadHighScore,
    saveHighScore: saveHighScore
  };
})(window);
