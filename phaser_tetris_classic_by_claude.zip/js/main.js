/*
 * main.js — Bootstraps the Phaser game and wires the surrounding DOM:
 * accessible buttons, touch controls, the screen-reader HUD mirror, global
 * error handling and tab-focus lifecycle.
 *
 * Covers: FR-ARCH-001 (timer-driven loop = Phaser game loop), FR-CTRL-004/005,
 *   FR-LIFE-008, FR-ERR-004/008, UI-HUD-001, UI-LAYOUT-001, NFR-A11Y-004,
 *   NFR-COMPAT-004 (static, no server runtime).
 */
(function (global) {
  'use strict';

  // Shared event bus: DOM controls -> active Phaser scene.
  global.TetrisBus = new global.Phaser.Events.EventEmitter();

  // ------------------------------------------------------ DOM HUD mirror
  function $(id) { return global.document.getElementById(id); }

  global.TetrisUI = {
    status: 'menu',
    update: function (score, level, lines, high) {
      var s = $('hud-score'), l = $('hud-level'),
          n = $('hud-lines'), h = $('hud-high');
      if (s) s.textContent = score;
      if (l) l.textContent = level;
      if (n) n.textContent = lines;
      if (h) h.textContent = high;
      var live = $('sr-live');
      if (live) live.textContent =
        'Score ' + score + ', level ' + level + ', lines ' + lines;
    },
    setStatus: function (st) {
      this.status = st;
      var ind = $('status-indicator');
      var pauseBtn = $('btn-pause');
      var newBtn = $('btn-newgame');
      if (ind) {
        ind.classList.remove('is-over', 'is-paused', 'is-playing');
        if (st === 'gameover') { ind.textContent = 'Game Over'; ind.classList.add('is-over'); }
        else if (st === 'paused') { ind.textContent = 'Paused'; ind.classList.add('is-paused'); }
        else if (st === 'playing') { ind.textContent = 'Playing'; ind.classList.add('is-playing'); }
        else { ind.textContent = 'Ready'; }
      }
      if (pauseBtn) {
        pauseBtn.textContent = (st === 'paused') ? 'Resume' : 'Pause';
        pauseBtn.disabled = (st === 'menu' || st === 'gameover');
      }
      if (newBtn) newBtn.textContent = (st === 'menu') ? 'Start' : 'New Game';
    },
    showGameOver: function (score) {
      var live = $('sr-live');
      if (live) live.textContent = 'Game over. Final score ' + score +
        '. Press R or New Game to restart.';
    }
  };

  // ----------------------------------------------------------- Phaser game
  var L = global.TetrisLayout;
  var config = {
    type: global.Phaser.AUTO,
    parent: 'game-container',
    width: L.WIDTH,
    height: L.HEIGHT,
    backgroundColor: '#0c1322',
    powerPreference: 'high-performance',
    scale: {
      mode: global.Phaser.Scale.FIT,            // adaptive, aspect-preserving (UI-RESP-001/002)
      autoCenter: global.Phaser.Scale.CENTER_BOTH
    },
    render: { antialias: true, roundPixels: true, pixelArt: false },
    scene: [global.MenuScene, global.GameScene]
  };

  var game = new global.Phaser.Game(config);
  global.TetrisGame = game;

  // Give the canvas a meaningful accessible name/role (NFR-A11Y-004).
  game.events.once('ready', function () {
    if (game.canvas) {
      game.canvas.setAttribute('role', 'img');
      game.canvas.setAttribute('aria-label',
        'Tetris playfield, 10 columns by 20 rows. Use the listed keyboard or ' +
        'on-screen controls to play.');
      game.canvas.setAttribute('tabindex', '0');
    }
  });

  function gameScene() { return game.scene.getScene('GameScene'); }

  // ------------------------------------------------------- DOM controls
  function emit(type, action) { global.TetrisBus.emit('input', { type: type, action: action }); }

  global.document.addEventListener('DOMContentLoaded', function () {
    // Primary buttons.
    var newBtn = $('btn-newgame');
    if (newBtn) newBtn.addEventListener('click', function () {
      global.TetrisAudio.unlock();
      if (global.TetrisUI.status === 'menu') emit('tap', 'start');
      else emit('tap', 'restart');
    });

    var pauseBtn = $('btn-pause');
    if (pauseBtn) pauseBtn.addEventListener('click', function () {
      emit('tap', 'pause');
    });

    var soundBtn = $('btn-sound');
    if (soundBtn) soundBtn.addEventListener('click', function () {
      var on = !global.TetrisAudio.enabled;
      global.TetrisAudio.setEnabled(on);
      soundBtn.textContent = on ? 'Sound: On' : 'Sound: Off';
      soundBtn.setAttribute('aria-pressed', String(on));
    });

    // Touch / on-screen controls (FR-CTRL-004). Each has data-action and
    // data-mode ('hold' for continuous, 'tap' for one-shot).
    var controls = global.document.querySelectorAll('[data-action]');
    Array.prototype.forEach.call(controls, function (el) {
      var action = el.getAttribute('data-action');
      var mode = el.getAttribute('data-mode') || 'tap';

      var down = function (ev) {
        ev.preventDefault();                // suppress zoom/scroll (FR-CTRL-005)
        global.TetrisAudio.unlock();
        if (action === 'start') { emit('tap', 'start'); return; }
        if (mode === 'hold') emit('press', action);
        else emit('tap', action);
      };
      var up = function (ev) {
        ev.preventDefault();
        if (mode === 'hold') emit('release', action);
      };

      el.addEventListener('pointerdown', down);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointerleave', up);
      el.addEventListener('pointercancel', up);
    });
  });

  // ------------------------------------------- lifecycle: tab/window focus
  // Auto-pause when backgrounded; Phaser already halts rAF, and the engine
  // caps delta, so there is no runaway loop or avalanche on return (FR-LIFE-008).
  global.document.addEventListener('visibilitychange', function () {
    if (global.document.hidden) {
      var gs = gameScene();
      if (gs && gs.scene.isActive()) gs.autoPause();
    }
  });
  global.addEventListener('blur', function () {
    var gs = gameScene();
    if (gs && gs.scene.isActive()) gs.autoPause();
  });

  // Suppress arrow/space page scroll during play (FR-CTRL-005), but never on
  // form controls/buttons so Enter/Space still activate them (NFR-A11Y-001).
  global.addEventListener('keydown', function (e) {
    var keys = [32, 37, 38, 39, 40]; // space + arrows
    if (keys.indexOf(e.keyCode) === -1) return;
    var t = e.target;
    var tag = t && t.tagName ? t.tagName.toUpperCase() : '';
    var interactive = (tag === 'BUTTON' || tag === 'INPUT' ||
      tag === 'TEXTAREA' || tag === 'SELECT' || tag === 'A');
    if (!interactive) e.preventDefault();
  }, false);

  // ----------------------------------------- global error handling (FR-ERR-008)
  var errorShown = false;
  function surfaceError(msg) {
    if (errorShown) return;              // avoid infinite error loop
    errorShown = true;
    var banner = $('error-banner');
    if (banner) {
      banner.textContent = 'An unexpected error occurred, but the game keeps ' +
        'running. Press New Game to restart if needed.';
      banner.style.display = 'block';
    }
    try { console.error('[Tetris] handled:', msg); } catch (e) {}
  }
  global.addEventListener('error', function (e) {
    surfaceError(e && e.message); /* no white screen, no rethrow */
  });
  global.addEventListener('unhandledrejection', function (e) {
    surfaceError(e && e.reason);
  });
})(window);
