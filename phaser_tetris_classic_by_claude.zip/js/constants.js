/*
 * constants.js — Static configuration for the Tetris game.
 * Covers: FR-GRID-001, FR-PIECE-001/002/003, FR-CFG-001/002/003,
 *         FR-ARCH-002, FR-LEVEL-002, FR-LOCK-002.
 */
(function (global) {
  'use strict';

  // --- Playfield dimensions (FR-GRID-001) -------------------------------
  var COLS = 10;          // 10 cells wide
  var ROWS = 20;          // 20 cells high (visible field, FR-GRID-003)
  var HIDDEN_ROWS = 2;    // spawn buffer above the visible field

  // --- Timing (FR-CFG-001/002, FR-LEVEL-002, FR-LOCK-002) ---------------
  var BASE_DROP_MS = 500; // base drop interval at starting level (FR-CFG-001)
  var MIN_DROP_MS = 50;   // never below 50 ms (FR-CFG-002)
  var LOCK_DELAY_MS = 500;// bounded lock delay (FR-LOCK-002)
  var LOCK_RESET_LIMIT = 15; // max move/rotate lock-delay resets (anti-stall)
  var LINES_PER_LEVEL = 10;  // 10 lines per level (FR-CFG-003 / FR-LEVEL-001)
  var SOFT_DROP_FACTOR = 20; // soft drop is this many× faster than gravity

  /**
   * Gravity interval for a given level (FR-LEVEL-002):
   *   max(50, 500 / (level + 1)) ms
   * Level is 0-based internally (starting level = 0 -> 500 ms, FR-CFG-001).
   */
  function dropIntervalForLevel(level) {
    return Math.max(MIN_DROP_MS, Math.floor(BASE_DROP_MS / (level + 1)));
  }

  // --- Piece type ids (FR-ARCH-002: 1..7 identify color) ----------------
  // 0 = empty. Order fixes the numeric id used in the board array.
  var TYPES = ['I', 'O', 'T', 'S', 'Z', 'L', 'J'];

  // --- Standard colors (FR-PIECE-002) -----------------------------------
  // I cyan, O yellow, T purple, S green, Z red, L orange, J blue.
  var COLORS = {
    I: 0x36c5f0, // cyan
    O: 0xf2c037, // yellow
    T: 0xa259e6, // purple
    S: 0x44cc55, // green
    Z: 0xff4d4d, // red
    L: 0xff9f43, // orange
    J: 0x3d7eff, // blue
    GHOST: 0xffffff,
    GRID: 0x223047,
    BG: 0x0c1322,
    BORDER: 0x3a4d6b
  };

  // Numeric id (1..7) -> color, for rendering locked cells from the board.
  var ID_TO_COLOR = {};
  TYPES.forEach(function (t, i) { ID_TO_COLOR[i + 1] = COLORS[t]; });

  /*
   * Tetromino definitions (FR-PIECE-001/003).
   * Each piece is defined by its rotation states as lists of [x,y] cells in a
   * local bounding box, matching the Super Rotation System (SRS) spawn states.
   * State 0 = spawn orientation (FR-PIECE-004). States ordered 0->R->2->L
   * (clockwise). Each state has exactly four cells (FR-PIECE-003).
   */
  var SHAPES = {
    I: [
      [[0, 1], [1, 1], [2, 1], [3, 1]],
      [[2, 0], [2, 1], [2, 2], [2, 3]],
      [[0, 2], [1, 2], [2, 2], [3, 2]],
      [[1, 0], [1, 1], [1, 2], [1, 3]]
    ],
    O: [
      [[1, 0], [2, 0], [1, 1], [2, 1]],
      [[1, 0], [2, 0], [1, 1], [2, 1]],
      [[1, 0], [2, 0], [1, 1], [2, 1]],
      [[1, 0], [2, 0], [1, 1], [2, 1]]
    ],
    T: [
      [[1, 0], [0, 1], [1, 1], [2, 1]],
      [[1, 0], [1, 1], [2, 1], [1, 2]],
      [[0, 1], [1, 1], [2, 1], [1, 2]],
      [[1, 0], [0, 1], [1, 1], [1, 2]]
    ],
    S: [
      [[1, 0], [2, 0], [0, 1], [1, 1]],
      [[1, 0], [1, 1], [2, 1], [2, 2]],
      [[1, 1], [2, 1], [0, 2], [1, 2]],
      [[0, 0], [0, 1], [1, 1], [1, 2]]
    ],
    Z: [
      [[0, 0], [1, 0], [1, 1], [2, 1]],
      [[2, 0], [1, 1], [2, 1], [1, 2]],
      [[0, 1], [1, 1], [1, 2], [2, 2]],
      [[1, 0], [0, 1], [1, 1], [0, 2]]
    ],
    L: [
      [[2, 0], [0, 1], [1, 1], [2, 1]],
      [[1, 0], [1, 1], [1, 2], [2, 2]],
      [[0, 1], [1, 1], [2, 1], [0, 2]],
      [[0, 0], [1, 0], [1, 1], [1, 2]]
    ],
    J: [
      [[0, 0], [0, 1], [1, 1], [2, 1]],
      [[1, 0], [2, 0], [1, 1], [1, 2]],
      [[0, 1], [1, 1], [2, 1], [2, 2]],
      [[1, 0], [1, 1], [0, 2], [1, 2]]
    ]
  };

  // Bounding-box width per piece, for the spawn centering formula (FR-PIECE-004).
  // x = floor(COLS/2) - floor(pieceWidth/2)
  var PIECE_BOX_WIDTH = { I: 4, O: 4, T: 3, S: 3, Z: 3, L: 3, J: 3 };

  /*
   * SRS wall-kick tables (FR-ROT-002).
   * Keyed by "<from><to>" rotation indices. Values are candidate [dx, dy]
   * offsets tried in order; first non-colliding one wins (FR-ROT-003).
   * Note: y is positive downward, so SRS "up" offsets are negated here.
   */
  var KICKS_JLSTZ = {
    '01': [[0, 0], [-1, 0], [-1, -1], [0, 2], [-1, 2]],
    '10': [[0, 0], [1, 0], [1, 1], [0, -2], [1, -2]],
    '12': [[0, 0], [1, 0], [1, 1], [0, -2], [1, -2]],
    '21': [[0, 0], [-1, 0], [-1, -1], [0, 2], [-1, 2]],
    '23': [[0, 0], [1, 0], [1, -1], [0, 2], [1, 2]],
    '32': [[0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]],
    '30': [[0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]],
    '03': [[0, 0], [1, 0], [1, -1], [0, 2], [1, 2]]
  };
  var KICKS_I = {
    '01': [[0, 0], [-2, 0], [1, 0], [-2, 1], [1, -2]],
    '10': [[0, 0], [2, 0], [-1, 0], [2, -1], [-1, 2]],
    '12': [[0, 0], [-1, 0], [2, 0], [-1, -2], [2, 1]],
    '21': [[0, 0], [1, 0], [-2, 0], [1, 2], [-2, -1]],
    '23': [[0, 0], [2, 0], [-1, 0], [2, -1], [-1, 2]],
    '32': [[0, 0], [-2, 0], [1, 0], [-2, 1], [1, -2]],
    '30': [[0, 0], [1, 0], [-2, 0], [1, 2], [-2, -1]],
    '03': [[0, 0], [-1, 0], [2, 0], [-1, -2], [2, 1]]
  };
  // O piece never needs kicks (symmetric).
  var KICKS_O = {
    '01': [[0, 0]], '10': [[0, 0]], '12': [[0, 0]], '21': [[0, 0]],
    '23': [[0, 0]], '32': [[0, 0]], '30': [[0, 0]], '03': [[0, 0]]
  };

  function kickTable(type) {
    if (type === 'I') return KICKS_I;
    if (type === 'O') return KICKS_O;
    return KICKS_JLSTZ;
  }

  // --- Scoring (FR-SCORE-002/004) ---------------------------------------
  var LINE_SCORE = { 1: 100, 2: 300, 3: 500, 4: 800 };
  var SOFT_DROP_POINTS = 1; // per cell (FR-SCORE-004)
  var HARD_DROP_POINTS = 2; // per cell (FR-SCORE-004)

  var STORAGE_KEY = 'tetris.phaser.highscore.v1';

  global.TetrisConst = {
    COLS: COLS,
    ROWS: ROWS,
    HIDDEN_ROWS: HIDDEN_ROWS,
    BASE_DROP_MS: BASE_DROP_MS,
    MIN_DROP_MS: MIN_DROP_MS,
    LOCK_DELAY_MS: LOCK_DELAY_MS,
    LOCK_RESET_LIMIT: LOCK_RESET_LIMIT,
    LINES_PER_LEVEL: LINES_PER_LEVEL,
    SOFT_DROP_FACTOR: SOFT_DROP_FACTOR,
    dropIntervalForLevel: dropIntervalForLevel,
    TYPES: TYPES,
    COLORS: COLORS,
    ID_TO_COLOR: ID_TO_COLOR,
    SHAPES: SHAPES,
    PIECE_BOX_WIDTH: PIECE_BOX_WIDTH,
    kickTable: kickTable,
    LINE_SCORE: LINE_SCORE,
    SOFT_DROP_POINTS: SOFT_DROP_POINTS,
    HARD_DROP_POINTS: HARD_DROP_POINTS,
    STORAGE_KEY: STORAGE_KEY
  };
})(window);
