/*
 * audio.js — Lightweight synthesized sound effects via the Web Audio API.
 * Covers FR-AUDIO-001..005. No external assets (keeps the bundle tiny,
 * NFR-PERF-003) and degrades gracefully when Web Audio is unavailable or the
 * user has it disabled (NFR-COMPAT-003).
 */
(function (global) {
  'use strict';

  function SoundFx() {
    this.ctx = null;
    this.enabled = true;
    this.supported = !!(global.AudioContext || global.webkitAudioContext);
    // Respect users who prefer reduced motion by NOT muting (audio is fine),
    // but we honor an explicit mute toggle.
  }

  SoundFx.prototype.ensure = function () {
    if (!this.supported || !this.enabled) return false;
    try {
      if (!this.ctx) {
        var Ctor = global.AudioContext || global.webkitAudioContext;
        this.ctx = new Ctor();
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return true;
    } catch (e) {
      this.supported = false;
      return false;
    }
  };

  // Must be called after a user gesture to unlock audio on mobile browsers.
  SoundFx.prototype.unlock = function () { this.ensure(); };

  SoundFx.prototype.setEnabled = function (on) {
    this.enabled = on;
    if (on) this.ensure();
  };

  // Play a simple tone. Wrapped in try/catch so audio never breaks gameplay.
  SoundFx.prototype.tone = function (freq, dur, type, vol) {
    if (!this.ensure()) return;
    try {
      var ctx = this.ctx;
      var t0 = ctx.currentTime;
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = type || 'square';
      osc.frequency.setValueAtTime(freq, t0);
      vol = (vol == null ? 0.08 : vol);
      gain.gain.setValueAtTime(0.0001, t0);
      gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t0);
      osc.stop(t0 + dur + 0.02);
    } catch (e) { /* ignore — audio is non-essential */ }
  };

  SoundFx.prototype.arpeggio = function (freqs, step, type, vol) {
    if (!this.ensure()) return;
    var self = this;
    freqs.forEach(function (f, i) {
      var ctx = self.ctx;
      try {
        var t0 = ctx.currentTime + i * step;
        var osc = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = type || 'triangle';
        osc.frequency.setValueAtTime(f, t0);
        gain.gain.setValueAtTime(0.0001, t0);
        gain.gain.exponentialRampToValueAtTime(vol || 0.09, t0 + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, t0 + step + 0.05);
        osc.connect(gain).connect(ctx.destination);
        osc.start(t0);
        osc.stop(t0 + step + 0.06);
      } catch (e) { /* ignore */ }
    });
  };

  // --- Game event sounds -------------------------------------------------
  SoundFx.prototype.move = function () { this.tone(220, 0.04, 'square', 0.04); };      // FR-AUDIO-001
  SoundFx.prototype.rotate = function () { this.tone(330, 0.05, 'square', 0.05); };    // FR-AUDIO-001
  SoundFx.prototype.land = function () { this.tone(140, 0.09, 'sine', 0.07); };        // FR-AUDIO-002
  SoundFx.prototype.clear = function () { this.arpeggio([523, 659, 784], 0.06, 'triangle', 0.08); }; // FR-AUDIO-003
  SoundFx.prototype.tetris = function () { // brighter than a normal clear (FR-AUDIO-004)
    this.arpeggio([659, 880, 1047, 1319], 0.07, 'triangle', 0.1);
  };
  SoundFx.prototype.gameover = function () { // low signal (FR-AUDIO-005)
    this.arpeggio([330, 247, 165, 110], 0.14, 'sawtooth', 0.09);
  };

  global.TetrisAudio = new SoundFx();
})(window);
