/*
 * MenuScene.js — Start screen (FR-LIFE-002 trigger point, NFR-LOAD-001).
 * Rendered with Phaser. Keyboard/DOM "Start" both transition to the game.
 */
(function (global) {
  'use strict';

  var Layout = global.TetrisLayout;

  function MenuScene() {
    global.Phaser.Scene.call(this, { key: 'MenuScene' });
  }
  MenuScene.prototype = Object.create(global.Phaser.Scene.prototype);
  MenuScene.prototype.constructor = MenuScene;

  MenuScene.prototype.create = function () {
    var W = Layout.WIDTH, H = Layout.HEIGHT;
    var C = global.TetrisConst.COLORS;

    this.cameras.main.setBackgroundColor(C.BG);

    // Decorative grid backdrop.
    var g = this.add.graphics();
    g.lineStyle(1, C.GRID, 0.5);
    for (var x = 0; x <= W; x += 30) { g.lineBetween(x, 0, x, H); }
    for (var y = 0; y <= H; y += 30) { g.lineBetween(0, y, W, y); }

    this.add.text(W / 2, H * 0.26, 'TETRIS', {
      fontFamily: 'Segoe UI, Arial, sans-serif',
      fontSize: '72px', color: '#ffffff', fontStyle: 'bold'
    }).setOrigin(0.5);

    this.add.text(W / 2, H * 0.40, 'Classic — built with Phaser', {
      fontFamily: 'Segoe UI, Arial, sans-serif',
      fontSize: '20px', color: '#9fb3d1'
    }).setOrigin(0.5);

    var help = [
      '← →  Move      ↓  Soft drop',
      'Up / X  Rotate CW      Z / Ctrl  Rotate CCW',
      'Space  Hard drop      C / Shift  Hold',
      'Esc / P  Pause      R  Restart'
    ].join('\n');
    this.add.text(W / 2, H * 0.56, help, {
      fontFamily: 'Consolas, monospace',
      fontSize: '16px', color: '#c7d4e8', align: 'center', lineSpacing: 8
    }).setOrigin(0.5);

    var prompt = this.add.text(W / 2, H * 0.80, 'Press Enter or tap Start', {
      fontFamily: 'Segoe UI, Arial, sans-serif',
      fontSize: '22px', color: '#ffd34d', fontStyle: 'bold'
    }).setOrigin(0.5);

    // Blink prompt unless reduced motion is requested (NFR-A11Y-005).
    if (!Layout.reducedMotion()) {
      this.tweens.add({ targets: prompt, alpha: 0.2, duration: 700,
        yoyo: true, repeat: -1 });
    }

    var self = this;
    this.startGame = function () {
      global.TetrisAudio.unlock();
      self.scene.start('GameScene');
    };

    // Keyboard: Enter or Space starts (NFR-A11Y-001 operable via Enter/Space).
    this.input.keyboard.on('keydown-ENTER', this.startGame);
    this.input.keyboard.on('keydown-SPACE', this.startGame);
    this.input.on('pointerdown', this.startGame);

    // DOM bus (Start button / touch).
    this.busHandler = function (msg) {
      if (msg && msg.action === 'start') self.startGame();
    };
    global.TetrisBus.on('input', this.busHandler);

    this.events.once('shutdown', function () {
      global.TetrisBus.off('input', self.busHandler);
    });

    if (global.TetrisUI) global.TetrisUI.setStatus('menu');
  };

  global.MenuScene = MenuScene;
})(window);
