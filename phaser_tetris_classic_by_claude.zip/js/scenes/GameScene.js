/*
 * GameScene.js — Main gameplay scene. Wires the pure GameEngine to Phaser
 * rendering, input, HUD, audio and overlays.
 *
 * Covers (rendering/UI side of): FR-LIFE-002..008, FR-GRID-003,
 *   FR-MOVE-*, FR-ROT-*, FR-CTRL-001/003/005, FR-GHOST-001, UI-HUD-001/002/003,
 *   UI-LAYOUT-001, FR-OVER-002, plus audio FR-AUDIO-*.
 */
(function (global) {
  'use strict';

  var Phaser = global.Phaser;
  var L = global.TetrisLayout;
  var K = global.TetrisConst;

  var DAS_DELAY = 150; // ms before auto-repeat begins (FR-CTRL-003)
  var ARR = 40;        // ms between auto-repeat moves

  function GameScene() {
    Phaser.Scene.call(this, { key: 'GameScene' });
  }
  GameScene.prototype = Object.create(Phaser.Scene.prototype);
  GameScene.prototype.constructor = GameScene;

  // ---------------------------------------------------------------- create
  GameScene.prototype.create = function () {
    var self = this;
    this.cameras.main.setBackgroundColor(K.COLORS.BG);

    this.engine = new global.GameEngine();
    this.highScore = global.TetrisStorage.loadHighScore();

    this.held = { left: false, right: false, soft: false };
    this.das = { dir: 0, timer: 0, charged: false };
    this.lastHud = {};

    this.buildStaticUi();
    this.boardGfx = this.add.graphics();          // grid + locked + ghost + active
    this.flashGfx = this.add.graphics();          // line-clear flash
    this.previewGfx = this.add.graphics();        // next + hold

    this.buildOverlays();
    this.bindKeyboard();
    this.bindBus();

    // Start a fresh game immediately (FR-LIFE-002).
    this.engine.start();
    this.syncHud(true);
    this.renderBoard();
    this.renderPreviews();
    this.setOverlay(null);
    if (global.TetrisUI) global.TetrisUI.setStatus('playing');

    this.events.once('shutdown', function () { self.teardown(); });
  };

  // ------------------------------------------------------------ static UI
  GameScene.prototype.buildStaticUi = function () {
    var C = K.COLORS;
    var g = this.add.graphics();

    // Playfield frame.
    g.fillStyle(0x070d18, 1).fillRect(L.BOARD_X - 3, L.BOARD_Y - 3,
      L.BOARD_W + 6, L.BOARD_H + 6);
    g.lineStyle(2, C.BORDER, 1).strokeRect(L.BOARD_X - 3, L.BOARD_Y - 3,
      L.BOARD_W + 6, L.BOARD_H + 6);

    var px = L.PANEL_X, pw = L.PANEL_W;
    var tStyle = function (size, color, bold) {
      return {
        fontFamily: 'Segoe UI, Arial, sans-serif',
        fontSize: size + 'px', color: color,
        fontStyle: bold ? 'bold' : 'normal'
      };
    };

    // SCORE / LEVEL / LINES / HIGH (UI-HUD-001, UI-LAYOUT-001).
    var y = L.BOARD_Y;
    this.add.text(px, y, 'SCORE', tStyle(14, '#7e92b0', true));
    this.scoreText = this.add.text(px, y + 18, '0', tStyle(28, '#ffffff', true));
    y += 60;
    this.add.text(px, y, 'HIGH', tStyle(14, '#7e92b0', true));
    this.highText = this.add.text(px, y + 18, '0', tStyle(20, '#ffd34d', true));
    y += 54;

    var half = pw / 2;
    this.add.text(px, y, 'LEVEL', tStyle(14, '#7e92b0', true));
    this.levelText = this.add.text(px, y + 18, '1', tStyle(24, '#ffffff', true));
    this.add.text(px + half, y, 'LINES', tStyle(14, '#7e92b0', true));
    this.linesText = this.add.text(px + half, y + 18, '0', tStyle(24, '#ffffff', true));
    y += 60;

    // NEXT + HOLD preview boxes.
    this.add.text(px, y, 'NEXT', tStyle(14, '#7e92b0', true));
    this.nextBox = { x: px, y: y + 20, w: pw, h: 84 };
    y += 20 + 84 + 16;
    this.add.text(px, y, 'HOLD', tStyle(14, '#7e92b0', true));
    this.holdBox = { x: px, y: y + 20, w: pw, h: 84 };

    var bg = this.add.graphics();
    bg.fillStyle(0x0a1322, 1).lineStyle(1, C.BORDER, 1);
    bg.fillRect(this.nextBox.x, this.nextBox.y, this.nextBox.w, this.nextBox.h);
    bg.strokeRect(this.nextBox.x, this.nextBox.y, this.nextBox.w, this.nextBox.h);
    bg.fillRect(this.holdBox.x, this.holdBox.y, this.holdBox.w, this.holdBox.h);
    bg.strokeRect(this.holdBox.x, this.holdBox.y, this.holdBox.w, this.holdBox.h);
  };

  // -------------------------------------------------------------- overlays
  GameScene.prototype.buildOverlays = function () {
    var W = L.WIDTH, H = L.HEIGHT;
    this.overlay = this.add.container(0, 0).setDepth(100);
    this.overlayBg = this.add.graphics();
    this.overlayBg.fillStyle(0x000000, 0.72).fillRect(0, 0, W, H);
    this.overlayTitle = this.add.text(W / 2, H / 2 - 60, '', {
      fontFamily: 'Segoe UI, Arial, sans-serif', fontSize: '46px',
      color: '#ffffff', fontStyle: 'bold', align: 'center'
    }).setOrigin(0.5);
    this.overlayBody = this.add.text(W / 2, H / 2 + 20, '', {
      fontFamily: 'Segoe UI, Arial, sans-serif', fontSize: '20px',
      color: '#dbe6f5', align: 'center', lineSpacing: 6
    }).setOrigin(0.5);
    this.overlay.add([this.overlayBg, this.overlayTitle, this.overlayBody]);
    this.overlay.setVisible(false);
  };

  GameScene.prototype.setOverlay = function (kind) {
    if (!kind) { this.overlay.setVisible(false); return; }
    this.overlay.setVisible(true);
    if (kind === 'paused') {
      this.overlayTitle.setText('PAUSED');
      this.overlayBody.setText('Press Esc or P to resume');
    } else if (kind === 'gameover') {
      this.overlayTitle.setText('GAME OVER');
      this.overlayBody.setText('Score  ' + this.engine.score +
        '\nPress R or tap New Game to restart');
    }
  };

  // -------------------------------------------------------------- keyboard
  GameScene.prototype.bindKeyboard = function () {
    var kb = this.input.keyboard;
    // Note: page-scroll suppression for arrows/space is handled at the window
    // level in main.js (FR-CTRL-005), guarded so it never blocks keyboard
    // activation of focused DOM buttons (NFR-A11Y-001).

    var self = this;
    var on = function (code, fn) { kb.on('keydown-' + code, fn); };

    on('LEFT', function () { self.press('left'); });
    on('RIGHT', function () { self.press('right'); });
    on('DOWN', function () { self.press('soft'); });
    kb.on('keyup-LEFT', function () { self.release('left'); });
    kb.on('keyup-RIGHT', function () { self.release('right'); });
    kb.on('keyup-DOWN', function () { self.release('soft'); });

    on('UP', function () { self.tap('rotateCW'); });
    on('X', function () { self.tap('rotateCW'); });
    on('Z', function () { self.tap('rotateCCW'); });
    on('CTRL', function () { self.tap('rotateCCW'); });
    on('SPACE', function () { self.tap('hardDrop'); });
    on('C', function () { self.tap('hold'); });
    on('SHIFT', function () { self.tap('hold'); });
    on('ESC', function () { self.tap('pause'); });
    on('P', function () { self.tap('pause'); });
    on('R', function () { self.tap('restart'); });
  };

  // ------------------------------------------------------------------ bus
  GameScene.prototype.bindBus = function () {
    var self = this;
    this.busHandler = function (msg) {
      if (!msg) return;
      if (msg.type === 'press') self.press(msg.action);
      else if (msg.type === 'release') self.release(msg.action);
      else if (msg.type === 'tap') self.tap(msg.action);
    };
    global.TetrisBus.on('input', this.busHandler);
  };

  // ------------------------------------------------------- input handling
  GameScene.prototype.press = function (action) {
    if (action === 'left') {
      this.held.left = true; this.startDas(-1); this.engine.move(-1);
      this.afterAction();
    } else if (action === 'right') {
      this.held.right = true; this.startDas(1); this.engine.move(1);
      this.afterAction();
    } else if (action === 'soft') {
      this.held.soft = true;
    }
  };

  GameScene.prototype.release = function (action) {
    if (action === 'left') {
      this.held.left = false;
      if (this.held.right) this.startDas(1); else this.das.dir = 0;
    } else if (action === 'right') {
      this.held.right = false;
      if (this.held.left) this.startDas(-1); else this.das.dir = 0;
    } else if (action === 'soft') {
      this.held.soft = false;
    }
  };

  GameScene.prototype.tap = function (action) {
    var e = this.engine;
    switch (action) {
      case 'rotateCW': e.rotate(1); break;
      case 'rotateCCW': e.rotate(-1); break;
      case 'hardDrop': e.hardDrop(); break;
      case 'hold': e.hold(); break;
      case 'softStep': e.softDrop(); break;
      case 'pause': this.togglePause(); break;
      case 'restart': this.restart(); break;
      default: break;
    }
    this.afterAction();
  };

  GameScene.prototype.startDas = function (dir) {
    this.das.dir = dir; this.das.timer = 0; this.das.charged = false;
  };

  GameScene.prototype.togglePause = function () {
    if (this.engine.status === 'playing') {
      this.engine.pause();
      this.setOverlay('paused');
      if (global.TetrisUI) global.TetrisUI.setStatus('paused');
    } else if (this.engine.status === 'paused') {
      this.engine.resume();
      this.setOverlay(null);
      if (global.TetrisUI) global.TetrisUI.setStatus('playing');
    }
  };

  GameScene.prototype.restart = function () {
    // Restart resets all state and begins fresh (FR-LIFE-007).
    this.engine.start();
    this.held = { left: false, right: false, soft: false };
    this.das.dir = 0;
    this.setOverlay(null);
    this.syncHud(true);
    if (global.TetrisUI) global.TetrisUI.setStatus('playing');
  };

  // Re-render immediately after an input so response is < 100 ms (NFR-CTRL-002).
  GameScene.prototype.afterAction = function () {
    this.processEvents();
    this.renderBoard();
    this.renderPreviews();
    this.syncHud(false);
  };

  // --------------------------------------------------------------- update
  GameScene.prototype.update = function (time, delta) {
    var e = this.engine;
    if (e.status === 'playing') {
      // Horizontal auto-repeat (DAS/ARR) — deterministic (FR-CTRL-003).
      if (this.das.dir !== 0) {
        this.das.timer += delta;
        if (!this.das.charged) {
          if (this.das.timer >= DAS_DELAY) {
            this.das.charged = true; this.das.timer = 0; e.move(this.das.dir);
          }
        } else {
          while (this.das.timer >= ARR) { this.das.timer -= ARR; e.move(this.das.dir); }
        }
      }
      e.update(delta, this.held.soft);
    }
    this.processEvents();
    this.renderBoard();
    this.renderPreviews();
    this.syncHud(false);
  };

  // -------------------------------------------------------- engine events
  GameScene.prototype.processEvents = function () {
    var fx = global.TetrisAudio;
    var evts = this.engine.drainEvents();
    for (var i = 0; i < evts.length; i++) {
      var ev = evts[i];
      switch (ev.name) {
        case 'move': fx.move(); break;
        case 'rotate': fx.rotate(); break;
        case 'lock': fx.land(); break;
        case 'clear':
          if (ev.data.count >= 4) fx.tetris(); else fx.clear();
          this.flashRows(ev.data.rows);
          break;
        case 'levelup':
          if (!L.reducedMotion()) this.cameras.main.flash(180, 60, 120, 200);
          break;
        case 'gameover':
          fx.gameover();
          this.onGameOver();
          break;
        default: break;
      }
    }
  };

  GameScene.prototype.onGameOver = function () {
    // Persist high score (FR-SCORE-005).
    if (this.engine.score > this.highScore) {
      this.highScore = this.engine.score;
      global.TetrisStorage.saveHighScore(this.highScore);
    }
    this.setOverlay('gameover');
    this.syncHud(true);
    if (global.TetrisUI) {
      global.TetrisUI.setStatus('gameover');
      global.TetrisUI.showGameOver(this.engine.score);
    }
    if (!L.reducedMotion()) this.cameras.main.shake(220, 0.006);
  };

  // ---------------------------------------------------------- rendering
  GameScene.prototype.cellRect = function (g, cx, cy, color, alpha, ghost) {
    var x = L.BOARD_X + cx * L.CELL;
    var y = L.BOARD_Y + cy * L.CELL;
    var s = L.CELL;
    if (ghost) {
      g.lineStyle(2, color, 0.9).strokeRect(x + 2, y + 2, s - 4, s - 4);
      return;
    }
    g.fillStyle(color, alpha == null ? 1 : alpha);
    g.fillRect(x + 1, y + 1, s - 2, s - 2);
    // Bevel highlight so locked/active cells read by shape, not color alone
    // (NFR-A11Y-002, UI-HUD-002).
    g.fillStyle(0xffffff, 0.18).fillRect(x + 1, y + 1, s - 2, 4);
    g.fillStyle(0x000000, 0.22).fillRect(x + 1, y + s - 5, s - 2, 4);
  };

  GameScene.prototype.renderBoard = function () {
    var g = this.boardGfx;
    g.clear();
    var C = K.COLORS;

    // Grid background lines.
    g.fillStyle(C.BG, 1).fillRect(L.BOARD_X, L.BOARD_Y, L.BOARD_W, L.BOARD_H);
    g.lineStyle(1, C.GRID, 0.6);
    for (var c = 0; c <= K.COLS; c++) {
      g.lineBetween(L.BOARD_X + c * L.CELL, L.BOARD_Y,
        L.BOARD_X + c * L.CELL, L.BOARD_Y + L.BOARD_H);
    }
    for (var r = 0; r <= K.ROWS; r++) {
      g.lineBetween(L.BOARD_X, L.BOARD_Y + r * L.CELL,
        L.BOARD_X + L.BOARD_W, L.BOARD_Y + r * L.CELL);
    }

    var e = this.engine;
    var hidden = K.HIDDEN_ROWS;

    // Locked cells (visible region only).
    for (var ry = 0; ry < K.ROWS; ry++) {
      var gy = ry + hidden;
      for (var rx = 0; rx < K.COLS; rx++) {
        var id = e.grid[gy][rx];
        if (id !== 0) this.cellRect(g, rx, ry, K.ID_TO_COLOR[id]);
      }
    }

    // Ghost piece (FR-GHOST-001) — drawn before active so active overlays it.
    if (e.active && e.status === 'playing') {
      var gYy = e.ghostY();
      var gcells = e.cellsFor(e.active.type, e.active.rot, e.active.x, gYy);
      for (var i = 0; i < gcells.length; i++) {
        var vy = gcells[i].y - hidden;
        if (vy >= 0) this.cellRect(g, gcells[i].x, vy,
          K.COLORS[e.active.type], 1, true);
      }
    }

    // Active piece (UI-HUD-002 distinct from locked via brightness + outline).
    if (e.active) {
      var acells = e.activeCells();
      var color = K.COLORS[e.active.type];
      for (var j = 0; j < acells.length; j++) {
        var avy = acells[j].y - hidden;
        if (avy >= 0) this.cellRect(g, acells[j].x, avy, color);
      }
      g.lineStyle(2, 0xffffff, 0.85);
      for (var k = 0; k < acells.length; k++) {
        var ay = acells[k].y - hidden;
        if (ay >= 0) {
          g.strokeRect(L.BOARD_X + acells[k].x * L.CELL + 1,
            L.BOARD_Y + ay * L.CELL + 1, L.CELL - 2, L.CELL - 2);
        }
      }
    }
  };

  GameScene.prototype.drawMini = function (g, box, type) {
    if (!type) return;
    var shape = K.SHAPES[type][0];
    var minx = 9, maxx = -9, miny = 9, maxy = -9;
    shape.forEach(function (p) {
      minx = Math.min(minx, p[0]); maxx = Math.max(maxx, p[0]);
      miny = Math.min(miny, p[1]); maxy = Math.max(maxy, p[1]);
    });
    var wCells = maxx - minx + 1, hCells = maxy - miny + 1;
    var cell = Math.min(22, Math.floor(box.w / 5));
    var ox = box.x + (box.w - wCells * cell) / 2 - minx * cell;
    var oy = box.y + (box.h - hCells * cell) / 2 - miny * cell;
    var color = K.COLORS[type];
    shape.forEach(function (p) {
      var x = ox + p[0] * cell, y = oy + p[1] * cell;
      g.fillStyle(color, 1).fillRect(x + 1, y + 1, cell - 2, cell - 2);
      g.fillStyle(0xffffff, 0.18).fillRect(x + 1, y + 1, cell - 2, 3);
      g.fillStyle(0x000000, 0.22).fillRect(x + 1, y + cell - 4, cell - 2, 3);
    });
  };

  GameScene.prototype.renderPreviews = function () {
    var g = this.previewGfx;
    g.clear();
    var nextType = this.engine.bag.peek(1)[0]; // matches actual spawn (FR-SPAWN-002)
    this.drawMini(g, this.nextBox, nextType);
    this.drawMini(g, this.holdBox, this.engine.holdType);
  };

  GameScene.prototype.flashRows = function (rows) {
    if (L.reducedMotion()) return; // limit flashing (NFR-A11Y-005)
    var g = this.flashGfx;
    var hidden = K.HIDDEN_ROWS;
    g.clear();
    g.fillStyle(0xffffff, 0.85);
    for (var i = 0; i < rows.length; i++) {
      var vy = rows[i] - hidden;
      if (vy >= 0) g.fillRect(L.BOARD_X, L.BOARD_Y + vy * L.CELL, L.BOARD_W, L.CELL);
    }
    g.setAlpha(1);
    this.tweens.add({ targets: g, alpha: 0, duration: 220,
      onComplete: function () { g.clear(); g.setAlpha(1); } });
  };

  // -------------------------------------------------------------- HUD sync
  GameScene.prototype.syncHud = function (force) {
    var e = this.engine;
    var lvl = e.level + 1; // display as 1-based
    if (force || this.lastHud.score !== e.score) {
      this.scoreText.setText(String(e.score));
    }
    if (force || this.lastHud.level !== lvl) this.levelText.setText(String(lvl));
    if (force || this.lastHud.lines !== e.lines) this.linesText.setText(String(e.lines));
    var hs = Math.max(this.highScore, e.score);
    if (force || this.lastHud.high !== hs) this.highText.setText(String(hs));

    if (global.TetrisUI &&
        (force || this.lastHud.score !== e.score ||
         this.lastHud.level !== lvl || this.lastHud.lines !== e.lines)) {
      global.TetrisUI.update(e.score, lvl, e.lines, hs);
    }
    this.lastHud = { score: e.score, level: lvl, lines: e.lines, high: hs };
  };

  // ------------------------------------------------------------- teardown
  GameScene.prototype.teardown = function () {
    if (this.busHandler) global.TetrisBus.off('input', this.busHandler);
  };

  // Called by main.js when the tab is hidden, to auto-pause (FR-LIFE-008).
  GameScene.prototype.autoPause = function () {
    if (this.engine && this.engine.status === 'playing') this.togglePause();
  };

  global.GameScene = GameScene;
})(window);
