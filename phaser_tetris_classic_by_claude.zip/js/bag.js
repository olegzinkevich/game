/*
 * bag.js — 7-bag randomizer (FR-SPAWN-001).
 * Each bag contains exactly the seven tetrominoes in random order, so within
 * any 7 consecutive spawns no piece repeats or is starved.
 */
(function (global) {
  'use strict';

  function SevenBag() {
    this.queue = [];
    this.refill();
    this.refill(); // keep enough lookahead for the Next preview
  }

  // Fisher–Yates shuffle of a fresh copy of the seven types.
  SevenBag.prototype.refill = function () {
    var bag = global.TetrisConst.TYPES.slice();
    for (var i = bag.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = bag[i]; bag[i] = bag[j]; bag[j] = tmp;
    }
    this.queue = this.queue.concat(bag);
  };

  // Pull the next type, refilling when the lookahead runs low.
  SevenBag.prototype.next = function () {
    if (this.queue.length <= 7) this.refill();
    return this.queue.shift();
  };

  // Peek ahead n upcoming pieces without consuming them (Next preview).
  SevenBag.prototype.peek = function (n) {
    while (this.queue.length < n) this.refill();
    return this.queue.slice(0, n);
  };

  global.SevenBag = SevenBag;
})(window);
