/*
 * layout.js — Canvas geometry shared by the Phaser scenes.
 * Defines the internal (design) resolution. The Phaser Scale Manager fits this
 * to any viewport while preserving aspect ratio (UI-RESP-001/002).
 */
(function (global) {
  'use strict';

  var C = global.TetrisConst;

  var CELL = 30;
  var MARGIN = 18;
  var BOARD_W = C.COLS * CELL;   // 300
  var BOARD_H = C.ROWS * CELL;   // 600
  var BOARD_X = MARGIN;
  var BOARD_Y = MARGIN;

  var PANEL_X = BOARD_X + BOARD_W + MARGIN; // 336
  var PANEL_W = 210;
  var WIDTH = PANEL_X + PANEL_W + MARGIN;   // 564
  var HEIGHT = BOARD_Y + BOARD_H + MARGIN;  // 636

  function reducedMotion() {
    try {
      return global.matchMedia &&
        global.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch (e) { return false; }
  }

  global.TetrisLayout = {
    CELL: CELL,
    MARGIN: MARGIN,
    BOARD_W: BOARD_W,
    BOARD_H: BOARD_H,
    BOARD_X: BOARD_X,
    BOARD_Y: BOARD_Y,
    PANEL_X: PANEL_X,
    PANEL_W: PANEL_W,
    WIDTH: WIDTH,
    HEIGHT: HEIGHT,
    reducedMotion: reducedMotion
  };
})(window);
