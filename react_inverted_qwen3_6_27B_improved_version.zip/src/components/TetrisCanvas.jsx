import { useEffect, useRef } from 'react';
import { PIECES, COLS, ROWS } from '../utils/pieces';

export default function TetrisCanvas({ canvasRef, draw }) {
  const renderRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const render = (state) => {
      renderRef.current = state;
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      const displayW = rect.width;
      const displayH = rect.height;

      if (canvas.width !== Math.floor(displayW * dpr) || canvas.height !== Math.floor(displayH * dpr)) {
        canvas.width = Math.floor(displayW * dpr);
        canvas.height = Math.floor(displayH * dpr);
      }

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      const cellW = displayW / COLS;
      const cellH = displayH / ROWS;

      const shakeX = state.shakeTimer > 0 ? (Math.random() - 0.5) * 4 : 0;
      const shakeY = state.shakeTimer > 0 ? (Math.random() - 0.5) * 4 : 0;

      ctx.save();
      ctx.translate(shakeX, shakeY);

      ctx.fillStyle = '#0a0a1a';
      ctx.fillRect(0, 0, displayW, displayH);

      ctx.strokeStyle = '#1a1a2e';
      ctx.lineWidth = 0.5;
      for (let x = 0; x <= COLS; x++) {
        ctx.beginPath();
        ctx.moveTo(x * cellW, 0);
        ctx.lineTo(x * cellW, displayH);
        ctx.stroke();
      }
      for (let y = 0; y <= ROWS; y++) {
        ctx.beginPath();
        ctx.moveTo(0, y * cellH);
        ctx.lineTo(displayW, y * cellH);
        ctx.stroke();
      }

      const isClearing = state.clearAnimFrame > 0;
      const flash = isClearing && state.clearAnimFrame % 2 === 0;

      for (let y = 0; y < ROWS; y++) {
        for (let x = 0; x < COLS; x++) {
          const cell = state.grid[y][x];
          if (cell !== 0) {
            const pieceColor = PIECES[Object.keys(PIECES).find(k => PIECES[k].id === cell)]?.darkColor || '#666';
            const isClearedRow = state.clearedRows.includes(y);
            if (isClearedRow && flash) {
              ctx.fillStyle = '#ffffff';
            } else {
              ctx.fillStyle = pieceColor;
            }
            ctx.fillRect(x * cellW + 1, y * cellH + 1, cellW - 2, cellH - 2);
          }
        }
      }

      if (state.pieceName && state.status === 'playing') {
        const piece = PIECES[state.pieceName];
        const { pieceX, pieceY, pieceCells } = state;

        let ghostY = pieceY;
        while (true) {
          let blocked = false;
          for (const [cx, cy] of pieceCells) {
            const gx = pieceX + cx;
            const gy = ghostY - 1 + cy;
            if (gy < 0) { blocked = true; break; }
            if (gx < 0 || gx >= COLS) { blocked = true; break; }
            if (state.grid[gy]?.[gx] !== 0) { blocked = true; break; }
          }
          if (blocked) break;
          ghostY--;
        }

        ctx.globalAlpha = 0.2;
        for (const [cx, cy] of pieceCells) {
          const gx = pieceX + cx;
          const gy = ghostY + cy;
          if (gy >= 0 && gy < ROWS && gx >= 0 && gx < COLS) {
            ctx.fillStyle = piece.color;
            ctx.fillRect(gx * cellW + 1, gy * cellH + 1, cellW - 2, cellH - 2);
          }
        }
        ctx.globalAlpha = 1;

        for (const [cx, cy] of pieceCells) {
          const px = pieceX + cx;
          const py = pieceY + cy;
          if (py >= 0 && py < ROWS && px >= 0 && px < COLS) {
            ctx.fillStyle = piece.color;
            ctx.fillRect(px * cellW + 1, py * cellH + 1, cellW - 2, cellH - 2);
            ctx.fillStyle = 'rgba(255,255,255,0.15)';
            ctx.fillRect(px * cellW + 1, py * cellH + 1, cellW - 2, (cellH - 2) * 0.4);
          }
        }
      }

      ctx.restore();

      if (state.status === 'menu') {
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(0, 0, displayW, displayH);
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.floor(displayW * 0.06)}px monospace`;
        ctx.textAlign = 'center';
        ctx.fillText('INVERTED TETRIS', displayW / 2, displayH * 0.4);
        ctx.font = `${Math.floor(displayW * 0.03)}px monospace`;
        ctx.fillText('Press ENTER or click START', displayW / 2, displayH * 0.55);
      }

      if (state.status === 'paused') {
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(0, 0, displayW, displayH);
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.floor(displayW * 0.06)}px monospace`;
        ctx.textAlign = 'center';
        ctx.fillText('PAUSED', displayW / 2, displayH / 2);
      }

      if (state.status === 'gameover') {
        ctx.fillStyle = 'rgba(0,0,0,0.75)';
        ctx.fillRect(0, 0, displayW, displayH);
        ctx.fillStyle = '#ff4444';
        ctx.font = `bold ${Math.floor(displayW * 0.06)}px monospace`;
        ctx.textAlign = 'center';
        ctx.fillText('GAME OVER', displayW / 2, displayH * 0.4);
        ctx.fillStyle = '#ffffff';
        ctx.font = `${Math.floor(displayW * 0.03)}px monospace`;
        ctx.fillText(`Score: ${state.score}`, displayW / 2, displayH * 0.52);
        ctx.fillText('Press R or click RESTART', displayW / 2, displayH * 0.6);
      }
    };

    draw(render);
  }, [canvasRef, draw]);

  return null;
}
