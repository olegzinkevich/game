import { useRef, useCallback, useState, useEffect } from 'react';
import useTetrisGame from '../utils/useTetrisGame';
import TetrisCanvas from './TetrisCanvas';
import SidePanel from './SidePanel';
import TouchControls from './TouchControls';

export default function TetrisGame() {
  const canvasRef = useRef(null);
  const [, setTick] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 100);
    return () => clearInterval(interval);
  }, []);

  const {
    stateRef,
    pressedKeysRef,
    draw,
    startGame,
    pauseGame,
    moveLeft,
    moveRight,
    softRise,
    releaseSoftRise,
    hardRise,
    rotateCW,
    rotateCCW,
    holdPiece,
  } = useTetrisGame(canvasRef);

  const handleRestart = useCallback(() => {
    startGame();
  }, [startGame]);

  const handleStart = useCallback(() => {
    startGame();
  }, [startGame]);

  return (
    <div className="game-container">
      <div className="game-main">
        <div className="canvas-wrapper">
          <canvas
            ref={canvasRef}
            className="tetris-canvas"
            aria-label="Inverted Tetris game board"
            role="img"
          />
          <TetrisCanvas canvasRef={canvasRef} stateRef={stateRef} draw={draw} />
          {stateRef.current.status === 'gameover' && (
            <div className="gameover-modal">
              <div className="gameover-modal-content">
                <div className="gameover-title">GAME OVER</div>
                <div className="gameover-stats">
                  <div className="gameover-stat-row">
                    <span className="gameover-stat-label">Score</span>
                    <span className="gameover-stat-value">{stateRef.current.score.toLocaleString()}</span>
                  </div>
                  <div className="gameover-stat-row">
                    <span className="gameover-stat-label">Level</span>
                    <span className="gameover-stat-value">{stateRef.current.level}</span>
                  </div>
                  <div className="gameover-stat-row">
                    <span className="gameover-stat-label">Lines</span>
                    <span className="gameover-stat-value">{stateRef.current.lines}</span>
                  </div>
                  <div className="gameover-stat-row">
                    <span className="gameover-stat-label">High Score</span>
                    <span className="gameover-stat-value highscore">{stateRef.current.highScore.toLocaleString()}</span>
                  </div>
                </div>
                <button
                  className="btn btn-restart"
                  onClick={handleRestart}
                  aria-label="Restart game"
                  tabIndex={0}
                >
                  RESTART
                </button>
              </div>
            </div>
          )}
        </div>

        <TouchControls
          onLeft={moveLeft}
          onRight={moveRight}
          onSoftRise={softRise}
          onReleaseSoftRise={releaseSoftRise}
          onHardRise={hardRise}
          onRotateCW={rotateCW}
          onRotateCCW={rotateCCW}
          onHold={holdPiece}
          onPause={pauseGame}
          pressedKeysRef={pressedKeysRef}
        />
      </div>

      <SidePanel
        stateRef={stateRef}
        onStart={handleStart}
        onRestart={handleRestart}
        onPause={pauseGame}
      />
    </div>
  );
}
