export default function TouchControls({
  onLeft, onRight, onSoftRise, onHardRise, onReleaseSoftRise,
  onRotateCW, onRotateCCW, onHold, onPause,
  pressedKeysRef,
}) {
  const btnStyle = {
    width: '64px',
    height: '64px',
    fontSize: '22px',
    fontWeight: 'bold',
    border: '2px solid rgba(255,255,255,0.3)',
    borderRadius: '12px',
    backgroundColor: 'rgba(255,255,255,0.1)',
    color: '#fff',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    userSelect: 'none',
    WebkitUserSelect: 'none',
    touchAction: 'manipulation',
    WebkitTapHighlightColor: 'transparent',
  };

  return (
    <div className="touch-controls" role="group" aria-label="Touch controls">
      <div className="touch-row">
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); onRotateCCW(); }}
          onMouseDown={(e) => { e.preventDefault(); onRotateCCW(); }}
          aria-label="Rotate counter-clockwise"
        >
          ↶
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); onRotateCW(); }}
          onMouseDown={(e) => { e.preventDefault(); onRotateCW(); }}
          aria-label="Rotate clockwise"
        >
          ↷
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); onHold(); }}
          onMouseDown={(e) => { e.preventDefault(); onHold(); }}
          aria-label="Hold piece"
        >
          H
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onClick={onPause}
          aria-label="Pause"
        >
          ⏸
        </button>
      </div>
      <div className="touch-row">
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.add('left'); }}
          onTouchEnd={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.delete('left'); }}
          onMouseDown={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.add('left'); }}
          onMouseUp={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.delete('left'); }}
          onMouseLeave={(e) => { if (pressedKeysRef) pressedKeysRef.current.delete('left'); }}
          aria-label="Move left"
        >
          ←
        </button>
        <button
          className="touch-btn"
          style={{ ...btnStyle, width: '90px' }}
          onTouchStart={(e) => { e.preventDefault(); onSoftRise(); }}
          onTouchEnd={(e) => { e.preventDefault(); if (onReleaseSoftRise) onReleaseSoftRise(); if (pressedKeysRef) pressedKeysRef.current.delete('softRise'); }}
          onMouseDown={(e) => { e.preventDefault(); onSoftRise(); }}
          onMouseUp={(e) => { e.preventDefault(); if (onReleaseSoftRise) onReleaseSoftRise(); if (pressedKeysRef) pressedKeysRef.current.delete('softRise'); }}
          onMouseLeave={(e) => { if (onReleaseSoftRise) onReleaseSoftRise(); if (pressedKeysRef) pressedKeysRef.current.delete('softRise'); }}
          aria-label="Soft rise"
        >
          ↑
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.add('right'); }}
          onTouchEnd={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.delete('right'); }}
          onMouseDown={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.add('right'); }}
          onMouseUp={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.delete('right'); }}
          onMouseLeave={(e) => { if (pressedKeysRef) pressedKeysRef.current.delete('right'); }}
          aria-label="Move right"
        >
          →
        </button>
        <button
          className="touch-btn"
          style={{ ...btnStyle, backgroundColor: 'rgba(255,80,80,0.25)' }}
          onTouchStart={(e) => { e.preventDefault(); onHardRise(); }}
          onMouseDown={(e) => { e.preventDefault(); onHardRise(); }}
          aria-label="Hard rise"
        >
          ⏫
        </button>
      </div>
    </div>
  );
}
