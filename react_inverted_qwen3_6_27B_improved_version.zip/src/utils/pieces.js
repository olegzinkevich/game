export const COLS = 15;
export const ROWS = 35;
const BASE_INTERVAL = 500;
const MIN_INTERVAL = 50;
export const LINES_PER_LEVEL = 10;

export const PIECES = {
  I: {
    id: 1,
    name: 'I',
    color: '#30b5c5',
    darkColor: '#2491a0',
    cells: [[0, 0], [0, 1], [0, 2]],
    width: 1,
    height: 3,
    pivotX: 0,
    pivotY: 1,
  },
  P: {
    id: 2,
    name: 'P',
    color: '#c00000',
    darkColor: '#9a0000',
    cells: [[1, 0], [0, 1], [0, 2]],
    width: 2,
    height: 3,
    pivotX: 0,
    pivotY: 1,
  },
  L: {
    id: 3,
    name: 'L',
    color: '#ED6D00',
    darkColor: '#c45900',
    cells: [[0, 0], [0, 1], [1, 2]],
    width: 2,
    height: 3,
    pivotX: 0,
    pivotY: 1,
  },
  C: {
    id: 4,
    name: 'C',
    color: '#a0d183',
    darkColor: '#7db060',
    cells: [[0, 0], [0, 1], [1, 1]],
    width: 2,
    height: 2,
    pivotX: 0,
    pivotY: 0,
  },
};

export const PIECE_NAMES = ['I', 'P', 'L', 'C'];

const SCORE_TABLE = [0, 100, 300, 500];

export function createGrid() {
  return Array.from({ length: ROWS }, () => Array(COLS).fill(0));
}

export function getInterval(level) {
  return Math.max(MIN_INTERVAL, Math.floor(BASE_INTERVAL / (level + 1)));
}

export function getScoreForLines(lines, level) {
  return SCORE_TABLE[lines] * (level + 1);
}

export function rotateCellsCW(cells, pivotX, pivotY) {
  return cells.map(([x, y]) => {
    const dx = x - pivotX;
    const dy = y - pivotY;
    return [pivotX - dy, pivotY + dx];
  });
}

export function rotateCellsCCW(cells, pivotX, pivotY) {
  return cells.map(([x, y]) => {
    const dx = x - pivotX;
    const dy = y - pivotY;
    return [pivotX + dy, pivotY - dx];
  });
}

export function normalizeCells(cells) {
  const minX = Math.min(...cells.map(([x]) => x));
  const minY = Math.min(...cells.map(([, y]) => y));
  return cells.map(([x, y]) => [x - minX, y - minY]);
}

export function getBoundingSize(cells) {
  const maxX = Math.max(...cells.map(([x]) => x));
  const maxY = Math.max(...cells.map(([, y]) => y));
  const minX = Math.min(...cells.map(([x]) => x));
  const minY = Math.min(...cells.map(([, y]) => y));
  return { width: maxX - minX + 1, height: maxY - minY + 1 };
}

export function collision(grid, cells, offsetX, offsetY) {
  for (const [cx, cy] of cells) {
    const x = offsetX + cx;
    const y = offsetY + cy;
    if (x < 0 || x >= COLS || y < 0 || y >= ROWS) return true;
    if (grid[y][x] !== 0) return true;
  }
  return false;
}

export function getSpawnX(piece) {
  return Math.floor(COLS / 2) - Math.floor(piece.width / 2);
}

export function getSpawnY() {
  return ROWS - 1;
}

export function createBag() {
  const bag = [...PIECE_NAMES];
  for (let i = bag.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  return bag;
}

export function calcGhostY(grid, cells, pieceX, pieceY) {
  let ghostY = pieceY;
  while (!collision(grid, cells, pieceX, ghostY - 1)) {
    ghostY--;
  }
  return ghostY;
}

export function clearLines(grid) {
  const fullRows = [];
  for (let y = 0; y < ROWS; y++) {
    if (grid[y].every(cell => cell !== 0)) {
      fullRows.push(y);
    }
  }
  if (fullRows.length === 0) return { newGrid: grid, clearedRows: [] };

  const newGrid = grid.filter((_, idx) => !fullRows.includes(idx));
  while (newGrid.length < ROWS) {
    newGrid.push(Array(COLS).fill(0));
  }
  return { newGrid, clearedRows: fullRows };
}

export function getHighScore() {
  try {
    const val = localStorage.getItem('inverted_tetris_highscore');
    if (val !== null) {
      const parsed = parseInt(val, 10);
      if (!isNaN(parsed) && parsed >= 0) return parsed;
    }
  } catch { /* ignore */ }
  return 0;
}

export function setHighScore(score) {
  try {
    localStorage.setItem('inverted_tetris_highscore', String(score));
  } catch { /* ignore */ }
}
