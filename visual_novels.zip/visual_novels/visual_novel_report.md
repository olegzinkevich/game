# Visual Novels — Genre Report

## 1. What the genre is

A visual novel (VN) is a narrative game built around reading text over static art: a background, character sprites, a text box, and a soundtrack. The player advances dialogue and occasionally makes choices. The genre grew out of Japanese adventure games in the 1980s–90s and is now split into two scenes: the **Japanese eroge/otome/bishoujo tradition** (Key, Type-Moon, Nitroplus, 5pb) and the **Western indie scene** (Ren'Py-based, itch.io/Steam-first).

Structural split that matters for design:

| Type | Description | Examples |
|---|---|---|
| **Kinetic** | No choices, pure reading | *Planetarian*, *Narcissu* |
| **Branching / route-based** | Choices set flags → routes → endings | *Fate/stay night*, *Clannad* |
| **Hybrid (VN + system)** | Adds puzzles, investigation, stats, combat | *Danganronpa*, *Zero Escape*, *Slay the Princess* |

## 2. Most popular / influential titles

**Steins;Gate (2009)** — A self-proclaimed mad scientist accidentally builds a microwave that sends text messages to the past. He and his lab-mates meddle with timelines, attracting a shadowy organization. Plot hinges on undoing a tragedy across worldlines. *Core gameplay:* phone-based choice system (which messages you reply to changes flags), multiple endings, route locks. Widely cited as the best entry point to the genre.

**Fate/stay night (2004)** — Seven mages summon historical heroes to fight for the Holy Grail. The protagonist, Shirou, is dragged in and must survive. Three routes (Fate/Unlimited Blade Works/Heaven's Feel) reframe the same events into different genres: romance, war epic, horror. *Core gameplay:* route gating, "choice points," affection/flag tracking, an unlockable encyclopedia.

**Clannad (2004)** — A delinquent loner befriends a shy girl and, through school-life arcs, rebuilds his relationships and family. The second half (*After Story*) is a decades-spanning family drama. *Core gameplay:* "Light Orb" system — kindness you show across routes earns orbs that unlock the true ending; heavy route structure.

**Muv-Luv / Muv-Luv Alternative (2003/2006)** — Starts as a generic high-school rom-com, then the sequel drops the cast into a war against alien BETA. Often called the most emotionally violent bait-and-switch in the medium. *Core gameplay:* extreme route/structure gating; Alternative is nearly kinetic but pays off choices from the first game.

**Higurashi When They Cry (2002)** — A rural village with a summer festival curse; each chapter is a different perspective on murders and paranoia. *Core gameplay:* "question arcs" then "answer arcs"; the reader must form theories. Originally sound-novel (no choices), later ports add choices.

**Umineko When They Cry (2007)** — A wealthy family is slaughtered on an island; the murders are framed as a witch's game. Meta-fictional duel between "magic" and "mystery" explanations. *Core gameplay:* deduction, the red/blue truth system, no traditional choices — you're meant to solve it.

**Doki Doki Literature Club! (2017)** — A cute school literature club that progressively breaks the fourth wall and its own game files. *Core gameplay:* poem word-selection minigame, meta file manipulation, route divergence. The genre's biggest mainstream crossover hit.

**Katawa Shoujo (2012)** — A Western-made VN about a boy with a heart condition attending a school for disabled students; five romance routes handled with unusual sensitivity. *Core gameplay:* classic choice/flag romance routing, act structure.

**The House in Fata Morgana (2012)** — A gothic, centuries-spanning tragedy about a cursed mansion and its doomed inhabitants. *Core gameplay:* mostly kinetic, door/room navigation, chapter structure, a huge narrative payoff.

**VA-11 Hall-A (2016)** — Cyberpunk bartender sim: mix drinks and listen to customers' stories in a dystopian city. *Core gameplay:* drink-mixing minigame that doubles as the choice system (a wrong drink steers conversation).

**The Zero Escape series: 999 / Virtue's Last Reward / Zero Time Dilemma (2009–2016)** — Nine people abducted onto a sinking ship / in a facility, forced into a deadly escape game. *Core gameplay:* escape-room puzzles + branching flowchart with a true-ending lock. Definitive VN/puzzle hybrid.

**Danganronpa (2010–2017)** — Elite students trapped in a killing game; you investigate murders and argue against classmates in court. *Core gameplay:* exploration, evidence gathering, "class trials" with minigames (nonstop debate, hangman's gambit, logic dive).

**Grisaia no Kajitsu (2011)** — A traumatized ex-mercenary is forced into a normal academy and helps five girls with severe psychological trauma. *Core gameplay:* common route → five character routes, choice flags, adult content in the original.

**Saya no Uta (2003)** — Horror: a medical student's perception is warped after brain surgery, and he falls for a monster only he can see. *Core gameplay:* short kinetic/branching hybrid; Urobuchi's most infamous work.

**White Album 2 (2010)** — A devastating love-triangle drama across high school and adulthood. *Core gameplay:* route structure with a notorious "closing chapter" gating.

**Slay the Princess (2023)** — A voice in your head tells you to kill a princess; the loop rewrites itself each time. *Core gameplay:* choice-driven loop with a massive decision tree and state memory. Modern western critical darling.

**Otome/other notable:** *Hatoful Boyfriend* (pigeon dating parody), *Dream Daddy*, *Monster Prom*, *Amnesia: Memories*, *Mystic Messenger* (mobile, real-time chat).

## 3. Why players engage (key hooks)

1. **Emotional payoff / catharsis** — VNs are optimized for the long-form gut-punch. *Clannad After Story* and *Muv-Luv Alternative* are famous for this.
2. **Agency over narrative** — "Choices matter" and the promise that a different route shows a different truth. The flowchart/multiple-ending structure is the core dopamine loop.
3. **Mystery and theory-crafting** — Higurashi/Umineko/Zero Escape build communities that theorize between releases.
4. **Character attachment (waifu/husbando)** — romance routes, affection, voice acting, and fan art culture create fandom that outlives the game.
5. **Low skill barrier** — anyone can finish; difficulty is emotional, not mechanical. Accessible to non-gamers.
6. **Production aesthetics** — high-quality illustration, CG galleries, voice acting, and OSTs (Key, Type-Moon soundtracks are concert material).
7. **Completionism / collection** — galleries, endings lists, achievements, true-end unlocks.
8. **Meta and fourth-wall play** — DDLC, Umineko, *OneShot* style tricks.
9. **Reader comfort** — auto-advance, backlog, skip-read-text, save anywhere; it's a book you can steer.

## 4. What each VN offers as "core gameplay"

The genre's actual mechanical surface is small. The recurring systems:

- **Text advance + auto/skip** — the base verb.
- **Choice menus** — set flags, affection, or route locks.
- **Flag/affection variables** — hidden or visible; determine route and ending.
- **Route/ending tree** — often gated (must finish A to unlock B); true ending usually locked behind all others.
- **Flowchart / chapter select** — Zero Escape, Steins;Gate Elite, modern remakes.
- **Minigames** — drink mixing (*VA-11 Hall-A*), poetry (*DDLC*), escape rooms (*Zero Escape*), class trials (*Danganronpa*), stat-raising (*Long Live the Queen*).
- **Phone/chat systems** — *Steins;Gate*, *Mystic Messenger* (real-time).
- **Meta-file interaction** — *DDLC*.
- **Encyclopedia/glossary** — Type-Moon's "Status" screen.
- **Gallery + music room** — unlockables as replay reward.
- **Save/load with named slots** and **backlog with voice replay**.

A useful way to state it: **the "gameplay" is state management over a narrative graph.** The art is in hiding the graph and making each branch feel inevitable.

## 5. AI pipeline to generate a visual novel

A realistic, tool-agnostic pipeline. Stages 1–3 are cheap and high-leverage; art/voice are where cost and risk concentrate.

### Phase 0 — Concept & scope
- Pick type (kinetic / branching / hybrid), length (2h vs 30h), rating, platform (Steam/itch).
- Write a one-page pitch: premise, hook, target audience, ending count.
- **AI use:** LLM for logline/theme brainstorming and competitor analysis.

### Phase 1 — World & characters
- Setting bible, character sheets (appearance, voice, arc), relationship map.
- **AI use:** LLM for generating 20–50 variants of character concepts, then human curation. Keep a locked "canon sheet" per character — this becomes the prompt seed for art.

### Phase 2 — Narrative design (the graph)
- Write the **branch map first**, before prose. Nodes = scenes; edges = choices; terminals = endings.
- Define flags/affection variables and gating rules explicitly (a table or JSON).
- **AI use:** LLM to draft the graph and flag schema; validate with a script that checks every ending is reachable and no node is orphaned.

### Phase 3 — Script generation
- Generate per-scene dialogue constrained by: character canon sheet, scene goal, emotional beat, branch state, target word count.
- Use a **style guide + few-shot examples** of your own writing to keep voice consistent. Generate branch variants in one pass so tone matches.
- **Human pass is mandatory** — AI prose reads flat; edit for voice, subtext, and pacing.
- **Output format:** write to a structured format (Ren'Py `.rpy`, Yarn Spinner, Ink, or your own JSON) so it's engine-ready.

### Phase 4 — Art
- **Backgrounds:** text-to-image (SDXL/Flux) + inpainting; generate at high res, keep a consistent style LoRA or IP-Adapter reference.
- **Character sprites:** this is the hard part. Solutions: train a **LoRA per character**; use **ControlNet** (OpenPose) for pose consistency; generate a base and then expression variants via inpainting; or use a **Live2D-ready layered PSD** workflow.
- **CGs:** key scenes, same LoRA + scene-specific prompts.
- **Consistency checklist:** same face, outfit, palette, line weight across all outputs. Expect 5–10x more generation than final assets.
- **Ethics/legal:** verify licenses of base models and training data; disclose AI use where platforms require it (Steam requires disclosure).

### Phase 5 — Audio
- **Music:** generative tools (Suno, Udio, MusicGen) for themes; license carefully. Need loops, menu, emotional cues, route themes.
- **SFX:** freesound/licensed libraries.
- **Voice:** TTS (ElevenLabs, GPT-SoVITS, StyleTTS2) with a distinct voice model per character. Get consent/clarity on voice cloning. Alternatively, no VO + "sound novel" style.
- **Mixing:** normalize to broadcast-ish levels; VN audio is quiet and repetitive, so loop points matter.

### Phase 6 — Engine & implementation
- **Ren'Py** (recommended default): Python-based, purpose-built for VNs, best-in-class save/backlog/auto/skip/localization, easy Steam/itch builds. Best for almost all cases.
- **Naninovel (Unity)** — if you need 3D, complex minigames, or console ports.
- **Godot + Dialogic** — free, flexible, growing VN support.
- **Web (Ren'Py web / custom)** — for itch.io browser play.
- Implement: choice handling, flag store, route gating, endings, gallery/music room, achievements, settings (text speed, auto, volume, fullscreen).

### Phase 7 — QA
- **Automated:** script to walk the graph — assert every ending reachable, no dead ends, no unresolved flags, no missing assets.
- **Playtest:** reading pace, branch clarity, save/load integrity, typo pass.
- **Localization:** if multi-language, structure strings for extraction from day one.

### Phase 8 — Build & release
- Store page, capsule art, trailer (often a montage of CGs + key lines), demo (first act).
- Platforms: Steam (disclose AI content), itch.io, possibly console via publisher.
- Post-launch: endings guide, achievements, patches, maybe a "true route" DLC.

### Minimal viable stack (solo dev)
`LLM (script) → SDXL/Flux + LoRA (art) → Suno (music) → ElevenLabs (VO, optional) → Ren'Py → graph-validator script → Steam/itch`

### Biggest failure modes
1. **Inconsistent character art** — solve with per-character LoRA + ControlNet, budget for it.
2. **Flat AI prose** — always do a human editing pass; AI can't sustain voice over 50k words unaided.
3. **Untestable branch explosion** — lock the graph before writing prose; validate reachability programmatically.
4. **Licensing** — model licenses, voice cloning consent, and platform AI-disclosure rules.
5. **Scope** — a 3-route VN with 3 CGs each is already 20–40 hours of art. Start with a kinetic 1-hour vertical slice.
