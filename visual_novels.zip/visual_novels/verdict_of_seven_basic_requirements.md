# Verdict of Seven — Design Requirements Document

## 0. Executive Summary

**Working title:** Verdict of Seven
**Target playtime:** ~2 hours per route; ~10–12 hours for full completion
**Genre:** Detective mystery + trial debate + romance, delivered as a stacked-genre visual novel
**Setting:** A sealed magic academy. Seven cursed students trapped inside. Each night, one vanishes. Each morning, the protagonist must investigate, cross-examine, and deliver a verdict — naming the suspect whose spell caused the disappearance. They will fall in love with at least one of them.
**Core loop:** Morning investigation → evidence collection → trial debate → verdict → night (disappearance) → loop reset / route progression
**Target audience:** 16–30, fans of Danganronpa, Clannad, Steins;Gate, Slay the Princess, Fate/stay night

**The design thesis:** *Verdict of Seven* reads as a romance adventure — until the player realizes the story is three genres stacked on top of each other (romance, detective, mystery), each revealed through route progression. The time-loop mechanic is diegetic: the protagonist's curse rewinds the day when their verdict is wrong. Replay is not punishment; it's the plot. Hidden affection, a collectible item economy, and route-locking gates the true ending behind both breadth of investigation and moral restraint.

---

## 1. Characters

### 1.1 Protagonist

The player character is a first-person protagonist — a transfer student at the academy who bears one of the Seven Curses. Their curse: **they can rewind the day**, but only if they die or deliver a wrong verdict. The rewind is imperfect — they retain all memories (the "Reading Steiner" diegetic replay from Steins;Gate), but evidence and clues persist only as fragments in their notes.

**Gender selection (game startup):**
- The first screen presents a binary choice: **Male** or **Female** protagonist.
- This choice is **irreversible** — it locks the protagonist's gender and determines the cast composition for the entire game.
- The gender selection is **not cosmetic**: it flips the gender of all six suspects to the opposite of the protagonist, ensuring natural heterosexual romance dynamics.

**Cast configurations:**

| Player selects | Protagonist | Six suspects | Romance model |
|---|---|---|---|
| **Male** | Male transfer student | 6 female students | Male lead → female romance targets |
| **Female** | Female transfer student | 6 male students | Female lead → male romance targets |

- Each suspect has a **male and female variant** (name, portrait, voice, pronouns in dialogue). Personality archetype, magic specialty, curse, speech manner, and romance tone remain identical across variants.
- All dialogue references to the protagonist and suspects adapt pronouns and gendered words automatically.
- The gender selection persists across saves and cannot be changed between runs.

**Customization (post-gender, pre-game):**
- **Name entry** — the player types the protagonist's name; it is used by all characters in dialogue.
- **Ability allocation** — 3–5 core magical abilities displayed as moving bars on a stat screen. The player distributes a fixed pool of points (e.g., 15 points across 5 abilities). The chosen balance directly affects gameplay:
  - **Perception** — reveals hidden clues during investigation that low-Perception runs miss
  - **Persuasion** — unlocks additional debate options and weakens suspect alibis faster during trial
  - **Arcana** — allows casting detection spells; some clues require a minimum Arcana threshold
  - **Endurance** — extends investigation time window; low Endurance cuts the morning phase short
  - **Empathy** — raises hidden affection gain per interaction; unlocks emotional confession scenes
- The ability balance is committed before Day 1 and cannot be changed mid-route. It reshapes which clues are visible, which debate lines are available, and subtly influences which routes are easier to access — but **does not lock any route entirely**. Every ending is reachable from any build, but the path differs.

**Ability limits (design rule):**
- No ability can exceed its max bar (3 per stat on a 15-point budget)
- The stat screen is visible at any time from the menu
- At least one "optimal" clue on each route requires a stat that the player likely underinvested — ensuring no build is perfect

### 1.2 The Seven Cursed Students (suspects + romance targets)

Seven characters. One is the protagonist. Six are suspects and romance targets. Each has a distinct psychology, speech manner, magical specialty, and a curse that binds them to the academy. The curse system ties their disappearance mechanic to their character.

**Gender rule:** All six suspects are the **opposite gender** of the protagonist (see §1.1). Each suspect has a male and female variant — same personality, magic, curse, speech pattern, and romance arc — but with a gender-appropriate name, portrait, and voice. The table below shows both name variants.

| # | Role | Archetype | Magic Specialty | Curse | Romance Tone | Name (M/F) |
|---|---|---|---|---|---|---|
| 1 | **Protagonist** | Transfer student | Reality rewind | Can rewind the day; each rewind erases one of their memories permanently | — | (player-chosen gender) |
| 2 | **KAI / KAIA** | The prodigy | Ward / barrier magic | Trapped inside any barrier they cast; escaping requires someone else to break it | Gentle, protective; slow-burn romance | Kai (M) / Kaia (F) |
| 3 | **LYRA / LEO** | The rebel | Illusion / deception magic | Cannot tell a lie, but their illusions become real for one hour each midnight | Sharp, flirtatious; tsundere-coded | Lyra (F) / Leo (M) |
| 4 | **ELIAS / ELSA** | The scholar | Summoning / binding magic | Binds involuntarily to objects they touch; removing a binding costs the object's existence | Quiet, analytical; intellectual romance | Elias (M) / Elsa (F) |
| 5 | **SERENA / SERAPH** | The athlete | Elemental (fire) magic | Their fire never extinguishes; they are dying of slow combustion | Energetic, loyal; childhood-friend-coded | Serena (F) / Seraph (M) |
| 6 | **DANTE / DANIELLE** | The outcast | Necromancy / spirit magic | Haunted by the spirits they've summoned; the spirits speak through them during trials | Brooding, mysterious; tragic romance | Danielle (F) / Dante (M) |
| 7 | **MIRA / MIRAN** | The wildcard | Chaos / probability magic | Their luck inverts — what should go right goes wrong, and vice versa | Playful, unpredictable; chaotic-good romance | Mira (F) / Miran (M) |

**Speech manner differentiation (hard requirement):**
Same across both gender variants. Labels use the female names (male names behave identically):
- **Kaia** — formal, measured; uses honorifics; speaks in complete sentences; never raises voice
- **Lyra** — colloquial, sarcastic; short sentences; uses rhetorical questions; addresses the protagonist by nickname
- **Elsa** — academic, precise; cites sources; uses conditional clauses ("If my analysis is correct…")
- **Serena** — energetic, exclamatory; uses action metaphors; interrupts herself mid-thought
- **Danielle** — slow, deliberate; speaks in fragments; references the dead; long pauses before answering
- **Mira** — rapid, tangential; uses slang; mid-sentence topic shifts; laughs at their own jokes

**The Night Mechanic:**
Each night, exactly one of the six suspects disappears. The disappearance is caused by one of the other five (or sometimes by the curse itself acting autonomously). The morning investigation reveals what happened. The trial determines who did it. A **correct verdict** advances the story. A **wrong verdict** triggers a time-loop rewind to the start of that day.

### 1.3 Supporting Characters

- **The Headmaster** — an unseen presence; communicates only through broadcast announcements and sealed letters. Motive unknown until late-game.
- **The Academy Spirit** — the building itself is semi-sentient; it shifts corridors and locks/unlocks rooms based on the curses' interactions. Serves as an ambient "environmental suspect."
- **The Previous Student** — glimpsed only in loop-fragment memories and collected evidence. Their failed verdict is the reason the current cycle exists.

---

## 2. Gameplay Systems

### 2.1 The Core Loop (per day)

Each "day" consists of four phases:

```
DAWN (brief — 1–2 minutes)
  │  Waking scene. One suspect is missing. Brief recap of last night's verdict.
  │  If this is a loop-rewind: disorienting transition; fragmented memory;
  │    the ability stat screen briefly flashes (one point lost from Perception, permanent decay)
  │
INVESTIGATION (5–8 minutes)
  │  The protagonist explores the academy's accessible rooms.
  │  Evidence collection: click-to-examine objects, read notes, interrogate suspects.
  │  Ability checks: Perception reveals hidden items; Arcana detects residual magic;
  │    Empathy unlocks personal confessions that hint at guilt/innocence
  │  Collectible items can be found in rooms (see §2.4)
  │  Timer: Endurance stat determines how long this phase lasts
  │
TRIAL / DEBATE (3–5 minutes) — Danganronpa-style cross-examination
  │  The gathered evidence and suspect testimonies are presented.
  │  The protagonist must identify contradictions in testimony vs. evidence.
  │  Three rounds of "Point Out" → "Press" → "Reveal Contradiction."
  │  Persuasion stat unlocks additional pressing options.
  │  Fail state: incorrect contradiction → damage to a "resolve" meter;
  │    resolve depletion = wrong verdict → loop rewind
  │
VERDICT (1–2 minutes)
  │  The protagonist names the suspect who cast the spell.
  │  Correct: the accused is bound by the academy's judgment; story advances.
  │  Incorrect: the protagonist dies (or the curse rewrites reality); LOOP REWIND.
  │
NIGHT (1–2 minutes — cinematic)
  │  The remaining suspects gather. Tension builds.
  │  One disappears in a scripted sequence. The method varies per disappearance.
  │  Affection flags shift based on who survived and who was accused.
  │
DAWN → repeat (or route conclusion)
```

**Day count:** 6 days = 6 disappearances. After the 6th verdict, the final disappearance reveals the true nature of the curse, and the story branches into route endings.

### 2.2 Trial / Debate System

A Danganronpa-inspired cross-examination, adapted for a visual novel engine:

**Testimony Block:**
Each suspect gives a multi-line testimony (4–8 lines). Lines are displayed as a vertical block. The protagonist can:
1. **Point Out** — select a specific line in the testimony
2. **Press** — challenge that line with evidence from the investigation
3. **Reveal Contradiction** — if the evidence directly contradicts the testimony, the contradiction is exposed

**Mechanics:**
- Each testimony has exactly **one true contradiction** per day (the mechanical "solution")
- Additional "soft contradictions" exist (factually inconsistent but not proof of guilt) — pressing these yields information but doesn't advance the trial
- The **Persuasion stat** unlocks bonus "Press" options that make contradictions easier to spot (additional hint text appears)
- The resolve meter (3 hearts) depletes by 1 for each failed press. Depletion = trial failure = loop rewind
- Some trials have **trap testimonies** — lines that appear contradictory but are actually true (testing the player's evidence reading)
- A correct full resolution of all contradictions in a trial unlocks a **bonus confession scene** with the cleared suspect (affection + collectible item reward)

### 2.3 Time Loop System

The loop is diegetic and tracked by the game's fiction:

**Loop Rules:**
1. A wrong verdict triggers a rewind to the DAWN of the same day
2. The protagonist retains all memories (Reading Steiner model)
3. Each loop permanently costs **1 Perception point** (decaying stat, visible on stat screen). After 3 loops on the same day, the protagonist can no longer find hidden Perception-gated clues that day
4. Evidence found in prior loops is recorded in the protagonist's **Investigation Notes** (a persistent log per day). Notes survive loops; the player can review them at any time
5. The Investigation Notes accumulate across loops — a loop-strategy game: "What did I see last time that I missed?"
6. Maximum loops per day: 4 (on the 4th failed verdict, the game soft-locks the day with a "curse collapse" scene and forces a bad ending — this is the failure floor)

**Design intent:** The loop is not a punishment but a puzzle-solving tool. The first pass gathers testimony; the second pass applies evidence with fresh knowledge; the third pass reveals hidden clues. The Perception decay creates urgency without wall-of-text failure screens.

### 2.4 Collectible Item Economy

Borrowed from Clannad's Light Orb system: items persist in a global, cross-save store and gate late-game content.

**Items:**
- **Cursed Fragments** — collectible objects found during investigation. Each room contains 0–2 fragments. Some are guaranteed; some require a specific ability threshold or correct loop strategy.
- Total available per day: 3–5 fragments
- Total available across 6 days: ~22 fragments

**Fragment Tiers:**
| Tier | Count | Requirement |
|---|---|---|
| **Common** | 12 | Guaranteed in one room per day if investigated properly |
| **Rare** | 7 | Requires specific ability threshold OR correct verdict on a specific day |
| **Unique** | 3 | Requires reaching a specific route's midpoint |

**Unlock Thresholds (global, persistent across saves):**
| Threshold | Unlocks |
|---|---|
| **8 Cursed Fragments** | After Story (post-game epilogue arc, +2 hours of content) |
| **15 Cursed Fragments** | All six character epilogues (one per suspect, ~10 minutes each) |
| **22 Cursed Fragments (all)** | True Ending — the complete resolution of the curse |

**Design rules:**
- Fragments are stored in **global system data**, not the save file. Deleting saves does not reset fragment count (Clannad model)
- The fragment count is **never shown as a number in the main UI** — it is visible only on the character stat screen and the fragment collection gallery
- The game **never explains** the fragment requirement in-game. Players discover it through exploration and the After Story unlock signal
- One fragment **disappears from the gallery mid-game** and reappears during the final day — a designed "you are not finished" signal (Clannad's vanishing orb)

### 2.5 Resource Management & Inventory

The protagonist has a simple inventory:

**Inventory Slots:** 5 slots for evidence items (carried from investigation to trial)
- Evidence items auto-fill from investigation; the player selects which 5 to bring
- Evidence items are consumed when used in a trial (used once, then gone)
- Some evidence items are **multi-use** (can be pressed against multiple testimonies)

**Cursed Fragment display:** Not in the active inventory. Fragments auto-collect and go to the persistent gallery.

**No other resource management.** There is no mana system, no currency, no consumable spells. The economy is entirely:
1. Time (Endurance-limited investigation window)
2. Attention (which clues to pursue, which suspects to interrogate)
3. Verdict accuracy (trial resolve meter)

---

## 3. Branching Narrative and Route Structure

### 3.1 Route Topology

```
DAY 1 — DAY 5 (common trunk, loop-enabled)
    │  Each day: Investigation → Trial → Verdict → Night (disappearance)
    │  Affection counters accumulate silently
    │
    │  DAY 6 VERDICT determines route lock
    │
    ├─ Correct verdict + balanced affection → COMMON ENDING (neutral conclusion)
    │
    │  Post-Day-6: route-lock flags checked
    │
    ├─ Kaia/Kai route lock   → Kaia Good End / Kaia Bad End
    ├─ Lyra/Léo route lock   → Lyra Good End / Lyra Bad End
    ├─ Elsa/Elias route lock → Elsa Good End / Elsa Bad End
    ├─ Serena route lock    → Serena Good End / Serena Bad End
    ├─ Danielle route lock  → Danielle Good End / Danielle Bad End
    ├─ Mira/Miran route lock → Mira Good End / Mira Bad End
    │
    │  All six good ends cleared + 8 fragments → AFTER STORY
    │  All 22 fragments collected → TRUE ENDING (after After Story)
    │
    │  Bad endings per route (wrong verdicts, affection failure):
    ├─ "The Cage"           → accused an innocent suspect on Day 6
    ├─ "Curse Collapse"     → exceeded loop limit on any day
    ├─ "Erased"             → chose to sacrifice oneself to save a suspect
    └─ "The Academy Wins"   → all suspects eliminated; protagonist alone
```

**Route Lock Mechanics:**
- Route locks are **silent** — the game never announces "You're entering Kai's route"
- The lock is determined by accumulated affection counters checked at the Day 6 verdict
- The pivot is a single Day 6 testimony line: who the protagonist chooses to **defend** in their final words
- Once locked, the route plays to its conclusion (good or bad ending)
- To see a different route: restart from the common intro and build different affection

### 3.2 Route Characteristics (genre stacking)

Each route reveals a different genre layer of the story:

| Route | Primary Genre | What It Reveals |
|---|---|---|
| **Kaia/Kai** | Romance | The emotional truth: the headmaster is the protagonist's lost sibling |
| **Lyra/Léo** | Mystery | The mechanical truth: the curses are the academy's protection, not punishment |
| **Elsa/Elias** | Detective | The factual truth: the Previous Student's journal explains the full history |
| **Serena/Seraph** | Action / thriller | The physical truth: the academy is collapsing; time is running out |
| **Danielle/Dante** | Horror / psychological | The dark truth: the spirits are the previous cycle's victims |
| **Mira/Miran** | Meta / surreal | The narrative truth: the loops are not rewind — they're parallel reads by the Academy Spirit |

**Design intent (from Fate/stay night):** Repeating the same 6 days under a different genre reframes previously-seen events. A clue that read as a love confession in Kaia's route reads as a death threat in Danielle's. The player's prior knowledge (from loops and completed routes) is the unlock.

### 3.3 Endings

| Ending | Type | Trigger |
|---|---|---|
| **Kaia Good** | Character ending | Kaia route lock + correct final choices |
| **Lyra Good** | Character ending | Lyra route lock + correct final choices |
| **Elsa Good** | Character ending | Elsa route lock + correct final choices |
| **Serena Good** | Character ending | Serena route lock + correct final choices |
| **Danielle Good** | Character ending | Danielle route lock + correct final choices |
| **Mira Good** | Character ending | Mira route lock + correct final choices |
| **Kaia Bad** | Bad ending | Kaia route lock + failed final choices |
| **Lyra Bad** | Bad ending | Lyra route lock + failed final choices |
| **Elsa Bad** | Bad ending | Elsa route lock + failed final choices |
| **Serena Bad** | Bad ending | Serena route lock + failed final choices |
| **Danielle Bad** | Bad ending | Danielle route lock + failed final choices |
| **Mira Bad** | Bad ending | Mira route lock + failed final choices |
| **"The Cage"** | Bad ending | Accused an innocent on Day 6 |
| **"Curse Collapse"** | Bad ending | Exceeded loop limit (4 wrong verdicts on one day) |
| **"Erased"** | Bad ending | Self-sacrifice choice on any day (1 specific choice per day) |
| **"The Academy Wins"** | Bad ending | Accumulated 4+ bad endings; final solo run |
| **Common Ending** | Normal ending | Balanced affection; no route lock at Day 6 |
| **After Story** | Post-game arc | 8+ Cursed Fragments + all 6 good ends |
| **True Ending** | **True / final ending** | All 22 fragments + After Story cleared |

**After Story** is a standalone 2-hour arc set after the common resolution. It ties together the genre layers from all six routes and confronts the headmaster. It has its own endings (good/bad) but does not gate the True Ending — only fragment count does.

---

## 4. Story Flags and Variables

### 4.1 Flag Taxonomy

| Category | Variables | Description |
|---|---|---|
| **Protagonist gender** | `protagonist_gender` (enum: male/female, global) | Set at game startup. Irreversible. Determines suspect cast gender. Stored in persistent system data. |
| **Per-suspect affection** | `affection_kaia` … `affection_mira` (integers, 0–15) | Hidden counters. Each route-relevant choice adds +1 or +2 to one or more suspects. Checked at Day 6 for route lock. |
| **Route lock** | `route_locked` (enum: none/kaia/lyra/elsa/serena/danielle/mira) | Set at Day 6 verdict. Irreversible. Determines post-Day-6 content. |
| **Day verdict** | `verdict_day[1..6]` (correct / incorrect / who accused) | Records each day's outcome. Checked by bad-ending triggers. |
| **Loop count** | `loops_day[1..6]` (integer, 0–4) | Per-day loop counter. At 4 → "Curse Collapse" bad ending. |
| **Evidence collected** | `evidence_day[1..6][item_id]` (boolean) | Per-day, per-evidence tracking. Powers trial logic. |
| **Cursed Fragments** | `fragment_count` (integer, global) | **Persistent system data**, not save-dependent. Gates After Story (≥8) and True Ending (≥22). |
| **Good end flags** | `good_end_kaia` … `good_end_mira` (boolean, global) | Persist across saves. All 6 required for After Story. |
| **Perception decay** | `perception_remaining` (integer, starts at allocated value) | Decrements by 1 per loop. Affects clue visibility. |
| **After Story cleared** | `after_story_done` (boolean, global) | Required for True Ending eligibility. |
| **Bad ending count** | `bad_end_count` (integer, global) | At 4+ → "The Academy Wins" becomes available on next run. |
| **Trap choice flags** | `trap_choice_day[1..6]` (boolean) | Mark when the protagonist took the emotionally comfortable but wrong choice (White Album 2 model). Gate bad endings and certain rare fragments. |

### 4.2 Flag Read Points

- **Every trial:** reads `evidence_day` for available presses; reads `persuasion` stat for bonus options
- **Every verdict:** reads `verdict_day`; on incorrect, increments `loops_day`; checks loop limit
- **Every investigation:** reads `perception_remaining` for hidden clues; reads `empathy` stat for confession scenes
- **Day 6 verdict:** reads all `affection_*` counters → sets `route_locked`
- **Post-Day-6:** reads `route_locked` → loads route-specific content
- **Ending screen:** reads `good_end_*` / `bad_end_count` / `after_story_done` / `fragment_count` → displays unlock status
- **Title screen:** checks `good_end_*` (all 6) + `fragment_count ≥ 8` → shows After Story button; checks `protagonist_gender` (enum: male/female) → loads correct cast configuration

---

## 5. Relationship and Affection System

### 5.1 Mechanics

Affection is **invisible**. The player never sees affection numbers. Affection is modeled as hidden integer counters (0–15 per suspect) that accumulate from:
- Interrogation tone choices during investigation (gentle vs. aggressive)
- Trial verdict alignment (accusing someone with low affection costs more trust)
- Bonuses from correct trial resolutions (defending an innocent suspect raises their affection)
- Empathy stat bonus (high Empathy adds +1 to random suspect per day)
- Self-sacrifice choices (raises one suspect's affection maximally but triggers "Erased" bad ending)

**Route lock threshold:** the suspect with the **highest affection at Day 6** locks the route. Ties break in favor of the suspect the protagonist defended in their final Day 6 testimony line.

### 5.2 Visible Relationship UI

Despite hidden counters, the game provides a **visible relationship indicator**:

- **Relationship Hearts** — a small UI element showing 1–5 hearts per suspect. Hearts update only at the end of each day, not per choice. This is a soft, imprecise indicator (not a direct mapping to the counter):
  - 0 hearts: 0–2
  - 1 heart: 3–5
  - 2 hearts: 6–8
  - 3 hearts: 9–11
  - 4 hearts: 12–14
  - 5 hearts: 15
- The heart display is available on the character stat screen
- It is intentionally **slightly misleading** — hearts update with a one-day delay, so the current day's changes are not yet visible. This prevents the player from perfectly reverse-engineering the counter

### 5.3 Relationship Dynamics

| Relationship | Nature | How it Moves |
|---|---|---|
| **Protagonist ↔ Kaia/Kai** | Protective, warm | Rises through defending Kaia in trial; falls through aggressive interrogation |
| **Protagonist ↔ Lyra/Léo** | Flirtatious tension | Rises through playful interrogation; falls through pressing Lyra's insecurities |
| **Protagonist ↔ Elsa/Elias** | Intellectual bond | Rises through matching Elsa's analytical dialogue options; falls through dismissing evidence |
| **Protagonist ↔ Serena/Seraph** | Loyal, energetic | Rises through protecting Serena during danger scenes; falls through accusing Serena |
| **Protagonist ↔ Danielle/Dante** | Trust / vulnerability | Rises through listening to spirit-possessed testimony; falls through ignoring Danielle's warnings |
| **Protagonist ↔ Mira/Miran** | Chaotic friendship | Rises through going along with Mira's tangents; falls through treating Mira frivolously |
| **Suspect ↔ Suspect** | Side dynamics | Certain suspect pairs have pre-existing relationships (Kaia protects Serena; Lyra and Mira banter; Elsa and Danielle share research). These are authored, not player-managed. |

---

## 6. UI Requirements

### 6.1 Screens

| Screen | Contents | Access |
|---|---|---|
| **Main game** | Dialogue box, character sprite, background, choice buttons | Primary |
| **Investigation** | Room view, clickable hotspots, evidence panel, timer (Endurance) | Investigation phase |
| **Trial / Debate** | Testimony block, evidence inventory, suspect sprite, resolve meter, choice buttons | Trial phase |
| **Character stat screen** | Protagonist portrait, name, ability bars (Perception/Persuasion/Arcana/Endurance/Empathy), Cursed Fragment count, relationship hearts | Menu button (always available) |
| **Flowchart** | Visual tree of visited scenes, branching points, and locked/unlocked paths. Colored nodes: visited (green), available (yellow), locked (gray). Shows loop count per day. | Menu button |
| **Investigation Notes** | Persistent log of clues, evidence, and observations. Survives loops. Organized by day and room. | Menu button |
| **Fragment Gallery** | Collection display of all Cursed Fragments with descriptions. One fragment is "question-marked" (the vanishing fragment). | Menu button, unlocks after first fragment |
| **Save/Load** | Multiple named save slots (minimum 10), quick save, quick load, auto-save at each DAWN | Menu button |
| **Backlog** | Scrollable text history with voice replay (if voiced) | Menu button |
| **Settings** | Text speed, auto-advance, skip-read-text, volume, fullscreen | Menu button |
| **Ending List** | Tracks which endings have been obtained, with thumbnail art | Title screen, after first ending |
| **Title Screen** | Game title, New Game, Continue, Load, Settings, Ending List, After Story (when unlocked) | Startup |

### 6.2 Flowchart Design

The flowchart is a core navigation tool and follows these rules:
- **No free scene select** — the flowchart is informational, not interactive. Players cannot click a node to jump there (Steins;Gate / Clannad model). To see a different branch, the player must reload an earlier save or restart.
- The flowchart shows **visited, available, and locked** nodes
- Each day is a horizontal row; branches within a day are vertical
- Loop nodes are shown as loops back to the DAWN node
- Locked routes (post-Day-6) are visible as grayed branches
- The flowchart does **not** reveal which nodes lead to which ending — it only shows the player's traversal history and available paths

---

## 7. Save, Load, and Replay

### 7.1 Save System

- **Named save slots:** minimum 10
- **Quick save / quick load:** always available
- **Auto-save:** at each DAWN (start of day), after each verdict, and at the title screen
- **No mid-scene save restriction** — the player can save at any non-interactive moment

### 7.2 Replay Design

- **No free chapter/scene select.** To see a different route, the player must:
  1. Load an early save (common intro) and make different choices, OR
  2. Start a new game
- **Skip-read-text** and **auto-advance** are essential for tolerable replay (the common intro repeats every route)
- **Backlog** with text replay supports investigation review across loops
- **Investigation Notes** persist within a save but not across saves — a new game starts with a fresh log

### 7.3 Persistent Data (survives save deletion)

- **Cursed Fragments** (`fragment_count`)
- **Good end flags** (`good_end_kaia` … `good_end_mira`)
- **Bad end count** (`bad_end_count`)
- **After Story clear** (`after_story_done`)
- **True ending clear**

This persistent system ensures that progress toward completion is never lost, even if the player deletes all saves. It also means that "new game" feels like continuation, not erasure — the meta-progression is the game's accumulation of care.

---

## 8. Inventory and Items

### 8.1 Evidence Inventory (per-route)

| Property | Value |
|---|---|
| **Slots** | 5 |
| **Source** | Investigation phase (click-to-collect from room hotspots) |
| **Consumption** | Used once in trial, then removed (unless marked multi-use) |
| **Carry between phases** | Yes (investigation → trial) |
| **Carry between days** | No (each day's evidence resets) |
| **Carry between loops** | No (but Investigation Notes record what was found) |

### 8.2 Cursed Fragments (persistent, global)

| Property | Value |
|---|---|
| **Source** | Hidden in investigation rooms (0–2 per room) |
| **Collection** | Automatic on contact; no inventory slot needed |
| **Persistence** | Global system data, survives save deletion |
| **Visibility** | Gallery only; count shown on stat screen |
| **Function** | Unlocks After Story (≥8), character epilogues (≥15), True Ending (≥22) |
| **Special behavior** | One fragment vanishes mid-game and returns on the final day |

### 8.3 Narrative Items (MacGuffins)

These are story objects that carry meaning and act as emotional flags:

| Item | Role |
|---|---|
| **The Previous Student's Journal** | Found across days; entries unlock in Elsa's route; explains the full curse history |
| **The Headmaster's Sealed Letters** | One per day; contents vary by route; tie into genre reveals |
| **The Academy Map** | Shifts between loops; rooms appear/disappear; tracking the map reveals the academy's sentience |
| **The Cursed Bracelets** | Each suspect wears one; their magical signatures are evidence items on specific days |
| **The Protagonist's Rewind Watch** | Diegetic representation of the rewind ability; cracks with each loop |

---

## 9. Multiple Endings — Complete Specification

### 9.1 Ending Classification

| Count | Category |
|---|---|
| 6 | Character good endings (one per suspect) |
| 6 | Character bad endings (one per suspect) |
| 4 | Structural bad endings (The Cage, Curse Collapse, Erased, The Academy Wins) |
| 1 | Common/normal ending |
| 2 | After Story endings (good / bad) |
| 1 | True ending |
| **20 total** | |

### 9.2 True Ending Conditions (all must be met)

1. All 6 character good endings cleared (persistent flags)
2. After Story cleared (persistent flag)
3. All 22 Cursed Fragments collected (persistent counter)

The True Ending is a completion reward, not a skill check. It is unlocked by **having investigated every angle and cared about every suspect**, which thematically equates the player's thoroughness with the protagonist's ability to truly understand the curse.

### 9.3 Bad Ending Design Philosophy

Bad endings are **written as plausible, painful continuations**, not punishment screens (White Album 2 model). "The Cage" is not a game-over screen — it's a scene where the protagonist watches an innocent suspect suffer the curse's punishment and realizes too late. "Curse Collapse" is a scene where the protagonist's memories fragment and they can no longer tell past from present.

---

## 10. Technical and Production Constraints

### 10.1 Engine Requirements

- Visual novel engine supporting:
  - Branching narrative with hidden flag tracking
  - Persistent global data (separate from save files)
  - Multiple save slots with thumbnails
  - Backlog with text/voice replay
  - Auto-advance and skip-read-text
  - Flowchart system (informational display, not scene-select)
  - CG gallery and music gallery
  - Custom UI for: ability stat bars, relationship hearts, evidence inventory, resolve meter, trial testimony block

### 10.2 Content Budget

| Asset | Count |
|---|---|
| **Character sprites** | 15 (protagonist × 2 gender variants + 6 suspects × 2 gender variants, minus unused set) × 4–6 expressions each = 56–84 sprites (render only the active gender set at runtime) |
| **Backgrounds** | ~15 (academy rooms: hallway, library, dorm, chapel, infirmary, boiler room, greenhouse, observatory, headmaster's office, courtyard, courtyard-night, common room, classroom, spirit room, academy exterior) |
| **CG images** | ~20 (one per good ending × 6, one per bad ending × 4, After Story × 4, True Ending × 2, common ending × 1, intermediate route CGs × 3) |
| **Voice lines** | Optional. If voiced: ~30,000–40,000 words of dialogue |
| **Music tracks** | ~15 (main theme, 6 suspect leitmotifs, investigation, trial, loop-rewind, night, After Story, True Ending, bad ending, common ending, title, credits) |
| **UI elements** | Stat screen, flowchart, evidence panel, testimony block, resolve meter, relationship hearts, fragment gallery, save/load, settings, ending list |

### 10.3 Playtime Budget

| Content | Target |
|---|---|
| Common route (Days 1–6, one pass) | ~40–50 minutes |
| One character route (post-Day-6) | ~15–20 minutes |
| Average loop (rewind of one day) | ~5–8 minutes |
| After Story | ~90–120 minutes |
| All 6 good ends + After Story + True Ending | ~10–12 hours |

---

## 11. Mechanics Heritage (Source Attribution)

| Mechanic | Source Game | Adaptation |
|---|---|---|
| **Genre-stacked routes** | Fate/stay night | 6 routes = 6 genre reframes of the same 6 days |
| **Persistent collectible gating** | Clannad (Light Orbs) | Cursed Fragments gate After Story (8) and True Ending (22) |
| **Vanishing collectible** | Clannad | One fragment disappears mid-game, returns on final day |
| **Global system data** | Clannad + DDLC | Fragments and ending flags persist outside save file |
| **Diegetic time loops** | Slay the Princess + Steins;Gate | Loop = diegetic rewind; protagonist retains memories (Reading Steiner) |
| **Loop as save/load** | Slay the Princess | Wrong verdict = loop; replay is the load screen |
| **Hidden affection counters** | Fate/stay night + Clannad | Invisible 0–15 counters; route lock at Day 6 |
| **Silent route pivot** | Clannad + Steins;Gate | Game never announces branch; attention = input |
| **Visible but imprecise relationship UI** | VA-11 Hall-A (inverse) | Hearts are visible but delay-updated, preventing perfect optimization |
| **Trial debate system** | Danganronpa (reference) | Testimony → Point Out → Press → Contradiction; resolve meter |
| **Trap choices** | White Album 2 | Emotionally comfortable option → bad ending; honest/painful → good |
| **Protagonist stat allocation** | Original design (per concept doc) | 3–5 abilities with point budget; affects clue visibility and debate options |
| **Flowchart (informational only)** | 999 (remaster FLOW Chart, read-only) | Shows visited paths; no scene-select |
| **Bad endings as written tragedy** | White Album 2 | Plausible, painful scenes — not game-over screens |
| **One verb = tension** | VA-11 Hall-A | Investigation attention and trial verdicts are the entire interaction vocabulary |
| **Meta-progression as theme** | Clannad | Thoroughness = understanding = breaking the curse |
| **Completion reward = true ending** | Fate/stay night + Steins;Gate | Gate the best ending behind breadth of care, not skill |

---

## 12. Non-Goals

What this game is **not**:
- Not a dating sim with free-text romance
- Not a strategy game with build optimization
- Not a horror game (despite Danielle/Dante's route — horror is a genre layer, not the primary tone)
- Not a choice-every-3-lines game (interactivity is focused on investigation and trial, not every dialogue line)
- Not a save-scumming dependency (loops are diegetic and tracked; the game is playable without manual reloading)
- Not Danganronpa (the trial system is inspired by it, but the game has no combat, no minigame timing, and a smaller scope)

---

## Appendix A — Day-by-Day Summary (Skeleton)

| Day | Disappearing Suspect | Key Evidence | Genre Focus | Fragment Availability |
|---|---|---|---|---|
| 1 | Serena | Burned curtains, elemental residue | Introduction / tutorial | 3 common |
| 2 | Danielle | Spirit residue, sealed door | Mystery deepens | 4 common + 1 rare |
| 3 | Mira | Probability anomalies, inverted luck objects | Investigation complexity | 4 common + 1 rare |
| 4 | Elsa | Summoning circle, missing object | Mid-point twist | 3 common + 2 rare |
| 5 | Kaia | Broken barrier, trapped magical signature | Romance tension peak | 4 common + 1 rare + 1 unique |
| 6 | Lyra/Léo | Illusion residue, revelation evidence | Final verdict → route lock | 4 common + 2 rare + 1 unique + 1 unique |

**Vanishing fragment:** disappears from gallery after Day 3, reappears on Day 6's final investigation.

---

## Appendix B — Ability Stat Effects Table

| Stat | Investigation Effect | Trial Effect | Narrative Effect |
|---|---|---|---|
| **Perception** | Unlocks hidden clues in 3 rooms/day (Perception ≥ 2). Decays by 1 per loop. | Reveals subtle inconsistencies in testimony (Perception ≥ 3) | Certain confession scenes require Perception ≥ 2 |
| **Persuasion** | — | +1 bonus Press option per testimony round (Persuasion ≥ 2). Resolve meter depletes slower (Persuasion ≥ 3) | Debate dialogue flavor; more authoritative voice |
| **Arcana** | Can cast detection spell (reveals magical residue on 2 objects/day, Arcana ≥ 2) | Can identify magical contradictions in testimony (Arcana ≥ 3) | Certain magic-related clues are only visible with Arcana ≥ 2 |
| **Endurance** | Investigation timer +30 seconds per point | — | Low Endurance (<2): protagonist mentions fatigue, affecting tone |
| **Empathy** | Unlocks emotional confession scene per suspect (Empathy ≥ 2). +1 random affection/day (Empathy ≥ 3) | — | Romance scenes are deeper and longer |
