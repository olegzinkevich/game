# Visual Novel Plots and Concepts: Market Report

*Prepared 2026-09-23. Sources are listed at the end. Market-size figures from commercial research firms vary widely and should be taken as rough signals, not facts (see the caveats in section 1).*

---

## 1. Market snapshot

| Signal | Figure | Source |
|---|---|---|
| Visual Novel-tagged games on Steam | ~15,400 titles, ~$470M total revenue, **median revenue ≈ $0** | games-stats.com |
| Share of all-time Steam RPG revenue | Visual Novel ≈ 3.2% of the Role-Playing category | GameDiscoverCo |
| Platform split (all VNs, 2025) | Mobile 38.6%, PC 31.2%, Console 24.5% | Dataintelo |
| Revenue by age group (2025) | Adults 18+ ≈ 62%, teens 13–17 ≈ 30% (teens growing fastest) | Dataintelo |
| China's otome market | ¥21.9B (2015) → ¥72.8B (2024) | QY Research via T&F Online |
| Doki Doki Literature Club | 30M+ players | Hey Poor Player, Dec 2024 |
| Dispatch (2025) | 1M copies in 10 days, 3M+ by year end | VGChartz, GameDiscoverCo |

**What the numbers say:**

1. **The genre is crowded and hit-driven.** Thousands of VNs are released on Steam every year, and the median title earns almost nothing. A generic premise does not survive; the hook has to be visible in the capsule art and the first line of the store description.
2. **The audience is loyal and eats a lot.** Analysts at How To Market A Game put VNs among the "non winner-take-all" genres: fans buy many titles, not only the one top hit. A good niche title can find buyers.
3. **Mobile is the largest platform by revenue,** driven by free-to-play otome and romance story apps (Love and Deepspace, Episode, Chapters, Romance Club). PC/Steam is where premium, author-driven indie VNs break out.
4. **Caveat on market reports.** Different firms estimate the "visual novel market" at anything from ~$1.3B (WiseGuy) to ~$9.4B (Dataintelo) for 2025, depending on whether they count gacha and story apps. Use them for direction, not for exact numbers.

---

## 2. Which plots are most popular

Popularity was judged from three angles: Steam user ratings (Steam 250 "Visual Novel" ranking), commercial breakouts, and the dominant categories on mobile story apps.

### 2.1 Top-rated VNs on Steam and their plot types

| Title | Year | Plot type |
|---|---|---|
| Dispatch | 2025 | Workplace comedy + superhero drama, romance options |
| Doki Doki Literature Club! | 2017 | Cute dating sim turning into meta psychological horror |
| Volcano Princess | 2023 | Parenting/life sim with branching fates |
| Senren＊Banka | 2020 | Classic Japanese romance with folklore elements |
| Magical Girl Witch Trials | 2025 | Detective / death game with a magical-girl cast |
| The Coffin of Andy and Leyley | 2023 | Dark comedy psychological horror about toxic siblings |
| Danganronpa: Trigger Happy Havoc | 2016 | Detective / death game |
| Steins;Gate | 2016 | Sci-fi time travel thriller |
| Needy Streamer Overload | 2022 | Internet culture satire, psychological horror |
| The Hungry Lamb | 2024 | Historical dating sim (Ming dynasty China) |
| Slay the Princess | 2023 | Branching psychological horror, loop structure, romance undertones |

### 2.2 Ranking of plot families by current audience pull

1. **Romance (in every form).** Still the backbone of the genre. It is the stated number one genre in every market report and dominates mobile. Even in Dispatch, a non-romance-first game, only ~5% of players finished without romancing someone. *Romance works best as a layer on top of another hook, not as the only hook.*
2. **Psychological horror / "genre subversion".** The most viral plot family on PC. DDLC, Slay the Princess, Coffin of Andy and Leyley, Needy Streamer Overload. It starts cute or normal and breaks. It's perfect for streamers and TikTok reaction clips.
3. **Mystery, detective, and death game.** Danganronpa, Magical Girl Witch Trials, Ace Attorney, Murder of Sonic. Players love solving mysteries along with the protagonist and arguing about theories online.
4. **Sci-fi / time loop / thriller.** Steins;Gate, 13 Sentinels, Zero Escape, Slay the Princess's loop structure. Loops fit the VN format naturally, since replaying routes becomes part of the story.
5. **Cozy / slice-of-life / "found family".** Coffee Talk, Volcano Princess, Clannad. Low stress, high emotion, strong word-of-mouth among cozy gamers.
6. **Mobile romance tropes.** On Episode, Chapters, and Romance Club the top categories are recognizable book tropes: *mafia romance, werewolf/alpha, contract/arranged marriage, forbidden romance, billionaire, royal drama, vampire, academy drama*. These mirror the Wattpad and BookTok best-seller lists.
7. **Adult (18+) content.** Large by volume ("Sexual Content" is one of Steam's most-populated tags) but platform-risky: Steam removed several adult VNs in 2025–2026. It is a separate business with its own distribution channels.

### 2.3 Common traits of the hits

- **A one-sentence hook that contains a contradiction:** "a dating sim that is a horror game", "a superhero game where you are the dispatcher", "magical girls on trial for murder".
- **The player's choices visibly change the story.** "Choices Matter" and "Multiple Endings" are among the most common tags on top-rated titles.
- **A small, intense cast.** 3–6 main characters with strong designs. Fans generate fan art, memes, and shipping.
- **Streamability.** Moments where the viewer reacts: a twist, a jump scare, a meta trick, a painful choice.
- **Short-to-medium length.** Many breakouts take 2–10 hours (DDLC, Slay the Princess, Needy Streamer). Long epics (Steins;Gate, Fata Morgana) succeed through reputation over years, not on launch.

---

## 3. Age and gender distribution by plot

No platform publishes precise age data per plot. The table below combines the survey and market data found (MangaGamer licensing survey; Dataintelo segmentation; academic otome studies; VNDev Wiki demographic notes) with patterns visible in store data. Treat it as an informed estimate.

### 3.1 Available hard data

- **MangaGamer's reader survey** (English-language localized Japanese VNs): 73% male, 23.5% female; 86% aged 18–30, and of those 62.5% aged 18–24.
- **Love and Deepspace** (3D otome gacha): about 86% female, with roughly half the players under 25, according to industry analysis. Chinese otome studies interview mostly women aged 18–25, students and young office workers.
- **Market reports:** adults (18+) generate ~62% of VN revenue; teens (13–17) ~30%, concentrated on mobile, free-to-play otome, school romance, and idol themes. Adult males 18–35 are the core of PC VN revenue.

### 3.2 Plot × audience map

| Plot family | Core age | Gender lean | Main platform | Notes |
|---|---|---|---|---|
| School romance / slice of life | 13–24 | Mixed (male for galge, female for otome) | Mobile, Switch | Cheapest to enter, most crowded |
| Otome / reverse harem, fantasy romance | 16–30 | Strongly female | Mobile (gacha), Switch | Highest spending per user in the genre |
| Mobile trope romance (mafia, werewolf, contract marriage) | 18–35 | Strongly female | Mobile story apps | Mirrors BookTok / Wattpad readers |
| BL / GL romance | 18–30 | Female (BL), mixed (GL) | PC, mobile | Small but very dedicated fanbases |
| Psychological horror / subversion | 15–25 | Mixed, slightly male | PC (Steam), streaming | Discovered via YouTube and Twitch |
| Mystery / detective / death game | 16–30 | Mixed | PC, Switch | Big theory-crafting communities |
| Sci-fi thriller / time loop | 20–35 | Male lean | PC, console | Older readers with anime background |
| Cozy / healing / found family | 20–40 | Female lean | Switch, PC | Cozy gaming community; ages up |
| Mature drama (grief, addiction, war, politics) | 25–45 | Mixed | PC | Smaller audience, strong critic support |
| Adult 18+ (eroge, nukige) | 18–35 | Strongly male | PC, specialized stores | Platform policy risk |

### 3.3 Takeaways

- **Teens (13–17):** mobile first, free to play, school/idol/romance fantasy, social sharing. Price-sensitive.
- **Young adults (18–25):** the heart of the genre. Horror subversion, death games, otome, meta-fiction. Discover games through streamers and TikTok.
- **Adults (25–40):** more disposable income, premium purchases, collector's editions. Prefer mature themes, cozy games, moral ambiguity, and complex romance with adult characters.
- **Gender:** female players dominate romance and otome spending; male players dominate PC anime-style and adult VNs; horror and mystery are the most gender-balanced, which is part of why they break out.

---

## 4. Proposed plots

Each concept combines a strong romance or character layer with a viral hook (subversion, mystery, or an unusual role), because that pairing drives current breakouts. The concepts are ordered by estimated attention potential.

### Concept 1. "Last Stream Online" — psychological horror + parasocial romance

- **Hook:** You're the moderator of a rising VTuber's chat. She starts sending you private messages. Then the chat begins predicting events in *your* real apartment.
- **Structure:** The game UI imitates a streaming platform: chat, donations, DMs. Choices are moderation actions (ban, pin, reply, ignore). Four routes; the true ending requires "reading" chat across loops.
- **Why it works:** Combines two proven hits (Needy Streamer Overload's internet satire + DDLC's meta horror) with a theme every Gen Z player knows: parasocial relationships. Extremely streamable, since streamers play a game about streaming.
- **Audience:** 15–25, mixed gender, PC/Steam, 4–6 hours.
- **Risk:** Comparisons to Needy Streamer Overload; needs its own twist.

### Concept 2. "Verdict of Seven" — fantasy death game + otome

- **Hook:** Seven cursed nobles are locked in a magic academy. Every night one of them dies, and every morning the heroine must accuse a killer before a trial. She is falling in love with at least one of the suspects.
- **Structure:** Detective investigation segments + trial debates (Danganronpa style) + romance affection per suspect. Loving someone can bias your evidence, which is the central mechanic.
- **Why it works:** Merges the two strongest plot families (mystery death game + otome romance). Magical Girl Witch Trials proved the death game format still sells in 2025; otome players are the highest spenders. Every character's possible death creates fan anxiety and discussion.
- **Audience:** 16–30, female lean with a mixed crossover, PC + Switch + mobile port.
- **Monetization idea:** Premium base game, DLC "after stories" per love interest.

### Concept 3. "The Night Dispatcher" — cozy workplace drama with a supernatural twist

- **Hook:** You work the night shift at a small-town 24/7 emergency hotline. Callers include a vampire with insomnia, a ghost who forgot her name, and a werewolf teenager having his first transformation. You can't leave your desk; everything happens through voices and the town map.
- **Structure:** Episodic (one night = one chapter). Choices affect townsfolk and unlock romance with regular callers. A slow-burn mystery about why the hotline exists.
- **Why it works:** Dispatch proved a "stuck at a desk, managing others" frame sells millions. Coffee Talk proved cozy supernatural conversation games have a durable audience. Episodic release matches the mobile story app habit.
- **Audience:** 20–40, female lean, Switch/PC/mobile. Cozy gamer community.

### Concept 4. "Contract Bride of the Iron Syndicate" — mobile-trope romance with real consequences

- **Hook:** A classic BookTok setup (arranged marriage to a crime boss's heir) played straight at first, then turned into a political thriller where the heroine can take over the syndicate, destroy it, or escape it.
- **Structure:** Chaptered romance with a visible "power / love / freedom" triangle. Choices are remembered, and endings vary strongly.
- **Why it works:** Uses the proven search keywords of mobile story apps (mafia, contract marriage, forbidden romance) but answers the most common complaint about those apps: choices that don't matter. This gives it a marketable angle: "the mafia romance where your choices actually matter."
- **Audience:** 18–35, strongly female, mobile first. Free to play with chapter passes, or premium on PC.

### Concept 5. "Save File 0" — time loop sci-fi romance

- **Hook:** The heroine's partner dies every Sunday. She wakes up on Monday with a notebook of what she tried. The loop is the save system, and the game eventually admits it knows that.
- **Structure:** Each loop is a short run; knowledge carries over and unlocks new options. Branches between saving him, letting go, and discovering who resets time.
- **Why it works:** Time loops fit the medium (Steins;Gate, Slay the Princess, Zero Escape) and justify replaying. The emotional core, grief and letting go, draws strong reviews and "I cried" clips.
- **Audience:** 18–35, mixed, PC/console, 8–12 hours.

### Concept 6. "Dorm 404" — school slice of life with a hidden horror layer (teen-friendly)

- **Hook:** A bright school club comedy with a mobile-friendly art style. The player slowly notices a student who appears in every photo but whom nobody remembers.
- **Structure:** Light daily-life routes + an "unease meter" controlled by what the player chooses to notice. Rated for teens: horror through mystery and atmosphere, not gore.
- **Why it works:** Captures the fastest-growing segment (teens on mobile) with the most viral mechanic (the cute-to-creepy switch) without adult-only content. Easy to share as short clips.
- **Audience:** 13–20, mixed, mobile + Steam.

### Concept 7. "The Last Tea House" — historical cozy drama

- **Hook:** You inherit a failing tea house in a historical port city (Ming China, Edo Japan, or Ottoman Istanbul) on the eve of a war. Guests bring rumors, romance, and requests; you decide who you shelter.
- **Why it works:** The Hungry Lamb (2024) proved historical dating sims can break out: it has 60,000+ Steam reviews at 94% positive. Rich cultural settings stand out from the flood of generic modern-school VNs. Strong appeal to adults 25+ and to players in Asian markets.
- **Audience:** 22–40, female lean, PC/Switch.

### Summary matrix

| # | Concept | Attention potential | Development cost | Main age group | Best platform |
|---|---|---|---|---|---|
| 1 | Last Stream Online | ★★★★★ (streamers) | Low–medium | 15–25 | PC |
| 2 | Verdict of Seven | ★★★★★ | High (mystery design) | 16–30 | PC, Switch |
| 3 | The Night Dispatcher | ★★★★ | Medium (voice acting) | 20–40 | Switch, PC, mobile |
| 4 | Contract Bride of the Iron Syndicate | ★★★★ (mobile ads) | Medium | 18–35 | Mobile |
| 5 | Save File 0 | ★★★★ | Medium | 18–35 | PC, console |
| 6 | Dorm 404 | ★★★ | Low | 13–20 | Mobile, PC |
| 7 | The Last Tea House | ★★★ | Medium (research, art) | 22–40 | PC, Switch |

**Recommendation for a first project by a small team:** Concept 1 or Concept 6. They are short, cheap to produce, and structurally designed to be streamed. **For a team with a writer who can plan complex mysteries:** Concept 2 has the highest ceiling.

---

## 5. Practical advice for attracting attention

1. **Pitch in one sentence with a contradiction.** Test the pitch on strangers before writing the script.
2. **Design at least three "clip moments"**: a twist, a painful choice, a meta trick. These are the free marketing.
3. **Launch a free demo or prologue** (Steam Next Fest, itch.io). DDLC was free and reached 30M players; paid content can come later (DDLC Plus).
4. **Give characters strong, readable designs.** Fan art and cosplay drive the long tail.
5. **Make choices matter visibly.** Show a flowchart, a relationship meter, or explicit consequences. "Choices don't matter" is the most common complaint in VN reviews.
6. **Plan localization early.** Localized releases of Japanese VNs earn 35–50% of lifetime sales outside Japan; Chinese, English, Spanish, Portuguese, and Russian are high-value languages.
7. **Avoid explicit 18+ content on Steam** unless that is the core business: store removals happened repeatedly in 2025–2026.
8. **Pick a demographic and design for it.** The VNDev Wiki's guidance is blunt: "your target audience is not everyone". Age and gender preferences differ a lot between plot families (section 3).

---

## Sources

- Games-Stats: Steam tags by revenue — https://games-stats.com/steam/tags
- GameDiscoverCo: Which genres have ruled Steam — https://newsletter.gamediscover.co/p/which-genres-have-ruled-steam-a-new
- GameDiscoverCo: How did Dispatch hit 1M sales so fast — https://newsletter.gamediscover.co/p/how-did-narrative-hit-dispatch-hit
- VGChartz: Dispatch sales top 1 million in 10 days — https://www.vgchartz.com/article/466170/dispatch-sales-top-1-million-units-in-10-days
- Steam 250: Top Visual Novel games — https://steam250.com/tag/visual_novel
- How To Market A Game: Popular genres on Steam — https://howtomarketagame.com/2022/04/18/what-genres-are-popular-on-steam-in-2022
- Dataintelo: Visual Novel Games Market Report 2034 — https://dataintelo.com/report/visual-novel-games-market
- WiseGuy Reports: Visual Novel Market 2035 — https://www.wiseguyreports.com/reports/visual-novel-market
- Growth Market Reports: Visual Novel Games Market — https://growthmarketreports.com/report/visual-novel-games-market
- Niche Gamer: Results of MangaGamer's licensing survey — https://nichegamer.com/the-results-of-manga-gamers-visual-novel-licensing-survey
- VNDev Wiki: Demographic — https://vndev.wiki/Demographic
- arimia: Your target audience is not everyone — https://arimiadev.com/panels/your-target-audience-is-not-everyone-notes
- Sixth Tone: How China fell in love with otome games — https://www.sixthtone.com/news/1016634
- Taylor & Francis: Women's engagement in otome games — https://www.tandfonline.com/doi/full/10.1080/1369118X.2025.2587132
- UChicago: Love and Deepspace study — https://knowledge.uchicago.edu/records/sf1w1-64d24
- Hey Poor Player: DDLC hits 30 million players — https://www.heypoorplayer.com/2024/12/10/doki-doki-literature-club-hits-30-million-players
- Episode Interactive — https://www.episodeinteractive.com
- Chapters: Interactive Stories (Google Play) — https://play.google.com/store/apps/details?id=com.mars.avgchapters
