# Game concepts:
Title: Verdict of Seven - age: 16–30
Plot: Seven cursed people are locked in a magic academy. Every night one of them dissapears. Every morning the heroine must accuse someone who implemented some magic so this hero dissapeared. But she is falling in love with at least one of the suspects. 
Key ideas: Detective, Mystery, romance. Detective investigation segments + trial debates (Danganronpa style) + romance affection per suspect.

# Requirements:

## Gameplay: 
playable in 2 hours
Use time travel and loops
Multiple endings
The game rewards completionism
no free chapter/scene select. To see a different route you reload the common intro (or restart) and make different choices
composite of genres - The game reads as a straightforward romance adventure — until the player realizes the story is three different genres stacked: romance, detective, mistery

## Scenes flow:
locked branches/unlocked scenes after main story
Players advance the story manually or with an auto-play mode.

## UI:
visible relationship UI
personage stat screen
The game UI should include the flowchart showing visited scenes

## Inner flags:
Story flags - Per-heroine affection counters (hidden). Every route-relevant choice adds points to one or more heroes. 
Route-lock flags. Once locked, the arc plays to its good or bad end. The pivot is silent.

## Resource management:
The game has RPG elements - collectable items, that can be used during gameplay. Player/core personage has inventory. There's some collectable economy, so user can pay for some progression in later scenes with collectable items. For example, 8 items unlock After Story, 10 unlock the true ending, etc.

Personages:
Each has its own psychology, abilities and speech manner. 

Protagonist: 
customization - change name. Ability to setup personage core 3-5 abilities with moving bars. Choosen abilities setup/balance should affect the game flow and plot.




