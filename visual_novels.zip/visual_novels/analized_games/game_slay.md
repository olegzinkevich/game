# Slay the Princess (2023) — Deep-Dive Mechanics Report

**Game:** Slay the Princess (STP)
**Developer / publisher:** Black Tabby Games — a two-person studio: writer/designer **Tony Howard-Arias** and artist **Abby Howard** (Ignatz-winning graphic novelist; all art hand-pencilled on paper)
**First release:** Windows / macOS / Linux, **23 October 2023**; later PS4/PS5, Xbox One/Series, Nintendo Switch
**Engine:** custom **Unity** visual-novel framework (not Ren'Py); first-person, fully voice-acted
**Voice cast:** **Jonathan Sims** (The Narrator + every Voice in Your Head + the Player's male-adjacent roles) and **Nichole Goodnight** (The Princess / The Shifting Mound)
**Music / sound:** Brandon Boone (score) and Phil Michalski (sound design)
**Genre:** horror visual novel / interactive fiction — marketed as a "dating sim" it deliberately refuses to be; psychological horror, metafiction, cosmic romance
**Structure:** an infinite time loop of a common trunk (**Chapter I**) that forks into **10 Chapter II routes**, several of which fork again into **Chapter III** (and, for one route, **Chapter IV**), all feeding a single **End of Everything** finale
**Free expansions:** *The End of Everything Update* (25 March 2024) and **The Pristine Cut** (24 October 2024) — +3 routes, +3 heavily expanded routes, +1 ending, +a 420-unlock **Gallery/Memories** system
**Playtime:** ~4–6 h for one loop-chain; ~15–20 h to see every vessel and ending

> **Scope note:** STP is not a stats-and-slots RPG. It has **no visible numbers, no affection meters, no inventory grid, no character creator, and no manual saving.** What it has instead is a **loop engine**: a common opening chapter, a "one-form-per-playthrough" memory rule, a set of *hidden* run flags, and two hidden numeric axes (Freedom / Satisfaction) that quietly describe how the Princess felt about you. Where a requested category barely exists (customization, inventory, save-slots) this report says so rather than inventing depth — but it also flags where the game turns the *absence* of a mechanic into the point.

---

## 0. Executive summary (the design in one paragraph)

You wake on a path in the woods. At the end of the path is a cabin; in the basement of the cabin is a Princess. A **Narrator** — voiced, insistent, and lying by omission — tells you to slay her, or she will end the world. A **Voice of the Hero** in your head tells you not to. You go down, you make one or two choices, and **you die** — and the loop resets, except it does not reset cleanly. The Princess, the cabin, and the world **rewrite themselves around the choice that killed you**, and a new **Voice** (an emotion of yours given a body) joins the ones already in your skull. You are not a blank-slate avatar; you are a god, **the Long Quiet**, split in half by a dying man who could not bear death. She is the other half, **the Shifting Mound** — change, transformation, and death itself — and she becomes whatever you perceive her to be. Each completed loop you drag a version of her ("a vessel") back to a mirror in the space between worlds and feed it to her true self. Deliver **five** vessels and the finale unlocks, where you must decide whether to finish the Narrator's plan (a world of eternal stasis, without death) or take her hand (a world of endless change, and oblivion). Every mechanic in the game is an argument about **choice, change, and whether a loop is a trap or a love story.**

---

## 1. Characters

### 1.1 Core character portraits

| Role | Name | Voice | Defining trait | Function in the machine |
|---|---|---|---|---|
| Protagonist | **You / The Player** → **The Long Quiet** | *unvoiced* | Unnamed, faceless, silent; an anthropomorphic **corvid** (taloned arms, feathers, white glowing eyes, two sets of wings) | The player avatar and the **"decider."** The Princess and Narrator call you "Hero," "the Dragon," "Little Bird," "Fledgling." Your true identity — the god of stasis — is hidden until the finale. |
| Guide / antagonist | **The Narrator** | Jonathan Sims | Urbane, condescending, insistent; denies the loop exists | An **echo** of the mortal man who tore the cycle of life and death in two and made you and her. He guides your blade and lies about the loop to keep you on task. He is *not* omniscient and can be talked into revealing everything. |
| The other half | **The Princess** → **The Shifting Mound** | Nichole Goodnight | Shifts form every loop; "becomes whatever you perceive her to be" | Goddess of **change, transformation, and death**. In her nascent form she is a **writhing multitude of hands** puppeting a vessel; awakened she is a sea of Princesses. She needs **5 vessels** to complete herself. |
| Internal chorus | **The Voices in Your Head** | Jonathan Sims (all) | 11 facets of your psyche, each a distinct character | Spawned **every time you die**, keyed to the choice that killed you. They bicker, advise, and vote. The Princess can only perceive them when she possesses or fuses with you. |
| Cosmic backdrop | **The construct / The Cabin / The Woods** | — | Recursive, self-similar spaces | The many-worlds trap the Narrator built; each loop is a different infinitesimal slice of it. |

**The Voices** are the game's real "party." There are **eleven**, each representing a personality trait and paired as a foil to a specific Princess form:

| Voice | Born from this death-choice | Trait | Foil Princess |
|---|---|---|---|
| **The Hero** | *always present* | Heroism, conscience | The Princess (base) |
| **The Broken** | You die pathetically | Despair, submission | The Tower |
| **The Cheated** | You are cheated out of a victory | Pessimism, spite | The Razor |
| **The Cold** | You make a heartless decision / suppress feelings | Apathy, lack of feeling | The Spectre |
| **The Contrarian** | You make a nonsensical / contrarian decision | Contrarianism, inanity | The Stranger |
| **The Hunted** | You give in to fear/instinct and die fighting | Fear response, instinct | The Beast |
| **The Opportunist** | You take advantage of a situation | Opportunism, ambition | The Witch |
| **The Paranoid** | You make a cowardly decision | Paranoia, cowardice | The Nightmare |
| **The Skeptic** | You are incredibly skeptical of the situation | Skepticism, truth-seeking | The Prisoner |
| **The Smitten** | You act on your feelings for the Princess | Infatuation, blind devotion | The Damsel |
| **The Stubborn** | You fight the Princess to the bitter end | Stubbornness, fighting spirit, rivalry | The Adversary |

Design tell: **every Voice speaks with a British accent** — per the devs, "because birds are from England." The Voice of the **Skeptic is the only Voice the Princess never hears.**

### 1.2 Character abilities / player-managed stats

There are **no RPG stats, no HP bar, no skill tree.** The game's "abilities" are narrative and hidden:

- **The Player — the power of perception.** The Princess literally *becomes whatever you believe her to be*. Your choices don't just select a path; they **author her body**. This is the single most important "ability" in the game, and the Narrator's whole plan hinges on you *not* realising it (a single intrusive thought, he says, could end the world instantly).
- **The Voices — spendable "traits."** Each Voice opens dialogue options and can sometimes **override your agency**: the Voice of the Skeptic *forces* you to take the blade as a "reflex" (The Prisoner, The Cage); the Contrarian *forces* you to throw it out a window (The Fury, No Way Out); the Cheated *skips the introductions* and drags you to the cabin (The Arms Race).
- **The Narrator — narrative authority (unreliable).** He can dictate narration, conjure a "reward," and even unmake the world when you turn back. He is defeated by *asking the right questions.*
- **The Shifting Mound — near-omnipotence when complete.** She can erase your memory, cannot be harmed or killed while nascent, and cannot interfere with the construct until she has five vessels. In the finale you can *overpower and destroy her anyway* if you argue from your history of violence.

**The only quantities the game actually maintains are two hidden numeric axes** — the Shifting Mound's **Freedom** and **Satisfaction** values (§4–5). The player never sees them; they are read only by the finale.

### 1.3 Character customization

- **None, by design — and the refusal is thematic.**
- **No name entry.** The protagonist is never named by the player; he is "you," the "decider," and eventually "the Long Quiet."
- **No appearance editor, no gender choice, no voice.** The Player is *unvoiced*; the devs have said three possible voices were considered (silent, layered/polyphonic, sinister whisper) and chose silence.
- **The only "build" is personality.** What you customise is *which Voices you accumulate* — the game reads your repeated choices and literally populates your head with the emotions you kept acting on. A player who keeps fighting accrues Stubborn; one who keeps submitting accrues Broken.
- The Narrator's account of "customisation": *"I didn't make her a Princess… You chose for that something to be a princess."* Even the **Princess's form is a projection of your psychology**, so "character creation" is inverted onto the antagonist.
- The Steam description openly trolls the expectation: *"Don't even think about trying to romance her."*

---

## 2. Dialogue and action choices

STP is a **first-person, fully voice-acted choice VN**: hand-pencilled static sprites over painted backgrounds, a dialogue box, and a **sidebar list of choices** that are clicked, not timed. There are no mini-games. The entire input surface is *choose a line / choose an action.*

Choices fall into three functional classes:

1. **Cosmetic / flavour choices.** Jokes, tone, how you hold the knife, whether you call the Princess by name. They tint dialogue and the Voices' reactions but change no structure. The clearest example: **The Stranger's "Explore" options** produce different alternate Princesses but are explicitly **superficial** — same outcome, no alternate vessels.
2. **Route-determining choices (the key ones).** Mostly in **Chapter I**, where a *single* decision forks the entire rest of the run:
   - whether you **take the Pristine Blade** from the table (blade/no-blade determines which ten Chapter II routes you can reach);
   - **how** you confront her — slay with hesitation → Adversary; slay without hesitation → Spectre; try and be overwhelmed → Tower; doubt the kill → Razor; free her / resist the Narrator → Prisoner or Damsel; betray her → Beast or Witch; **leave her in the basement** → Nightmare; **refuse to go to the cabin at all** → Stranger.
3. **Ending-determining choices.** The finale (The End of Everything) and the intermission (The Spaces Between) choices decide which of the proper endings you get — including one that hinges on whether you were **cruel to your own Voices** and one that requires you to have taken **every vessel through violence**.

Two structural choice-rules matter:

- **"One form per playthrough."** Once you have entered a Chapter II or III, *that Princess can never appear again this run.* Later choices that would lead there are **greyed out, removed, or met with a "Change your course" rebuff from Her.** This is how the loop enforces variety without a route-select screen.
- **The abort / "turn back."** At the start of Chapter II or III you may refuse to go to the cabin. The world unwinds into nothingness, the Narrator fades, and you fall into Her embrace. This is a *choice* with its own escalating text and its own ending.

**A diegetic input tell:** the **mouse cursor is your hand**, and its sprite changes based on state — empty, holding the pristine blade, bloodied, reverse-grip, upgraded to the **Pristine Sword**, your left hand after the Razor severs your right, or your beak. The UI quietly narrates your situation.

---

## 3. Branching narrative and key scenes

### 3.1 How the story splits

The story is a **hub-and-spoke loop**, not a linear multi-route VN:

- **Chapter I: The Hero and the Princess** — the common trunk. Always the same woods, cabin, table, blade, basement. Your one or two choices here determine everything downstream.
- **Chapter II** — one of **ten** rewritten worlds, each a different Princess form and a different Voice.
- **Chapter III / IV** — several Chapter II forms escalate into a stronger form; the Razor uniquely runs to Chapter IV.
- **The Spaces Between (the Long Quiet)** — the intermission after *every* route ends. You feed the form to the Shifting Mound, look in a mirror, and loop.
- **The End of Everything** — the finale, unlocked after **five vessels**.

### 3.2 Route map (Chapter II → what it leads to)

| Chapter II form | How you get it | Leads to | Classification |
|---|---|---|---|
| **The Adversary** | Slew her *with hesitation* (a fair duel) | → Eye of the Needle **or** Fury **or** ends the route | **Key** (form + Voice + vessel) |
| **The Tower** | Tried to slay her, overwhelmed / gave up | → Apotheosis **or** Fury **or** ends | **Key** |
| **The Spectre** | Slew her *without hesitation*, then slew yourself | → Wraith **or** The Princess and the Dragon (PC) **or** ends | **Key** |
| **The Razor** | Doubted the kill / doubted she was unarmed | → **Ch III** (Arms Race / No Way Out) → **Ch IV** (Mutually Assured Destruction / The Empty Cup) | **Key** (only 4-chapter route) |
| **The Prisoner** | Freed her and resisted the Narrator (blade taken) | → The Cage (PC) **or** The Grey **or** ends | **Key** |
| **The Beast** | Betrayed her; she tore you apart (no blade) | → The Den **or** The Wild **or** ends | **Key** |
| **The Witch** | Betrayed her and fought to the death / let her escape (no blade) | → The Thorn **or** The Wild **or** ends | **Key** |
| **The Damsel** | Went full "save the Princess," resisted the Narrator (no blade) | → Happily Ever After (PC) **or** The Grey **or** ends | **Key** (the "romance" route) |
| **The Nightmare** | Left her in the basement (blade irrelevant) | → The Moment of Clarity **or** Wraith **or** ends | **Key** |
| **The Stranger** | Refused to go to the cabin at all | Always ends the same; **no alternate vessels**; Explore options are cosmetic | **Mixed** — key to a special ending, cosmetic internally |

**Chapter III "joint chapters"** are reachable from *two* different Chapter II forms (the one-form-per-run rule still applies):

- **The Fury** ← Adversary *or* Tower
- **The Wraith** ← Spectre *or* Nightmare
- **The Wild** ← Witch *or* Beast
- **The Grey** ← Damsel *or* Prisoner

**The Pristine Cut added three routes:** **The Princess and the Dragon** (from the Spectre), **The Cage** (from the Prisoner), **Happily Ever After** (an *Epilogue* from the Damsel), plus major expansions to The Fury, The Den, and The Apotheosis.

**Every route ends one of two ways:**
1. **Claiming a Vessel** — a multitude of hands takes the Princess, leaving a mirror; you enter The Spaces Between and feed her to the Shifting Mound. Text is some variant of *"You do not get the chance to respond. Something has taken her away from you…"*
2. **Aborting the Route** — you turn back; the world unwinds; she is disappointed.

### 3.3 Key scenes (the load-bearing moments)

- **The first basement.** The Princess chained to the wall, the blade on the table, the Narrator's instruction, the Hero's dissent. The entire game is seeded here.
- **The death that names a Voice.** Every death re-casts your psyche; the first time you see a new Voice manifest is the game's core emotional beat.
- **The mirror in the Spaces Between.** You approach a mirror and watch yourself **rot** — "It's you / You've grown / You've withered / You've unraveled / You are nothing at all" — one image per vessel delivered.
- **The Narrator reveal (5 vessels).** The mirror no longer shows you; it shows a **bird-god** — and then shatters to reveal the Narrator. You get a **budget of ~9–10 questions** (each answer shatters a piece of the mirror) to learn the construct, the loop, the Narrator's suicide, and your true identity before he fades.
- **The finale: the Shifting Mound awakens.** A tsunami of Princesses erupts from the hill; she offers you godhood. Your final choice is the game's thesis: **change vs. stasis, together vs. alone.**

---

## 4. Story flags and variables

STP does not show you a flag list, but it maintains a rich hidden state machine. The tracked variables fall into four families:

### 4.1 Run flags (this playthrough)

- **`has_blade`** — did you take the Pristine Blade in Chapter I? This one Boolean gates *five* of the ten Chapter II routes and colours how the Princess addresses you.
- **Chapter-I outcome** — slew-with-hesitation / slew-without / overwhelmed / doubted / freed / betrayed / left / never-went. Directly selects the Chapter II form and the Voice.
- **Route-completion set** — the game records every Chapter II/III form you've entered and **locks it out** for the rest of the run (greyed options, "Change your course"). This is the "one form per playthrough" rule enforced by a visited-set.
- **`stranger_first`** — was the Stranger your *first* vessel? Flips the finale into the **Strange Beginnings** variants and changes the cabin and the available Voices.
- **Vessel count (0–5)** — gates the Spaces Between text and the finale; also gates whether the **Good Ending** is even reachable (it is *only* available before any vessel is delivered).
- **Abort counter** — number of times you turned back. **Six aborts before the second vessel** → the **Just As You Once Were Nothing** ending; after two vessels you can no longer abort at all.
- **Cruelty counter (Voices)** — how many times you were cruel to the Voices at the mirror. **≥2** → the "everyone hates you" ending variant.
- **Violence qualification (per vessel)** — whether each of the five vessels was obtained through extreme violence/hostility (Deconstructed Damsel, Mutual Assured Destruction, etc.). **All five + red finale dialogue every time** → the Pristine Cut's **Your New World** ending.
- **Narrator "aggravation" (+1 flags)** and **revealed-fact flags** — inside the 5-vessel conversation, some questions set an aggravated state or "reveal" a fact that **opens or closes other questions**, and the mirror physically breaks in pieces (a question budget).

### 4.2 Hidden numeric axes (per run)

The Shifting Mound carries two invisible values that change with **how each vessel ended**:

- **Freedom** — how much that version of her wanted to be free / to change (−1 / 0 / +1 / +2).
- **Satisfaction** — how content she was with you (−2 … +2).

They are read only at the finale (e.g., the "Fourth Time" text branches on whether Freedom is positive; certain endings require a specific violence/qualification profile). Examples: the Damsel's *"And They Lived Happily Ever After"* = **Freedom −1 / Satisfaction +2**; the Wild's *"A Glimpse of Something Bigger"* = **Freedom +2 / Satisfaction +1**; the Wraith's *"The Exorcist III"* = **Freedom −1 / Satisfaction −2**.

### 4.3 Persistent meta-flags (across runs)

- **The Gallery / "Memories"** (added by The Pristine Cut) is a save-file-level collection of **420+ unlocks** recording which vessels you've met and which choices you made. It is the game's only true cross-run memory, and it unlocks only after a *proper* ending (not the Good Ending or Oblivion).

### 4.4 Design reading

The flag system is deliberately **inverted from a normal VN**: instead of flags deciding *what scene you see next*, flags decide **who the Princess is** and **who you are** (which Voices inhabit you). The loop is the save system; the flags are the loop's memory.

---

## 5. Relationship and affection systems

There is **no affection meter, no romance bar, no "route lock-in" by points.** Relationships in STP are qualitative and reframed every loop:

- **You ↔ The Princess (the central relationship).** Each loop the same two beings meet as strangers who remember. Her disposition toward you is authored per route: adversarial (Adversary), worshipful/submissive (Tower, Broken), devoted (Damsel, Smitten), betrayed and reciprocal (Witch), trusting-but-armed (Prisoner), terrified and terrifying (Nightmare), hungry (Beast), ghostly and longing (Spectre). The hidden **Freedom/Satisfaction** axes are the closest thing to an affection model — they encode how *she* felt, not how much she likes you, and they steer the finale's tone.
- **Trust is a literal gate, not a number.** The **Thorn** grips the blade "like her life depends on it"; you must **earn her trust to retrieve it.** The **Prisoner** needs you to act on her plan; the **Witch** will betray you the instant you betray her ("even if it hurts her simultaneously").
- **You ↔ The Voices (internal relationships).** The Voices are the game's other relationship system — and it has real teeth: being **cruel to them at the mirror twice** changes the ending so that all but the Hero and Contrarian **promise to make your eternity unpleasant.** The Voices also *bicker*, *override you*, and *grieve*, so they read as a found family / chorus rather than stats.
- **The "romance" is a trap and a thesis.** The Smitten (infatuation) and the Damsel route are the game's romance-comedy surface; the game explicitly warns "don't even think about trying to romance her." The true emotional relationship is between the two halves of a torn god, and the game argues that **love across change is the point of existence** ("This is a love story").
- **No rivalry/friendship/resentment counters** exist as mechanics — but the *narrative* produces all of them, and the Voices embody resentment (Cheated), rivalry (Stubborn), and devotion (Smitten) as characters rather than scores.

---

## 6. Multiple endings

Endings split into **two pre-finale joke endings** (they roll credits but don't count for the "Our Song" completion achievement) and the **proper "End of Everything" endings.**

### 6.1 Before the End of Everything

| Ending | Trigger | Type |
|---|---|---|
| **The 'Good' Ending** | Slay the Princess in Chapter I and *accept* the Narrator's "eternal paradise." Only available if you have **not** delivered a vessel. Reward: an eternity of nothingness and a badly-drawn thank-you card. | **Bad/joke** ("failure" — the world is saved into stasis) |
| **Just As You Once Were Nothing** ("Oblivion") | **Turn back / abort a route six times** before delivering the second vessel. She begs; you keep refusing; you both remain incomplete forever, in a loop of her pain and her embrace, until you choose to **give up existing.** | **Bad/failure** (unresolved, entombed) |

### 6.2 The End of Everything (proper endings)

After **five vessels** and the Narrator conversation, you meet the awakened Shifting Mound. The finale branches into:

**A. Surrender to her — "There Are No Endings"** *(achievement: "Only new beginnings")*
Accept godhood; the two of you shatter the construct and leave together into infinite change. The **true/"good"** ending — the game's thesis ending.

**B. Reject her — "The Heart of the Shifting Mound"** (you return to the cabin's basement and face her as she first was):

| Ending | Choice | Type |
|---|---|---|
| **A New and Unending Dawn** | Take the blade, **slay** her heart. You become god of a deathless world; the Voices return to argue over eternity. | **Bad/true-antagonist** (stasis) |
| **A New and Unending Dawn, and Everyone Hates You** | Same, but you were **cruel to the Voices at the mirror ≥2 times**; all but Hero and Contrarian vow to make your eternity hell. | **Bad variant** |
| **You're on a Path in the Woods…** | Take the blade, but **hand it to her**; she tearfully kills you and the cycle restarts with a clean slate. | **Loop/failure** |
| **And? What Happens Next?** | Take **no blade**; you and she **leave the cabin together as mortals**, into the unknown. | **Normal/"leave"** ending |
| **Strange Beginnings** | The **Stranger was your first vessel**; variants of the above where the Voices of the Hero and Contrarian send you off. | **Special variant** |

**C. Overwhelm her — "Your New World"** *(added in The Pristine Cut; achievement "There are worse things to be than alone")*
Obtain **all five vessels through extreme violence or hostility**, then choose the **red (hostile) dialogue every time** in the finale. You fight and destroy her without outside help and build a world under your own control, free of death. No Voices appear. | **New/bad** (lonely godhood)

### 6.3 The route "mini-endings"

Every route also concludes in a **named vessel-ending** (e.g., the Prisoner's *Talking Heads* / *Prison of the Mind*, the Razor's *Mutually Assured Destruction* / *The Empty Cup*, the Den's *Heroic Strike* / *Coup de grâce*, the Wild's *The Wound*, the Thorn's *Turning Over a New Leaf*, the Grey's *Burning Down the House* / *And All This Longing…*). These aren't credits-endings; they are the perspectives you feed the Shifting Mound, and they set the Freedom/Satisfaction axes.

**Completion:** the **"Our Song"** achievement requires finishing the game via a *proper* ending — the Good Ending and Oblivion explicitly **do not count.**

---

## 7. Save and load

STP deliberately **strips the usual VN convenience layer** and replaces it with the loop:

- **No manual save, no quick-save, no quick-load, no save slots.** The game **auto-saves continuously**; the main menu offers a single **Continue.**
- **No chapter select / scene select in-game.** You cannot rewind to an earlier branch mid-run. To see a different branch you must **start a new loop from Chapter I** — which is exactly the fiction the game is dramatising ("You're on a path in the woods…" again).
- **One-form-per-playthrough memory** (a *within-run* persistence rule) means your save remembers which Princesses you've already seen and locks them out, pushing you toward new content without a menu.
- **The Gallery / "Memories"** (post-Pristine Cut) is the **cross-run persistence layer**: it tracks the vessels you've met and choices you made across saves, with **420+ unlocks**, and is unlocked by earning a proper ending (not the Good Ending or Oblivion). Note: it does **not retroactively sync** progress from saves made before the Pristine Cut.
- **Version/branch support:** Steam beta branches let you revert to *The End of Everything Update* (password `endofeverything`) or the *Launch Version* (`originalrecipe`); Steam Cloud saves are supported.
- **Design reading:** the "no save-scumming" stance is thematic — the loop *is* the load screen, and the game's horror is that you cannot un-choose. Replay is the intended "chapter select."

---

## 8. Inventory / items

STP has **one real item**, and it is the whole inventory system: **the Pristine Blade.**

- **Acquisition:** at the start of almost every chapter the blade sits on the table in the cabin. Whether you **take it** is a run-defining Boolean (see §4).
- **The blade is never consumed and never changes** ("even when the cabin changes… the blade remains unchanged and pristine"). What changes is *where it is and who holds it*:
  - **In your possession** (The Cage, The Princess and the Dragon — where it links your body to the Dragon's).
  - **In her possession** (lodged in the Grey's chest; worn as a necklace by Happily Ever After; gripped by the Thorn, who must *trust* you before you can take it).
  - **Elsewhere / absent** (launched into a tree by the Apotheosis; entirely missing in the Wraith, forcing the "throw yourself into the abyss" resolution).
- **The blade can be transformed** — in The Apotheosis the Paranoid uses your perception to upgrade it into the two-handed **Pristine Sword**, capable of breaking her barrier.
- **The blade can be taken from you by the Voices** — the Cheated forces you to take it (The Arms Race), the Contrarian forces you to throw it away (The Fury / No Way Out).
- **The cursor mirrors the item state** (normal / bloodied / reverse-grip / sword / severed hand), making the "inventory" diegetic.
- **Other props are set dressing, not inventory:** the Narrator's "evidence" document (read in The Prisoner), the Damsel's blade-necklace, the knife in the Grey. There are **no keys, no gifts, no consumables, no crafting** in the RPG sense.
- **The mirror** in the Spaces Between is the closest thing to a usable "object," but it is an interactive scene device, not an item.

**Design reading:** by reducing the inventory to a single symbolic knife, the game keeps the player's hands empty of *stuff* and full of *decision.* The blade is not a tool you use; it is the question the game keeps asking.

---

## Appendix A — Full route/ending quick-reference

**Chapter II forms (10):** Adversary, Tower, Spectre, Razor, Prisoner *(blade)*; Beast, Witch, Damsel *(no blade)*; Nightmare, Stranger *(blade-independent)*.

**Chapter III forms:** Eye of the Needle, Apotheosis, The Moment of Clarity, The Den, The Thorn *(single)*; The Fury, The Wraith, The Wild, The Grey *(joint)*; The Arms Race / No Way Out *(Razor, → Chapter IV: Mutually Assured Destruction / The Empty Cup)*; The Princess and the Dragon, The Cage, Happily Ever After *(Pristine Cut)*.

**Endings (proper):** There Are No Endings · A New and Unending Dawn · A New and Unending Dawn, and Everyone Hates You · You're on a Path in the Woods… · And? What Happens Next? · Strange Beginnings · Your New World.
**Endings (pre-finale):** The 'Good' Ending · Just As You Once Were Nothing (Oblivion).

**Voices (11):** Hero, Broken, Cheated, Cold, Contrarian, Hunted, Opportunist, Paranoid, Skeptic, Smitten, Stubborn.

---

## Appendix B — Mechanics checklist

| Requested mechanic | Present in STP? | Form it takes |
|---|---|---|
| Character portraits | ✅ | Hand-pencilled sprites; every Princess form is a bespoke portrait |
| Character abilities / stats | ⚠️ Hidden | Perception-as-power; Voices as abilities; hidden **Freedom/Satisfaction** axes |
| Character customization | ❌ | No name/appearance/gender; "build" = which Voices you accrue |
| Dialogue/action choices | ✅ | Sidebar choices; 3 classes (cosmetic / route / ending) |
| Branching routes | ✅✅ | 1 trunk → 10 Ch.II → Ch.III/IV; one-form-per-run lockout |
| Cosmetic vs key routes | ✅ | Only the Stranger's Explore options are truly cosmetic; all others are key |
| Story flags / variables | ✅✅ | has_blade, route-visited set, abort counter, cruelty counter, vessel count, narrator aggravation, Freedom/Satisfaction |
| Relationship/affection | ⚠️ | No meter; disposition authored per route; hidden Freedom/Satisfaction; cruelty-to-Voices flag |
| Multiple endings | ✅✅ | 2 pre-finale + 7 proper endings + per-route vessel-endings |
| Save/load | ⚠️ Inverted | Auto-save only; no manual/slots; loop = load; Gallery = cross-run memory |
| Inventory/items | ⚠️ Single item | The Pristine Blade (+ Pristine Sword upgrade); everything else is set dressing |

---

*Sources: Slay the Princess Wiki (Chapters, Voices, Endings, The Spaces Between, The Shifting Mound, The Player, Pristine Blade, Gallery, The Pristine Cut, main game page); Black Tabby Games store copy and press materials.*
