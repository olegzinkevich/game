# VA-11 HALL-A: Cyberpunk Bartender Action (2016) — Deep-Dive Mechanics Report

**Game:** *VA-11 HALL-A: Cyberpunk Bartender Action* (stylized *VA-11 HALL-A*, read "Valhalla")
**Developer / publisher:** **Sukeban Games** (Venezuela) — published by Ysbryd Games
**Design & art:** Christopher Ortiz (Kiririn51) · **Writing & programming:** Fernando Damas · **Music:** Michael Kelly
**First release:** Windows / macOS / Linux, **21 June 2016**; later PS Vita (2017), PS4 & Nintendo Switch (2019)
**Engine:** **GameMaker: Studio** (GML) — not Ren'Py
**Genre:** Visual novel / bartending simulation / slice-of-life cyberpunk ("a booze 'em up about waifus, technology, and post-dystopia life")
**Setting:** Glitch City, year **207X** — a nanomachine-infected dystopia run by corporations and the corrupt **White Knights**
**Structure:** a free standalone **Prologue** + a main campaign of **19 numbered shifts** grouped into three chapters, then per-character **epilogues**
**Playtime:** ~10–15 h for one pass; longer for all epilogues and New Game+
**Sequel:** *N1RV Ann-A* announced 2018, delayed indefinitely

> **Scope note — the central design fact:** *VA-11 Hall-A* has **no dialogue options at all**. There is no "say this / do that" menu. The **only** verb that changes the story is **mixing and serving a drink**. The bartending minigame *is* the choice system. Everything the player does — remembering a regular's favourite cocktail, deliberately serving the wrong thing, adding or withholding alcohol, buying or skipping a home item — is expressed through that one loop. Where a requested category genuinely does not exist in this game (character customization, combat stats, romance routes in the dating-sim sense), this report says so rather than inventing depth, and flags where the *absence* is itself the design.

---

## 0. Executive summary (the design in one paragraph)

You are **Julianne "Jill" Stingray**, a 27-year-old night-shift bartender at the dive bar **VA-11 Hall-A** in a rain-soaked block of **Glitch City**. Each shift, customers walk in and order drinks; you mix them from **five fictional ingredients** and serve them. That's the whole game. But because the drink is the only lever, the drink becomes characterization: serving a regular the drink they *ask for* versus the drink they *need* changes their dialogue, unlocks or closes their personal story, and decides who gets a happy epilogue. Alcohol (**Karmotrine**) loosens tongues and gets people drunk, so a stronger pour literally produces juicier conversation; a weaker pour keeps someone guarded. Between shifts you go home, browse a 4chan-like imageboard (**danger/u/**), read the in-world news site (**The Augmented Eye**), and buy furniture, decor and subscriptions with the money you earned — and if you skip the thing Jill is fixating on, she gets **distracted at work and forgets orders**, so even the shop is a mechanic. The plot is a mostly-linear slice-of-life spine that detonates halfway through: on **December 21** a customer reveals that Jill's ex-girlfriend **Lenore** is dead, and the game becomes a quiet study of grief. The bartending never stops; it just starts to mean something. **How well you pay attention to people is the difficulty curve.**

---

## 1. Characters

### 1.1 Core character portraits

The cast is deliberately made of the people who would be *background NPCs* in a normal cyberpunk game. Only one character — **Jill** — is the player; everyone else is a regular, a coworker, or a passing customer.

| Role | Name | Defining trait | Function in the machine |
|---|---|---|---|
| **Protagonist / player** | **Julianne "Jill" Natalie Stingray** | 27, dour, deadpan, secretly soft; hates being called "Julianne"; bi; has a liver implant that blocks drunkenness | The only character you control. Her focus, mood and money are the game's "stats." |
| Boss | **Dana Zane** | Ex-wrestler ("Red Comet"), mechanical left arm, "eternally seventeen," loves spicy chicken and cute things | Bar owner and bouncer; Jill's unspoken crush. Central to the good ending. |
| Coworker | **Gillian "Gil"** | Pretty-boy with a mysterious (possibly KGB/Hong Kong riot-police) past; constantly misnamed "John" | Second bartender; comic relief with a hidden dangerous life. |
| Bar mascot | **Rad Shiba** | A talking Shiba Inu in sunglasses and a Hawaiian shirt | Running gag; a customer, then mysteriously absent late-game. |
| Regular — journalist | **Alma Armas** | "Christmas cake," calls herself a **security consultant** (white-hat hacker), not a hacker | One of the two main friendship/ending tracks; links to the Lenore subplot. |
| Regular — Lilim | **Dorothy Haze** (Rebecca Dorothy Willow Graem) | An android ("Lilim") sex worker; cheerful, filthy, earnest | Fan-favourite; own ending; comic and emotional anchor. |
| Regular — White Knight | **Sei P. Asagiri** | One of the few genuinely good White Knights; gentle, self-sacrificing | Ties into Stella, Virgilio and the *Kira* Miki ending. |
| Regular — catgirl | **Stella Hoshii** | Ojou-sama "cat boomer" (human-cat hybrid); Sei's partner | Links to Sei and Virgilio; concert ending. |
| Regular — defector | **Virgilio Armandio** | Speaks only in cryptic riddles; secretly a former White Knight named **Timothy Mercury** | Hardest "puzzle" customer; own ending. |
| Regular — detective | **Art von Delay** | A Seinfeld "George" expy; silent, laconic private eye | Recurring drink-route character. |
| Regular — editor | **Donovan D. Dawson** | Bald, chauvinistic, blackmailing chief editor of **The Augmented Eye**; J. Jonah Jameson expy | The one customer Jill hopes never returns; Big Beer every time. |
| Regular — grump | **Ingram McDougal** | Complaining tough guy | Serving him *sweet* drinks reveals his backstory (and breaks Flawless Service). |
| Regular — streamer | **Streaming-chan** | Streams her life 24/7 including intimate moments | Nico-Nico-style text floods her sprite; interface-screw gag. |
| Idol | **\*Kira\* Miki** (Michelle Kingston) | Android pop idol; huge in-world star | Own ending (a concert). |
| Regulars | **Jamie** (augmented hitman), **Betty** & **Deal** (veterinarian + android at a corgi-staffed firm), **Taylor** (a brain in a jar), **Mario**, **Norma**, **Nacho**, **Kimberly La Vallete** (neurotic; Dana saved her from a suicide attempt) | Working-class Glitch City in miniature | Fill out the bar's social texture. |
| Cameos (secret) | **Lexi, TOMCAT, Jess** | Crossover characters from *2064: Read Only Memories* | Summoned by the Flaming Moai secret (§4). |
| Spoiler characters | **Anna Graem** (invisible to everyone but Jill), **Lenore Kurow** (Jill's dead ex-girlfriend), **Gabrielle "Gaby" Kurow** (Lenore's sister) | The emotional core and the hidden supernatural thread | Anna has unlockable bonus chapters; Lenore/Gaby drive the second half. |

**Music as identity (a tracked tell):** the jukebox is player-programmed each shift, and each regular is associated with a track; **Streaming-chan's theme overrides whatever you chose**, and the soundtrack cuts to **total silence** the moment Gaby says "She's dead" (a *Sudden Soundtrack Stop* used as a story beat).

**Drinks as characterisation (a core authorial tool):** every regular has a **signature drink** that encodes who they are — Donovan's **Big Beer** ("the bigger, the better"), Dorothy's **Piano Woman**, Alma's **Brandtini**, Ingram's **Gut Punch**, Sei's non-alcoholic **Blue Fairy**, Stella's **Piano Woman**, \*Kira\* Miki's **Mulan Tea**. Learning these *is* learning the characters.

### 1.2 Character abilities / player-managed stats

There are **no RPG stats, no HP, no skill trees, no levels, no combat**. What the game tracks instead:

- **Money ($).** Earned from drink prices + tips + a **Flawless Service bonus** for a perfect shift + a **commission** from the bar's take. Spent on bills and furniture. This is the closest thing to a health bar: failing to pay **rent** produces the bad ending.
- **"Total Karmotrine used."** A hidden running counter of every unit of the alcoholic ingredient Jill pours. It decides **how drunk** a customer gets, which in turn decides how candid, emotional or chaotic the scene becomes. Ignored when mixing two drinks at once; bottled drinks never contain Karmotrine.
- **The mistake counter.** Each wrong drink increments it; it can trigger a **Game Over** (see §4).
- **Jill's focus / distraction.** A binary state, set *outside* the bar. If Jill wants an item and you don't buy it (or can't afford it), she spends the next shift distracted — her internal monologue replaces the reminder of what the customer ordered, so you must remember or guess. A focused Jill narrates "Stella asked for a Beer"; a distracted Jill rambles about the poster she wanted.
- **Jill's abilities as a character (not a stat sheet):** recipe recall (there is an in-game **recipe book**), reading a customer's real desire under their stated order, and professional composure — the game's "skill" is *the player's*, not a number.

### 1.3 Character customization

- **None for Jill.** Her name, face, body and personality are fixed; the game actively punishes the player for wanting to rename her ("Do not call me Julianne"). There is no protagonist name entry.
- **What *is* customizable is the apartment and the bar's ambience.** Money buys furniture, posters, plants, a PC and games, and **Nanocamo** (leopard-pattern wall/table skins), which are pure self-expression and achievement fodder.
- **The jukebox** is a form of customization: at the start of each shift the player programs the playlist that scores the night.
- **The real "customization" is the drink.** Every cocktail is authored by the player from five ingredients, ice/age toggles, and big/small sizing — the player literally builds the objects that carry the story.

---

## 2. Dialogue and action choices

*VA-11 Hall-A* deliberately **has no dialogue-choice menus**. Designer Christopher Ortiz said traditional VN dialogue options "interfered with the subtlety of the game," so the team replaced them with the bartending loop.

### 2.1 The drink-mixing minigame (the only choice system)

- **Five ingredients**, mapped to keys: **Adelhyde** (sweet, `Q`), **Bronson Extract** (bold/bitter, `W`), **Powdered Delta** (sour, `E`, historically a rat poison), **Flanergide** (spicy, `R`), **Karmotrine** (alcohol, `T`). `Shift`+key removes one.
- **Modifiers:** `A` toggles **ice**, `S` toggles **aging**; drinks can be mixed **small or big**; `Space` mixes/starts/serves; you may **reset** an order at any time and start over.
- **No time limit and no fail on technique** — a mistake can simply be reset. The "tension" is entirely social: *what the customer meant*.
- **Serving correctly** yields the price + tip; a full flawless shift adds a **Flawless Service bonus**; Jill also earns a **commission** on the bar's total. There is an in-game **recipe book** to look recipes up.

### 2.2 The four kinds of order (and why "wrong" is often right)

1. **Explicit orders** — "give me a Beer." Straightforward, but even here the *size* can matter (Donovan wants a **Big** Beer).
2. **Vague / mood orders** — "something sweet," "something strong," "surprise me," "something classy," "make me forget." The player must infer the recipe *and* the intent.
3. **Cryptic / puzzle orders** — **Virgilio** speaks only in riddles ("17?", "a plum floating in perfume," "something fake," "purity"). These require lateral reading of recipes and ingredient counts.
4. **Trap / emotional orders** — the customer asks for one thing but needs another. The signature example: a depressed regular asks for something sweet, but a stiff pour does more good; or **Sei** asks for a **Bleeding Jane** when injured, and giving her a **cold non-alcoholic** drink instead *extends the conversation and opens her ending*. Giving the "wrong" drink is frequently the *correct* choice.

**Consequences of the drink:**
- A **wrong drink changes the dialogue** and can shut down a scene.
- **Alcohol dosage** changes how drunk and how forthcoming the customer is; **Streaming-chan** can be plied with a Big Fringe Weaver (the strongest drink) to get her hammered on request.
- **Serving a Flaming Moai** to almost anyone sets a hidden flag that **summons a secret cameo customer** (§4).
- **Ingram** and others react to drinks outside their "type" with unique dialogue; giving Ingram sweet drinks reveals his past but costs the Flawless bonus.

### 2.3 Non-bar "choices"

Outside the shift, the player still never picks dialogue — but does make **economic and browsing choices**:
- **Shopping** (which item/subscription to buy) sets Jill's focus for the next shift.
- **danger/u/** threads and **phone texts** are read, not answered; they seed plot (this is how Gaby finds Jill).
- **The "Model Warrior Julianne" minigame** (a hidden bullet-hell shmup) unlocks if you buy the **PC-9X** console and **Assorted Cartridges** — an optional action-game tucked inside the VN.

---

## 3. Branching narrative and key scene description

### 3.1 How the story is split

The narrative is **a single linear spine with per-character branches hanging off it** — not separate romance routes. The game uses two counters of time:

- **Chapters (major acts):** **Prologue** (free standalone), **Chapter 1: Primerá** (bitter), **Chapter 2: Amarga** (sour), **Chapter 3: Dulce** (sweet).
- **Days (shifts):** 19 numbered days in the main campaign, running **12/13 → 12/31**, plus dated **epilogues** in January–August.

```
PROLOGUE  (free standalone episode — the original 2014 game-jam build, "reduxed")
  Days 1–3: introduces the bar, Dana, Gil, the mixing loop
        │
MAIN GAME
  CHAPTER 1 — Primerá   Days 1–6   (12/13 – 12/18)
     Introduces most regulars; establishes signature drinks
     Day 4 (12/16): first bill (porn subscription, $800)
     Day 6 (12/18): "Hangin' With the Boss" — no apartment, a fixed Dana day
        │
  CHAPTER 2 — Amarga    Days 7–13  (12/19 – 12/25)
     Day 12 (12/24): power bill ($8000)
     *** WHAM EPISODE — Day 9 (12/21): Gaby reveals Lenore is dead ***
     Day 13 (12/25): MEGA CHRISTMAS party (TRUTH or DARE)
        │
  CHAPTER 3 — Dulce     Days 14–19 (12/26 – 12/31)
     Jill's grief arc; every regular reacts to her changed mood
     Day 18 (12/30): RENT due ($10000)  ← the ending gate
     Day 19 (12/31): last shift; Gaby returns
        │
   ┌────┴─────────────────────────────────────────────┐
   │  EPILOGUES (dated, unlocked by drink consistency) │
   │  Good ending   8/25   Jill & Dana → Panama        │
   │  Dorothy       1/15   Dorothy & Anna              │
   │  \*Kira\* Miki  1/30   the concert                 │
   │  Virgilio      2/3    "Tim's Curry"               │
   │  Alma          2/25   the sleepover               │
   └───────────────────────────────────────────────────┘
   (These stack: one playthrough can show several epilogues.)
   SEPARATE: "ANNA" chapters (Demo = before the game, Start = after),
             unlocked from the main menu.
```

### 3.2 Routes, and cosmetic vs. key

"Routes" here are **character drink-tracks**, not divergent storylines. The spine is fixed; what varies is *which epilogues unlock* and *how scenes read*.

| Route / track | Unlock condition | Leads to | Type |
|---|---|---|---|
| **Main / Dana ("Good")** | Pay **every bill on time** | Golden ending (Dana romance, Panama) | **KEY** (the game's true ending) |
| **Bad / eviction** | Fail to pay rent (spend the money, or under-earn) | Jill evicted, moves in with Alma ("Cozy Hell") | **KEY** (a genuine alternate ending) |
| **Alma** | Give her a **Brandtini** when she wants "classy," and again when she's down | Alma epilogue (sleepover) | KEY (own epilogue) |
| **Dorothy** | Give her a **Piano Woman** when she's sad; plus give Sei a cold non-alcoholic drink instead of a Bleeding Jane when she's hurt | Dorothy epilogue | KEY (own epilogue) |
| **Virgilio** | Get **all his cryptic orders right** (and fulfil ≥1 Dorothy condition) | Virgilio epilogue ("Tim's Curry") | KEY (own epilogue) |
| **\*Kira\* Miki** | Get her **drunk on her first visit** and get her orders right; give her **Mulan Tea** | \*Kira\* Miki epilogue (concert) | KEY (own epilogue) |
| **Sei / Stella** | Cold, non-alcoholic, gentle drinks at the right moments | Threads through Dorothy, Virgilio and \*Kira\* Miki endings | Key (supporting) |
| **Ingram's backstory** | Serve him **sweet** drinks | Extra dialogue (forfeits Flawless bonus) | Cosmetic (no ending) |
| **Flaming Moai cameos** | Mix a **Flaming Moai** (flag `ft_any`) — and specifically for Alma/Stella | Summons secret customers **Lexi / TOMCAT / Jess** | Cosmetic-secret (achievements) |
| **Anna Graem** | Unlock the "ANNA" menu chapters | Hidden supernatural side-story | Key (bonus content) |

Most *individual* order mistakes are **cosmetic**: they change one conversation, cost a tip and break the Flawless bonus, but do not alter the ending. Only the **rent gate** and the **consistency of a character's drink track** produce structural differences.

### 3.3 Key scenes

- **The tutorial shift (Chapter 1, Day 1).** Jill's first solo night: Gil, Donovan, Ingram, Sei, Kim. Teaches mixing by doing, and introduces the signature-drink logic.
- **The Flaming Moai nights.** Serving the notorious drink summons **Lexi** (12/26), **TOMCAT** (12/28) and **Jess** (12/29) — crossover cameos from *Read Only Memories*; a reward for players who experiment.
- **"Hangin' With the Boss" (12/18).** A rare non-bar day with Dana; deepens the Jill–Dana thread.
- **The Wham Episode (12/21).** A new customer, **Gaby**, is Lenore's sister. Mid-conversation she says **"She's dead."** All music **cuts to silence**, and the rest of the shift is a bitter argument in dead air. Jill collapses into a **Heroic BSoD** — screaming, self-loathing ("a piece of shit"), drinking, and going to work purely to distract herself.
- **The "someone else behind the bar" scene.** During the breakdown, **Alma briefly takes over the bar and serves *Jill*** as the customer — so that Jill can finally be the one with a shoulder to cry on. A structural inversion of the whole game.
- **The MEGA CHRISTMAS party (12/25).** TRUTH or DARE with the cast; the comic relief beat before the grief arc.
- **The rent night (12/30).** The ending gate: pay **$10,000** and keep the apartment, or be evicted.
- **The final shift (12/31).** Gaby returns; Jill serves the last drink of the run (a Piano Woman / non-alcoholic Blue Fairy reads as a toast) and the credits roll into whichever epilogues you earned.
- **The Anna Graem chapters.** Accessible from the main menu (the blue `+`), *ANNA → DEMO* (set before the main game) and *START* (set after); a secret, largely-invisible character whose presence only Jill can see.

---

## 4. Story flags and variables

This is the game's real skeleton, and it is unusually well documented: a community project (CyberShadow's *Complete Script Flowchart*) emulated the GameMaker VM and enumerated **every reachable game state** — roughly 2.2 × 10⁴⁰ states at the end. It published the actual **variable index**. *VA-11 Hall-A* is a dense flag machine wearing a visual novel's clothes.

### 4.1 The variable taxonomy

The game's internal variables fall into a few families (all prefixed by character and numbered by encounter):

| Family | Examples | Meaning |
|---|---|---|
| **Encounter / trust flags** | `alma5`, `alma6`, `alma7`, `alma8`; `ing1`…`ing7`; `stel1`…`stel11`; `sei5`…`sei9`; `miki1`…`miki5`; `dorothy12`…`dorothy14`; `db1`…`db8`; `virgilio6`; `truevirgilio1`, `truevirgilio2` | Set as you progress a character's conversation track; later read to gate the next scene or the epilogue. |
| **Drunkenness counters** | `almadrunk1/2`, `dondrunk1/3`, `ingdrunk1`, `dorodrunk1`, `drunkmiki1`, `seidrunk1`, `steldrunk1`, `streamdrunk1`, `kimdrunk1`, `jilldrunk1`, `bettydrunk1` | Set when a character is served enough alcohol (or by specific scenes); read later to open candid dialogue. |
| **Drink-behaviour flags** | `dorodrink1/7/9`, `bettydrunk1` | Record *which drink* a character was served at a key moment. |
| **Secret-client flags** | `ft_any`, `ft_alma`, `ft_stella` | Set by **mixing a Flaming Moai** (for anyone / for Alma / for Stella). Read to summon Lexi, TOMCAT, Jess. |
| **Misc plot flags** | `gabyorder`, `dogpick` (which dog/pet choice), `housedl` (housing deadline / rent), `brian1/2`, `kim1`, `jamie1/2`, `art6/7`, `mario1/2/3`, `norma1`, `stream1`…`stream6`, `anna1/2/3` | Individual scene gates and branch conditions. |

### 4.2 How flags are set and read

- **Set by service.** The overwhelming majority of flags are written the instant a drink is served (or mixed — see below). `dorodrunk1 := 1`, `ing3 := 1`, `alma7 := 1`.
- **Read later.** Days later, the script checks the value: `Value of alma7?` → branches the conversation, unlocks an epilogue line, or withholds a scene. The variable index shows, for example, `stel1` being *read* on eight separate later days.
- **The rent/housing flag (`housedl`)** is the one that decides the ending: paying rent on 12/30 keeps Jill housed (→ good ending); failure routes to eviction (→ bad ending).
- **Money is itself a flag.** Bills arrive on fixed days — **porn subscription $800 (12/16)**, **power $8000 (12/24)**, **rent $10000 (12/30)**. Missing a payment does not crash the game; it *substitutes the next day's order descriptions with a random placeholder* (Jill is too worried to remember what people want). This is a flag that degrades *information* rather than blocking progress.
- **The purchase flag** (Jill's fixation item) is checked the next morning: buy it → `focused`; skip it → `distracted` (order text becomes rambling). The player-facing effect of a Boolean is therefore **lost information**.

### 4.3 Mechanics the flags encode

- **Total Karmotrine used** — a numeric accumulator (not per-character) that drives drunkenness scenes.
- **Flaming Moai trick (a famous exploit of the flag system):** the `ft_*` flag is set when the drink is **mixed**, not when it's **served**. You can mix a Flaming Moai, **reset the order**, serve something else, and the flag still fires — so you can summon every secret customer *and* keep Flawless Service.
- **Mistake → Game Over:** serving **three wrong "simple" drinks in a row** (Sugar Rush, Sparkle Star, Blue Fairy, Sunshine Cloud, Frothy Water, or any bottled drink) triggers a **Non-Standard Game Over** — Dana abruptly ends the shift and a Game Over screen appears. The dialogue even varies by circumstance.
- **Achievement flags:** `CREVICE_TROPHY` (serve a Crevice Spike), `RIGHT_WRONG_TROPHY` (serve a wrong drink), plus ending and secret-client achievements.

### 4.4 Known script quirks (evidence of the flag machinery)

Documented bugs double as a map of the internals: the "big drink" **+$100** bonus fires even on a small drink (the size check is missing); mixing two drinks when the first is correct **resets the day's non-tip income** (a cash-reset bug); **Art's** high-alcohol branch checks the wrong variable and is unreachable; several taste strings are misspelled (`"ssour"`, `"Bitter"`), and a typo breaks one dialogue line. A guide author even noted Steam itself flags these community guides as "removed/incompatible" while they remain the definitive reference.

---

## 5. Relationship and affection systems

There are **no affection meters, no trust bars, no romance flags in the dating-sim sense**. Sukeban deliberately built friendships that "come to be" rather than ones the player *earns from scratch*. Affection is expressed through **attention**, not points:

- **Remembering a drink = intimacy.** The game's thesis: once you know a person well enough to know what they want to drink *in that exact moment*, you've reached a "very personal" relationship. Getting a character's order right, consistently, is the affection system.
- **Alcohol as intimacy.** Karmotrine loosens people up; getting a character drunk is a way to unlock their guard. But the game also lets you *withhold* alcohol to protect someone — the Sei subplot rewards giving her a cold, non-alcoholic drink instead of the Bleeding Jane she asked for.
- **The "right drink at the right time" beats** function as relationship milestones:
  - **Piano Woman** for Dorothy when she's down → her ending.
  - **Brandtini** for Alma when she's low → her ending.
  - **Mulan Tea / getting her drunk** for \*Kira\* Miki → her ending.
  - **All of Virgilio's riddles** → his ending (and his trust).
  - **Cold non-alcoholic drink** for injured Sei → extends her thread.
- **Romance:** the only explicit romance is **Jill → Dana** (a one-sided, heavily signposted crush; Dana is oblivious). It pays off only in the **good ending**, where the two go to Panama together (implied relationship upgrade). Jill is **bisexual**; her central past relationship was with **Lenore** (her former student-teacher girlfriend, whom she left after a fight and who then died) — the game's emotional engine.
- **No rivalry, fear, or resentment mechanics.** Antagonism exists only *in fiction* (Donovan is loathsome; the White Knights are villains), not as a tracked stat. The closest thing to a negative relationship state is **Gaby's accusation** that Jill's breakup killed Lenore — a one-way story beat, not a meter.
- **Found family.** Virgilio/Sei/Stella form a protective triangle; Jill/Alma/Dorothy/Gaby form another. Endings reward emotional consistency, not "choosing a girl."

---

## 6. Multiple endings

The game has **at least seven endings**: a good ending, a bad ending, and five character epilogues (four named plus the good one). They are **not mutually exclusive** — a single strong playthrough can trigger several.

| Ending | Trigger | Content | Type |
|---|---|---|---|
| **Good / Golden ("And now, for something completely different…")** | Pay **every bill on time** (porn 12/16, power 12/24, rent 12/30) | Jill and **Dana** (now dating) vacation in **Panama**; Jill reconciles with **Gaby** over Lenore's death and begins to heal | **True ending** |
| **Bad ("Cozy Hell")** | **Fail to pay rent** (overspend / under-earn) | Jill is **evicted** and moves in with **Alma**, who platonically cuddles her to sleep — leaving Jill more depressed and sexually frustrated than ever | **Bad ending** |
| **Alma's ending ("Sisterly bonding")** | Brandtini when she wants classy + when she's down | Jill, Alma and **Gaby** have a sleepover (dated **2/25**) | Character ending |
| **Dorothy's ending ("Dorothinquisition!")** | Piano Woman when she's sad + cold drink for Sei | Jill and **Dorothy** talk about **Anna** (Anna listening nearby) between raunchy stories (dated **1/15**) | Character ending |
| **Virgilio's ending ("Tim's Curry")** | All his cryptic orders correct (+ ≥1 Dorothy condition) | Virgilio opens a **curry shop**; revealed as **Timothy Mercury**, the ex-White Knight who saved Sei and Stella; Jill, Sei and Stella eat curry (dated **2/3**) | Character ending |
| **\*Kira\* Miki's ending ("Listen to my song!")** | Get her drunk first visit, get her orders right, serve Mulan Tea | Jill, **Stella** and **Sei** attend her concert; a song dedicated to Jill; Sei gets a job offer (dated **1/30**) | Character ending |
| **Game Over ("Non-Standard Game Over")** | Serve **three wrong simple drinks in a row** | Dana cuts the shift short; Game Over screen | **Failure state** |

**Failure modes:** the "failure" of the main story is **relationship/security breakdown** (eviction → bad ending) rather than death; the Game Over is a *service* failure. Unresolved threads remain by design: the bar's rumoured closure by parent company **BTC** is never resolved ("What happened to the mouse?"), and Rad Shiba simply vanishes late-game.

**New Game+:** unlocked after any ending; **carries over all money and unlockables**, so debt and distraction stop mattering — the intended space for experimentation.

---

## 7. Save and load

- **Save slots / manual save.** The PC release lets the player save progress (and a guide explicitly says "**save the game here**" at the 12/29 apartment point before the rent gate), so branching can be replayed without restarting from scratch.
- **Autosave by day.** The game advances day-by-day and saves between shifts, so a shift is the natural checkpoint.
- **Text controls:** `Space` advances text; `Ctrl` **fast-forwards** (very fast); `Tab` opens the **conversation history**; `V` toggles text sound. There is a text-speed/auto facility typical of VNs.
- **No built-in chapter/scene select or flowchart.** Unlike *Steins;Gate* or *999*, *VA-11 Hall-A* ships **no in-game route map**; players rely on the community **flowcharts** (CyberShadow's script flowchart, 100 % guides) to see locked branches. This is a notable gap relative to other VNs.
- **NG+ "Heart save data."** A dedicated save carries money/furniture into a new run; a guide reminds players to "save your heart data for NG+."
- **Extras menu.** The main-menu `+` opens the **ANNA** chapters (Demo/Start) and the jukebox/soundtrack content — a form of post-game scene selection.

---

## 8. Inventory / items

The player does not carry a traditional key-item inventory. The "items" are **home furnishings, consumables and subscriptions bought from the shop**, plus a handful of story objects. They matter because (a) buying the item Jill fixates on prevents her from being **distracted** at work, and (b) bills must be paid to avoid the bad ending.

### 8.1 Bills and subscriptions (the must-buy "items")

| Date | Item | Cost | Consequence of skipping |
|---|---|---|---|
| 12/16 | Porn-site subscription | **$800** | Next day's order descriptions become placeholder rambling |
| 12/24 | Power bill | **$8000** | Same distraction penalty |
| 12/30 | **Rent** | **$10000** | **Bad ending (eviction)** |

### 8.2 Apartment / decor items (bought on the shopping days)

Dated purchases documented across the campaign include:
- **Holo-plant** and **Mulan Tea** (12/14)
- **"Your Love is a Drug"** (12/15)
- **Joker Cyclone** (12/17)
- **Cracked Daruma** (12/19)
- **"Shoulder Massager"** (12/20)
- **Beer on Discount** (12/21)
- **Cutesy Game Poster** (12/22)
- **MEGA CHRISTMAS Tree** (12/23)
- **Alex Figurine** (12/26)
- **Movie poster** (12/27)
- **Maneki Neko** (12/28)
- **\*Kira\* Miki Poster** (12/29)
- **PC-9X + Assorted Cartridges** (12/30, optional — unlocks the **Model Warrior Julianne** minigame)
- **Nanocamo** skins (leopard wall/table patterns) and the **RAD SHIBA camo** — pure decor/achievements
- **Jukebox music tracks** (bought in NG+, on a third shop page)

Buying the day's **desired item** clears Jill's fixation (she stays focused); skipping it makes her distracted. A meta-achievement ("So unnecessary") requires buying *everything*.

### 8.3 Story items and gifts

- **Gaby's note** (Day 15) — a plot object tied to the Lenore aftermath.
- **The Mulan Tea** — both a purchasable item and the drink that unlocks \*Kira\* Miki's ending.
- **Nanomachine wallpaper / Nanocamo** — the in-world expression of the setting's nanotech (decor that doubles as worldbuilding).
- **The "Model Warrior Julianne" cartridge** — an item that contains a whole hidden game (and a callback to Jill's hated first name).

There are **no weapons, keys or quest documents** in the traditional sense; the closest analogues are the **drink recipes** (knowledge as inventory) and the **flags** in §4.

---

## Appendix A — The drink menu (in-game data)

| Drink | Price | Alcohol | Ice | Flavor | Primary type | Secondary |
|---|---|---|---|---|---|---|
| A Fedora | $500 | Yes | No | — | Bottled | — |
| Absinthe | $500 | Yes | No | — | Bottled | — |
| Bad Touch | $250 | Yes | Yes | Sour | Classy | Vintage |
| Beer | $200 | Yes | No | Bubbly | Classic | Vintage |
| Bleeding Jane | $200 | No | No | Spicy | Classic | Sobering |
| Bloom Light | $230 | Yes | Yes | Spicy | Classic | Bland |
| Blue Fairy | $170 | Optional | No | Sweet | Promo | Soft |
| Brandtini | $250 | Yes | No | Sweet | Classy | Happy |
| Cobalt Velvet | $280 | Yes | Yes | Bubbly | Classy | Burning |
| Crevice Spike | $140 | Optional | No | Sour | Manly | Sobering |
| Flaming Moai | $150 | Yes | No | Sour | Classic | Classy |
| Fluffy Dream | $170 | Optional | No | Sweet | Girly | Soft |
| Fringe Weaver | $260 | Yes | No | Bubbly | Classy | Strong |
| Frothy Water | $150 | No | No | Bubbly | Classic | Bland |
| Grizzly Temple | $220 | Yes | No | Bitter | Promo | Bland |
| Gut Punch | $80 | Optional | No | Bitter | Manly | Strong |
| Marsblast | $170 | Yes | No | Spicy | Manly | Strong |
| Mercuryblast | $250 | Yes | Yes | Sour | Classy | Burning |
| Moonblast | $180 | Yes | Yes | Sweet | Girly | Happy |
| Mulan Tea | $500 | Yes | No | — | Bottled | — |
| Piano Man | $320 | Yes | Yes | Sour | Promo | Strong |
| Piano Woman | $320 | Yes | No | Sweet | Promo | Happy |
| Pile Driver | $160 | Yes | No | Bitter | Manly | Burning |
| Rum | $500 | Yes | No | — | Bottled | — |
| Sparkle Star | $150 | Optional | No | Sweet | Girly | Happy |
| Sugar Rush | $150 | Optional | No | Sweet | Girly | Happy |
| Sunshine Cloud | $150 | Optional | Yes | Bitter | Girly | Soft |
| Suplex | $160 | Yes | Yes | Bitter | Manly | Burning |
| Zen Star | $210 | Yes | Yes | Sour | Promo | Bland |

*(The "trap" of the design lives in this table: the same word — "sweet," "strong," "classy" — can describe several drinks, and "optional" Karmotrine means the player, not the recipe, decides how drunk the customer gets.)*

## Appendix B — Controls (PC)

`Space` advance / mix / serve · `Ctrl` fast-forward · `Tab` history · `V` text sound · `Q W E R T` add Adelhyde / Bronson / Delta / Flanergide / Karmotrine · `Shift+` remove · `A` ice · `S` age · `I O P K L` streaming text

## Appendix C — Sources

- Wikipedia, *VA-11 Hall-A* (gameplay, development, characters, reception).
- TV Tropes, *VisualNovel/VA11HALLA* and *Characters/Va11HallA* (endings, characters, signature drinks, key scenes).
- CyberShadow, *Complete Script Flowchart: ALL Decisions, Branches, and Outcomes* (Steam guide) — day/chapter structure, variable index, omitted mechanics, bugs.
- BunnyBot 5000, *VA-11 Hall-A 100 % Completion Guide* (Steam guide) — drink table, dated purchases, bills, ending triggers, NG+.
