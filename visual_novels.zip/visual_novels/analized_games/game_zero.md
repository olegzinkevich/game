# Zero Escape: 999 — *Nine Hours, Nine Persons, Nine Doors* (2009) — Deep-Dive Mechanics Report

**Game:** *Zero Escape: Nine Hours, Nine Persons, Nine Doors* (JP: 極限脱出 9時間9人9の扉, *Kyokugen Dasshutsu: Kujikan Kunin Kyū no Tobira*); commonly **999**
**Developer:** Chunsoft (now Spike Chunsoft)
**Director / writer:** Kotaro Uchikoshi · **Producer:** Jiro Ishii · **Designer:** Akihiro Kaneko · **Programmer:** Yasushi Takashina
**Character art:** Kinu Nishimura · **Music:** Shinji Hosoe (SuperSweep)
**Publishers:** JP Spike · NA/EU Aksys Games · WW Spike Chunsoft
**First release:** Nintendo DS, **10 December 2009** (JP) / **16 November 2010** (NA)
**Later releases:** iOS *999: The Novel* (2013/2014) · *Zero Escape: The Nonary Games* remaster — PS4 / PS Vita / Windows (24 March 2017) · Xbox One (22 March 2022)
**Genre:** visual novel + escape-the-room adventure; psychological horror / mystery / sci-fi thriller
**Structure:** a "common trunk" of escape rooms forked by a sequence of **numbered-door choices**, producing **6 endings** (7 in the iOS port)
**Series:** first entry of the *Zero Escape* trilogy (*Virtue's Last Reward* 2012, *Zero Time Dilemma* 2016)

> **Scope note:** 999 is *not* a stats-and-affection VN. It has **no character creator, no visible stats, no affection meters, no persistent inventory, and no route-lock menu in the original DS build.** Its core is a **state machine over a narrative graph**: the player's "state" is the **set of numbered doors traversed** plus a handful of **dialogue flags**, and that state selects one of six endings. This report treats the escape-room layer (a puzzle/adventure system) and the novel layer (a choice/flag system) as two halves of one mechanism, and flags where the original release and the remaster differ.

---

## 0. Executive summary (the design in one paragraph)

Nine strangers wake on a sealed, sinking cruise liner with metallic **bracelets** locked to their wrists, each showing a digit. An unseen host, **Zero**, forces them into the **Nonary Game**: within nine hours they must find a door marked **9** and escape, or the ship sinks and they drown. Every numbered door (1–9) opens only for a group of **3–5 players** whose bracelet values sum to a **digital root equal to the door's number**; passing through arms a "detonator" that must be cleared at the **DEAD** within **81 seconds**. The story alternates between **Novel sections** (reading + choices) and **Escape sections** (first-person room puzzles), and the player, as college student **Junpei**, picks which door and which group to take. Each door sequence is a branch; the combination of doors plus four specific dialogue choices determines which of **six endings** you get. Beneath it all is a hidden premise: the entire game is being watched through **morphic resonance** by a **12-year-old Akane Kurashiki** nine years in the past — and on the DS, **the bottom screen is her point of view**, which the game never tells you until the true ending.

---

## 1. Characters

### 1.1 Core character portraits

Nine participants + the host. Every player hides behind a **codename** derived from their bracelet symbol (Junpei is the only one whose real name leaks before the naming consensus). True identities are plot-critical and revealed across endings.

| # (bracelet symbol) | Codename (true name) | Role / defining trait | Function in the machine |
|---|---|---|---|
| **5** | **Junpei** (Junpei Tenmyouji) | College student, protagonist, snarky puzzle-solver | The **player avatar** and the only character the player steers. Later implied to be an **esper** — able to remember information across timelines, which is the in-fiction excuse for the meta-flag system. |
| **6** (actually a flipped **9**) | **June** (Akane Kurashiki) | Junpei's gentle childhood friend; wants nobody left behind | The emotional centre and the **hidden antagonist**. Her bracelet *displays* 6 but secretly functions as **0**. Revealed in the true ending to be **Zero**, the game's architect. |
| **9** | **9th Man** (Teruaki Kubota) | Fidgety, nervous, "knows more than he lets on" | The **tutorial death**. He breaks the rules in the first five minutes and detonates, teaching the player that the stakes are real. Also the source of the "9" bracelet Ace later kills for. |
| **2** | **Snake** (Light Field) | Blind, princely, encyclopaedic; Clover's brother | The **information dispenser** — reads the braille rules sheet, supplies exposition. His faked death (a decoy corpse in his clothes) is the central mid-game mystery. |
| **4** | **Clover** (Clover Field) | Snake's younger sister; emotionally volatile, blunt | The **danger variable**. Her grief over "Snake's death" drives the **Axe / Knife / Syringe** bad endings; giving her a bookmark is the flag that disarms her. |
| **3** (secretly **9**) | **Santa** (Aoi Kurashiki) | Silver-haired punk with an attitude | **Zero's accomplice** and Akane's brother. His bracelet symbol is 3 but works as 9; he pairs with June's 0 so the two "cancel out." |
| **7** | **Seven** | Huge, amnesiac, gentle-giant ex-detective | The **muscle and the memory**. Regains memories of the First Nonary Game; the player's ally across most routes. |
| **8** | **Lotus** (Hazuki Kashiwabara) | Self-serving, flirtatious; secretly a programmer/mother of twins | **Pragmatic math/logic voice**; her missing bracelet is a clue to Ace's killings. |
| **1** | **Ace** (Gentarou Hongou) | Calm, elderly "voice of reason"; CEO of Cradle Pharmaceutical | The **false ally / real killer**. Suffers **prosopagnosia** (face-blindness), which is both his motive (cure it via morphic fields) and his tell (he killed a decoy believing it was Snake). |
| — | **Zero** | Cloaked figure in a gas mask, speaks over loudspeakers | The **host**. Identity is the central mystery; revealed as **Akane**, assisted by Aoi/Santa. |
| **O** (letter, value **6**) | **"Cap"** (Kagechika Musashidou) | Dead captain found in the Captain's Quarters | **Item/flag** more than character: his 0-faced bracelet and the bloody axe sit next to his corpse; the 0 actually computes as 6. |
| **2** | **"Guy X"** (Nagisa Nijisaki) | Cradle Pharmaceutical executive | The **decoy corpse**: dressed in Snake's clothes and dumped behind Door 3 so the group believes Snake died. |

**Codenames are literally the bracelet symbols, not the hidden values** — "Ace" = 1 (card face), "Snake" = 2 ("snake eyes"), "Santa" = 3 ("san", Japanese for three), "Clover" = 4 (four-leaf), "Seven" = 7, "Lotus" = 8 (eight petals), "June" = 6 (the month). This is a deliberate design trick: the player reads the codenames as a clean 1–9 identity, while the true math hides two lies (Santa 3→9, June 6→0).

### 1.2 Character abilities / player-managed stats

There are **no RPG stats, no HP, no skill tree, no affection numbers.** The "abilities" are narrative and mostly hidden:

- **Junpei — puzzle literacy + latent esper.** The player's only skill is reading rooms and doing arithmetic (the game ships an in-game **digital-root calculator**). His true "power" is remembering prior timelines, which the game uses to justify ending-to-ending carryover.
- **Snake — sensory substitution.** Blind, but functions as a normal (better-than-normal) investigator; supplies the rules and key deductions.
- **Seven — strength + recovered memory.** Only he and Ace can do certain physical tasks; his recovered detective memories unlock the First Nonary Game backstory.
- **Lotus — computation.** The logic/math partner in escape rooms.
- **Ace — prosopagnosia (hidden debuff/ability).** The "disability as plot device" — his face-blindness makes him the killer and the key to identifying him.
- **Clover — volatility (hidden hazard).** Not a stat, but a **stateful threat**: depending on prior choices she murders the protagonist with an axe, a knife, or a syringe.
- **Bracelets — the real "character sheet."** Each participant's effective power is their **bracelet value** (see §4), which decides which doors they can open and therefore which routes are physically possible.

### 1.3 Character customization

**None.** The protagonist is a fixed, named, voiced character (Junpei); there is no name entry, appearance, gender, or build choice. Codenames are assigned by the cast, not the player. The only "customization" is **which door/group you take**, which reshapes your party composition for that run rather than your character.

---

## 2. Dialogue and action choices

999 alternates between two interaction modes; the "choice" verb exists in both.

**Novel sections** — reading over static art with voice beeps (DS) or full VO (remaster). Periodically the game stops and presents a **choice menu** of what Junpei says or does. Choices are of three kinds:

1. **Door/group choices** (the load-bearing ones) — "Door 4 or Door 5?", then "Door 3, 7 or 8?", then "Door 1, 2 or 6?". These set the route.
2. **Story flags disguised as flavour** — e.g. accept or decline **Santa's bookmark**; stay in the **Kitchen freezer** to hear the Ice-9 story vs leave; ask **Seven about Ice-9** in the Operating Room; **give the bookmark to Clover**. These look like small talk; four of them gate the true ending.
3. **Colour/flavour choices** — jokes, which character to talk to, the "Funyarinpa" painting gag, etc. Mostly cosmetic.

**Escape sections** — the action verb. First-person, node-based navigation around a room (DS: stylus/touch on the bottom screen); the player **examines** objects, **takes** items into a room-local inventory, **combines** items (there is a dedicated item-combination screen), and **inputs** answers on keypads/locks. The in-game calculator handles digital roots. **Hints** are available from the accompanying characters if the player is stuck.

Design tell: the escape rooms are **self-contained** — *"All Escape sections are self-contained, with all items required to solve the puzzles being available within that section; items are not carried over between Escape sections."* The adventure-game "inventory" is therefore a per-room scratchpad, not a campaign resource. Cleared rooms are replayable from the main menu.

---

## 3. Branching narrative and key scene description

### 3.1 How the story splits

The game is a **common prologue + three sequential "sets" of numbered doors**, each set a discrete choice, plus a terminal chapel/Door-9 sequence. Doors are the branch nodes; the story is told as a re-readable graph rather than parallel romance routes.

**Door sets (as documented):**

| Set | Options | Rooms entered | Junpei's companions |
|---|---|---|---|
| Prologue | *(none)* | 3rd Class Cabin (flooding) | — |
| **Set 1** (B Deck) | **Door 4** / **Door 5** | 2nd Class Cabin + Kitchen / 1st Class Cabin + Casino | Door 4: Santa, June, Lotus · Door 5: Snake, Seven |
| **Set 2** (Large Hospital Room) | **Door 3** / **Door 7** / **Door 8** | Shower Room / Operating Room / Laboratory | Door 3: Santa, June, Seven · Door 7: Clover, Seven · Door 8: Clover, Lotus |
| **Set 3** | **Door 1** / **Door 2** / **Door 6** | Chart Room + Captain's Quarters / Confinement Room + Torture Room / Steam Engine Room + Cargo Room | Door 1: Ace, Clover · Door 2: Seven, Lotus · Door 6: Ace, Santa, June |
| Finale (Chapel) | **Large Door 9** (Safe) / **Small Door 9** (True) | Incinerator / Library + Study + Incinerator | Snake, Seven / Snake, Clover, Seven |

The **ending is a function of the door sequence plus the four true-ending dialogue flags**, not a named "route" the player selects.

### 3.2 Routes: where they lead, cosmetic vs key

The community-documented ending triggers:

| Ending | Door path (and flags) | Type |
|---|---|---|
| **Submarine** | **Door 2 on any route.** In DS/remaster, choosing **Door 3** also forces the player into Door 2, so Door 3 leads here too. | **Key** (bad end) |
| **Knife** | **Door 6** without the Safe path: `4>7>6`, `4>8>6`, or `5>7>6`. | **Key** (bad end) |
| **Safe / Zero Lost** | **`5>8>6` — the only way.** | **Key** (normal/good; gates the True ending) |
| **Axe** | **Door 1** on any route **and** failing any true-ending story check (bookmark / freezer / Seven / give bookmark). | **Key** (bad end) |
| **Coffin** | The **true-ending path `4>7>1`** with all flags, **but without having seen the Safe ending**. | **Key** (incomplete/“To Be Continued”) |
| **True** | **`4>7>1`** + accept Santa's bookmark + listen to the freezer Ice-9 conversation + ask Seven about Ice-9 + give Clover the bookmark, **and** the Safe ending must already have been seen. | **Key** (canonical ending) |
| **Syringe** | **Door 3**, **iOS only**. | **Key** (bad end, platform-exclusive) |

**Cosmetic layer:** the flavour dialogue, the order in which you chat with characters, the "Funyarinpa" answer, and most non-gating choices change text and tone but not outcomes. **Key layer:** the three door sets and the four true-ending flags.

**Notable route facts:** the **Incinerator is not itself an escape room** (except for its puzzle in the True ending). Across all routes, **Seven travels with Junpei through the most doors (5)**, Clover 4, then Akane/Santa/Lotus at 3 each.

### 3.3 Key scenes (spoiler-level, with mechanics attached)

- **The 9th Man's death (Set 1 opening).** The 9th Man holds Clover at knifepoint and forces **Ace (1) + Clover (4) + himself (9) = 14 → digital root 5** to open **Door 5**. He goes through alone; because the DEAD authentication fails, his bracelet detonates and he is blown apart. **This scene is the rules tutorial**: it demonstrates both the digital-root arithmetic and the 81-second penalty.
- **The first choice — Door 4 or 5.** Splits the party and the tone: Door 4 puts Junpei with Santa/June/Lotus (2nd Class Cabin, Kitchen — where the **Ice-9 / morphic-resonance** exposition lives), Door 5 with Snake/Seven (1st Class Cabin, Casino).
- **Snake's "death" (Set 2).** Behind Door 3 the group finds a corpse in Snake's clothes; the game sells it as Snake. In the Safe ending Junpei realises the body's **left arm is not prosthetic** (Snake had a prosthetic left arm) — the decoy is **Nagisa Nijisaki, "Guy X."** This is the mechanical hinge that exposes Ace's **prosopagnosia**.
- **The third choice — Door 1 / 2 / 6.** Door 1 (Chart Room + Captain's Quarters) yields the **pocket watch, the dead captain, the 0 bracelet and the bloody axe** — the ingredients of the Axe ending. Door 6 (Steam Engine + Cargo) yields the **Cradle Pharmaceutical documents** and the **golden revolver hidden in a coffin** (Ace's weapon). Door 2 leads to the **Submarine** ending.
- **Safe ending — Ace unmasked.** Junpei opens the safe in the 1st Class bathroom (Clover's corpse holding the "sinister hand" paper and the 0 bracelet), identifies Ace as **Gentarou Hongou**, proves the decoy murder, and demonstrates the trick that the RED accepts a bracelet waved near it. Ace takes Lotus hostage; **Snake, freed from the coffin, grapples Ace and both burn in the incinerator**; June collapses with fever and vanishes; Junpei is gassed.
- **True ending — the perspective reveal.** Junpei relives the incinerator puzzle, but the game reveals the narration he has been reading **was 12-year-old Akane's point of view** during the *First* Nonary Game. She connected to future-Junpei through **morphic fields**, watched his possible futures (i.e. **the multiple endings**), and steered him. Junpei relays the **Sudoku solution** back in time, saving young Akane; she gives him the string **2+4+5+7+8** that opens **Door q**. The survivors discover they were in **Building Q, Nevada**, all along, find Ace bound in an SUV, and pick up the hitchhiker **Alice**.
- **Axe ending — Clover's rampage.** Clover, believing Snake murdered, kills Santa, Seven and June, offers Junpei escape, and **kills him with an axe**. **Knife** and **Syringe** are the same betrayal with a different weapon (Ace's knife; Clover's syringe). These endings exist to punish the player for not building Clover's trust.

---

## 4. Story flags and variables

999's hidden state is small, precise, and mostly **door-based**. It uses four kinds of variables:

**(a) Door-visitation flags (the primary state).** Each numbered door traversed is recorded; the ending resolver reads the *sequence*. This is why the triggers are written as strings (`5>8>6`, `4>7>1`).

**(b) Boolean dialogue flags (the true-ending gate).** Four flags, all disguised as optional flavour, must be **true** for the True ending:
1. Accept **Santa's bookmark** in the 2nd Class Cabin.
2. Stay for the **Ice-9 conversation in the Kitchen freezer** (answer "It did strike Junpei as rather odd").
3. Ask **Seven about Ice-9** in the Operating Room.
4. **Give Clover the bookmark** when prompted.

Failing any of these on the `4>7>1` path yields the **Axe** ending instead of the True one.

**(c) A persistent meta-flag: "Safe ending seen."** This is the game's most important variable and its most famous design idea. The True ending is **hard-locked** until the Safe ending has been completed — the in-fiction justification being that Junpei, an **esper**, "remembers information across timelines." Concretely, the Safe ending gives the player the **"sinister hand" tip** and the **coffin combination `14383421`**, which the True path needs. Following the True path *without* this flag produces the **Coffin** ending: the same route, stopping just before the coffin opens, with a **"To Be Continued"** screen and a voice saying **"Truth has gone."**

**(d) Hidden numeric values — the bracelet "true values."** The game quietly lies about the numbers on screen. The displayed symbol is not always the arithmetic value:

| Character | Symbol shown | True value | Notes |
|---|---|---|---|
| Ace | 1 | 1 | |
| Snake | 2 | 2 | one of two 2s |
| **Santa** | **3** | **9** | secretly a 9; pairs with June's 0 to "cancel" |
| Clover | 4 | 4 | |
| Junpei | 5 | 5 | |
| **June** | **6** | **0** | an upside-down 9; works as 0 |
| Seven | 7 | 7 | |
| Lotus | 8 | 8 | |
| 9th Man (Kubota) | 9 | 9 | |
| Captain Musashidou | **O** | **6** | letter O = hex 24 → 2+4 = 6 |
| Nagisa Nijisaki ("Guy X") | 2 | 2 | second 2 |

This hidden-value layer is the game's biggest "variable twist": the player does arithmetic on symbols that are, for two party members and one key item, **not the values they appear to be**. It is also the source of the Axe ending's cruel irony — Clover thinks `4+5+0=9`, but the captain's "0" is actually 6, so the door would never open for her.

**How flags are read:** the ending resolver = (door sequence) → branch, then (dialogue flags) → which terminal, then (meta-flag Safe-seen) → whether the True terminal is reachable. The remaster's **FLOW Chart** makes this machinery visible, even showing **"which requirements for unlocking the True and Safe endings are or are not met."**

---

## 5. Relationship and affection systems

999 has **no numeric affection meters**, but it does have **relationship state encoded as booleans and door choices**. The relationships are:

- **Junpei ↔ June / Akane (romance).** Childhood friends; the emotional spine. In the Safe ending there is a romantic scene between them; in the True ending the romance becomes the mechanism of the plot (she is literally reaching across time to him). Her "affection" is not a bar but the entire premise.
- **Clover ↔ Snake (siblings).** Clover's devotion is the most mechanically consequential bond in the game. Her grief at Snake's (fake) death turns her into the **bad-ending killer**. Building her **trust** (giving her the bookmark; telling her Snake may still be alive) is the difference between the True ending and being axed/knifed/syringed.
- **Clover ↔ Junpei (trust flag).** The **bookmark gift** is the closest thing to an affection variable: a single boolean that disarms her rampage.
- **Ace (rival / hidden enemy).** Not "affection" but **deception**: the game makes the calm old man the ally until the reveal. His prosopagnosia is both motive and vulnerability.
- **Santa / Aoi (secret ally).** Reads as hostile; is Zero's assistant and Akane's brother. His "trust" arc is a misdirection.
- **Seven (friendship).** The reliable protector; his regained memories are a trust-gated exposition channel.
- **Lotus (neutral/pragmatic).** Self-interested but competent; her hostility can be softened by dialogue.
- **The player ↔ the cast (party-composition effect).** Choosing a door changes *who you spend the next act with*, which changes which relationships get screen time. Relationship "affection" is therefore expressed through **route composition**, not meters.

Design reading: 999 replaces the dating-sim affection bar with a **binary trust flag** (the bookmark) that only matters on one route, plus the **route composition** as the ambient relationship system.

---

## 6. Multiple endings

**Six endings** on DS / *The Nonary Games* (**seven** on iOS). Classified by type:

| Ending | Type | Outcome |
|---|---|---|
| **True** | True / canonical | Akane saved across time; Building Q revealed; Alice teaser. Requires Safe seen + all four flags + `4>7>1`. |
| **Safe / Zero Lost** | Good / normal | Ace exposed; Snake burns with Ace; June vanishes. The **required prerequisite** for the True ending. |
| **Coffin** | Incomplete True (“To Be Continued”) | The True path run *without* the Safe flag; stops at the sealed coffin. |
| **Submarine** | Bad | Ace fakes death and murders the cast; Junpei is stabbed and drowns. |
| **Knife** | Bad | Ace stabs Junpei in the back; the only ending where Junpei sees the killer but cannot name him. |
| **Axe** | Bad | Clover, driven mad, kills the party and Junpei. |
| **Syringe** *(iOS)* | Bad | Clover drugs Junpei and lets him drown; iOS-only. |

**Failure modes** are explicitly relationship-driven: a *relationship breakdown* (Clover's trust fails → Axe/Knife/Syringe), *unresolved mystery* (Coffin's "To Be Continued," the Coffin ending even auto-clears once the True ending is obtained), or *alternate conclusion* (Submarine/Knife). The True ending is the only one that resolves the central mystery, and it is **hard-locked** behind the Safe ending — a deliberately structural, not skill-based, gate.

---

## 7. Save and load

Save/load is the most **platform-divergent** system in the game, and the source of its most-criticised design flaw.

- **Nintendo DS (original):**
  - **Manual save/load** through the pause menu with a small number of slots (the game does not autosave; players are expected to manage saves themselves). *(See uncertainty flag.)*
  - **No FLOW Chart.** To see another branch the player must **replay the whole game**, re-solving every escape room. This is the game's single most-criticised mechanic.
  - **Fast-forward of already-read text** is available via the D-pad, but there is **no auto-advance**.
  - **"Memories of the Escape"** — a bonus replay mode unlocked after the first ending: it lets the player **re-enter and replay cleared escape rooms** (listed by the order the endings visited them — True, Safe, Submarine). Cutscene interactions are replaced with "I feel like something has happened here." This is the DS build's closest thing to chapter select.
  - **No time limit:** despite the "9 hours" premise, there is **no in-game timer**.
- ***The Nonary Games* remaster (PS4 / Vita / PC / Xbox):**
  - Adds the **FLOW Chart**: jump to any point, re-enter escape rooms or novel sections, re-make decisions, without replaying from the start. The chart **judges the player on the last decisions made** and **shows whether the True/Safe unlock requirements are met**.
  - Adds **auto-advance mode**, full voice acting, higher-quality art/music.
  - Retains **"Memories of the Escape."**
- **iOS *999: The Novel*:**
  - **No escape rooms at all** — puzzles are narrated; the game is comic-panel style.
  - **Has a FLOW Chart** (arrows choose doors directly), but loses the dual-screen twist's impact.
  - Adds the **Syringe** ending.
- **Cross-platform caveat:** because the game was built around the **DS's two screens**, the remaster explicitly notes that **"certain parts of the game simply do not have the same impact in single-screen platforms"** — the bottom-screen reveal is a one-console trick (see §4/§8).

---

## 8. Inventory / items

There are **two distinct inventories**, and only one of them persists.

**(a) Escape-room inventory (per room, non-persistent).** Each escape room is a closed system: all items needed to solve it are inside it, and **items do not carry between rooms**. The player picks up keys, tools, cards, and components, examines them, and **combines** them (the game has a dedicated item-combination screen) to build the object that opens the exit. The in-game **digital-root calculator** is effectively a permanent "tool" always available.

Representative items per scene (key / document / weapon / gift):

| Scene (door) | Notable items collected / used |
|---|---|
| **3rd Class Cabin** (prologue) | Escape-the-flooding-room components; the game's first puzzle |
| **2nd Class Cabin + Kitchen** (Door 4) | **Santa's bookmark** (gift / trust flag); the freezer scene's **Ice-9** exposition |
| **1st Class Cabin + Casino** (Door 5) | Casino/gambling puzzle items; the **safe** and **"sinister hand" paper** are reached from here in the Safe ending |
| **Shower Room** (Door 3) | The **decoy corpse** ("Guy X") in Snake's clothes — the prosopagnosia clue |
| **Operating Room** (Door 7) | **Seven's Ice-9 conversation** (flag) |
| **Laboratory** (Door 8) | Lab puzzle components |
| **Chart Room + Captain's Quarters** (Door 1) | **Pocket watch** (exit key), the **dead captain**, the **0 bracelet** (true value 6), the **bloody axe** |
| **Confinement Room + Torture Room** (Door 2) | Puzzles en route to the **Submarine** |
| **Steam Engine Room + Cargo Room** (Door 6) | **Cradle Pharmaceutical documents**; the **golden revolver** hidden in a coffin (Ace's weapon) |
| **Chapel** (finale) | **Two Door 9s**; the **coffin** holding Snake; the **`14383421`** keypad combination (Safe-flag knowledge) |
| **Library + Study** (True, small Door 9) | The **First Nonary Game backstory documents** (Cradle, morphic fields, the 18 children) |
| **Incinerator** (True) | The **Sudoku puzzle** (relayed to the past) and **Door q** code **2+4+5+7+8** |

**(b) Persistent "key items" (the bracelets).** The only items that persist are the **bracelets** themselves. They are, mechanically, the game's character sheet and door keys: the symbol/value on each decides who can pass which door, and **dead players' bracelets come off**, so **collecting corpses' bracelets** is a strategy (Ace kills for the 9 and the 0; the group opens Door 9 with the captain's "0" = 6). The **0 bracelet, the golden revolver, the axe, the knife, and the syringe** are the recurring "weapons" that produce the bad endings.

Design reading: the adventure-game inventory is deliberately **throwaway** (room-local), while the **bracelet values** are the true, persistent inventory — a neat inversion of the genre norm.

---

## Appendix A — Route/ending quick-reference

```
Prologue (3rd Class Cabin, flooding)
        │
   ┌────┴─────────────────────────┐
 Door 4                        Door 5
 (2nd Class Cabin + Kitchen)   (1st Class Cabin + Casino)
        │                          │
   ┌────┼────┐                ┌────┼────┐
 Door 3  D7  D8             Door 3  D7  D8
 Shower  Oper  Lab          Shower  Oper  Lab
   │      │     │              │      │     │
   └──────┼─────┴──────┬───────┴──────┼─────┘
        ┌─┴─┐        ┌─┴─┐         ┌──┴──┐
      Door1 Door2   Door1 Door2    Door1 Door2
        │    │        │    │         │    │
        │    └──► Submarine (any Door 2; DS Door 3 forces Door 2)
        │
   Door 1 ──► Axe  (unless True flags + Safe seen)
   Door 6 ──► 5>8>6 = Safe ;  4>7>6 / 4>8>6 / 5>7>6 = Knife
   Door 4>7>1 + 4 flags + Safe seen = True ;  without Safe seen = Coffin
   Door 3 (iOS only) = Syringe
```

**True-ending flags (all four required):** Santa's bookmark · freezer Ice-9 talk · ask Seven about Ice-9 · give Clover the bookmark.
**True-ending hard gate:** Safe / Zero Lost ending must already be cleared.

## Appendix B — What a designer should steal from *999*

1. **The digital-root door is a brilliant choice-encoder.** It turns "which group do I go with?" into **arithmetic the player can verify**, so route choice feels like a *rule of the world* rather than a dialogue option.
2. **Disguise gates as flavour.** The four true-ending flags are all optional small talk; the player never sees a "this will matter" marker. High-risk, high-payoff.
3. **Make the meta-progression diegetic.** "You must finish the Safe ending first" is justified as **esper memory across timelines** — the save-file mechanic becomes the plot. This is the game's signature idea.
4. **Hide a lie in your UI.** Displayed bracelet values ≠ true values (Santa 3→9, June 6→0, "0"=6) is a variables twist that makes the player distrust the interface itself.
5. **Use the hardware as a narrative layer.** The DS bottom screen being a second consciousness (young Akane's POV) is a once-per-platform trick that no single-screen port can reproduce.
6. **Weaponise a relationship boolean.** One gift (the bookmark) is the entire difference between the true ending and being murdered by Clover.
7. **Know the cost.** The DS build's lack of a flowchart forced full replays and is the game's most-hated flaw; the remaster's FLOW Chart is the fix every branching VN should ship with.

## Sources

- Zero Escape Wiki (Fandom), *Nine Hours, Nine Persons, Nine Doors endings* (archived capture) — ending triggers and summaries.
- Zero Escape Wiki (Fandom), *Zero Escape: Nine Hours, Nine Persons, Nine Doors* (archived capture) — plot, characters, gameplay, escape-room table, platform differences.
- Zero Escape Wiki (Fandom), *Numbered Doors*, *Bracelet*, *FLOW Chart* (archived captures) — digital-root rules, RED/DEAD, bracelet true values, flowchart history.
- Wikipedia, *999: Nine Hours, Nine Persons, Nine Doors* — development, gameplay, localization, the bottom-screen/POV footnote, reception.

## Uncertainty flags

- **DS save/load specifics** (number of slots, whether saving is allowed inside escape rooms, whether there is any autosave) are **not documented** in the sources consulted and are stated from general knowledge; verify against the DS build before quoting exact numbers.
- **Door 3 behaviour** is reported inconsistently across wiki pages: one page treats Door 3 as a normal Set-2 branch (Shower Room, leading onward), another says choosing Door 3 "forces the player into Door 2" (Submarine) on DS/remaster. Both are reported above; the iOS build unambiguously maps Door 3 → Syringe.
- The **iOS Syringe ending** and the **extra ending** wording differ slightly between sources (some call Syringe the seventh ending; the remaster omits the iOS extra).
- **Item lists per room** are representative (key/document/weapon/gift examples) rather than exhaustive; individual escape-room item manifests are spread across per-room wiki articles not fully retrieved here.
- The **Junpei-is-an-esper** framing is the in-fiction explanation for cross-timeline memory; the actual save/flag implementation is a normal engine feature dressed in that language.
