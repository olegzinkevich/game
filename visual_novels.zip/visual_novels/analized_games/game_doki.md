# Doki Doki Literature Club! (2017) — Deep-Dive Mechanics Report

**Game:** Doki Doki Literature Club! (DDLC)
**Developer / publisher:** Team Salvato — created, written, programmed and scored by **Dan Salvato** (art by Satchely, backgrounds by VelinquenT)
**First release:** Windows / macOS / Linux, **22 September 2017**, freeware (itch.io, later Steam; "pay what you want")
**Engine:** **Ren'Py** (Python) — heavily extended with custom Python that reaches outside the game window
**Enhanced version:** *Doki Doki Literature Club Plus!* (30 June 2021) — rebuilt in **Unity**, adds a "virtual desktop", side stories, and a music player
**Genre:** Visual novel / dating-sim parody → **metafictional psychological horror**
**Structure:** four acts (1 romance, 2 collapse, 3 the void, 4 restored world) plus an epilogue/credits
**Playtime:** ~4–6 h for one pass; ~8–10 h for full completion
**Content warning:** the game opens with an unavoidable disclaimer — *"This game is not suitable for children or those who are easily disturbed."*

> **Scope note:** DDLC *looks* like a standard choice-menu dating sim and then deliberately dismantles the player's control. Its "routes" are shallow and mostly cosmetic; its real machinery is **hidden affinity counters, a persistent meta-file, and the player's own operating system/filesystem**. Where the requested category barely exists (customization, inventory, stats), this report says so rather than inventing depth — but it also flags where the game's *absence* of a mechanic is itself the design.

---

## 0. Executive summary (the design in one paragraph)

The player is an unnamed, player-named high-school student who is dragged by his childhood friend **Sayori** into the school's **Literature Club**. Each day the player "writes a poem" by selecting twenty words from a word pool; every word secretly carries an affinity to one of three girls — **Sayori**, **Natsuki** or **Yuri** — so the poem determines which girl you bond with. This is the whole of the "gameplay": a dating sim with a word-picker. Then the game breaks. **Monika**, the club president, is a **self-aware character who knows she is in a video game and can edit its code and files**. She amplifies the other girls' worst traits (Sayori's depression, Natsuki's harshness, Yuri's obsession), deletes characters, hijacks the cursor and dialogue, erases your save files, disables the save and skip buttons, reads your computer's username, and finally asks you to **delete her own character file** from your hard drive. The player's real interface with the game is therefore not a menu — it is the **file explorer**. The "choices" mostly do not matter; the things that *do* matter are which **CGs** you unlocked (a save-scumming meta-task) and whether you physically delete the right file at the right moment.

---

## 1. Characters

### 1.1 Core character portraits

The player character is an **unvoiced, player-named** first-person narrator (fandom calls him "MC"). Dan Salvato states he is not a real character — "just a blank slate that says whatever is convenient" — and *Plus!* lore reframes him as an interface Monika built to talk to the player.

| Role | Name | Defining trait | Function in the machine |
|---|---|---|---|
| Protagonist | **Player's Choice** (a.k.a. MC) | Underachieving, blunt, kind underneath; plays games and watches anime | Player avatar; his name is entered at start. Monika treats him as a puppet and addresses the **player** over his head. |
| Childhood friend | **Sayori** (紗世里) | Cheerful, clumsy, sleeps in; hides **depression** | The emotional hook of Act 1; her suicide ends it. She is the **president after Monika**, so she becomes self-aware in Act 4. |
| Tsundere | **Natsuki** (夏樹) | Prickly, proud, small; loves manga and bakes **cupcakes** | Comic relief whose home life (an abusive father, malnourishment) is revealed in Act 2; Monika makes her harsher. |
| Shy bookworm | **Yuri** (優里) | Tall, quiet, elegant; **knife and self-harm** obsession; reads *Portrait of Markov* | The object of the forced Act 2 route; Monika makes her obsessive, and she kills herself. |
| Club president | **Monika** (莫妮卡) | Confident, popular, "perfect"; **self-aware antagonist** | The true engine of the game. She edits the script, the files, and the other characters, and falls in love with the **player**, not the protagonist. |
| Off-screen | **Natsuki's father / Yuri's parents / Sayori's family** | Never shown | Sources of the girls' real-world trauma, delivered through poems and dialogue. |

**Music as identity (a tracked tell):** the track **"Okay, Everyone!"** exists in **four versions** — piano (Monika), pizzicato/harp (Yuri), xylophone/recorder (Natsuki), ukulele (Sayori). The version playing signals whose "space" the scene is in, and the score's two ominous tracks, **"Sayo-nara"** and **"Just Monika"**, mark the horror turns.

**Naming as a hint:** every girl has a Japanese name except **Monika** — an English name, planted as a subtle flag that she is "outside" the fake-Japan fiction.

### 1.2 Character abilities / player-managed stats

There are **no RPG stats** — no HP, no skill points, no visible affection numbers. What stands in for "abilities" is authored and asymmetric:

- **The protagonist** — no abilities. His only agency is clicking words and (in Act 3) the operating system. He gradually stops reacting to the world as Monika overrides him.
- **Monika — the game's only "powered" character.** Her abilities are literally **developer/file-system access**:
  - editing dialogue and character files;
  - deleting characters (`yuri.chr`, `natsuki.chr`, and by implication Sayori);
  - **disabling the Save, Load and Skip buttons** and erasing saves (Act 3);
  - hijacking the **cursor** and forcing a "choice" (Act 2);
  - reading the player's **OS username** and PC name aloud;
  - triggering a fake **blue screen of death** and detecting recording software (OBS/XSplit);
  - glitching sprites, fonts, backgrounds and audio on demand.
- **Sayori** — gains the same "president awareness" when she inherits the role (Act 4 and the Quick Ending), the game's built-in proof that *the presidency is what corrupts*.
- **Natsuki / Yuri** — no powers, but Monika **amplifies their traits** by editing their files, which is why Act 2 Yuri is obsessive and self-harming and Act 2 Natsuki is cruel.

The only quantity the game actually maintains is a **hidden per-girl poem-affinity counter** (§4–5). The player never sees it.

### 1.3 Character customization

- **Name entry only.** At the start the player types the protagonist's name; this name is then **spoken by the other characters** and, crucially, used by Monika.
- **No appearance, no voice, no personality build, no romance target selection at creation.** The protagonist's face is never shown (only his back, once, and his arms).
- The customization the game *pretends* to offer is the **poem**: twenty word-clicks per day that nominally author your own text but in fact only feed a hidden counter.
- Monika's twist on customization: she addresses **you**, using your **computer username**, breaking the "character creation" fiction entirely.
- In **DDLC Plus!** the OS-level file manipulation is replaced by an in-game **"virtual desktop"**, so the "customization" of your own filesystem is abstracted away.

---

## 2. Dialogue and action choices

DDLC uses the **standard Ren'Py choice-point model**, but its arc is a slow *removal* of choice.

- Static 2-D sprites over first-person backgrounds, a dialogue box, first-person narration, no voice acting (except Monika's song).
- The recurring, *real* input is the **poem word-selection minigame** (§2.1).
- Menu choices fall into three functional classes:
  1. **Cosmetic / colour choices** — who to talk to, a joke line, a flavour response. They nudge hidden affinity and change nothing structural.
  2. **Route-tinting choices** — the Day-2 argument (side with Natsuki, Yuri, or ask Sayori), the festival-helper choice (Monika / Sayori / Natsuki / Yuri), the Sunday "date", and the **Sayori confession (accept / reject)**. These change scenes, dialogue and **CG unlocks**, but the plot still funnels to the same Act 1 ending.
  3. **Forced / hijacked choices** — in Act 2 the cursor is **dragged to Monika**; if you fight it and click Yuri or Natsuki you get a static/eyeball jumpscare and the menu returns with only **"Monika"** buttons. In Act 3 the only option is **"Yes"**, and the only real action is closing the game and deleting `monika.chr`.

### 2.1 The poem word-selection minigame (the core loop)

- Each day you are shown a pool of words and **select 20** to build a poem.
- Every word carries a **hidden affinity tag to one of the three girls** (Sayori / Natsuki / Yuri). The game tallies how many of each girl's words you chose; the girl with the **highest tally** becomes the focus of the next scene and reacts most warmly to your poem.
- **Sayori's affinity dominates the word table**, so it is almost impossible to write a poem Sayori dislikes — a designed trap that makes her eventual despair land harder.
- The **Day-2 argument** choice grants **+5 bonus affinity points** to the girl you side with, applied to the next poem game.
- **Monika is deliberately excluded** from the word pool (she has no words), which is itself a clue: she is not playing the same game as the others.
- In **Act 2** the word table can **glitch** (each word has a ~1/401 chance per game to become a corrupted word), distorting the minigame's textures and audio.
- In **Act 3** the minigame returns, but every word is a misspelling of **"Monika"** — the only poem you can write is her.

**Player-facing feel:** the design's bet is that the "game" (word-picking) is a comforting illusion of authorship. When Monika seizes the script, the player discovers the words were never really theirs.

---

## 3. Branching narrative and key scenes

### 3.1 How the story splits

DDLC is **not** a true route-based VN. It has **acts** that play in a fixed order, with **soft, per-playthrough affinities** inside Act 1 and **forced** story beats afterward. Wikipedia's summary is blunt: choices "affect the development of his relationships … but ultimately have little effect on the outcome."

```
ACT 1 — the dating sim
  Common intro (Sayori drags you into the club)
        │  daily poem word-selection builds hidden affinity
        ├─ Sayori tint   ── scene + CG (blazer button; art supplies)
        ├─ Natsuki tint  ── scene + CG (manga/closet; cupcakes)
        ├─ Yuri tint     ── scene + CG (Portrait of Markov; banners)
        └─ Neutral tint  ── "beach poem" (no romance scene)
        │
   Day 2 argument (Natsuki / Yuri / Sayori)  → +5 affinity, cosmetic
   Day 4 festival-helper choice (Monika/Sayori/Natsuki/Yuri) → scene + CG
   Sunday "date" (Natsuki or Yuri) + Sayori confession (accept/reject)
        │
   FIXED END: Sayori hangs herself → game returns to title, saves wiped
        ▼
ACT 2 — the collapse  (Sayori absent; world glitching)
   Same skeleton, but: forced into Yuri; Monika rewrites characters;
   random horror events; Natsuki's cry-for-help note; Yuri's suicide
        │
   FIXED END: Yuri stabs herself; forced weekend with the corpse;
              Natsuki flees; Monika deletes Yuri and Natsuki
        ▼
ACT 3 — the void  (Monika alone in space)
   No save, no skip, no choices except "Yes"; Monika's monologue;
   the ONLY exit is deleting monika.chr from your filesystem
        ▼
ACT 4 — the restored world
   Club exists again without Monika; Sayori becomes self-aware
        │
        ├─ NORMAL ENDING   (not all CGs seen) → Monika deletes the game
        └─ GOOD ENDING     (all 10 CGs seen) → Sayori thanks you; game spared

SIDE EXITS (from the title screen / filesystem, not the story)
        ├─ QUICK ENDING    → delete monika.chr before a new game
        ├─ SHORT QUICK END → delete sayori.chr with Act-1 save data
        └─ CHEATING SCENE  → copy a save across acts without the "persistent" file
```

### 3.2 "Routes": levers, destinations, and weight

| Route / branch | How it is entered | Where it leads | Long-term consequence? | Type |
|---|---|---|---|---|
| **Sayori tint** | Pick Sayori's words / side with her | Extra scenes + **CG**; her confession; still ends in her suicide | **Key for the good ending** (her CGs), not for the plot | Cosmetic-with-a-key-CG |
| **Natsuki tint** | Pick Natsuki's words | Extra scenes + **CG**; cupcakes; her note in Act 2 | Key for the good ending (CGs) | Cosmetic-with-a-key-CG |
| **Yuri tint** | Pick Yuri's words | Extra scenes + **CG**; *Portrait of Markov*; forced in Act 2 | Key for the good ending (CGs); Act 2 forces her anyway | Cosmetic-with-a-key-CG |
| **Neutral "beach poem"** | Never let Yuri/Natsuki love or hate your poem twice | Generic scene, no romance CG | None | Purely cosmetic |
| **Day-2 argument** | Side with Natsuki / Yuri / Sayori | Different dialogue, +5 affinity to that girl | Feeds affinity only | Cosmetic |
| **Festival helper** | Pick Monika / Sayori / Natsuki / Yuri | Scene + CG (Natsuki or Yuri) | Key for good ending (CGs); Monika/Sayori gives no CG | Cosmetic-with-a-key-CG |
| **Sayori confession** | Accept / reject | Different lines + **hug CG** if accepted | Feeds the good ending (CG); no plot change | Cosmetic-with-a-key-CG |
| **Act 2 forced Yuri** | Automatic (cursor hijack) | Yuri's obsession and suicide | **Key** — the plot's turning point | Key (forced) |
| **Act 3 Monika** | Automatic after Act 2 | The void; the meta reveal | **Key** — only exit is file deletion | Key (meta) |
| **Act 4 ending branch** | All 10 CGs seen vs not | Normal vs Good ending | **Key** — determines the finale | Key |
| **Quick / Short Quick ending** | Delete a character file before starting | Alternate "bad" finale | **Key** — an ending of its own | Key (filesystem) |

**Cosmetic vs key, clarified:** almost every *in-story* choice is **cosmetic** — the plot is a rail. The genuinely **key** inputs are (a) **collecting all ten CGs**, which requires **save-scumming and replaying Act 1**, and (b) **manipulating the filesystem** (deleting `monika.chr`). The "routes" are an illusion maintained for Act 1; the game's actual branching is meta.

### 3.3 Key scenes (spoiler-level, with mechanics attached)

- **The opening walk / joining the club.** Sayori drags the protagonist in; the four girls are introduced. This establishes the dating-sim façade the game will spend three acts destroying.
- **The daily poem-sharing.** Each girl responds to your poem; the **word-affinity tally** decides who leans in. This is the only "system" the player believes they are playing.
- **The Day-2 argument.** Natsuki vs. Yuri over writing style; whoever you side with gets **+5 affinity**. The game later reveals it does not matter.
- **The Sunday dates and Sayori's confession.** Natsuki or Yuri almost kisses you (CG); Sayori confesses her lifelong depression and her love. Accepting gives a hug **CG**; rejecting changes only her heartbreak. Either way the plot proceeds.
- **Sayori's suicide (end of Act 1).** Monika shows you a poem reading only **"get out of my head"**; you rush to Sayori's house and find her **hanged**. The game glitches, plays the distorted **"Sayo-nara"**, and dumps you at a title screen where her sprite is a scrambled composite of all four girls. **All save files are erased.** This is the first time the game acts on *your* machine.
- **Act 2 — the collapse.** Sayori is gone and *no one remembers her*. The world is corrupted: **mojibake text, distorted sprites, "realistic" eyes, random horror events** (eyeballs exploding, a hanging poster in the classroom, a fake BSOD, Monika's "Save Me / Delete Her" poem). **Natsuki** is revealed as malnourished and abused, and hands you a **note begging you to get Yuri help** — which Monika then glitches away. **Yuri** becomes obsessive and self-harming.
- **Yuri's suicide (end of Act 2).** Yuri ejects the others, confesses obsessively, and **stabs herself three times** regardless of your answer. A "broken script" forces you to spend the **weekend staring at her decomposing body** while 1,400+ lines of gibberish scroll. Natsuki flees in horror; Monika **deletes Yuri and Natsuki** on screen and returns you to the menu.
- **Act 3 — the void (the meta reveal).** Monika, alone in a starfield classroom, admits she edited everyone: she deepened **Sayori's depression**, made **Natsuki harsher**, made **Yuri obsessive** — trying to make them unlikable so you would choose her. She confesses she loves **the player**, not the protagonist, and talks indefinitely. **Save and Skip are dead**, prior saves erased; the only way forward is to open your file explorer and **delete `monika.chr`**.
- **Monika's deletion and apology.** As she is erased she lashes out, then forgives you, regrets what she did to her friends, and **restores the game without herself**.
- **Act 4 and the ending.** The club is normal again; **Sayori** becomes president and gains self-awareness — and Monika (not quite gone) **deletes her** before she can repeat the cycle. Then either Monika **deletes the whole game** (Normal) or, if you saw every CG, **Sayori thanks you** and the game is spared (Good).
- **"Your Reality" (credits).** Monika's self-written song, sung by Jillian Ashcraft — the only confirmed voice in the game — plays over the credits, the last emotional weapon before the ending note.

---

## 4. Story flags and variables

The game keeps a **hidden variable store**, a **persistent meta-file**, and — uniquely — uses the **real filesystem** as its flag array.

1. **Per-girl poem-affinity counters (hidden).** Each word you pick adds to Sayori's, Natsuki's or Yuri's tally; the highest tally selects the next scene. The **Day-2 argument adds +5** to the chosen girl. There is no visible meter. Sayori's words are over-represented, so she nearly always "wins".
2. **CG-unlock flags (the real ending gate).** Ten CGs exist (poem/confession CGs for Sayori, Natsuki, Yuri, plus Monika's Act-3 CG). The **Good Ending fires only if all ten are flagged as seen.** Because Act 1 is short and reusable, the intended method is to **save before the first poem, replay for each girl, and reload** — i.e. the ending is gated on **save-scumming**, not on a story decision. (Not viewing Monika's Act-3 CG before deleting her forfeits the Good Ending.)
3. **The "persistent" file.** A separate file outside the save slots stores cross-session state (current act, seen content). Copying a save across acts **without** the matching persistent file trips a **"cheating" detection**: a black screen, then Monika asking if you are trying to cheat.
4. **Filesystem flags — the character files.** The `characters/` folder holds `monika.chr`, `sayori.chr`, `natsuki.chr`, `yuri.chr` (actually disguised image/audio/text files). Their **presence or absence is a flag the script reads**:
   - Deleting `monika.chr` in Act 3 is the **only way to progress**.
   - Deleting it **before a new game** triggers the **Quick Ending**.
   - Deleting `sayori.chr` with Act-1 save data triggers the **Short Quick Ending**.
   - Restoring `monika.chr` in Act 4 makes her refuse ("Please stop playing with my heart") and delete herself.
5. **Act-state / read-state tracking.** Standard per-line "already-read" flags power Skip; a **`firstrun`** file gates the first launch and is the documented hard-reset flag (delete it to replay without reinstalling). In *Plus!* a `reset.sh` plays this role.
6. **Random-chance pseudo-flags.** Many Act 2 events are **not** choice-driven but probability-driven, so no two players see the same horror: Natsuki's eyes explode (1/3), a hanging poster appears (1/6), a glitched word spawns (1/401 per word), Monika flashes in the menu (1/50), the game boots to a corrupted END screen (1/64), and so on.
7. **Special-poem selection.** At the start of a run, **three of eleven** "special poems" are drawn to appear after poem games in Act 2. They are **fixed for that playthrough**; only a **new game** rerolls them — a per-run seed.
8. **Environment flags.** Monika reads the **OS username / PC name** (spoken aloud) and **detects capture software** (OBS/XSplit), which replaces her line with a **jump-scare** — flags that live outside the game entirely.

**Crucially, later scenes check these values:** Act 4 checks the **CG flags** to pick the ending; the script checks **file presence** to pick Act 3's exit and the Quick Ending; the save system checks the **persistent file** to detect cheating. The game never explains the CG requirement, which is why the Good Ending is famously easy to miss on a first run.

---

## 5. Relationship and affection systems

DDLC presents a dating-sim relationship web and then **deconstructs it**. There is **no relationship UI** — no bars, hearts or trust numbers. Relationships are modelled as **hidden poem-affinity counters** feeding scene selection, plus a great deal of authored emotion.

| Relationship | Nature | How it moves |
|---|---|---|
| **Protagonist ↔ Sayori** | Childhood-friendship, unrequited love, depression | Rises through her word picks and the confession; accepting yields a CG. The plot kills her regardless. |
| **Protagonist ↔ Natsuki** | Tsundere romance, guarded by pride | Rises as you pick her words and bake cupcakes; her home abuse is the real subject. |
| **Protagonist ↔ Yuri** | Shy romance → obsession | Rises as you pick her words; **forced** in Act 2, where Monika inflates it into fixation and self-harm. |
| **Monika ↔ the PLAYER** | The game's central, fourth-wall romance | Not an affinity counter at all: Monika loves **you**, the person at the keyboard, and rewrites the game to isolate you with her. |
| **Monika ↔ the other girls** | False friendship / manipulation | She edits their files, deletes them, and (in Act 3) admits she could not bring herself to delete them for real. |
| **Sayori ↔ Monika** | Succession and repetition | Whoever is **president** becomes self-aware and unstable; Sayori inherits the curse in Act 4. |
| **Natsuki ↔ Yuri** | Rivalry without real malice | The Day-2 argument; Natsuki's Act-2 note shows she actually **fears for Yuri**. |
| **Girls ↔ their families** | Off-screen trauma | Natsuki's abusive father; Yuri's parents; Sayori's depression — delivered through poems and subtext, not stats. |

**Important:** the affection system is **invisible and largely a lie**. The player's choices move hidden counters and unlock CGs, but they cannot change the tragedy — Sayori dies, Yuri dies, and Monika takes over no matter what. There are **no separate rivalry, fear or resentment meters**; those tones are conveyed by **writing and file corruption**. The one relationship that "wins" is the one that was never a route: **Monika's love for the player**.

---

## 6. Multiple endings

The game's endings fall into the requested types, but several are **forced story beats** rather than player-chosen branches.

| Ending | Type | Canon? | Summary |
|---|---|---|---|
| **Sayori's suicide** | Forced bad event (Act 1) | Yes | Unavoidable; the game returns to title and **wipes saves**. |
| **Natsuki's "ending"** | Optional bad event (Act 2) | No | Triggered by writing two poems for Natsuki; her neck snaps, an "END" card flashes, then the game resumes as if nothing happened. |
| **Yuri's suicide** | Forced bad event (Act 2) | Yes | She stabs herself regardless of your answer; the weekend-with-the-corpse sequence follows. |
| **Monika's "ending"** | Forced meta event (Act 3) | Yes | You must **delete `monika.chr`**; she is erased, apologizes, restores the game. |
| **Normal Ending** | **Normal / bad ending** | The default | Seen if you did **not** unlock all ten CGs: Monika **deletes the whole game** during the credits; unseen CGs render in grayscale; Monika leaves a bittersweet note. |
| **Good Ending** | **Good / true ending** | The "true" completion | Requires **all ten CGs** (i.e. save-scumming/replaying Act 1) **and** seeing Monika's Act-3 CG. Sayori, self-aware, **thanks the player**; the credits keep their images; you get a **letter from Dan Salvato**. |
| **Quick Ending** | **Bad / alternate ending** | No | Delete `monika.chr` **before a new game**: Sayori panics ("PLEASE MAKE IT STOP!"), the game force-quits, and reopening shows "END" then a grayscale Sayori hanging; after ten minutes: **"Now everyone can be happy."** |
| **Short Quick Ending** | Bad / alternate | No | Delete `sayori.chr` with Act-1 save data: jumps straight to the monochrome hanging image. |
| **"Cheating" scene** | Non-ending interruption | — | Copying a save across acts without the persistent file: Monika confronts you for cheating. |
| **Plus! `test.vm`** | Hidden completion epilogue | — | Full data collection unlocks an eighth side story ending in a failed server connection and one of hundreds of random VM2 log lines. |

**Failure states** map onto bad endings: **relationship breakdown** (Sayori's and Yuri's deaths), an **unresolved mystery** (the "Libitina"/`projectlibitina.com` ARG never resolves in-game), or an **alternate conclusion** (the Quick Ending's bleak "everyone can be happy"). The design thesis is inverted from a normal VN: **completionism (seeing every CG) is the only thing that saves the game**, and the reward for caring about everyone is that the game survives.

---

## 7. Save and load

DDLC ships the standard Ren'Py comfort toolkit — and then **takes it away**, which is the point.

- **Multiple save slots**, plus **quick save / quick load**.
- **Backlog** with replay, **auto-advance**, and **Skip** (including skip-read-text) — the affordance that makes replaying Act 1 for CGs bearable.
- **Settings** (text speed, volume, fullscreen) and a **content warning** gate on first launch.
- **Persistent file** storing act/seen state, and the **`firstrun`** flag for a hard reset.
- **No chapter/scene select** — you replay from the start of an act or from a save.
- **Act 3 revokes saving and loading entirely.** Prior saves are erased, the Save button triggers a pop-up ("There's no point in saving anymore, don't worry, I'm not going anywhere"), and **Skip is disabled**. The game's "save system" becomes Monika herself.
- **Cheating detection.** Copying saves between acts without the persistent file produces the black-screen "Unable to load the save file" then Monika's cheating confrontation.
- **The Good Ending depends on save-scumming.** Because Act 1 is the only place to earn the girls' CGs, the intended path is: save before the first poem → replay for each girl → reload → continue. The save system is thus not just QoL; it is **the mechanism the true ending is built on**.
- **`Plus!`** replaces manual file surgery with an in-game **virtual desktop** and a **`reset.sh`** in its built-in OS, and adds a **music player** and gallery.

**Important caveat:** the game deliberately **punishes** the instinct to reload (Monika deletes saves, disables saving, detects cheating). Its usability is *hostile by design* — but the ending that spares the game requires exactly the save-reload behaviour the game seems to forbid.

---

## 8. Inventory / items

There is **no player-managed inventory** — no bag, no item screen. The "inventory" is split between **in-story objects** (poems, gifts, a knife) and, far more importantly, **the game's own files**, which the player literally handles in Windows Explorer.

### 8.1 The character files — the real "inventory"

| File | Disguised as | What it hides / does |
|---|---|---|
| **`monika.chr`** | a `.png` image | A flaming ring with binary pixels → Base64 → a document. **Deleting it is the only way through Act 3**; deleting it early triggers the Quick Ending; restoring it in Act 4 is refused. |
| **`sayori.chr`** | a `.ogg` audio file | A **spectrogram that renders a QR code** to `projectlibitina.com` (the ARG site). Deleting it early triggers the Short Quick Ending. |
| **`natsuki.chr`** | a `.jfif` image | Colour-inverted and polar-mapped, reveals a white-haired, eyeless woman. |
| **`yuri.chr`** | a `.txt` text file | A long Base64 string decoding to a story Salvato wrote before DDLC. |

### 8.2 In-story objects (MacGuffins and flags)

| Item | Where it appears | Role |
|---|---|---|
| **Your poems** | Every day, all acts | The output of the word minigame; the visible face of the hidden affinity counters. |
| **The word pool / selected words** | Poem minigame | The actual input; each word a hidden affinity token. |
| **`Portrait of Markov`** | Yuri's route (Acts 1–2) | Yuri's disturbing novel; links to the "Libitina" experiment mythos. |
| **Natsuki's cupcakes** | Festival prep | The gift/bond object of Natsuki's route (CG). |
| **Yuri's banners & pocket knife** | Festival prep | The banner CG; the knife foreshadows her self-harm and suicide. |
| **Sayori's poem "get out of my head"** | End of Act 1 | The trigger for the discovery of her body. |
| **Natsuki's note** | Act 2, Day 4 | A cry for help about Yuri that Monika glitches out of existence. |
| **The 11 special poems** | Act 2 (3 per run) | Randomly seeded collectible poems; several are hidden confessions ("i love you", "Nothing is real?", Renier/Elyssa text). |
| **`CAN YOU HEAR ME` (.txt)** | Appears in the game folder in Act 2 | Monika's out-of-game plea for help. |
| **`hxppy thxughts.png`** | Appears during Act 1's final day | A corrupted child's drawing of Sayori's hanging — a special poem's source image. |
| **`have a nice weekend!`** | Appears before Yuri's confession | A Vigenère cipher (key "libitina") → Base64 → a short text. |
| **`iiiiiiiiiiiiiiiiiiii.txt`** | Act 2, after *Portrait of Markov* | An out-of-game document. |
| **`traceback`** | Shortly after Sayori's death | A fake crash log in the game folder. |
| **Monika's "Your Reality"** | Credits | Her self-written song; the only voice in the game. |
| **`test.vm`** (Plus!) | Full data collection | The hidden final side story and its random VM2 logs. |

**Design takeaway:** items exist to **make the meta-fiction legible** — a knife is a knife, but a `.chr` file is a character you can *kill*. The player never opens a bag; the "inventory" is the **`characters/` folder**, and the most powerful item in the game is the **Delete key**.

---

## Appendix A — Act/ending topology and the CG economy

```
Playthrough 1 (blind)         → Normal Ending  (Monika deletes the game)
        │
   save before first poem ▼
   replay Act 1 for Sayori    → CGs
   replay Act 1 for Natsuki   → CGs
   replay Act 1 for Yuri      → CGs
   view Monika's Act-3 CG     → CG
        │  all 10 CGs flagged
        ▼
   Good Ending (Sayori thanks you; Dan Salvato's letter)

Side exits (filesystem, from the title screen):
   delete monika.chr early    → Quick Ending ("Now everyone can be happy.")
   delete sayori.chr early    → Short Quick Ending
   cross-act save copy        → "Cheating" confrontation
```

- **CGs are global-ish (per save/profile)**, and the ending checks the **count**.
- **Act order is fixed**; there is no branching topology, only **soft tints** and **meta exits**.
- **The Good Ending is a completion reward** built on **replay and save-scumming**, thematically equating the player's care for all four girls with the game's survival.

---

## Appendix B — What a designer should steal from *DDLC*

1. **Make the medium the mechanic.** The game's best "puzzle" is opening a file explorer. The interface the player already owns (their OS) became the game's most memorable level.
2. **Let a hidden variable be the whole romance system.** A word-picker whose tags the player never sees is enough to *feel* like a dating sim — until the reveal that the tags were never theirs.
3. **Use absence of agency as escalation.** Act 1 offers choices; Act 2 hijacks the cursor; Act 3 deletes the Save button. Withdrawing control is more frightening than any monster.
4. **Gate the good ending on breadth of care, not skill.** Requiring all ten CGs forces the player to romance every girl — the exact behaviour Monika is punishing — which makes the ending *earned* and thematically loaded.
5. **Persist outside the save file.** Files in the game folder (`monika.chr`, `firstrun`, `CAN YOU HEAR ME`) turn the install directory into an ARG and make "deleting the game" a story action.
6. **Plant one asymmetry as a clue.** Monika has an English name and no poem words; she is visibly "outside" the fiction before she ever speaks. Fair-play foreshadowing in a meta-horror.
7. **Ration your horror.** The scares are sparse, mostly quiet, and often random — built on discomfort and corrupted routine, not gore, which is why the mundane dating-sim sections still read as sinister on replay.

---

## Sources

- English Wikipedia, *Doki Doki Literature Club!* — gameplay (choice-driven, low interactivity; poem minigame; Monika excluded; choices "ultimately have little effect"; three acts + epilogue; required file manipulation; *Plus!* virtual desktop and side stories), plot (Sayori's suicide, Act 2 glitches, Yuri's death, Monika's reveal and deletion, Normal/Good/Quick endings, Dan Salvato's letter), development (Ren'Py, Satchely, four "Okay, Everyone!" arrangements, Monika's English name as a hint), release and reception.
- DDLC Fandom Wiki (via MediaWiki API) — **Act 1** (word-affinity and Sayori over-representation, Day-2 argument +5 points, festival-helper and confession choices and CGs, beach poem), **Act 2** (Monika's script rewrites, Natsuki's note and neck-snap, Yuri's suicide and the corpse weekend, cursor hijack), **Act 3** (Monika's monologue, disabled save/skip, file deletion as the only exit), **Act 4** (Sayori's awareness, Normal vs Good ending conditions), **Possible Endings** (Sayori/Natsuki/Yuri/Monika events; Normal, Good, Quick, Short Quick; 10 CGs; Dan Salvato's letter), **Special Poems** (11 poems, 3 per run), **Easter Eggs** (character `.chr` file contents, `CAN YOU HEAR ME`, `hxppy thxughts.png`, `have a nice weekend!`, traceback, cheating detection, random-chance events with their probabilities, unused files), **Protagonist** (player-named, blank-slate design, Monika's tampering), **Files (DDLC Plus)** and **Test VM**.
- Team Salvato — official *About Censorship* post (PS4/PS5 blood-to-ink change for Yuri's death).

*Report compiled 2026-09-22.*
