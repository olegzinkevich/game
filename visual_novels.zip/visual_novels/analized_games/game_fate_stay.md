# Fate/stay night (2004) — Deep-Dive Mechanics Report

**Game:** Fate/stay night (フェイト／ステイナイト)
**Developer:** TYPE-MOON (first commercial work)
**Director / Writer:** Kinoko Nasu · **Character design:** Takashi Takeuchi · **Music:** KATE
**First release:** 30 January 2004, Microsoft Windows (18+ *eroge*)
**Re-releases:** *Fate/stay night [Réalta Nua]* PS2, 19 Apr 2007 (all-ages, full voice) → PS Vita 29 Nov 2012 → iOS 18 Apr 2015 → Android 29 May 2015 → **REMASTERED** Steam/Switch, 8 Aug 2024 (first official English & Simplified-Chinese release)
**Engine:** KiriKiri (original PC) · AGES mkII (Réalta Nua / Remastered)
**Genre:** Visual novel / sound novel (text + decision points)
**Structure:** one shared two-week trunk → **three sequential routes** → **5 main endings + 1 epilogue**, plus **40 bad endings** with the *Tiger Dojo* hint skits
**Playtime:** ~50 hours for all routes (VNDB)

> **Scope note.** Like *Tsukihime* before it, *Fate/stay night* is a near-kinetic sound novel. It has **no player-managed stat screen, no character customization, and no conventional inventory UI**. What it *does* have — and what this report focuses on — is one of the densest hidden **flag + affection** layers of its era, driving a strictly gated three-route structure and a large bad-end / hint ecosystem. Where a requested category simply does not exist, this report says so explicitly.

---

## 0. Executive summary (the design in one paragraph)

The player is **Shirou Emiya**, a novice magus dragged into the Fifth Holy Grail War, in which seven Masters each command a summoned Heroic Spirit ("Servant") for a wish-granting artifact. The game reads as a straightforward fantasy-romance adventure — until the player realizes the story is **three different genres stacked on the same two weeks**. Completing the introductory **Fate** route (romance) unlocks **Unlimited Blade Works** (a war epic about ideals), which unlocks **Heaven's Feel** (a horror about the price of saving one person). The player's only inputs are **2–3-way dialogue/action choices** at decision points. Most are cosmetic; a minority set **hidden flags and affection counters** that determine (a) which route you are on and (b) which of that route's endings you reach. The game is generous with failure — 40 scripted bad ends, each rewarded with a comedic **Tiger Dojo** hint — and rewards completionism with the true finale, **Last Episode**. The "puzzle" is not in the UI; it is the causal graph of the story, and the game gives you almost no visibility into it.

---

## 1. Characters

### 1.1 Core character portraits

The cast is organized as **Master ↔ Servant** pairs (seven classes). Shirou is the fixed protagonist; the "core portraits" are the four Masters/Servants whose relationships drive the routes.

| Master | Servant (class) | Heroic Spirit | Role / defining trait | Route weight |
|---|---|---|---|---|
| **Shirou Emiya** | **Saber** | Artoria Pendragon (King Arthur) | Protagonist. Amateur magus; survivor of the Fuyuki fire; obsessed with becoming a "Hero of Justice." Projection / Reinforcement / Tracing; later Reality Marble *Unlimited Blade Works*. | All three |
| **Rin Tohsaka** | **Archer** | EMIYA (future Shirou) | Model student & idol; heir of the Tohsaka line. Jewel magecraft; rival-turned-ally. | UBW heroine; key in all |
| **Illyasviel von Einzbern** | **Berserker** | Heracles | Childlike German aristocrat; enormous mana; Shirou's adoptive sister. | Key in all; HF central |
| **Shinji Matou → Zouken Matou** | **Rider** | Medusa | Shinji: arrogant vice-captain, abusive brother. Zouken: centuries-old Makiri patriarch, insect familiars. | Rider central in HF |
| **Kirei Kotomine** | **Lancer** | Cú Chulainn | Overseer priest of the Church; secretly Lancer's Master; the war's antagonist. | Key in all |
| **Souichirou Kuzuki** | **Caster** | Medea | Former assassin turned teacher; Caster's devoted Master. | Fate / UBW / HF |
| **Zouken Matou** | **True Assassin** | Hassan of the Cursed Arm | Only in Heaven's Feel; summoned from the false Assassin's corpse. | HF only |
| — (survivor of the 4th War) | **Gilgamesh** (Archer-class, 8th Servant) | Gilgamesh | Secret independent Servant; the true final boss of two routes. | Fate / UBW |
| Caster (proxy) | **Assassin (false)** | Sasaki Kojirou | Temple gatekeeper; not a true Heroic Spirit. | Fate / UBW / HF |

**Supporting cast with mechanical/narrative weight:** **Taiga Fujimura** (Shirou's guardian; co-host of Tiger Dojo), **Sakura Matou** (Shirou's underclassman and HF heroine), **Kiritsugu Emiya** (deceased adoptive father; the origin of Shirou's ideal), **Issei Ryuudou** (student council president), **Ayako Mitsuzuri** (archery captain), **Sella & Leysritt** (Illya's maids), **Zouken Matou** (HF antagonist).

### 1.2 Character abilities / player-managed stats

There is **no player-managed stat system**. No HP bar, no skill tree, no point allocation, and no visible numbers. What functions as "stats" is entirely diegetic:

- **Servant parameters** — every Servant has letter-rank parameters (Strength, Endurance, Agility, Mana, Luck, Noble Phantasm) that the story *narrates* but the player never allocates. They change only through scripted events (e.g. Saber's weakened state because Shirou cannot supply mana).
- **Command Spells** — the closest thing to a **consumable resource**: three crystallized absolute orders on the Master's hand. The counter decrements on use and is checked repeatedly by the flag layer (§4). This is the single most "gamey" variable in the title.
- **Shirou's magecraft** — **Reinforcement** (basic), **Projection / Tracing** (manifesting copies of weapons), **Avalon** (regeneration; §8), and eventually the **Reality Marble "Unlimited Blade Works."** These are unlocked by *story progress*, not by player choice.
- **Hidden affection counters** — the true "stats" of the game, tracked invisibly for Saber, Rin, Sakura and Illya (§5).

### 1.3 Character customization

**None.** Shirou is a fully authored character: fixed name, appearance, backstory, and voice (in Réalta Nua onward). There is no avatar, no name entry, no personality/behavior build, and no equipment. The player's only authorship is the choice menu (§2). The three routes are effectively three *authored* Shirous — the same boy pushed into romance, war, and horror — not three player builds.

---

## 2. Dialogue and action choices

The interaction model is the classic sound-novel one:

- The game spends most of its runtime printing text — either spoken **dialogue** or Shirou's **inner monologue** — over a static background and character sprite.
- At irregular intervals the flow pauses at a **decision point**, presenting typically **two to three options** on screen. The player picks what Shirou says or does; the chosen option advances the plot in a specific direction.
- **No timers, no QTEs, no mini-games.** Choice is the entire interaction vocabulary.

Choices fall into three behavioral classes:

| Class | Effect | Example |
|---|---|---|
| **Cosmetic** | Flavor line / minor scene variation; no lasting state | "Compliment her cooking" vs "Stay quiet" — different text, same outcome |
| **Affection / flag-setting** | Increments or decrements a hidden counter; may set a boolean | Choosing to reassure Saber, trust Rin, or protect Sakura |
| **Structural (route / ending)** | Changes which route or ending is reachable; can be an instant bad end | Day 3 Command Spell decision (Fate↔UBW); walking Sakura home (HF) |

The crucial design point: **the player cannot see which class a choice belongs to.** A throwaway line can set a flag checked ten in-game days later, and an obviously "important" scene may have only cosmetic variants. This opacity is deliberate and is mirrored by the game's *replay* framing (see Appendix B).

---

## 3. Branching narrative and key scene description

### 3.1 How the story splits into routes

*Fate/stay night* has **three routes**, each reframing the same two-week Holy Grail War around a different heroine and genre:

- **Fate** — Saber route. **Romance / heroic tragedy.** Shirou refuses to compromise his ideal; the story is about the beauty and cost of an impossible wish.
- **Unlimited Blade Works** — Rin (and Archer) route. **War epic.** Shirou confronts the future his ideal produces; the story is an argument about what an ideal is *for*.
- **Heaven's Feel** — Sakura route. **Horror / psychological drama.** Shirou must choose between his ideal and the person he loves; the story exposes the war's true, rotten machinery.

### 3.2 Route gating (strictly sequential)

Route access is **not** a free menu. It is gated by *completion*:

```
Fate  ──(clear Fate)──►  Unlimited Blade Works  ──(clear UBW)──►  Heaven's Feel  ──► (terminal)
```

- **Fate** is available from the start.
- **UBW** unlocks only after Fate is cleared.
- **HF** unlocks only after UBW is cleared.
- In the original 2004 PC release this is pure progression gating. Réalta Nua and the 2024 Remastered keep the same order; there is **no route-select menu** — the branching choices for a locked route simply do not appear until its prerequisite is done.

### 3.3 The pivotal branch points

| Branch | When | The choice that decides it |
|---|---|---|
| **Fate ↔ UBW** | ~Day 3 | After Saber turns on Archer/Rin, Shirou's handling of the confrontation. If he **uses a Command Spell to stop Saber before she gravely wounds Archer**, Rin is grateful and the **UBW** path opens; in the **Fate** path Saber has already wounded Archer and Shirou stops her without spending a Command Spell. ⚠ *The behavioral difference is documented; the exact option wording is not.* |
| **UBW ↔ HF** | Day 1 | The **HF** branch diverges at the very outset: Shirou insists on **walking Sakura home**. This option only becomes selectable once Fate *and* UBW are cleared; HF then re-plays the Day 3 events in the *Fate* configuration. |
| **Off-ramp (dead end)** | Day 4 | Declining Rin's offer of cooperation does **not** grant early UBW content — it funnels to the bad end **"Texture,"** in which Rin erases Shirou's memory. |

### 3.4 Route-by-route weight: cosmetic or key?

The user's "cosmetic vs key" distinction is best applied at two levels:

**Route level — all three main routes are KEY.** Each has permanent, long-term consequences: it reveals a different truth about the Grail, permanently changes what the player knows, and unlocks the next route. None is a cosmetic variant.

| Route | Weight | Leads to | Ends in |
|---|---|---|---|
| **Fate** | **KEY** (mandatory entry point) | Unlocks UBW | 1 true end + 14 bad ends |
| **Unlimited Blade Works** | **KEY** | Unlocks HF | 1 true end + 1 good end + 10 bad ends |
| **Heaven's Feel** | **KEY** (terminal; the "black side" / lore payoff) | Nothing further (except Last Episode) | 1 true end + 1 normal end + 16 bad ends |

**Choice level — most choices are cosmetic; a minority are key.** The bad-end lists (Appendix A) function as the game's map of "key choices": every choice that *can* produce a bad end is a key structural choice, while the remainder only change flavor text.

### 3.5 Key scenes

**Shared trunk / prologue**
- **The summoning.** Lancer spears Shirou through the heart at school; Rin revives him with her heirloom pendant; Lancer attacks again at home; a girl in armor blocks the spear — *"I ask of you, are you my Master?"* This is the game's single most iconic image and the point at which the Grail War begins.
- **Kotomine Church briefing.** Shirou learns the rules and formally enters the war.
- **Berserker at the Emiya house.** Saber is outmatched; Shirou throws himself in front of a lethal blow to shield her. Illya leaves, confused — establishing both Shirou's suicidal altruism and his bond with Illya.

**Fate route**
- **Saber's identity.** The reveal of Artoria Pendragon and the weight of her kingship.
- **The date / the question of the wish.** Shirou forces Saber to confront whether the Grail is worth her self-erasure.
- **Final battle.** Shirou vs Kirei and Gilgamesh; Saber destroys the Grail with Excalibur and returns to Camlann, accepting her death. Bittersweet "Fate" ending.

**Unlimited Blade Works**
- **Archer's identity.** The reveal that Archer is a future Shirou who took the same ideal to its logical end.
- **Shirou vs Archer.** A literal argument between the ideal and the idealist, resolved by a Reality Marble clash.
- **Shirou vs Gilgamesh.** The underdog's victory of "infinite copies" over "the original," followed by the True/Good ending split (§6).

**Heaven's Feel**
- **The Shadow.** An indiscriminate, civilian-draining darkness; the horror engine of the route.
- **Sakura's truth and Zouken's basement.** The revelation of Sakura's abuse and the Makiri worm magecraft.
- **Saber Alter.** Saber, consumed by the Shadow, returns as a black knight — the emotional nadir of the game.
- **Nine Lives Blade Works / Kanshou & Bakuya.** Shirou's desperate projections against Berserker and Saber Alter.
- **Illya's sacrifice.** The true ending hinges on Illya's affection and her choice to close the Grail; the normal ending withholds it.

**Réalta Nua epilogue**
- **Last Episode.** After all five endings, the title screen changes and Shirou and Saber reunite in Avalon.

---

## 4. Story flags and variables

The game **secretly tracks** the player's decisions as boolean flags and counters, then checks them later to open or close events. The wiki's own citations expose per-scene state identifiers (e.g. `FateDay3 Scene0`, `HFDay9 Scene19`, `HFDay14 Scene11`), confirming that the engine stores state at scene granularity. ⚠ *The literal internal variable names in the KiriKiri/AGES scripts are not published; what follows are the documented behavioral checks.*

**Counter variables**

| Variable | Init | Behavior |
|---|---|---|
| **Command Spell count** | 3 | Decrements on each use; checked at multiple later decision points (using/not using a Spell is frequently the trigger for a bad end). |
| **Saber affection** | hidden | Threshold-checked in the Fate route and for the UBW good end. |
| **Rin affection** | hidden | Threshold-checked for the UBW true vs good end. |
| **Sakura affection** | hidden | Checked in HF (e.g. avoiding "Ocean Depths," Day 7). |
| **Illya affection** | hidden | Checked for the HF true end (≥4) and several HF bad ends. |

**Boolean / decision flags (documented examples)**

| Day | Flag / decision | Consequence if wrong |
|---|---|---|
| D3 | Agreed to enter the Grail War? | Bad end **"Forest of no return"** |
| D3 | Used a Command Spell to stop Saber? | **Sets Fate vs UBW** |
| D4 | Accepted Rin's alliance? | Bad end **"Texture"** |
| D10 | Followed Saber? | Bad end **"Nutcracker doll"** |
| D11 | Agreed to be Illya's servant? | Bad end **"Dress of heaven"** |
| D13 | Told Saber not to attack Caster? / let her fight alone? | **"Witch's mark"** / **"Walpurgis night"** |
| D15 | Returned **Avalon** to Saber? | Bad end **"Holy Grail completed"** |
| D15 | Saber affection above threshold? | Bad end **"That which cannot be changed"** |
| HF D9 | Kept the "Hero of Justice" ideal and resolved to kill Sakura? | Bad end **"Mind of Steel"** (a.k.a. **"Superhero"**) |
| HF D9 | Asked Tohsaka for help? | Bad end **"Miserable Lone Force"** |
| HF D9 | Accepted Rin's geas? | Bad end **"Geas"** |
| HF D12 | Used Archer's left arm? | Without it, the bad end **"Happy End"** becomes unavoidable |
| HF D13 | Chose to kill Sakura? | Bad end **"Happy End"** (ironic title) |

**Design takeaway:** the flags are mostly *single-bit* gates layered onto a linear trunk, plus a few hidden numeric meters. The game never surfaces them; the **Tiger Dojo** is the only feedback channel, and it deliberately gives only vague hints.

---

## 5. Relationship and affection systems

Relationships are the load-bearing system of the game. Two layers coexist:

**(a) Authored relationship arcs** (fixed by the route):

| Relationship | Dynamic | Route |
|---|---|---|
| **Shirou ↔ Saber** | Knight-and-Master → mutual respect → romance; Shirou's protective instinct vs Saber's pride | Fate |
| **Shirou ↔ Rin** | Rival magi → grudging alliance → partnership/romance | UBW |
| **Shirou ↔ Sakura** | Quiet domestic closeness → protective love → impossible choice | HF |
| **Shirou ↔ Illya** | Enemy Master → sibling bond (she is Kiritsugu's true daughter) | All; payoff in HF |
| **Shirou ↔ Archer** | Ideological conflict: the ideal vs the man it made | UBW |
| **Shirou ↔ Kirei** | Antagonism; mirror-image nihilism vs idealism | All |
| **Shirou ↔ Shinji** | Old friendship corroded into rivalry and contempt | All |
| **Rin ↔ Sakura** | Estranged sisters; the Tohsaka/Matou split | HF |

**(b) Hidden affection counters** — the mechanical layer. The game raises or lowers numeric affection for the heroines based on whether Shirou gives the answer they want. Confirmed thresholds:

| Ending / gate | Required affection |
|---|---|
| **Fate true end** | Saber affection at/above threshold (else "That which cannot be changed") |
| **UBW true end** | **Rin affection > 8** |
| **UBW good end "Sunny Day"** | **Saber affection > 4 AND Rin affection < 8** |
| **HF true end** | **≥ 4 Illya affection points**, plus correct final choices |
| **HF normal end** | **< 4 Illya affection points** (or extra projection / Excalibur choice) |
| **HF bad ends** | Sakura affection gates "Ocean Depths"; Illya affection gates "Battle of the Holy Grail" |

Key structural fact: **affection does not select the route** (gating does) — it selects the *ending within* a route. UBW's True-vs-Good and HF's True-vs-Normal splits are explicit threshold checks. ⚠ *Per-choice point values and mappings are not published; treat any table claiming exact numbers as fan-derived.*

---

## 6. Multiple endings

The game has **5 main endings + 1 epilogue + 40 bad endings**.

| # | Route | Type | Name | Trigger |
|---|---|---|---|---|
| 1 | Fate | **True** | Fate True End ("Saber Ending") | Only ending of the route; avoid Day 15 bad end — requires sufficient Saber affection |
| 2 | UBW | **True** | UBW True End ("Rin True Ending") | **Rin affection > 8**; Saber vanishes; Shirou goes to the Clock Tower with Rin |
| 3 | UBW | **Good** | **"Sunny Day"** | **Saber affection > 4 AND Rin affection < 8**; Saber survives and contracts with Rin |
| 4 | HF | **True** | HF True End ("Sakura True Ending") | **≥4 Illya affection**, no extra projection vs Saber Alter, choose to find another way to stop Avenger; Illya sacrifices herself; Shirou's soul placed in a puppet body |
| 5 | HF | **Normal** | **"Cherry Blossom's Dream"** (桜の夢) ⚠ | Any of: extra projection to aid Rider, **<4 Illya affection**, or projecting Excalibur after Kirei; Sakura waits her whole life and dies on a cherry-blossom road |
| 6 | Fate (Réalta Nua) | **Epilogue** | **"Last Episode"** | Unlocked **after all five endings**; selectable from the title screen; Shirou and Saber reunite in Avalon |

**Ending types present:** true endings (Fate, UBW, HF), good ending ("Sunny Day"), normal ending (HF), and a hidden final/epilogue ending (Last Episode). There are **no per-character "friend" endings**; the romance is always the heroine of the route.

**Failure states** are the 40 bad ends. They include relationship breakdown, being killed by the heroine, mind-wipe, absorption by the Shadow, and body/soul destruction. Each is immediately followed by a **Tiger Dojo** comedic skit hosted by **Taiga Fujimura** (judo gi) and **Illya** (gym uniform, "disciple #1"), plus deformed cameos. The Dojo explains how to avoid the ending, is recorded as a **Tiger Stamp**, and every **10 stamps unlocks a Mini Theater**; collecting **all 40 stamps + all endings** unlocks a bonus "Tiger Dojo Special." Distribution: **Fate 14, UBW 10, HF 16** bad ends.

---

## 7. Save and load

*Fate/stay night* ships the standard high-comfort VN toolkit (engine: KiriKiri on the original PC; AGES mkII on Réalta Nua/Remastered):

- **Multiple save slots** (the genre standard across pages of slots).
- **Quick save / quick load** for instant re-entry.
- **Backlog / scrollback** — review and replay recent text, including voice.
- **Auto-advance** (hands-free) and **Skip** (fast-forward, typically "skip read text only").
- **Text speed, volume, and display settings.**
- **Ending List** — tracks which of the five endings are cleared.
- **Tiger Dojo / Tiger Stamp collection** — 40 stamps; one Mini Theater per 10; Special at full completion.
- **Changing title screen** — the title art changes as content is cleared (from the "dawn landscape" to a "horizon pierced by swords" after all routes, and again after Last Episode).
- **CG gallery / music gallery** — standard for the engine and genre and strongly implied by the game's structure. ⚠ *Not confirmed from the sources used.*
- **In-game glossary / encyclopedia** — the title is famous for its terminology database, and the 2024 Remastered adds achievements named **"Weapon Menu," "Status Menu,"** and **"Acquire All Weapon Data,"** implying in-game weapon/status databases. ⚠ *The exact unlock behavior of the in-game glossary is unconfirmed; the wiki's `Encyclopedia/*` pages are transcriptions of the printed *Fate/side material* books, not necessarily the in-game menu.*

**Important caveat:** because branching is invisible and route access is gated by completion, **there is no free chapter-select or branch flowchart**. To see another branch the player reloads an earlier save or replays, and is expected to remember the flags themselves. The **Tiger Dojo** is the only built-in "you missed a flag here" tool — and it is intentionally vague.

---

## 8. Inventory / items

There is **no player-managed inventory**. Items are story-tracked MacGuffins; several double as **state flags** (possessing/returning an item gates a branch). The item layer exists to make the war's logic legible.

| Item | What it is | Mechanical role |
|---|---|---|
| **Command Spells** | Three crystallized absolute orders on the Master's left hand | The closest thing to a resource counter; decrements on use and is checked repeatedly (§4) |
| **Rin's jewel pendant** | Tohsaka heirloom charged with mana | Revives Shirou at the start; the two identical pendants later reveal Rin saved him (key UBW beat) |
| **Avalon** | Saber's scabbard, implanted in Shirou by Kiritsugu | Grants regeneration; blocks Merodach; **must be returned to Saber in the Fate route** (else "Holy Grail completed"); altered Shirou's Origin/Element to "Sword" |
| **Azoth Sword** | Tohsaka Mystic Code (a jeweled dagger) | Shirou stabs Kirei with it (Fate) and finishes Saber Alter with it (HF) |
| **Book of the False Attendant** | Shinji's substitute Command Spell | Makes Shinji a Master; burns away when Rider dies |
| **Rule Breaker** | Caster's Noble Phantasm | Severs Servant contracts; used on Saber and Archer |
| **Kanshou and Bakuya** | Archer's projected twin swords | Shirou projects them; key to HF's "Nine Lives Blade Works" |
| **Archer's left arm** | Transplanted to Shirou in HF | Enables Shirou's projection/UBW in that route; using it (D12) gates the "Happy End" |
| **Jeweled Sword of Zelretch** | Rin's projected Mystic Code | Used in HF's finale |
| **Dress of Heaven** | Illya's Mystic Code | HF; tied to Illya's role in the Grail |
| **Excalibur / Caliburn / Merodach** | Saber's and Gilgamesh's Noble Phantasms | Decisive weapons in the finale; Excalibur projection is an HF normal-end trigger |
| **The Holy Grail** | The wish-granting prize (actually corrupted) | The object all routes converge on; its true nature is the series' core reveal |

**Gifts / domestic items** also carry emotional flags: the **key** Shirou gives Sakura (HF), and shared meals/cooking scenes that raise affection. In Remastered, the **Weapon Data** achievement implies a collectible weapon database rather than a usable inventory.

---

## Appendix A — Route, ending, and bad-end map

```
                          ┌───────────────────────────┐
                          │  Shared two-week trunk     │
                          │  (prologue → Day 3 branch) │
                          └─────────────┬─────────────┘
                                        │
        Day 3: use Command Spell to stop Saber?      Day 1: walk Sakura home?
                    │                    │                     │
              (no / Fate)          (yes / UBW)         (after Fate+UBW cleared)
                    ▼                    ▼                     ▼
             ┌──────────┐        ┌───────────────┐     ┌───────────────┐
             │  FATE    │───────►│     UBW       │────►│  HEAVEN'S FEEL│
             │ (Saber)  │ clear  │ (Rin/Archer)  │clear│   (Sakura)    │
             └────┬─────┘        └──────┬────────┘     └──────┬────────┘
                  │                     │                     │
         True End (Saber)      True End (Rin > 8)      True End (Illya ≥ 4)
         14 bad ends            Good "Sunny Day"        Normal "Cherry Blossom's Dream"
                                (Saber > 4, Rin < 8)    16 bad ends
                                10 bad ends
                                        │
                                        ▼  (all five endings)
                                  "Last Episode" (Réalta Nua)
```

**Bad-end titles (partial, documented):** Forest of no return · Texture · Nutcracker doll · Dress of heaven · Witch's mark · Walpurgis night · Holy Grail completed · That which cannot be changed · Mind of Steel / Superhero · Miserable Lone Force · Geas · Ocean Depths · Battle of the Holy Grail · Happy End · Sparks Liner High · Third Death · Spider's Captive · Hypnos · Killer · Hazy · Artificial Noble Phantasm · Sword and magic · One Conclusion · Heavens Fall.

---

## Appendix B — What a designer should steal from *Fate/stay night*

1. **Make the route the reward, not the menu.** Locking UBW behind Fate and HF behind UBW forces the player to live the "wrong" genre first, so the later reframes land as revelations rather than options.
2. **Reframe, don't repeat.** Three routes reuse the same two weeks but change the genre (romance → war epic → horror). The replay is diegetic: knowledge, not new content, is the unlock.
3. **Hide the machinery, surface the consequence.** Affection counters and flags are never shown; the only feedback is the Tiger Dojo — and it withholds the answer. Opacity is the tension.
4. **Weaponize failure.** 40 bad ends turn failure into content, a hint system, and a collectible (Tiger Stamps → Mini Theaters). Dying becomes rewarding.
5. **Use items as flags, not loot.** Avalon, the Command Spells, and Archer's arm are not gear — they are branch conditions. One object, one irreversible decision.
6. **Let the ending answer the theme.** The same protagonist reaches "ideal upheld" (Fate), "ideal interrogated" (UBW), and "ideal abandoned for a person" (HF). The affection thresholds encode the philosophical choice.

---

## Sources

- TYPE-MOON Wiki (Fandom): *Fate/stay night*, *Fate (route)*, *Unlimited Blade Works (route)*, *Heaven's Feel (route)*, *Command Spell*, *Avalon*, *Azoth Sword*, *Derisive Heart of Steel*, *Fate/stay night: sunny day*.
- English Wikipedia: *Fate/stay night* (gameplay, characters, plot, endings, development).
- Japanese Wikipedia: *Fate/stay night* (game system, route order, endings count, Tiger Dojo, affection thresholds).
- VNDB entry v11 (release history, playtime).
- Steam store app 2396980 and Steam achievements, *Fate/stay night REMASTERED* (2024 release, official EN/CN, achievements).

### Uncertainty flags
1. Exact in-game wording of the Day 3 Fate/UBW choice and the Day 1 HF choice — behavior is sourced, verbatim text is not.
2. "Cherry Blossom's Dream" as the official HF Normal End title — common fan/JP name; sources label it "Sakura Normal Ending."
3. Per-choice affection point values and mappings — not published; treat as fan-derived.
4. Internal flag/variable names — not published; only behavioral checks are documented.
5. Save-slot count, quick-save/load specifics, CG/music galleries, and the in-game encyclopedia's unlock mechanics — partially unverified.

*Report compiled 2026-09-22.*
