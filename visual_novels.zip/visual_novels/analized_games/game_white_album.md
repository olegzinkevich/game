# White Album 2 (2010) — Core Mechanics Analysis

**Developer:** Leaf (Aquaplus) · **Scenario:** Fumiaki Maruto (丸戸史明) with Kikakuya
**Genre:** Adult romance visual novel / love-triangle drama
**PC release:** *Introductory Chapter* (Mar 26, 2010), *Closing Chapter* (Dec 22, 2011), *Coda* (hidden route in CC)
**Ports / re-releases:** PS3 *Shiawase no Mukōgawa* (2012), PS Vita (2013), *Mini-After Story* (2014), *Extended Edition* (2018)

> **One-line thesis:** *White Album 2* is not a "choices everywhere" VN. Its opening act is a **kinetic novel** (no choices, one ending). All real branching, flag-tracking and gating live in the **Closing Chapter**, and the true finale (**Coda**) is a **hidden route** deliberately locked behind the rest of the game.

---

## 0. Structural Overview (read this first)

The game is a **three-act structure**, not a flat route list:

| Act | Time frame | Player agency | Endings |
|---|---|---|---|
| **Introductory Chapter (IC)** | Oct–Dec, high school (2007) | **None** — read-only | 1 (fixed) |
| **Closing Chapter (CC)** | 3 years later, university (2010) | Heavy — route selection | Many (per-heroine good/bad) |
| **Coda** | 2 years after CC, adulthood (2012) | Heavy — final choices | 4 (true / normal / bad) |
| **Mini-After Story** | Epilogue | None | 2 epilogues (one per main heroine) |

The critical design decision: **IC is linear on purpose.** It builds the love triangle as a fixed, inescapable tragedy, so that CC's choices feel like the player is trying to *repair* something already broken. This is the source of the game's reputation.

---

## 1. Characters

### Protagonist (fixed — no customization)

- **Haruki Kitahara (北原 春希)** — The player avatar, but a fully authored character: earnest, meddlesome, preachy, top-of-class, class-committee president type. Amateur second guitarist who started playing "to look cool for a girl he liked." In CC he is a burnt-out university student juggling jobs to avoid facing his past; in Coda he is a new employee at a publisher, engaged to Setsuna. He is **not** a blank self-insert — he has opinions, a family backstory (divorced parents, cold relationship with his mother), and makes catastrophic decisions the player often cannot prevent.

### Main heroines

- **Setsuna Ogiso (小木曽 雪菜)** — School idol, two-time "Miss Hōjō," brilliant amateur singer. Outwardly warm; inwardly guarded, a people-pleaser terrified of being excluded (trauma from losing friends in middle school). Obsessed with keeping "the three of us" together. Described by the writer as having the charm of "a losing habit." The **only character central to every route**, including Coda.
- **Kazusa Touma (冬馬 かずさ)** — Piano prodigy, blunt, hostile, chronically late/truant, sweet-toothed. Daughter of world-famous pianist **Yōko Touma**; an illegitimate only-child who doesn't know her father. A "stray dog" figure — all bark, deeply dependent. Transfers from the music division to the general course and ends up beside Haruki.

### Supporting / CC sub-heroines

- **Takeya Iizuka (飯塚 武也)** — Haruki's best friend, light-music-club president, womanizer, comic relief; secretly devoted to Io.
- **Io Mizusawa (水沢 依緒)** — Setsuna's tomboy classmate, ex-basketball captain, Haruki's old friend.
- **Koharu Sugiura (杉浦 小春)** — CC sub-heroine. A third-year at Hōjō who is essentially a "female Haruki" (nicknamed *Koharuki*); a principled, meddling junior who confronts Haruki on behalf of a friend.
- **Chiaki Izumi (和泉 千晶)** — CC sub-heroine. Haruki's easygoing seminar classmate; secretly a brilliant stage actress/playwright who has been researching Haruki and Setsuna's past under a false identity.
- **Mari Kazaoka (風岡 麻理)** — CC sub-heroine. Haruki's workaholic editor boss, 5 years older; he sees traces of Kazusa in her.
- **Yōko Touma (冬馬 曜子)** — Kazusa's mother; a manipulative, dying (leukemia in Coda) pianist who engineers the final arc.

### Abilities / stats / customization — **absent**

There is **no player-managed stat system, no skill tree, no character customization, no equipment.** "Abilities" exist only as narrative facts (Haruki's guitar improves across IC; Kazusa's piano is world-class). Nothing the player allocates or levels. This is a pure dialogue-choice VN.

---

## 2. Dialogue and Action Choices

### IC — no choices at all
Confirmed by the game's own documentation and Wikipedia: in *Introductory Chapter* the **only interaction is clicking to advance text.** There is a single ending and no branching. It functions as a kinetic novel / prologue.

### CC and Coda — choice-driven
Wikipedia: *"both 'closing chapter' and 'coda' require comprehensive multiple choice questions to handle the trend of the plot development."*

Choice types:
- **Spoken response** — what Haruki says to a character (deflect, confess, lie, stay silent).
- **Action / destination choice** — who to visit, whether to answer a call/message, whether to take on a work assignment, whether to go to an event.
- **Commitment choices** — in Coda, whether Haruki is honest with Setsuna, whether he crosses the line with Kazusa, whether he fully commits to one woman.

Design notes:
- Choices are **weighted and cumulative**, not "one choice = one route." Early innocuous answers feed hidden values that only pay off much later.
- The game frequently offers **tempting "trap" choices** — the emotionally comfortable option often leads to a bad/normal ending, while the honest, painful option is required for a true ending.
- Some pivotal moments give the player a choice that **Haruki's characterization resists** — the game uses this dissonance deliberately (you may be forced to steer him toward or away from infidelity).

---

## 3. Branching Narrative, Routes and Key Scenes

### How the story splits

```
IC (linear, 1 ending: Kazusa leaves for Vienna, Haruki breaks up with Setsuna)
        │
        ▼
CC common prologue (Haruki & Setsuna estranged, 3 years later)
        │  choices determine route
        ├── Setsuna route  ── good end / bad end
        ├── Koharu route   ── good end / bad end
        ├── Chiaki route   ── good end / bad end
        └── Mari route     ── good end / bad end
                    │
                    │  clear Setsuna GOOD end → unlocks ▼
                    ▼
CODA (hidden route — continues the Setsuna ending)
        ├── Setsuna True End
        ├── Kazusa True End
        ├── Kazusa Normal End (bad)
        └── Coda Normal End
```

### Route table

| Route | Act | Leads to | Cosmetic or Key? | Notes |
|---|---|---|---|---|
| IC (single path) | IC | CC | **Key** (sets all backstory flags) | No choices; one fixed ending |
| Setsuna (CC) | CC | Coda (if good end) | **Key** | The spine route; Coda continues from its good end |
| Koharu (CC) | CC | Self-contained ending | **Key** (own long-term ending) | "Female Haruki" mirror route |
| Chiaki (CC) | CC | Self-contained ending | **Key** | Meta/theatrical route; actress researching the trio |
| Mari (CC) | CC | Self-contained ending | **Key** | Adult-workplace route; echoes Kazusa |
| Bad/Normal ends (any CC route) | CC | Dead end / unresolved | **Key** (lock you out of Coda) | Failure states |
| Coda | Coda | 4 final endings | **Key** | Hidden; gated behind CC |
| Extra episode *Fugutaiten no Kimi e* (PS3) | Side story | Standalone | **Cosmetic** | Added in console port; not part of main spine |

**Gating (the notorious part):**
- **Coda is a hidden route.** It was not advertised — the game was publicly billed as a two-part work. It only becomes available after clearing Closing Chapter (community-documented condition: clearing the **Setsuna good ending**, the ending Coda narratively follows).
- This means the **true, emotionally heaviest content is locked behind finishing the "lesser" routes first.** Players who stop after one CC ending never see the finale the game is famous for — the core complaint about the "closing chapter gate."
- Within CC, route entry is governed by hidden accumulated values, so the Setsuna route (and therefore Coda) is not trivially reachable on a first blind playthrough.

### Key scenes

**Introductory Chapter**
1. **Rooftop** — Haruki overhears Setsuna singing "White Album" and recruits her.
2. **Music-room sessions** — Kazusa silently accompanies Haruki's guitar practice from the next room; the piano/guitar motif is born.
3. **The school festival performance** — the trio plays "White Album," "Sound of Destiny," and the original **"Todokanai Koi" (届かない恋 / "A Love That Cannot Reach")**. The emotional peak of the act.
4. **Setsuna's confession** — she confesses first, knowing Kazusa loved Haruki too, out of fear of being left alone.
5. **The missed birthday** — Haruki stands up Setsuna to go to Kazusa; the betrayal point.
6. **The night with Kazusa**, then **the airport farewell** — the trio's relationship collapses. Setsuna watches and understands it is over.

**Closing Chapter**
7. Haruki is assigned a **feature article on Kazusa** by editor Mari — reopening the wound.
8. **The family-restaurant arc** with Koharu, who forces Haruki to face what he did.
9. **The reconciliation attempt with Setsuna** — they nearly reunite, but Haruki's unresolved feelings for Kazusa make Setsuna recoil. The act's emotional pivot.
10. **Chiaki's reveal** — the easygoing classmate is exposed as an actress who has been studying the trio's tragedy, mirroring the player's own voyeurism.

**Coda**
11. **Strasbourg, Christmas Eve** — Haruki, engaged to Setsuna, runs into Kazusa by fate.
12. **Kazusa moves into the next apartment** — engineered by her mother; a half-cohabitation begins.
13. **The affair and its consequences** — leading to the four divergent endings below.

---

## 4. Story Flags and Variables

*White Album 2* hides its machinery completely — there is **no visible meter or stat screen.** Internally it uses a classic flag/counter model, and the later acts read those values to decide what is available.

Representative variable categories (the game does not expose exact names):

- **Affection / attachment counters** — separate hidden values for Setsuna, Kazusa, and the CC sub-heroines. These accumulate from dialogue and action choices and decide which route opens.
- **Trust / honesty flags** — whether Haruki has told Setsuna the truth about Kazusa; whether he lied; whether he kept a promise. In Coda these largely decide Setsuna True vs. a failure ending.
- **Event-visit flags (Booleans)** — did Haruki go to the birthday; did he read/respond to the letter; did he answer a call; did he accept the magazine assignment; did he visit a given location. Later scenes are simply *unavailable* if the flag is false.
- **"Line crossed" flags** — whether Haruki slept with / confessed to a given heroine. These are the hard switches between good, normal and bad endings.
- **Commitment / wavering value** — in Coda, tracks how fully Haruki gives himself to Kazusa. This is the specific value that separates **Kazusa True** (fully committed, honest) from **Kazusa Normal** (half-measures → mutual ruin) and **Coda Normal** (he pulls back and stays with Setsuna).
- **Motif flags** — recurring soft signals (whether Haruki picks up the guitar again; whether Setsuna sings again; the three-person festival photograph) act as emotional-state markers the script keys off.

Design consequence: because values are hidden and cumulative, **blind first playthroughs frequently land on a bad/normal ending**, and the "correct" path must be reverse-engineered from a walkthrough or repeated runs. This is intentional and central to the game's mystique.

---

## 5. Relationship and Affection Systems

There is **no numeric affection UI.** Relationships are modeled as hidden state and expressed through the narrative.

Relationships modeled:

| Relationship | Nature | Can move toward… |
|---|---|---|
| Haruki ↔ **Setsuna** | Main romance / guilt axis | love, dependency, resentment, estrangement, reconciliation |
| Haruki ↔ **Kazusa** | Fated, unspoken love | longing, betrayal, commitment, destruction |
| Setsuna ↔ Kazusa | Rivalry that wants to be friendship | "either an irreconcilable enemy or a lifelong best friend" |
| Haruki ↔ **Koharu** (CC) | Mentor/junior, mirror | trust, admiration, romance, guilt |
| Haruki ↔ **Chiaki** (CC) | Casual friendship / meta | intimacy, manipulation, revelation |
| Haruki ↔ **Mari** (CC) | Boss/subordinate | respect, adult romance, transference (she reminds him of Kazusa) |
| Takeya / Io → Haruki & Setsuna | Peer pressure / support | they actively push for reconciliation; their interference can *hurt* |

Mechanics:
- Choices **raise or lower** hidden attachment/trust values. Being kind, present and honest generally raises trust; avoidance, lying and infidelity raise attachment *and* resentment simultaneously — the game is built on the idea that **love and harm are not opposites.**
- There is no "fear/rivalry meter," but rivalry is dramatized: Setsuna's and Kazusa's values pull against each other, and favoring one visibly damages the other.
- Relationship breakdown (not death) is the primary failure mode — see endings.

---

## 6. Multiple Endings

### Introductory Chapter
- **1 ending (fixed).** Kazusa leaves for Vienna; Haruki ends things with Setsuna; all three scatter. There is no alternate IC outcome.

### Closing Chapter
- **Per-heroine good and bad/normal endings** for Setsuna, Koharu, Chiaki and Mari (roughly 8–10 endings depending on how normal ends are counted).
- **Good endings** resolve that heroine's arc; **bad/normal endings** leave the relationship broken or unresolved and **do not unlock Coda.**
- Clearing the **Setsuna good ending** is the documented gate to Coda.

### Coda (four endings)
| Ending | Type | Outcome |
|---|---|---|
| **Setsuna True** | True/Good | Haruki reaffirms his love for Setsuna; they marry and have a child |
| **Kazusa True** | True/Good | Haruki and Kazusa rekindle the affair but choose honesty; they marry (ceremony at Hōjō) |
| **Kazusa Normal** | **Bad** | The affair ends with Haruki destroying his relationships with *both* women permanently |
| **Coda Normal** | Normal | Haruki wavers, has a change of heart, and stays with Setsuna without fully giving himself to Kazusa |

### Epilogue
- **Mini-After Story** provides two character epilogues: Kazusa's *"The Road Back to Happiness"* and Setsuna's *"The Road Onward to Happiness."*
- PS3/Vita extra episode ***Fugutaiten no Kimi e*** (*"To You, My Irreconcilable Enemy"*) is a separate bonus scenario.

**Failure design:** the characteristic "bad" outcome is **relationship breakdown and unresolved feelings**, not a game-over. Bad endings are written as *plausible, painful continuations* rather than punishment screens — a hallmark of the game's tone.

---

## 7. Save and Load

Standard, fully featured visual-novel systems:

- **Multiple save slots** with screenshots/thumbnails and timestamps.
- **Quick-save / quick-load** for instant bookmarking mid-scene.
- **Backlog / history** with voice replay and rewind.
- **Auto-advance and Skip** (including skip-read-text-only) — essential given the length and the need to replay for Coda.
- **Scene / chapter selection** — after clearing, players can jump back to key scenes to replay branches without restarting, which is critical because the Coda gate requires re-running CC.
- **Ending/route tracking** — the game records which endings you have obtained (needed to know whether Coda has unlocked).
- **PS Vita additions:** a *"famous scene marker"* (名場面マーカー) that warns when you are approaching a fan-voted memorable scene, plus a *"novel mode"* layout (full-screen text / hidden sprites).

Replayability design: the save/scene-jump tools exist specifically to support the **multi-run structure** the gating demands.

---

## 8. Inventory / Items

**There is no item-inventory mechanic.** *White Album 2* has no collectible objects, no keys/documents/weapons, and no inventory screen. It is a pure dialogue-and-flag VN.

However, the story uses **recurring "key objects" as symbolic load-bearing props** (the VN equivalent of items — they carry memory and act as emotional flags):

| Object | Role |
|---|---|
| **The acoustic guitar** | Haruki's link to the trio; put away in CC (symbol of avoidance), picked back up as a sign of healing |
| **"Todokanai Koi" (the song)** | The original song written for the festival; the love that cannot reach — the game's central motif |
| **"White Album" (the song)** | The inherited song from the first game; the rooftop origin of the trio |
| **The three-person festival photograph** | Kept framed in Haruki's room; symbol of the irrecoverable past |
| **Kazusa's letter** | Left in Setsuna's desk before leaving; a delayed emotional trigger |
| **The engagement ring** (Coda) | Marks Haruki's commitment to Setsuna and what the affair threatens |
| **The piano** | Kazusa's identity and her only "skill"; the counterpart to Haruki's guitar |

There is nothing to *collect per scene*; these objects persist as narrative constants that later scenes reference to gauge emotional state.

---

## Appendix — Quick Summary of "What Kind of Game Is This Mechanically"

- **IC:** kinetic novel. 0 choices, 1 ending.
- **CC:** route-based branching with hidden cumulative flags; 4 heroine routes; good/bad ends.
- **Coda:** hidden finale, gated behind CC; 4 endings (2 true, 1 normal, 1 bad).
- **No stats, no customization, no inventory, no combat.**
- **Difficulty = figuring out the hidden flag math** to unlock the true route and Coda.
- **Signature mechanic:** the *Closing Chapter gate* — the game hides its emotional payoff behind mandatory replay of other routes, turning the save/scene-jump system into a core part of the experience.

---

*Sources: English/Japanese/Russian Wikipedia articles on White Album 2; Leaf/Aquaplus product documentation; widely documented player-community route/gating knowledge. Specific hidden-flag names are not published by the developer and are described here as representative categories rather than literal engine identifiers; the Coda unlock condition (clearing the CC Setsuna good ending) reflects the commonly documented community understanding.*
