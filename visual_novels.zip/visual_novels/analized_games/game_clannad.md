# Clannad (2004) — Deep-Dive Mechanics Report

**Game:** CLANNAD (クラナド)
**Developer:** Key / publisher VisualArt's (PC), later Interchannel (PS2) and Prototype (PSP, X360, PS3, Vita, PS4, Switch)
**First release:** Windows, 28 April 2004 (limited ed.; standard ed. 6 Aug 2004)
**Director / lead writer:** Jun Maeda (with Yūichi Suzumoto, Kai, Tōya Okano)
**Artist:** Itaru Hinoue · **Composers:** Jun Maeda, Shinji Orito, Magome Togoshi
**Genre:** Romance adventure / visual novel — explicitly a **"nakige"** (cry-inducing game)
**Structure:** two arcs — **School Life** (common intro → 8 story arcs across ~10 characters) + **After Story** (unlocked), with a hidden **Light Orb** meta-layer and a gated **true ending**
**Playtime:** ~80–300 h depending on completionism (VNDB/Russian Wikipedia)
**Note:** *Clannad* was Key's first **all-ages** title (unlike *Kanon* and *Air*, which shipped as adult games).

> Scope note: *Clannad* is a **classic choice-menu visual novel**, not a gimmick-driven one. There is **no phone-trigger, no stat screen, no avatar, and no player inventory**. Its distinguishing machinery is a **cross-playthrough collectible ("Light Orbs")** that gates the second half and the true ending, layered on a **strict route-completion order**. Where the requested category does not exist, this report says so rather than inventing it.

---

## 0. Executive summary (the design in one paragraph)

The player is Tomoya Okazaki, a burned-out delinquent in his last year of high school. In the **School Life** arc he meets a shy repeat-student, Nagisa Furukawa, and is drawn into helping her revive the disbanded drama club — and, through it, into the private crises of roughly ten people. At scripted **choice points** the player steers Tomoya's attention and affection. Spend enough of it on one girl and the story locks into her **route**, ending in a romantic "good end." Each cleared heroine route awards a **Light Orb**; the orbs persist in system data across playthroughs. Once **8 orbs** are held, the second half — **After Story**, a decades-spanning family drama about Tomoya and Nagisa's marriage, their daughter Ushio, and a hereditary illness — unlocks. After Story has a tragic **normal ending** (Nagisa dies in childbirth; Ushio dies five years later) and, if the player has gathered **all 13 orbs**, a **true ending** in which the accumulated kindness of the whole town performs a miracle and rewrites that fate. The "game" is therefore not the UI — it is a **completion loop**: to reach the real ending you must first live through everyone else's, and then replay the core.

---

## 1. Characters

### 1.1 Core character portraits

The player character is fully voiced-absent (Tomoya is unvoiced in-game) and the narration is first-person. The cast is organised around **five heroines** (the routes required to unlock After Story) plus **secondary route characters** and a large family/supporting ensemble.

| Role | Name | Defining trait | Story hook (route premise) |
|---|---|---|---|
| Protagonist | **Tomoya Okazaki** (岡崎 朋也) | Cynical "delinquent"; kind underneath; carries guilt about his father | Dislocated his right shoulder in a fight with his father → lost basketball; can't raise the arm. His arc is escaping his own fatalism. |
| Main heroine | **Nagisa Furukawa** (古河 渚) | Shy, sickly, earnest; repeats a year; loves the "Big Dango Family" | Wants to revive the drama club. Her route is the spine; **After Story is her continuation.** |
| Heroine | **Kyō Fujibayashi** (藤林 杏) | Tomboy, class rep, throws dictionaries; rides a scooter | Secretly loves Tomoya but pushes her twin sister Ryou at him; the sisters' love triangle. |
| Heroine | **Kotomi Ichinose** (一ノ瀬 ことみ) | Prodigy physicist's daughter; reads foreign books in the library; plays painful violin | Trauma over her parents' death and the last words she said to them; a "message from the past." |
| Heroine | **Tomoyo Sakagami** (坂上 智代) | Physically strongest student; silent, intimidating; transferred in | Runs for student council president to save the town's cherry trees; romance vs. her public role. |
| Heroine | **Fuko Ibuki** (伊吹 風子) | Odd first-year carving starfish with a knife | **She is a spirit**: her body is comatose after a pre-enrolment accident; people forget her as her wish is fulfilled. |
| Secondary route | **Ryou Fujibayashi** (藤林 椋) | Timid twin; class rep; terrible cook; fortune-teller | Kyou's side route — the shy sister's version of the triangle. In the true ending she pairs with Kappei. |
| Secondary route | **Yukine Miyazawa** (宮沢 有紀寧) | Calm girl in the library reference room | Her dead brother Kazuto's gang, and a boy (Yu) whose sister is entangled with it. |
| Secondary route | **Misae Sagara** (相楽 美佐枝) | Dorm mother; ex-student-council president | A wish made to a "boy" (Katsuki) who is really her **cat** in human form. |
| Hidden route | **Kappei Hiiragi** (柊 勝平) | Travelling young man; appears only in the game | Hit by Kyou's scooter; a girl (Ryou) leaves a handkerchief. Treated for **osteosarcoma**. |
| Family | **Akio & Sanae Furukawa** | Nagisa's loud father and crybaby mother; run Furukawa Bakery | Akio's "grass baseball" team (the Furukawa Bakers) spawns a special ending. |
| Family | **Naoyuki Okazaki / Shino Okazaki** | Tomoya's estranged father; his grandmother | The After Story reconciliation: Shino reveals Naoyuki's sacrifice. |
| Family | **Ushio Okazaki** (岡崎 汐) | Tomoya and Nagisa's daughter | The heart of After Story; the "Girl in the Illusionary World" reveal. |
| Support | **Youhei Sunohara** | Tomoya's fellow delinquent; comic relief | Target of Tomoyo's beatings; brother of Mei. |
| Support | **Yūsuke Yoshino / Kōko Ibuki** | Ex-rockstar electrician; Fuko's elder sister | Tomoya's employer in After Story; the couple Fuko's arc protects. |
| Illusionary World | **The Girl / the Junk Robot** | Sole human and her junk-bodied companion "I" | Framing device: the robot narrates the fantasy world. They are **Ushio and Tomoya**, and the girl is gathering the Light Orbs. |

**Music as identity:** six characters get BGM leitmotifs (the five heroines + Yukine), a common Key device that signals whose "space" a scene is in.

### 1.2 Character abilities / player-managed stats

There is **no stat system** — no HP, no skill points, no visible affection numbers. What stands in for "abilities" is entirely authored:

- **Tomoya's physical past** — former basketball team captain; the dislocated shoulder is a permanent, unhealable limit (he cannot raise his right arm above the shoulder). It is the body-as-metaphor for his stunted life.
- **Kotomi's intellect** — national top-ten scores; she reads academic English/French and solves problems analytically. The one "skill check" of the game is a *puzzle of interpretation* (decoding her parents' message), not a number.
- **Tomoyo's strength** — she wins fights (biker gangs, Sunohara) and wins an election; her route is a "can she have both a public duty and a private love" test.
- **Kyō's athleticism and cooking**, **Ryou's fortune-telling** (always wrong, but inversely accurate), **Fuko's carvings**, **Misae's authority**, **Nagisa's stage acting** — all narrative competencies, never stats.

The only quantity the game actually maintains is a **hidden affection counter per heroine** (see §4–5). The player never sees it.

### 1.3 Character customization

**None.** Tomoya is a fixed, authored character: no name entry, no avatar, no appearance or personality build, no voice for the protagonist. The player's entire authorship is choice selection (§2).

---

## 2. Dialogue and action choices

*Clannad* uses the **standard Key/VN choice-point model** rather than a bespoke gimmick.

- The screen shows static 2-D sprites over first-person backgrounds with a dialogue box; narration is Tomoya's interior voice.
- Interactivity is deliberately **low**: the player reads, and at **developer-determined moments** the text stops and offers a **menu of two-to-four options** ("what Tomoya says or does").
- Choices fall into two functional classes:
  1. **Cosmetic / colour choices** — a joke line, who to talk to first, a flavour response. They add banter or tiny affection nudges and change nothing structural.
  2. **Route-determining choices** — which girl Tomoya spends time with, accepts an invitation from, or protects. Enough of these in one direction locks the **route** and eventually the **ending**.
- A few choices are **concrete actions rather than dialogue**, and they can gate whole side routes. The documented example: Tomoya meets **Kappei** only if he **dodges Kyō's scooter to the right**; the wrong side misses the hidden route entirely.
- There is at least one **minigame-flavoured branch**: Akio's **grass-baseball** sequence, which can produce a special ending.
- **Crucially, the game does not tell you a branch happened.** As with most Key titles, the route pivot is silent; players routinely discover they "chose wrong" only at the ending screen.

**Player-facing feel:** the design's bet is that *who you pay attention to* is the entire game. There is no meter to optimise — only attention.

---

## 3. Branching narrative and key scenes

### 3.1 How the story splits

The game is two arcs joined by an unlock:

```
SCHOOL LIFE (available from the start)
  Common intro (the sloped road; the drama-club goal; choices distribute attention)
        │
        ├─ Nagisa route        ── good end ──► ORB   (also the gateway to After Story)
        ├─ Fuko route          ── good end ──► ORB
        ├─ Kotomi route        ── good end ──► ORB
        ├─ Kyō route           ── good end ──► ORB   (+ Ryou side ending)
        ├─ Tomoyo route        ── good end ──► ORB
        ├─ Ryou route          ── side ending
        ├─ Yukine route        ── side ending
        ├─ Misae route         ── side ending
        ├─ Kappei route        ── hidden side ending (dodge scooter RIGHT)
        └─ Grass-baseball      ── special joke ending
        │
   each heroine route also has BAD ENDINGS on wrong choices
        │
   after 8 orbs (the five heroines' good ends) ▼
AFTER STORY (unlocked)
        ├─ normal/tragic ending (Nagisa dies; Ushio dies)
        └─ TRUE ENDING (all 13 orbs → the miracle)
```

**Design notes on the structure:**
- School Life is divided into **eight story arcs covering about ten characters**; which arc you enter is decided by choices made in the **common introduction**. Because the intro repeats every playthrough, you must restart and choose differently to see the others.
- **Route completion is strictly ordered in effect**: After Story requires the **good endings of the five main heroines** (a "good ending" = Tomoya and the girl become a couple). Five orbs come from those.
- The **Light Orb economy**: 8 orbs unlock After Story; **all 13** unlock the true ending. One orb **disappears during School Life and reappears in After Story** — a deliberate "you are not done yet" signal.
- Each heroine arc is a **self-contained relationship story with one good ending and several bad endings**, *except* **Kyō's arc, which carries a side ending for her twin Ryou**.
- The original design brief reportedly wanted **RPG-like collectible items**; this was cut because it distracted from the story. The Light Orbs are the surviving, heavily simplified remnant — a "collectible" whose only use is to **gate content**.

### 3.2 Routes: levers, destinations, and weight

| Route | How it is entered | Where it leads | Long-term consequence? | Type |
|---|---|---|---|---|
| **Nagisa** | Steer attention to Nagisa through the common route | Romantic good end; **required** for After Story | **Key** — the only route that continues into the second half | Key route |
| **Fuko** | Help Fuko with her starfish/ghost objective | Good end; Fuko's wish resolves; **orb** | Key to unlocking After Story (orb) | Key (completion) |
| **Kotomi** | Befriend Kotomi; pursue the library/parents mystery | Good end; she confronts her trauma; **orb** | Key (orb) | Key (completion) |
| **Kyō** | Spend time with the twins; let the triangle resolve toward Kyō | Good end; **orb**; **Ryou side ending** available | Key (orb); also the Ryou branch | Key (completion) |
| **Tomoyo** | Side with Tomoyo; support her council run | Good end; **orb** | Key (orb) | Key (completion) |
| **Ryou** | Resolve the triangle toward the shy twin | Side ending (romance) | No After-Story gate; flavour/content | Side / cosmetic-to-progression |
| **Yukine** | Frequent the reference room; engage her brother's gang plot | Side ending | None on the true-end gate | Side |
| **Misae** | Dorm-life scenes; the Katsuki/cat story | Side ending; tied to a **light orb** thematically | None on the gate | Side |
| **Kappei** | **Dodge Kyō's scooter on the right** | Hidden route; Kappei's illness; Ryou romance in canon | None on the gate; a completionist/true-ending texture | Hidden side |
| **Grass baseball** | Play Akio's baseball sequence | Joke/special ending | None | Easter egg |
| **After Story** | Hold **8 orbs**, then clear Nagisa's good end | Normal (tragic) or **true** ending | **Key** — the canon conclusion | Key route |

**Cosmetic vs key, clarified:** the vast majority of individual choices are **cosmetic** (banter, minor affection). A small subset are **key**: the attention-distribution choices that lock a route, the Kappei scooter dodge, and the After Story outcome. The five heroine routes are not "cosmetic" in the flag sense, but they are **content-complete in themselves** — they end the game with that girl and do not continue.

### 3.3 Key scenes (spoiler-level, with mechanics attached)

- **The sloped road (opening).** Tomoya meets Nagisa standing still, muttering the name of the food she wants to motivate herself. This is the game's "origin point"; every route begins from this common morning. It is the scene the true ending ultimately protects.
- **The drama-club restoration.** The through-line of the common route. Its goal (restaging the disbanded club) is the mechanical spine that lets Tomoya meet every other heroine. Nagisa's eventual play — **the Girl in the Illusionary World** — is the framing story of the whole game.
- **Fuko's arc.** Fuko carves wooden starfish to give as gifts for her sister Kōko's wedding. The reveal: she is a **spirit** — her real body lies comatose after a traffic accident before she ever enrolled. As her goal is achieved, **people forget her one by one**; those close to her body never perceived her at all. Only the persistence of her effect (the wedding guests, the lingering talk of her) survives. If conditions are met, she can cameo in other routes.
- **Kotomi's arc.** A childhood prodigy who witnessed a bus/car collision, re-triggering the trauma of her parents' death — and of the **cruel last words she said to them** before they died. A strange "Gentleman" approaches her; a **message left by her parents** (a birthday gift / document) must be found and understood. Her route is the game's only genuinely *new* structural move according to critic Kōkoro Satō; the others echo *Kanon*/*Air* beats.
- **Kyō / Ryou arc.** Kyō plays matchmaker for Ryou, then falls for Tomoya herself. A near-kiss and a school rumour force Kyō to withdraw; she even tries dating Sunohara. Tomoya must break cleanly with Ryou (who consents, having understood both hearts) to reach Kyō. In the **true ending**, Ryou is instead paired with **Kappei**.
- **Tomoyo's arc.** Tomoyo runs for student council president to protect the town's **cherry trees**. She wins, then her relationship with Tomoya becomes public and she is pressured to choose duty over love; they separate. Eight months later she returns, declaring she cannot imagine anyone else. (Her story continues in the adult spin-off *Tomoyo After: It's a Wonderful Life*.)
- **Yukine's arc.** The library reference room as a neutral ground; her late brother **Kazuto**'s delinquent gang, and the boy **Yu**, whose sister is caught up with them.
- **Misae's arc.** The dorm mother's past: a wheelchair-bound boy, **Katsuki Shima**, whom she encouraged. He returns to repay her — but the real Katsuki died, and **his cat took human form** to grant Misae's wish. The arc is the game's clearest statement of the **Light Orb rules** (a wish granted literally and incompletely).
- **Nagisa's arc and the confession.** Nagisa overcomes her illness and self-doubt to perform the Illusionary-World play; Tomoya confesses. This good end is the gateway to After Story.
- **After Story — the family drama.** Tomoya graduates and takes a job at **Yūsuke Yoshino's electrical company**. Nagisa repeats another year, graduates, and they marry. She becomes pregnant and gives birth to **Ushio** — and **dies in childbirth**. Tomoya collapses into five years of depression and hands Ushio to Akio and Sanae. On a trip with Ushio he meets his **grandmother Shino**, learns the truth of his father **Naoyuki's** sacrifices, and reconciles. He begins to raise Ushio — and then **Ushio contracts the same illness** and dies in the snow. This is the **normal/tragic ending**.
- **The Illusionary World.** Interstitial scenes: a lone **Girl** and a mute **junk robot** in a dead world. The girl created the robot so she would not be alone; she is **collecting Light Orbs to make a miracle** to save her family, and does not remember why. The reveal: the girl is **Ushio**, the robot is **Tomoya**, and the orbs are the player's accumulated kindness.
- **The true ending.** With all 13 orbs, Tomoya's wish is granted: he is carried back to the moment **Ushio is born**, retaining memories of the lost timeline, into a world where **both Nagisa and Ushio live**. The miracle is not free — the orbs grant the wish *exactly* as asked, and only if it is genuinely wanted (see §4).

---

## 4. Story flags and variables

The game keeps a hidden variable store and a **persistent meta-store**. Nothing is displayed as a number; guides reverse-engineered the mechanics.

Categories of tracked state:

1. **Per-heroine affection counters (hidden).** Every route-relevant choice adds points to one or more heroines. When a heroine's total crosses a threshold at the route-decision point, that route locks. There is no visible meter.
2. **Route-lock flags.** Once locked, the arc plays to its good or bad end. The pivot is silent.
3. **Good-ending completion flags (per heroine).** Clearing a heroine's good end sets a flag and awards an orb. **Five such flags are required to unlock After Story.**
4. **Light Orbs — the persistent, cross-save variable.** Orbs are **not** stored in the normal save file; they are written to **system/global data** and accumulate across playthroughs and restarts. This is the game's most important variable:
   - **8 orbs → After Story unlocks.**
   - **13 orbs → the true ending unlocks.**
   - **One orb vanishes during School Life and reappears in After Story** — a designed re-check that forces a second pass.
   - Orbs are *created whenever Tomoya helps someone achieve happiness*, so the "kindness" of each route is literally converted into a stored resource.
5. **Choice/action booleans.** Concrete flags such as the **Kappei trigger** (scooter dodged right = route open; left = no route). Similar flags gate side-route availability.
6. **The After Story "genuine wish" checks.** In the ending logic (and elaborated in the anime), the orbs obey rules:
   - They do **exactly** what is asked — no more (Misae asks Katsuki to love her forever, and he reverts to being her cat).
   - They grant only **genuinely wanted** wishes (Tomoya's self-pitying wish that he had never met Nagisa is *not* granted).
   - A child is the culmination of the parents' wishes — which is why **Ushio** can carry the miracle.
7. **Read/skip state.** Standard per-line "already-read" tracking that powers Skip; it is functionally a large boolean array and is the main QoL that makes replaying the intro tolerable.

Crucially, **later content checks these values**: the route pivot checks affection; After Story checks the five heroine flags; the true ending checks the orb total. The game **never explains the orb requirement in-game**, which is why reaching the true ending without a guide is famously obscure — a point reviewers singled out as a usability flaw.

---

## 5. Relationship and affection systems

*Clannad* has **no visible relationship UI** — no hearts, bars, or trust numbers. Relationships are modelled as **hidden affection counters feeding route flags**, plus a great deal of authored emotion. The tracked relationships:

| Relationship | Nature | How it moves |
|---|---|---|
| **Tomoya ↔ Nagisa** | The central romance; the canon pairing | Built throughout the common route; her route is mandatory for the second half. |
| **Tomoya ↔ Kyō** | Tsundere romance, complicated by her sister | Rises as Tomoya engages the twins; the triangle must be resolved toward Kyō or Ryou. |
| **Tomoya ↔ Ryou** | Gentle, unrequited-then-reciprocated | The side version of the triangle; in canon she ends with Kappei. |
| **Tomoya ↔ Kotomi** | Childhood friends → romance | Rises as he investigates her past and supports her. |
| **Tomoya ↔ Tomoyo** | Romance vs. public duty | Rises as he backs her council run; tested by the separation. |
| **Tomoya ↔ Fuko** | Friendship/guardianship, not romance | Rises as he helps her starfish goal; her arc is about memory and letting go. |
| **Tomoya ↔ Yukine** | Platonic confidante | Rises through reference-room visits; the brother-gang plot. |
| **Tomoya ↔ Misae** | Mentor/landlady bond | Dorm scenes; the Katsuki story is her past, not a romance with Tomoya. |
| **Tomoya ↔ Sunohara** | Best-friend comedy duo | Static trust; comic relief; the butt of Tomoyo's strength. |
| **Kyō ↔ Ryou** | Twin sisters; love rivalry without malice | The emotional engine of the Fujibayashi arc; Kyō suppresses her feelings for Ryou. |
| **Fuko ↔ Kōko** | Sisters; the wish is Kōko's wedding | Fuko's arc resolves into Kōko ↔ Yūsuke's marriage. |
| **Tomoya ↔ Naoyuki / Shino** | Estranged father; reconciling grandmother | After Story's emotional climax; no player input — pure story. |
| **Tomoya ↔ Ushio** | Father and daughter | After Story's second half; the route to the true ending. |

**Important:** affection and route are the **same system** — raising a heroine's hidden count *is* choosing her. The game has **no separate rivalry, fear, or resentment stats**; those tones (Kyō's self-sacrifice, Kotomi's guilt, Naoyuki's shame) are conveyed by **writing**, not by tracked numbers. The only "negative" mechanic is that a wrong affection spread produces a **bad ending** rather than a lower relationship score.

---

## 6. Multiple endings

The game's endings fall into the requested types:

| Ending | Type | Canon? | Summary |
|---|---|---|---|
| **Five heroine good endings** (Nagisa, Fuko, Kotomi, Kyō, Tomoyo) | Character endings | Nagisa's is canon | Tomoya and the girl become a couple; each awards a **Light Orb**. |
| **Per-route bad endings** | Bad endings | No | Wrong choices within a heroine's arc strand it — the relationship fails and the game ends early. Each heroine arc has several. |
| **Ryou ending** | Side / character ending | Partly | The shy twin's version of the Kyō triangle. |
| **Yukine ending** | Side ending | No | Resolves her brother's gang plot. |
| **Misae ending** | Side ending | No | Resolves the Katsuki/cat wish. |
| **Kappei ending** | Hidden character ending | Ties to canon (Ryou) | The osteosarcoma arc; Ryou's romance in the true timeline. |
| **Grass-baseball ending** | Special / joke ending | No | Triggered via Akio's baseball sequence. |
| **After Story normal ending** | **Bad / tragic ending** | No | Nagisa dies in childbirth; Tomoya raises Ushio; Ushio dies of the same illness. |
| **After Story true ending** | **True / final ending** | **Yes** | With all **13 orbs**, the miracle sends Tomoya back to Ushio's birth into a world where **Nagisa and Ushio live**. |

**Failure states** map onto bad endings: relationship breakdown (route bad ends), unresolved grief and a broken family (After Story normal end), or a locked-out conclusion (insufficient orbs). The game **rewards completionism aggressively**: the true ending is gated behind **collecting every orb**, i.e. behind first experiencing every other character's happiness. The design thesis is that the miracle is *earned by the player's accumulated play*, not by a single late choice.

---

## 7. Save and load

*Clannad* ships the standard high-comfort VN toolkit, and it depends on it — because routes require restarting the common intro:

- **Multiple named save slots** (port-dependent counts).
- **Quick save / quick load.**
- **Backlog** with voice replay (in voiced ports).
- **Auto-advance** (hands-free reading) and **Skip**, including **"skip already-read text only."** This is the key affordance that makes replaying the shared intro bearable.
- **Scene / CG gallery** and **music gallery** for cleared content.
- **Ending list / clear tracking** so the player can see which conclusions are unlocked.
- **Dangopedia** — the English/console glossary of Japanese cultural, food, and family terms. Added for the international releases and specifically praised by reviewers as a usability win.
- **Persistent system data for Light Orbs** — the crucial twist: orbs live **outside** the save file, so deleting or overwriting a save does **not** lose progress toward After Story or the true ending. This is what makes the meta-progression feel like a global "kindness account."

**Important caveat:** there is **no flowchart and no free chapter/scene select**. To see a different route you **reload the common intro (or restart)** and make different choices; the game expects you to use Skip and your own memory. Reviewers criticised the lack of any in-game hint that you must *replay* arcs to reach the true ending, and that some arcs must be read in a particular order.

---

## 8. Inventory / items

There is **no player-managed inventory** — and this is a design decision with a paper trail: Key **considered RPG-style collectible items and dropped them** because they distracted from the story. What survives is one meta-item and a set of **narrative objects** that are effectively flags in disguise.

### 8.1 The one "real" item: the Light Orb

| Item | What it is | Mechanical role |
|---|---|---|
| **Light Orb** (光の玉) | A glowing sphere said to be born whenever someone is helped to happiness; visible in the Illusionary World | The game's **only collectible and its only persistent variable**. Awarded per cleared route; **8 unlock After Story, 13 unlock the true ending**; one vanishes in School Life and returns in After Story. Functions as a wish-granting resource in the finale. |

### 8.2 Narrative items (MacGuffins and flags)

| Item | Where it appears | Role |
|---|---|---|
| **Fuko's starfish carvings** | Fuko's arc | The gifts she makes for her sister's wedding; the vehicle of her ghost story and of her being forgotten. |
| **The drama-club play script / the Illusionary-World play** | Common route → Nagisa's arc | The framing story; ties the school plot to the fantasy world. |
| **Kotomi's parents' "message"** (birthday gift/document) | Kotomi's arc | The key object of her route; decoding it resolves her trauma. |
| **Kotomi's violin** | Kotomi's arc | A character object (she plays terribly) that marks her isolation and her reconnection. |
| **The Big Dango Family / dango** | Nagisa throughout | Nagisa's mascot obsession; thematic symbol of family; carried into After Story via Ushio. |
| **Ryou's tarot cards** | Kyō/Ryou arc | A gift from Tomoya; her fortune-telling accuracy improves once she uses them. |
| **Kappei's handkerchief** | Kappei route | Left by the kind girl (Ryou) after the scooter crash; the object of his search and their bond. |
| **Tomoya's basketball / the bad shoulder** | Backstory, 3-on-3 event | The "item" he lost; the physical reminder of his abandoned potential. |
| **Misae's cat (Katsuki)** | Misae's arc | The transformed "boy" who repays her wish; the literal-and-incomplete-wish demonstration. |
| **Ushio's lost toy robot** | After Story | The object she searches for in the flower field — the diegetic echo of the Junk Robot in the Illusionary World. |
| **Yūsuke's guitar / the electrical tools** | Fuko arc / After Story | Yūsuke's rock past and Tomoya's job; the bridge between the school story and adult life. |

**Design takeaway:** items exist to make **memory and kindness legible**, not to be managed. The player never opens a bag; the "inventory" is the **orb count on the system data**, which is the whole point.

---

## Appendix A — Route/ending topology and the orb economy

**Orb flow across a full completion run:**

```
Playthrough 1  Nagisa good end      → ORB 1
Playthrough 2  Fuko good end        → ORB 2
Playthrough 3  Kotomi good end      → ORB 3
Playthrough 4  Kyō good end         → ORB 4   (+ Ryou side end available)
Playthrough 5  Tomoyo good end      → ORB 5
               (side routes: Yukine, Misae, Kappei → more orbs)
                     │
               at 8 orbs ▼
               AFTER STORY unlocks
                     │
        After Story normal end (Nagisa & Ushio die)
                     │
        replay/collect remaining orbs → 13 total
                     │
               TRUE ENDING (Nagisa & Ushio live)
```

- **Orbs are global, not per-save.** They survive save deletion.
- **One orb is temporarily absent** during School Life and reappears in After Story, forcing a re-check of the orb count.
- **The true ending is a completion reward**, not a skill check: it is unlocked by *having lived every other route*, which thematically equates the player's grind with the town's collective kindness.

---

## Appendix B — What a designer should steal from *Clannad*

1. **Make the meta-progression the moral thesis.** The Light Orbs are not a currency; they are *acts of kindness converted into saved data*. The best ending is literally "you helped enough people." Progression and theme are the same object.
2. **Gate the second half behind breadth, not depth.** Requiring all five heroine good ends forces the player to *care about everyone* before earning the right to the main story.
3. **Keep the meta-store out of the save file.** Persisting orbs in system data turns "restart" from a punishment into a continuation — replay feels like accumulation, not erasure.
4. **Use a silent route pivot.** Never announce the branch; let attention be the input. (Pair it with a skip-read-text feature so replaying the shared intro is cheap.)
5. **Signal incompleteness with one diegetic object.** The orb that vanishes in School Life and returns in After Story is a masterclass in wordless "you are not finished."
6. **Spend your one collectible wisely.** Key cut RPG-style items precisely because they competed with the story; the single surviving item exists only to unlock narrative. Restraint is the feature.

---

## Sources

- English Wikipedia, *Clannad (video game)* — gameplay (choice points, Light Orbs, 6 plotlines/5 available, 8 orbs → After Story, 13 → true ending, cut item system), characters, plot, development, release history.
- Japanese Wikipedia, *CLANNAD (ゲーム)* — story structure (School Life / After Story / Illusionary World), light-orb world-switch, character arcs, Akio's grass-baseball ending, platform history.
- Russian Wikipedia, *Clannad (игра)* — gameplay detail (low interactivity, choice-driven route branches, eight School Life arcs across ten characters, strict completion order, five heroine good ends required for After Story, single good ending per heroine plus several bad ends, Kyō's Ryou side ending, orb per cleared arc, restart-from-intro loop, cut RPG collectibles), route synopses (Nagisa, Kyō/Ryou, Tomoyo, Kotomi, Fuko, Misae, Kappei/osteosarcoma), and critical reception.
- Clannad Fandom Wiki (via MediaWiki API) — *Light orbs* (orb origin and the three wish rules; Ushio/Tomoya Illusionary-World reveal) and character/route page index.
- VNDB entry (developer, playtime, release history).

*Report compiled 2026-09-22.*
