# Steins;Gate (2009) — Deep-Dive Mechanics Report

**Game:** STEINS;GATE
**Developer:** 5pb. / Nitroplus (Science Adventure series, #2)
**First release:** Xbox 360, 15 Oct 2009 (later PC, PSP, iOS, PS3, Vita, Android, PS4, Switch)
**Genre:** "Speculative Science ADV" — sound-novel-style visual novel
**Playtime:** ~43h 45m (VNDB, 973 votes)
**Structure:** single linear trunk + mid-game heroine branches → **6 endings** (5 alternate + 1 true)
**Design concept:** "99% science and 1% fantasy"

> Scope note: *Steins;Gate* deliberately strips the genre down. There are **no player-managed stats, no character customization, and no inventory UI**. Its entire interaction budget is spent on one system — the **Phone Trigger** — plus a hidden flag layer and a "worldline" state variable. This report maps the requested categories onto that reality and flags where a category simply does not exist.

---

## 0. Executive summary (the design in one paragraph)

The player is Rintaro Okabe, who accidentally invents time travel via text messages ("D-Mails") sent through a modified microwave. The game is a near-kinetic sound novel: you read, and the only inputs you make are **whether to answer a phone call** and **which highlighted word in an incoming text message to reply with**. Those tiny inputs set hidden flags. From the middle of the game onward, each chapter spotlights one heroine and offers a branch that can end the story with her. If the player passes all of those branches and satisfies a prescribed set of flags, they reach the final chapter and the true ending. The "puzzle" the player solves is not in the UI — it is the **causal graph of the story itself**, tracked by a single displayed number: the divergence value.

---

## 1. Characters

### 1.1 Core character portraits (Future Gadget Lab members)

Okabe's circle is a small invention club, the **Future Gadget Laboratory** ("Lab"), whose members are numbered **Lab Members (LabMem)**. The number itself is a narrative device (membership = relationship state).

| No. | Name | Nickname(s) | Role / defining trait | "Ability" / speciality | Voice (JP) |
|---|---|---|---|---|---|
| 001 | **Rintaro Okabe** | Okarin, Hououin Kyouma | Protagonist; self-styled mad scientist (chuunibyou persona) | **Reading Steiner** (retains memories across worldline shifts) | Mamoru Miyano |
| 002 | **Mayuri Shiina** | Mayushii, Mayushi | Childhood friend; airhead, kind | Cosplay / costume-making; emotional anchor | Kana Hanazawa |
| 003 | **Itaru "Daru" Hashida** | Daru, Super Hacker | Perverted otaku hacker | Hacking, programming, hardware; later builds the time machine | Tomokazu Seki |
| 004 | **Kurisu Makise** | Assistant, Christina, "Zombie", Celeb Sev | Heroine; 18-y/o neuroscience researcher published in *Science* | Neuroscience research & experiment design; builds the Time Leap Machine | Asami Imai |
| 005 | **Moeka Kiryu** | Shining Finger | Tech journalist searching for the IBN 5100 | Writing, rapid e-mail input; **extreme phone addiction** | Saori Gotō |
| 006 | **Luka Urushibara** | Lukako | Shrine maiden's child; feminine upbringing | Kendo / martial arts; (becomes female in one worldline) | Yū Kobayashi |
| 007 | **Rumiho Akiha** | Faris NyanNyan | Maid-café star; her family owns Akihabara | Chuunibyou "cat" persona; **RaiNet Access Battlers** card-game champion | Haruko Momoi |
| 008 | **Suzuha Amane** | Part-time Warrior | Part-timer at the CRT shop; secretly John Titor | Martial arts, survival skills, cycling | Yukari Tamura |
| 009* | **Maho Hiyajo** | Loli-chan | Kurisu's colleague (β worldline / S;G 0) | Neuroscience research | Sayuri Yahagi |
| 010* | **Kagari Shiina** | Black leather-suit woman | Mayuri's adopted daughter from the future (S;G 0) | — | Megumi Han |
| 011* | **Yuki Amane** | — | Suzuha's mother; cosplayer (S;G 0) | Cosplay | Yukari Tamura |

\* LabMem 009–011 are added in the β-worldline sequel *Steins;Gate 0* (LabMem 009 is present in the original's data as the final "canon" member count).

Supporting cast with mechanical weight:
- **Yugo Tennouji ("Mr. Braun")** — Okabe's landlord, CRT-TV shop owner; secretly **FB**, the Rounder handler. His daughter **Nae** becomes a Rounder in some worldlines.
- **Dr. Nakabachi / Shouichi Makise** — Kurisu's father; steals her time-travel thesis; the true antagonist whose publication triggers World War III.
- **SERN** and its covert arm, the **Rounders** — the conspiracy hunting the time machine.

### 1.2 Character abilities / player-managed stats

There is **no stat system**. No HP, no skill points, no affection numbers shown to the player. What functions as "abilities" is entirely narrative:

- **Reading Steiner (Okabe)** — the load-bearing mechanic. When the worldline shifts, everyone's memories are rewritten *except Okabe's*. This is why he can carry knowledge across routes and why replays are diegetic: the player's out-of-game memory and Okabe's in-game memory are the same thing.
  - Narrow sense: the dizzy spell when divergence changes.
  - Broad sense: faint memories of other worldlines surfacing as dreams/déjà vu — which happens to several characters (Kurisu awakens it in the film; Fubuki and Yuki show traces in S;G 0).
- **Hacking (Daru)** — the only "skill check" in the plot; needed to crack SERN.
- **Neuroscience (Kurisu)** — produces the Time Leap Machine.
- **Kendo / survival / cycling (Luka, Suzuha)** — used in specific scenes.
- **RaiNet Access Battlers (Faris)** — a card game that is essentially *Geister*-like; a skill-based game (not luck), played by adults. It returns as the backdrop of Faris's ending.

### 1.3 Character customization

**None.** The protagonist is fully authored. There is no avatar, no name entry, no appearance/behavior build. The player's only authorship is the Phone Trigger (Section 2).

---

## 2. Dialogue and action choices — the Phone Trigger

*Steins;Gate* has **no conventional choice menus**. Instead, director Tatsuya Matsubara designed the **Phone Trigger** (フォーントリガー) system. The original pitch was to link the game to the player's *real* mobile phone, but it was abandoned due to Japanese privacy-law concerns and technical limits.

The system works in two modes:

1. **Calls** — when the phone rings, the player chooses to **answer** or **ignore**. Ignoring is a real, recorded choice.
2. **Text messages (mail)** — incoming messages render certain words **underlined and highlighted in blue, like hyperlinks**. Selecting a highlighted word chooses the reply. Most messages can be ignored; some are mandatory.

Key properties:
- The phone UI sits on screen during normal reading; the player can open it at almost any time.
- Most calls/mails "do not require a response," but **a single mail or a single phone call can change the entire route**. This is the design's signature: the input is tiny, the consequence is enormous.
- The phone also stores a **history of received/sent mail and calls**, so missed triggers can be reviewed.
- In the sequel *Steins;Gate 0* this evolves into the **RINE Trigger** (a LINE-like app): the player picks a reply text or a **sticker**, and — importantly — the game shows the exact message before sending and **auto-saves**. RINE replies in S;G 0 are largely cosmetic; the branching there is driven by whether Okabe answers **Amadeus's calls**.

**Player-facing feel:** the choice never announces itself as a branch. The game trusts the player to intuit that *who you reply to, and how* is the entire game.

---

## 3. Branching narrative and key scenes

### 3.1 How the story splits

The Japanese Wikipedia description of the system is the clearest statement of the structure:

> The story is a sound-novel-style adventure game with **6 multiple endings**, where the lives of companions and humanity's future hinge on the protagonist's choices. From the middle of the story onward, each chapter focuses on one heroine, and branches to each heroine's route are provided. **When a branch occurs, the story ends with the protagonist ending up with that heroine in that chapter.** By proceeding without ending up with anyone and **setting the prescribed flags**, the player can proceed to the final chapter, opening the path to the true ending. There are no conventional choice menus; instead the **Phone Trigger** is central.

So the shape is:

```
Common trunk (early chapters)
        │
        ├─ branch → LUCA route        (terminal)
        ├─ branch → FARIS route       (terminal)
        ├─ branch → SUZUHA route      (terminal)
        │
        └─ keep going (no heroine locked in)
                 │
                 ├─ Kurisu flags NOT set → MAYURI ending (terminal)
                 ├─ Kurisu flags set     → KURISU ending (near-miss)
                 └─ Kurisu flags + all conditions → TRUE END ("Steins;Gate")
```

### 3.2 The branch levers

The decisive mid-game decisions are all framed as **"send the D-Mail that undoes a previous change, or don't."** Refusing to send it strands the story in that heroine's altered worldline and ends the game with her.

| Route | Trigger (player decision) | Where it leads | Long-term consequence? | Type |
|---|---|---|---|---|
| **Luka Urushibara** | Do **not** send the D-Mail that reverts Luka to male | Okabe accepts Mayuri's death and stays with Luka; post-credits they have a child | Terminal — replaces the rest of the game | Alternate ending (non-canon dead end) |
| **Faris NyanNyan** | Do **not** send the D-Mail that caused Faris's father's death | Divergence jumps past 1% into an unstable reading; nobody remembers Okabe; he and Faris are a couple, playing RaiNet tournaments | Terminal | Alternate ending (non-canon dead end) |
| **Suzuha Amane** | Do **not** send the D-Mail that stops Okabe pursuing Suzuha | Okabe endlessly time-leaps to keep Mayuri alive, hollowing out emotionally; he and Suzuha travel to the past together to fight SERN | Terminal | Alternate ending (non-canon dead end) |
| **Mayuri Shiina** | Continue to the end **without** the Kurisu conversation flags | Okabe chooses Mayuri; returns to β where Kurisu's murder proceeds; he and Mayuri become lovers | Terminal | Alternate ending |
| **Makise Kurisu** | Have had **several conversations with Kurisu** through the game | Same road as the True End, but Kurisu's death is **not** prevented; Suzuha never returns; World War III is implied | Near-canon | Key route (pays into true-end logic) |
| **True End — "Steins;Gate"** | Kurisu flags + pass all heroine branches + complete the final operation | Reaches divergence **1.048596%**, the boundary worldline where no one is fated to die | Canon conclusion | **Key (the only canon ending)** |

**Cosmetic vs key, clarified:** the vast majority of individual Phone Trigger replies are **cosmetic** — they change a line of banter and nothing else. A small subset are **key**: the Kurisu conversations (cumulative flag), the answer/ignore decisions at scripted moments, and the "send / don't send" D-Mail gates. The four heroine endings are not "cosmetic" in the flag sense, but they are **narratively terminal** (dead ends relative to canon).

### 3.3 Key scenes (spoiler-level, with mechanics attached)

- **The opening at Radio Kaikan (28 Jul 2010).** Okabe finds Kurisu in a pool of blood, texts Daru, and the world "flickers" — Reading Steiner fires for the first time. The message arrives **one week in the past**: the PhoneWave is a time machine. This scene is *also the true ending's target*: the entire finale is built to make this exact moment happen without Kurisu dying.
- **Mayuri's death loop.** SERN's Rounders kill Mayuri. Okabe uses Kurisu's **Time Leap Machine** (memory → past, max 48h) to retry endlessly. The game teaches "worldline convergence": Mayuri dies *no matter what*, because she is a fixed point of the α attractor field. This is the mechanical heart of the middle act.
- **The D-Mail reversions (the branch gates).** To recover the lost IBN 5100 and hack SERN, Okabe must undo the changes the lab caused — Luka's sex change, Faris's altered Akihabara. Each reversion is a "send or refuse" gate (Section 3.2).
- **The truth about the first D-Mail.** Okabe realizes that deleting the evidence of his *original* D-Mail is what returns the world to β — a world where Kurisu is dead. Kurisu tells him to save Mayuri. He does.
- **The failed rescue and the self-inflicted murder.** Suzuha takes Okabe to the past to save Kurisu; he attacks her father and **accidentally kills Kurisu himself**, then screams — the very scream his past self will hear and run toward. Causality closes.
- **Operation Skuld / the true ending.** Future-Okabe's video message tells present-Okabe the solution: "**the one you must deceive is yourself** — your past self saw Kurisu bleeding and dead." The plan:
  1. Buy the **Metal Upa** *before* his past self does, so Mayuri gets the ordinary plush and the Metal Upa ends up in the data file with Nakabachi's stolen thesis (a metal detector will later find it in the fire).
  2. Hide in the room. Stun Kurisu with a **taser** so she collapses; use the **Cyalume Saber's fake blood** — but it has dried, so Okabe **lets Nakabachi wound him** and uses his *own* blood to form the pool around her.
  3. Cry out in pain so his past self, hunting the scream's source, sees the "corpse" — preserving history exactly.
  4. Destroy the thesis and return. The worldline settles at **1.048596%** — the Steins;Gate worldline, between α and β, untouched by convergence.
- **The reunion.** Okabe and Kurisu meet by chance in Akihabara; she seems to carry faint memories of everything (Reading Steiner bleeding through).

---

## 4. Story flags and variables

The game **secretly tracks decisions** in a hidden variable store. Nothing is shown as a number except the divergence meter; the rest is inferred by players and documented by guides.

Categories of tracked state:

1. **Call decisions** — a boolean per scripted call: *answered* / *ignored*. Ignoring is not neutral; some calls must be answered and some must be ignored.
2. **Mail replies** — which highlighted word was selected for each tracked message. Most are cosmetic; a defined subset accumulates into the **Kurisu flag** (the "several conversations with Kurisu" requirement for the Kurisu/True route).
3. **D-Mail reversion booleans** — `sent_luka_reversion`, `sent_faris_reversion`, `sent_suzuha_reversion`, etc. If a gate is refused, the route flag locks and the chapter ends in that heroine's ending.
4. **The Kurisu affection/conversation counter** — an implicit accumulator. Enough "correct" Kurisu interactions → Kurisu route instead of Mayuri route.
5. **The global divergence value** — the single displayed state variable. It is both narrative feedback and a soft progress indicator. Examples (see Appendix): β ≈ 1.13%, α = 0.x%, Steins;Gate = 1.048596%.
6. **Possession/status flags** — e.g., whether the lab has the **IBN 5100**, whether the PhoneWave exists, whether a given character knows the time-travel secret. These gate later scenes.
7. **Read/skip state** — standard VN "already-read text" tracking that enables Skip; functionally a per-line boolean array.

Crucially, **later scenes check these values** to decide what is available: the heroine branches check the reversion booleans; the final chapter checks the Kurisu flag; the true ending additionally checks that no heroine route was taken. The game never explains this, which is why reaching endings without a guide is genuinely hard (a point critics made about both S;G and S;G 0).

---

## 5. Relationship and affection systems

*Steins;Gate* has **no visible affection meter** — no hearts, no numbers, no "trust" bar. Relationships are modeled as **hidden flags** driven by the Phone Trigger and the route gates. The tracked axes:

| Relationship | Nature | How it moves |
|---|---|---|
| **Okabe ↔ Kurisu** | Tsundere romance; the canon pairing | Grows via the cumulative "conversations with Kurisu" flag. Determines Kurisu ending vs. Mayuri ending, and unlocks the true end. |
| **Okabe ↔ Mayuri** | Childhood friendship that can become romance | Default if Kurisu flags are absent; the Mayuri ending makes it explicitly romantic. Her survival is the fixed point that drives the whole plot. |
| **Okabe ↔ Luka** | Unrequited love (Luka loves Okabe); can become a couple | Luka route: if the reversion D-Mail is refused, they stay together (child in the epilogue). |
| **Okabe ↔ Faris** | Flirtatious; becomes marriage | Faris route: refusing the reversion makes them a couple and erases everyone's memories of Okabe. |
| **Okabe ↔ Suzuha** | Comrades-in-arms, not romance | Suzuha route: shared mission to stop SERN; both risk losing their memories. |
| **Okabe ↔ Daru** | Best friends / lab co-founders | Static trust; comic relief; Daru is the one who ultimately builds the time machine. |
| **Daru ↔ Suzuha** | Father and daughter (revealed) | Structural reveal, not a player-managed axis. |
| **Moeka ↔ FB (Mr. Braun)** | Fanatical loyalty to her handler | Contextualizes Moeka's betrayal; she is a Rounder under FB. |
| **Okabe ↔ Mr. Braun / Nae** | Landlord / neighbor | Nae's fear of Okabe; Braun's dual identity as FB. |

Because affection is folded into the **same flag layer** as branching, "relationship" and "route" are the same system in this game. Raising a heroine's flag *is* choosing her route. There are no separate rivalry, fear, or resentment stats — those are conveyed by writing, not mechanics.

---

## 6. Multiple endings

The game ships **6 endings**. Types as requested:

| # | Ending | Ending type | Canon? | Summary |
|---|---|---|---|---|
| 1 | **Luka Urushibara** | Character ending (bad/dead end) | No | Refuses the reversion D-Mail; accepts Mayuri's death; lives with Luka; child in the epilogue. |
| 2 | **Faris NyanNyan** | Character ending (bad/dead end) | No | Refuses the reversion; past-1% divergence; friends forget Okabe; couples with Faris; RaiNet tournaments. |
| 3 | **Suzuha Amane** | Character ending (bad/dead end) | No | Refuses the D-Mail; endless time-leaping erodes Okabe; he and Suzuha travel to the past to fight SERN. |
| 4 | **Shiina Mayuri** | Normal/character ending | No | No Kurisu flags; chooses Mayuri; returns to β where Kurisu dies; they become lovers. |
| 5 | **Makise Kurisu** | Character ending (bittersweet near-miss) | No | Kurisu flags present but the final operation is not completed; Kurisu's death is not prevented; WWIII implied. |
| 6 | **True End — "Steins;Gate"** | **True / final ending** | **Yes** | Operation Skuld succeeds; divergence reaches 1.048596%; both Mayuri and Kurisu live; Okabe and Kurisu reunite. |

**Failure states** map onto the alternate endings: relationship breakdown or a hollowed-out protagonist (Suzuha), an unresolved/erased world (Faris), or an unresolved mystery with an implied apocalypse (Kurisu/Mayuri). The game rewards completionism: the true end is **gated** behind the Kurisu flag and behind *not* committing to any heroine route.

*(For completeness: the follow-up* Steins;Gate 0 *uses a different topology — one early branch into two main paths plus side stories, with endings "Promised Rinascimento," "Vega and Altair," "Recursive Mother Goose," "Twin Automata," "Gehenna's Stigma," and the final "Milky-way Crossing," which is only unlocked after the first two.)*

---

## 7. Save and load

*Steins;Gate* ships the standard high-comfort visual-novel toolkit:

- **Multiple named save slots** (plus system/auto slots on most ports).
- **Quick save / quick load** for instant re-entry.
- **Backlog** — scroll back through recent text, including **voice replay** (click a line to hear it again).
- **Auto-advance** mode (hands-free reading) and **Skip** (fast-forward, with a "skip already-read text only" behavior).
- **Text-speed, volume, and display settings**.
- **Phone Trigger history** — received/sent mail and call log, so the player can inspect the choices they made (and see missed messages).
- **Tips / glossary** — an in-game encyclopedia of real-world science, net slang, and fictional terms. It is one of the most-praised usability features of the game and is explicitly called out in reviews.
- **Clear list / ending gallery** — tracks which endings the player has unlocked.

**Important caveat:** the original does **not** provide a branch flowchart or free chapter-select, because branching is done invisibly through the phone. To replay a different route you reload an earlier save (or restart), and you are expected to use your own memory of the worldlines — which the game deliberately mirrors with Okabe's Reading Steiner. Later editions/ports and *Steins;Gate Elite* add conveniences, but the core design is "save often, because the branch happened ten minutes ago and you didn't notice."

---

## 8. Inventory / items

There is **no player-managed inventory**. Items are narrative MacGuffins whose acquisition and loss are scripted, and several are *state flags* in disguise (possessing the IBN 5100 gates the SERN hack; possessing the Metal Upa gates the true ending). The item layer exists to make the time-travel logic legible.

### 8.1 Key items (narrative MacGuffins)

| Item | What it is | Mechanical role |
|---|---|---|
| **D-Mail (Dメール)** | A text message sent to the past via the PhoneWave | The fundamental time-travel unit; each one rewrites history and shifts the worldline. Only a few characters fit. Sending one can erase its own send history. |
| **IBN 5100** | A legendary 1975 retro computer (real-world IBM 5100; $20,000 list) | The **key item** of the mid-game: SERN's old systems are compatible only with it, so it is required to hack SERN. Its loss (via Faris's D-Mail) drives the reversion subplot. |
| **Phone Microwave (name subject to change)** — Future Gadget #8 | A microwave remotely operated by mobile phone | The time machine itself. Sends D-Mails; upgraded to the Time Leap Machine. |
| **Time Leap Machine** | PhoneWave + EEG scanner | Sends **memory** (not matter) up to **48 hours** into the past, overwriting the past self's brain. The tool of the Mayuri death-loop. (Later/improved versions: 234 hours in the film; two weeks in S;G 0.) |
| **Divergence Meter** | Nixie-tube device built from John Titor's described principles | Measures and displays the worldline divergence value — the game's single visible state variable. |
| **Metal Upa** | Rare **metal** version of the lab's mascot plush | The true-ending key: bought early so Mayuri gets the normal plush; the Metal Upa ends up in the file with Nakabachi's stolen thesis and lets the future locate/destroy it. |
| **Upa (うーぱ)** | Round-eared mascot of the card game *RaiNet Kakeru*; a virtual pet in-universe, secretly a "monster program" | Mayuri's obsession; rare Upa goods are expensive. Source of the Metal Upa plot. |
| **Cyalume Saber** — Future Gadget #6 | Glowstick sword equipped with **fake blood** | The fake blood is used in Operation Skuld (and has dried, forcing Okabe to use real blood). |
| **Taser / stun gun** | Non-lethal stun device | Used to make Kurisu collapse and appear dead in the true ending. |
| **Nakabachi's thesis / time-travel document** | Kurisu's stolen research, published by her father | The object whose survival causes World War III; destroying it (with the Metal Upa in the file) is the true ending's objective. |
| **Suzuha's time machine** (FG204 / C204 / C203) | A true physical time machine | Carries bodies and objects, unlike D-Mail/Time Leap; used for the final operations. |

### 8.2 Future Gadgets (the lab's "inventory" of inventions)

The Future Gadget Lab numbers its inventions; most are useless, one is a time machine. This list doubles as the game's collectible lore:

| No. | Name | Function |
|---|---|---|
| 1 | Bit Particle Cannon | Toy ray gun fused with a TV remote |
| 2 | Takekopukamera | Bamboo-copter with a miniature camera in the shaft |
| 3 | "Could it be Ora Ora!?" | Lie detector (sweat sensor); sold as the LE physical toy |
| 4 | Moad Snake | Instant humidifier shaped like a Claymore mine |
| 5 | "I went and connected something useless again, by Goemon" | Hair dryer powered by vacuum-cleaner exhaust heat |
| 6 | Cyalume Saber | Glowstick sword, equipped with fake blood |
| 7 | Ghost-in-the-Shell Camouflage Ball | 12 CRT TVs in a sphere — pseudo-optical camouflage |
| 8 | **Phone Microwave (name subject to change)** | Phone-remote microwave → **time machine** |
| 9 | "Return of the Tear-Soaked Goddess" | Vinyl umbrella with GPS |
| 10 | Bikkuri Megane-chan | 3D-glasses-style video device |
| 11 | "Baro's Thing" | Cola-carbonation-powered skateboard |
| 12 | "Darling no baka" | Wristwatch lie detector (appears in the δ / 3% worldline) |
| 13 | (unnamed) | Headphone-type brain-measurement device |
| 14 | Radio-Wave Jammer | Antenna-equipped HDD that jams analog signals |

*(In the sequel, the inventory gains the **Amadeus** AI system and **Kurisu's hard drive** — the S;G 0 MacGuffins.)*

---

## Appendix A — Worldlines and divergence values (the state variable)

Divergence is the world's "difference" from a reference worldline (0.000000%). Attractor fields are ~1% wide bands of worldlines that converge on the same macro-fate.

| Worldline / field | Divergence | Fate |
|---|---|---|
| **α (Alpha)** | 0.x% (e.g., **0.571046%**) | Kurisu lives; **Mayuri dies**; SERN dystopia by 2034. Main story's middle act. |
| **β (Beta)** | ~1% (e.g., **1.130205%**) | **Kurisu dies**; World War III ~2025. The game's **opening** worldline; S;G 0's setting. |
| **γ (Gamma)** | 2.x% (e.g., **2.615074%**) | Drama-CD worldline. |
| **δ (Delta)** | 3.x% | Setting of the fandisc *My Darling's Embrace*. |
| **Ω (Omega)** | **negative** 0.x% | **Faris ending** worldline; everyone but Faris forgets Okabe; no PhoneWave. |
| **Steins;Gate** | **1.048596%** | Boundary between α and β; immune to convergence; **true ending**. Both Mayuri and Kurisu live. |
| (movie) | 1.048595% | A stagnant, depopulated worldline visited in the film. |
| (Phenogram) | 4.456441% | Mayuri goes missing; Okabe owes ¥3,000,000. |

Design takeaway: the divergence number is the game's **only always-visible game state**. It is simultaneously a mood meter, a progress bar, and a puzzle solution.

---

## Appendix B — What a designer should steal from *Steins;Gate*

1. **Shrink the input.** One system (Phone Trigger) with two verbs (answer/ignore; pick reply). No menus, no stats. Depth comes from consequence, not complexity.
2. **Make the branch invisible, then make the replay diegetic.** Reading Steiner turns "new game+" into a plot point: the player's meta-memory and the protagonist's power are the same thing.
3. **Gate the true ending behind restraint.** You reach the best ending by *refusing* every heroine route — a strong, counterintuitive completion loop.
4. **Give the hidden flag layer exactly one public face** (the divergence meter) so the player always has a signal without seeing the machinery.
5. **Reuse your MacGuffins causally.** The fake-blood saber, the Metal Upa, the scream, the thesis all pay off in the finale — items are not decoration, they are the solution.

---

## Sources

- English Wikipedia, *Steins;Gate* (gameplay, characters, plot, True End and alternate endings, production).
- English Wikipedia, *Steins;Gate 0* (gameplay/RINE, branching, endings, worldline concepts).
- Japanese Wikipedia, *STEINS;GATE* (game system: 6 endings, Phone Trigger, heroine chapters, flag-gated final chapter; Lab Member table; Future Gadget list).
- Japanese Wikipedia, *STEINS;GATEの用語一覧* (D-Mail, Time Leap, Divergence Meter, Reading Steiner, IBN 5100, attractor fields, worldline list, Upa, RaiNet Access Battlers).
- Russian Wikipedia, *Steins;Gate* (episode/route synopses confirming the Metal Upa's role, the Cyalume-Saber fake blood, and the true-ending operation).
- VNDB entry v2002 (developer, playtime, release history).

*Report compiled 2026-09-22.*
