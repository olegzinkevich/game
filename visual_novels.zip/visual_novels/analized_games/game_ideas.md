# 7 New Visual Novel Concepts

Built from the mechanics extracted across the deep-dive reports in this folder (999, Steins;Gate, Fate/stay night, Clannad, White Album 2, VA-11 Hall-A, Slay the Princess, DDLC). Each concept borrows specific, proven systems and repackages them in a fresh premise. Ranked by projected engagement and interest.

> Rating scale: **9–10** breakout / high viral potential, **7–8** strong genre hit, **5–6** solid niche title.

---

## 1. "Last Frequency" — *cozy-radio thriller* — Rating: 9.5

**Hook:** You are the night-shift host of a pirate radio station in a small city that is quietly falling apart. Every night the transmitter flickers to life and the calls come in. You cannot leave the booth. You cannot call anyone. The only thing you can do is **decide what to say on air, and whose call to take next.**

**Core mechanic (the verb):** *the broadcast.* A direct descendant of VA-11 Hall-A's drink loop — one input channel, everything flows through it. Each night you field 3–5 callers (a regular insomniac, a trucker, a cop, a kid, a whistleblower who has been trying to reach you for weeks). Before each break you pick from a small set of responses: **comfort, probe, dismiss, lie on air, cut the feed, or play a song instead.** Your words shape what callers reveal, who trusts you, and what rumors spread across the city between shifts.

**Mechanics borrowed:**
- **One verb = the whole game** (VA-11 Hall-A): like "wrong drink is often right," here "saying less" or "playing the right song" is frequently the correct move.
- **Rumor as a state variable:** the city has a hidden "panic" counter that your broadcasts nudge. This is the Steins;Gate divergence meter's tonal cousin — one visible public gauge (the station's listener count / the mayor's approval index) that quietly reflects your hidden flags.
- **Cozy-to-dark pivot** (VA-11 Hall-A / DDLC): the first half is warm slice-of-life calls; the midpoint reveals a real conspiracy the station has been implicated in, and the same callers you comforted become witnesses, victims, or liars.

**Structure:** linear spine (19 shifts over one winter) with per-caller epilogue branches, plus a true ending gated behind paying attention to one particular caller's throwaway remark — a "flag disguised as flavor" lifted straight from 999.

**Why it will engage:** radio-as-intimacy is underexplored, the "you only have your voice" constraint is both cozy and tense, and the single-verb design makes it accessible while the rumor state gives theory-crafters something to dig into.

---

## 2. "The Wake" — *grief-mystery, one night* — Rating: 9.0

**Hook:** A person died under unclear circumstances. You are the last person who saw them alive. Tonight is the wake, in a single house, with a fixed cast of mourners. By dawn the truth of how they died will be decided — and it is **your responses to grief that decide which version becomes real.**

**Core mechanic (the verb):** *how you answer grief.* During the night you circulate and, at each guest, choose between **console, confront, deflect, confess, or stay silent.** There is no combat, no inventory, no stat screen — only the weight of what you say to people who are breaking.

**Mechanics borrowed:**
- **Reframe-don't-repeat** (Fate/stay night): the same death is re-examined across the night, and each guest's testimony reframes it into a different genre — accident, suicide, murder, mercy, sacrifice.
- **The trap choice** (White Album 2): the emotionally comfortable option (deflect, soothe, protect) reliably produces the worse ending; the honest, painful option unlocks truth.
- **Hidden affection = hidden suspicion:** the game tracks neither "like" nor "trust" but a hidden **suspicion** counter per guest. Later confrontations check it (who believes you, who turns on you).
- **No save-scumming, loop as load** (Slay the Princess): a single night, autosave only, and you cannot un-choose.

**Structure:** one common trunk → five "testimony" branches → six endings (a true "what actually happened" ending locked behind hearing every guest's full story — the Clannad breadth gate in miniature).

**Why it will engage:** maximum emotional torque with minimal art budget (one house, ~8 sprites), a locked-room whodunit with a genuinely human core, and huge replay appeal for a single-night story.

---

## 3. "Recut" — *meta film-editor thriller* — Rating: 8.5

**Hook:** You are the editor assembling the final cut of a documentary about a tragedy that was covered up. The footage is real (within the fiction), the crew is dead or vanished, and **every choice you make is an editing decision: what to keep, what to cut, whose voiceover to run, what to title the film.** The finished cut determines whose version of the truth the public sees.

**Core mechanic (the verb):** *the edit.* A timeline sits in the corner like a phone. Each scene offers a small set of "cuts": **keep the raw take, use the alternate angle, cut mid-sentence, add narration, splice two takes together.** The film is the game state.

**Mechanics borrowed:**
- **Choice as authorship, not just selection** (DDLC / Slay the Princess): you are literally assembling the object that carries the story, and the game asks whether you are telling the truth or building a story.
- **The medium is the mechanic** (DDLC): the "game" is the editing suite; the interface itself (timeline, cut list, render) is the fiction. Late-game, footage begins to change under your hands — the game questions whether *you* edited it or whether something is editing *you*.
- **Hidden lie in the UI** (999): frame numbers, timestamps, and a "continuity" meter quietly lie; the player must distrust the tool they're holding.
- **Reframe the same events** (Fate/stay night): identical raw footage yields radically different films depending on the cut.

**Structure:** fixed footage corpus (a dozen scenes), a huge combinatorial edit space, and a small number of "screenable cuts" as endings — each a coherent, very different truth, one of which is the true one.

**Why it will engage:** fresh meta-hook with genuine player authorship, strong visual identity (the editing UI *is* the art), and built-in discourse bait: players will argue about "the real cut."

---

## 4. "The Diviner" — *oracle, perception-as-power* — Rating: 8.0

**Hook:** You are a fortune-teller in a crumbling port city. Your readings are never wrong — because **what you tell a client becomes true.** The cards are a lever on the future, and everyone who sits at your table wants you to steer their life somewhere.

**Core mechanic (the verb):** *the reading.* Each client session presents a spread; you choose **what to say the cards mean.** There is no "correct" interpretation — your words set a hidden flag on that person, and days later the city's events reshape around it (a shop prospers or burns, a marriage holds or breaks, a ship sails or sinks).

**Mechanics borrowed:**
- **Perception as power** (Slay the Princess): the world literally becomes what you call it. The central horror/temptation is that you can never tell if you are predicting or causing.
- **Hidden consequence, delayed payoff** (Steins;Gate / Clannad): an innocuous reading pays off ten scenes later, with no marker on the choice.
- **The meta-progression is diegetic** (999 / Steins;Gate): every ending you have seen is a future your oracle-self has already glimpsed; the New Game+ screen is her seeing the other threads. "Reading Steiner" becomes "the sight."
- **A moral economy:** clients pay, and money is finite (VA-11 Hall-A's bills); the temptation to tell a rich client the future they *want* versus the one they *need* is the game's trap choice.

**Structure:** common hub (the shop) → client routes → a converging finale where all your accumulated readings collide into one night, with endings keyed to which futures you authored.

**Why it will engage:** a beloved fantasy (the oracle) rebuilt as a mechanic, strong moral-temptation loop, and a genuinely novel take on "choices matter" — your choices are *prophecies*.

---

## 5. "The Succession" — *regency court drama* — Rating: 7.5

**Hook:** The old king is dying without an heir, and you — a newly legitimized bastard — are thrust into the court season that will decide the throne. Three rivals, one season, and the same events told three times from different angles.

**Core mechanic (the verb):** *classic choice-menu flag-and-affection,* but with the strongest structural idea from Fate/stay night: **sequential route gating where each route reframes the same season into a different genre.**

**Mechanics borrowed:**
- **Three routes = three genres** (Fate/stay night): Romance (courtly love and loyalty) → Political thriller (alliances, espionage, betrayal) → Horror (the dynasty's buried secret). Each locked behind the previous, so the reframe lands as revelation, not option.
- **Hidden affection counters** (Fate/Clannad): trust, fear, and suspicion are all tracked invisibly; a "fear" counter is the rare inversion of the genre's usual affection-only model.
- **Items as branch flags** (Fate/stay night): a signet ring, a sealed letter, a vial of poison — each is not loot but an irreversible decision dressed as an object.
- **Tiger-Dojo-style bad ends** (Fate): a comedic "gossip court" recap after each death that hints, vaguely, what flag you missed.

**Structure:** one shared season → three sequential routes → five endings + a true ending that only resolves when the player has lived all three versions of the season.

**Why it will engage:** court-intrigue VNs are underserved in the West, the "three genres, one season" gimmick gives it a strong pitch, and it targets the large audience that already loves *Fate*-style route economies.

---

## 6. "The Caretaker" — *hospice, kindness-as-progression* — Rating: 7.0

**Hook:** You are the night caretaker at a hospice at the end of a long, strange road. Patients arrive with unfinished business — a letter unsent, a name forgotten, a grudge, a recipe. You have one season to help as many of them find peace as you can. **The peace you give does not disappear: it is stored, and it is spent.**

**Core mechanic (the verb):** *the final wish.* Clannad's Light Orb system rebuilt as the entire game: every resolved wish becomes a **"ember"** written to global system data, surviving any restart.

**Mechanics borrowed:**
- **Kindness converted to saved data** (Clannad): the embers are the moral thesis made literal — progression *is* compassion, and it persists outside the save file.
- **Gate the ending behind breadth** (Clannad): the true ending (one patient's miracle) is unlocked only by holding every ember, forcing the player to care for every patient, not just the one they liked.
- **The emotionally comfortable option is wrong** (White Album 2): the gentle lie ("it'll be okay") often blocks the wish; the hard truth unlocks it.
- **One disappearing ember** (Clannad): a single ember vanishes mid-game and returns at the end — the wordless "you are not finished" signal.

**Structure:** common season → per-patient mini-routes (mostly not romantic — a deliberate break from genre default) → a finale where the embers are spent in one act.

**Why it will engage:** a proven-tearjerker formula (this is the Clannad/Key audience) with a fresher, non-school setting, and a completionist loop that doubles as the theme.

---

## 7. "The Third Wheel" — *matchmaker comedy, inverted dating sim* — Rating: 6.5

**Hook:** You are not the romantic lead. You are the friend everyone dumps their love life on. A wedding is coming, the seating chart is a battlefield, and **everyone else's affection is the resource you manage.**

**Core mechanic (the verb):** *the advice.* You never date anyone. Instead you listen, and at each juncture choose **what to tell one friend about another** — push them together, keep them apart, tell the truth, or gossip. The **affection counters belong to NPCs, not you.**

**Mechanics borrowed:**
- **Inverted affection system** (VA-11 Hall-A / Fate, subverted): you raise and lower hidden affection between *other* characters. Your "route" is a couple you assemble, and the endings are which pairings survive to the wedding.
- **Remember-the-drink intimacy** (VA-11 Hall-A): the mechanic for success is *remembering what people told you* — a detail dropped three scenes ago is the key to the right advice now.
- **Trap choices as comedy** (White Album 2): the obvious, satisfying advice ("just tell them!") reliably explodes; the ending rewards the restraint of *not* meddling when you shouldn't.
- **A gossip economy** (VA-11 Hall-A bills): information is a resource you spend, and being caught gossiping degrades the trust the others place in you.

**Structure:** common pre-wedding season → multiple pairing permutations → endings keyed to which couples (and which friendships) survive, plus a "chaos" ending where everything you touched collapses.

**Why it will engage:** a genuinely fresh, low-stakes, high-charm angle on a saturated genre; ideal for a shorter comedy title and for streamer-friendly "messy run" replayability.

---

## How the ranking was decided

| Rank | Title | Core draw | Primary mechanic borrowed |
|---|---|---|---|
| 1 | Last Frequency | Cozy-to-dark, one powerful verb | VA-11 Hall-A drink loop + rumor state |
| 2 | The Wake | Emotional locked-room mystery | Fate reframe + White Album trap choices |
| 3 | Recut | Meta authorship, "the real cut" | DDLC medium-as-mechanic |
| 4 | The Diviner | Perception-as-power, moral temptation | Slay the Princess + Steins;Gate |
| 5 | The Succession | Court intrigue, three genres | Fate/stay night route gating |
| 6 | The Caretaker | Kindness-as-progression tearjerker | Clannad Light Orbs |
| 7 | The Third Wheel | Inverted dating sim comedy | VA-11 Hall-A attention-as-intimacy |

The top three rank highest because they combine a **single, memorable, streamable verb** with strong replayability and a clear marketing hook. The bottom two are excellent formulas but lean on an existing audience (Key-style tearjerkers; dating-sim comedies) rather than opening a new one.

---

# Part 2 — Positive / Wholesome Variants

Same proven mechanics, same engagement potential — but the stakes are warmth, connection and joy instead of grief, betrayal and death. Nobody dies, nobody is punished for caring, and every true ending is a happy one. Ranked by projected engagement.

---

## 8. "The Perfect Day" — *wholesome time-loop festival* — Rating: 9.5

**Hook:** You are a teen who has just moved to a small town on the eve of its biggest annual festival. You wake on festival morning… and when the day ends, it starts again. Nothing bad happens — the loop is not a trap, it is a **second chance engine.** Your goal is to make this one day the best it can possibly be for everyone in town, all at once.

**Core mechanic (the verb):** *the schedule.* Each run of the day you choose **where to be and who to help** — fix the banner, find the lost dog, calm the nervous performer, reunite two old friends, buy the last ingredient for the baker. You cannot do everything in one pass; the loop is the puzzle.

**Mechanics borrowed:**
- **Loop as save/load, diegetic** (Steins;Gate / Slay the Princess): "replay" is literally the protagonist re-living the day; the player's meta-memory and the character's memory are the same thing.
- **Kindness converted to persistent data** (Clannad Light Orbs): every person you help deposits a **"moment"** (a small memory gem) into system data. These survive every loop and every restart.
- **The true ending gates behind breadth** (Clannad): the "perfect day" finale — where the whole town converges in one flawless evening — unlocks only when you have collected **every** moment, i.e. helped *everyone*, not just your favorite person.
- **Hidden schedule conflicts** (999): some moments are mutually exclusive within one day, and discovering the optimal route is the completionist puzzle.

**Structure:** one looping day → ~12 character threads → many "good" single-thread endings (each a warm snapshot of that person's perfect day) → one **true "Perfect Day"** ending where all threads reconcile simultaneously.

**Why it will engage:** the time-loop genre is a proven dopamine machine, but almost always used for horror or tragedy — a *wholesome* loop is genuinely fresh. It keeps all the replay hooks and gives players a reason to cry for joy instead of grief.

---

## 9. "Bloom & Brew" — *botanical café, plant-as-advice* — Rating: 8.5

**Hook:** You inherit a tiny plant-and-tea café on a quiet corner. Every customer who walks in carries a problem they can't quite say aloud. Your counter holds a shelf of plants and herbs — and **the plant (or tea) you choose for them is the advice you give.** Nobody here is dying; everybody is simply trying to grow.

**Core mechanic (the verb):** *the plant.* A one-to-one rebuild of VA-11 Hall-A's drink loop, but inverted from "loosen tongues with alcohol" to "nurture with the right living thing." Each order is explicit ("something for my desk"), vague ("something that won't die"), or a riddle ("something that blooms in the dark"). The plant you pick — a forgiving succulent, a fussy orchid, a sprig of rosemary, a determined cactus — steers the conversation and their life afterward.

**Mechanics borrowed:**
- **One verb = the whole choice system** (VA-11 Hall-A): remember a regular's plant and serve the one they *need* (not the one they asked for) and their arc opens; give the wrong one and they just smile and go.
- **The wrong choice is often right** (VA-11 Hall-A): a regular asks for the flashy orchid but actually needs the low, stubborn mint — and giving them the "lesser" plant is the correct, more loving move.
- **A nurturing economy, not a debt one:** instead of punishing bills, the shop slowly grows — customers' plants are visible behind them in later visits, a gentle, wordless progress bar for the whole town.
- **Remembering = intimacy** (VA-11 Hall-A): the game's affection system is literally "you remembered their plant."

**Structure:** a season of days at the counter → per-customer epilogues (a gallery of "how they grew") → a golden ending where every regular is thriving and the café throws a garden party.

**Why it will engage:** cozy games are booming, and this is the rare cozy game with a *real* mechanical core (a gentle logic puzzle in plant language) rather than a decoration loop. Instant comfort-play + streamer appeal.

---

## 10. "The Bookmender" — *library, the right book at the right time* — Rating: 8.0

**Hook:** You are the town's new librarian and book-repairer. Patrons arrive with borrowed lives — a wedding, a new baby, a move, a quiet loneliness — and they ask for a book. **The book you hand them is the choice you make**, and a mended book is a mended person.

**Core mechanic (the verb):** *the book.* Descended from VA-11 Hall-A but keyed to reading: you read a patron's mood (their stated request vs. their real need) and select from a shelf of hand-mended titles — an adventure, a cookbook, a collection of letters, a book with a name written inside it. Some patrons even bring in a *damaged* book they want repaired, and **how you repair it** (keep its history, erase the annotation, replace the cover) becomes a moral choice.

**Mechanics borrowed:**
- **Wrong book = wrong advice, but right is often counterintuitive** (VA-11 Hall-A): a heartbroken regular asks for a romance and needs a mystery; giving the "wrong" book is the loving answer.
- **Items as branch flags** (Fate/stay night): a book with an inscription is not loot — it is a decision you make about whose past to preserve or overwrite.
- **Hidden "reader" state** (Steins;Gate flags): each patron has hidden counters for what they've borrowed and whether they returned it; later scenes check them.
- **A gallery as the reward** (Clannad): the "card catalog" fills with each patron's story, and completion unlocks the true ending — the library's centennial, where every life you touched shows up.

**Structure:** a season behind the desk → patron routes → a true ending where the whole town gathers for a reading, every shelf full and every patron present.

**Why it will engage:** libraries are beloved and underserved; the "prescribe the right book" fantasy is universal; and the book-repair choice adds a rare, tactile moral dimension that readers (the exact target audience) will adore.

---

## 11. "Starfall Inn" — *cozy fantasy, wearied travelers* — Rating: 7.5

**Hook:** You keep an inn at the edge of the known world, where the road runs out and the stars fall. The guests who arrive are tired heroes, homesick wizards, and ordinary people who have walked too far. **You cannot solve their quests — you can only give them a good night's rest, a warm meal, and the right room** — and that, the game argues, is the bravest thing anyone can give.

**Core mechanic (the verb):** *the welcome.* Each evening you assign guests to rooms, cook the evening meal, and sit with whoever needs company — choosing **what to serve, which room to give, and what to say across the hearth.** The inn itself remembers kindness, and the rooms you tend grow warmer (literally and mechanically) the more care you put in.

**Mechanics borrowed:**
- **Resource-as-kindness** (VA-11 Hall-A money, inverted): your limited resources — firewood, ingredients, rooms, time — must be distributed among guests, and the game rewards generosity, not hoarding.
- **Hidden wish-counters** (Clannad orbs): each guest's unspoken need, once met, becomes a **"star"** in the sky over the inn — the global, persistent meta-progress.
- **The true ending gates behind breadth** (Clannad): the finale — a night when every star the inn ever earned falls at once, and the whole cast returns — unlocks only when every guest has been truly helped.
- **No combat, no death** (VA-11 Hall-A): the whole point is that rest is the quest; the game deliberately refuses to let you "fix" the heroes' battles, only their hearts.

**Structure:** seasons at the inn → guest arcs → a golden "night of falling stars" true ending.

**Why it will engage:** cozy fantasy (the *Legends & Lattes* / *A Short Hike* audience) with a built-in tearjerker ending and a strong, quietly subversive thesis — that care, not power, is heroism.

---

## 12. "Five Summers" — *homecoming, rekindled friendship* — Rating: 7.5

**Hook:** You left your hometown years ago and drifted from everyone. Now you return for one summer — and the game follows you and your four oldest friends across five summers, mending what drifted apart. **Nobody is in danger and no one dies; the only stakes are whether these five people stay in each other's lives.**

**Core mechanic (the verb):** *the choice to show up.* A classic choice-menu flag-and-affection VN, but the "route" system is reframed: instead of choosing one romance, you are choosing **which friendship to repair this summer**, and the true ending is not "you end up with X" but "all five of you, together again."

**Mechanics borrowed:**
- **Sequential route gating** (Fate/stay night): each summer you focus on one friend; clearing one unlocks the next, and the knowledge you gain reframes the earlier summers on replay.
- **Hidden affection counters** (Clannad / Fate): trust and warmth are tracked invisibly; a careless word lowers them, but — crucially — **they can always be raised back.** The game refuses permanent damage.
- **The comfortable choice is wrong** (White Album 2, softened): the easy, avoidant response ("we'll catch up later") reliably worsens things; the honest, slightly awkward one rebuilds trust.
- **Kindness as global progression** (Clannad): the accumulated repaired friendships write to system data, and the fifth-summer true ending checks them all.

**Structure:** common reunion → five summer arcs → individual "renewed friendship" endings → a true ending where the friend group (and the families and partners you met along the way) gathers for one perfect reunion.

**Why it will engage:** a deeply relatable, all-ages premise with broad appeal beyond the usual VN audience, and the "friendship, not romance" frame is a refreshing, much-requested alternative to the genre's default.

---

## 13. "Camp Brightwater" — *summer camp, found family* — Rating: 7.0

**Hook:** You are a first-year counselor at a sleepaway summer camp. A dozen campers and a handful of fellow counselors arrive with their own quiet fears and hopes, and you have one season to help them all feel like they belong. **The camp has no villains and no danger — the only enemy is the end of summer.**

**Core mechanic (the verb):** *the plan.* Each day you schedule activities — archery, the lake, arts & crafts, the campfire — and choose **which camper to spend the day with, and what to say when they open up.** Your choices shape not just friendships but which fears a camper overcomes by season's end.

**Mechanics borrowed:**
- **Attention as the input** (Clannad / VA-11 Hall-A): who you spend time with is the entire game; there is no meter except presence.
- **Hidden needs, not affection** (Steins;Gate flags): each camper has a hidden worry (homesickness, a secret, a fear of the dark) that only surfaces if you are there at the right moment.
- **A persistent "campfire log"** (Clannad orbs): every breakthrough becomes a story added to the campfire log, a global cross-save record that unlocks the finale.
- **The true ending gates behind breadth** (Clannad): the final campfire — where every camper tells their story and the season is declared perfect — unlocks only if you reached everyone, not just your favorites.

**Structure:** a summer of days → camper arcs → individual "they found their people" endings → a true "last campfire" ending.

**Why it will engage:** found-family summer-camp stories are a beloved, evergreen genre (*The Parent Trap*, *Wet Hot American Summer*, *Camp Camp*) with strong nostalgic pull, and the format is perfectly sized for a warm, mid-length VN.

---

## 14. "The Garden's Promise" — *orchard, harvest as progression* — Rating: 6.5

**Hook:** You inherit a neglected orchard and the house beside it. Across a year of seasons you tend the trees, and — because the orchard is a strange and generous place — **every kindness you do in the village makes a tree bear fruit.** The harvest is literally your accumulated good deeds.

**Core mechanic (the verb):** *the tending.* A gentle hybrid: you plan what to plant and tend each season, and between seasons you visit the village and choose **who to help** — a neighbor's roof, a child's garden, a shopkeeper's ailing mother. The orchard responds.

**Mechanics borrowed:**
- **Kindness converted to a visible, persistent resource** (Clannad Light Orbs, made tangible): each good deed becomes a fruit on a tree, and the orchard is a living progress bar you can walk through.
- **Meta-progression out of the save file** (Clannad): the harvest is stored globally and survives restarts, so "replay" feels like the seasons continuing, not erasing.
- **The true ending gates behind breadth** (Clannad): the harvest festival finale — where the whole village eats the fruit of your year — unlocks only when every tree has borne fruit, i.e. every neighbor has been helped.
- **Seasons as reframing** (Fate/stay night): the same village is revisited in spring, summer, autumn and winter, each pass revealing more of the neighbors' lives.

**Structure:** a year of seasons → village vignettes → a true "harvest festival" ending.

**Why it will engage:** the farming-sim audience is enormous (*Stardew Valley*), and this is that fantasy distilled into a narrative with an actual thematic payoff — your kindness is the harvest. Slightly lower rank only because its pacing is quieter than the top entries.

---

## Positive-set ranking rationale

| Rank | Title | Core draw | Primary mechanic borrowed |
|---|---|---|---|
| 8 | The Perfect Day | Wholesome time loop, second chances | Steins;Gate loop + Clannad orbs |
| 9 | Bloom & Brew | Plant-as-advice cozy puzzle | VA-11 Hall-A drink loop |
| 10 | The Bookmender | The right book at the right time | VA-11 Hall-A + Fate item-flags |
| 11 | Starfall Inn | Care as heroism, cozy fantasy | Clannad orbs + VA-11 economy |
| 12 | Five Summers | Friendship over romance, homecoming | Fate gating + Clannad affection |
| 13 | Camp Brightwater | Found family, summer nostalgia | Clannad breadth-gate |
| 14 | The Garden's Promise | Kindness as a visible harvest | Clannad orbs made tangible |

The common thread: every one of these **keeps a real mechanical spine** (a loop, a puzzle-verb, hidden flags, a persistent kindness currency) and simply redirects it from loss to warmth. Engagement survives because the replay hooks, the completionist reward, and the "one more run" loop are all intact — the *stakes* changed, not the *systems.*
