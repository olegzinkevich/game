/*
 * game-scene.js — The Phaser 3 scene that runs Inverted Tetris.
 *
 * Owns the game state (grid, active piece, score/level/lines), the inverted
 * game loop (figures rise from the bottom), all input handling, and rendering
 * of the playfield via the Graphics API. HUD numbers, previews, overlays and
 * touch buttons live in the DOM (see index.html / main.js); the scene talks to
 * them through this.game.events.
 */
(function (global) {
  'use strict';

  const P = global.IT_Pieces;
  const B = global.IT_Board;
  const A = global.IT_Audio;

  const FIELD_W = P.FIELD_W;
  const FIELD_H = P.FIELD_H;

  // Tunables.
  const SOFT_INTERVAL = 40;     // ms per cell while soft rising
  const LOCK_DELAY = 500;       // bounded lock delay (req. 3.6.9)
  const MAX_LOCK_RESETS = 15;   // prevents indefinite stalling
  const DAS = 160;              // delayed auto shift (ms before repeat)
  const ARR = 40;               // auto repeat rate (ms between repeats)
  const DELTA_CLAMP = 100;      // avoid tick avalanche after tab refocus (req. 8.6)
  const LINE_SCORE = { 1: 100, 2: 300, 3: 500 }; // per-lock line clear base (req. 3.8)
  const HS_KEY = 'inverted_tetris_highscore';

  function hexToInt(hex) { return parseInt(hex.slice(1), 16); }
  function darken(intColor, f) {
    const r = Math.floor(((intColor >> 16) & 255) * f);
    const g = Math.floor(((intColor >> 8) & 255) * f);
    const b = Math.floor((intColor & 255) * f);
    return (r << 16) | (g << 8) | b;
  }

  // Pre-compute int colours for the renderer.
  const COLOR_INT = {};
  const COLOR_DARK = {};
  Object.keys(P.COLOR_BY_ID).forEach((id) => {
    COLOR_INT[id] = hexToInt(P.COLOR_BY_ID[id]);
    COLOR_DARK[id] = darken(COLOR_INT[id], 0.78);
  });

  class GameScene extends Phaser.Scene {
    constructor() { super({ key: 'game' }); }

    create() {
      this.audio = A;

      // --- state ---
      this.grid = B.createGrid();
      this.active = null;
      this.bag = new P.Bag();
      this.nextType = this.bag.next();
      this.holdType = null;
      this.holdUsed = false;
      this.score = 0;
      this.lines = 0;
      this.level = 1;
      this.high = this.loadHigh();
      this.status = 'menu'; // menu | playing | paused | clearing | gameover

      // --- loop accumulators ---
      this.riseAcc = 0;
      this.landed = false;
      this.lockTimer = 0;
      this.lockResets = 0;
      this.softHeld = false;
      this.touchSoft = false;

      // horizontal auto-repeat
      this.dasDir = 0;
      this.dasCharge = 0;
      this.arrAcc = 0;

      // clear animation
      this.clearingRows = null;
      this.clearFlashOn = false;

      this._hudDirty = false;
      this.reduceMotion = global.matchMedia &&
        global.matchMedia('(prefers-reduced-motion: reduce)').matches;

      // --- rendering ---
      this.gfx = this.add.graphics();
      this.onResize(this.scale.gameSize);
      this.scale.on('resize', this.onResize, this);

      // --- input: keyboard ---
      this.setupKeyboard();
      // --- input: touch swipes on the playfield ---
      this.setupPointer();

      // Make the rendered canvas itself accessible (req. 6.4).
      if (this.game.canvas) {
        this.game.canvas.setAttribute('role', 'img');
        this.game.canvas.setAttribute('aria-label',
          'Inverted Tetris playfield, 15 columns by 35 rows. Figures rise from the bottom.');
        this.game.canvas.setAttribute('tabindex', '0');
      }

      // expose for DOM wiring
      this.game.itScene = this;

      this.emitHud();
      this.emitPreview();
      this.emitState();
    }

    // ----------------------------------------------------------------- input
    setupKeyboard() {
      const KC = Phaser.Input.Keyboard.KeyCodes;
      const k = this.input.keyboard;
      // Prevent arrows/space from scrolling the page (req. 5.2.5).
      k.addCapture('UP,DOWN,LEFT,RIGHT,SPACE');
      this.keys = {
        left: k.addKey(KC.LEFT),
        right: k.addKey(KC.RIGHT),
        up: k.addKey(KC.UP),
        space: k.addKey(KC.SPACE),
        z: k.addKey(KC.Z),
        x: k.addKey(KC.X),
        ctrl: k.addKey(KC.CTRL),
        c: k.addKey(KC.C),
        shift: k.addKey(KC.SHIFT),
        esc: k.addKey(KC.ESC),
        p: k.addKey(KC.P),
        r: k.addKey(KC.R)
      };
    }

    setupPointer() {
      this._ptr = null;
      this.input.on('pointerdown', (p) => {
        this._ptr = { x: p.x, y: p.y, t: p.downTime || 0, moved: false };
      });
      this.input.on('pointerup', (p) => {
        if (!this._ptr || this.status !== 'playing') { this._ptr = null; return; }
        const dx = p.x - this._ptr.x;
        const dy = p.y - this._ptr.y;
        const cell = this.cell || 20;
        const adx = Math.abs(dx), ady = Math.abs(dy);
        if (adx < cell * 0.6 && ady < cell * 0.6) {
          this.rotate(1); // tap = rotate CW
        } else if (adx > ady) {
          const steps = Math.max(1, Math.round(adx / cell));
          for (let i = 0; i < steps; i++) this.move(dx > 0 ? 1 : -1);
        } else if (dy < 0) {
          const steps = Math.max(1, Math.round(ady / cell));
          for (let i = 0; i < steps; i++) this.tickRise();
        } else {
          this.hardRise(); // swipe down = hard rise
        }
        this._ptr = null;
      });
    }

    /** Public action API used by the on-screen touch buttons (main.js). */
    action(name) {
      switch (name) {
        case 'left': this.move(-1); break;
        case 'right': this.move(1); break;
        case 'cw': this.rotate(1); break;
        case 'ccw': this.rotate(-1); break;
        case 'soft': this.tickRise(); break;
        case 'hard': this.hardRise(); break;
        case 'hold': this.hold(); break;
      }
    }
    setTouchSoft(v) { this.touchSoft = !!v; }

    // ----------------------------------------------------------- lifecycle
    startGame() { this.restart(); }

    restart() {
      this.grid = B.createGrid();
      this.bag = new P.Bag();
      this.nextType = this.bag.next();
      this.holdType = null;
      this.holdUsed = false;
      this.score = 0;
      this.lines = 0;
      this.level = 1;
      this.riseAcc = 0;
      this.landed = false;
      this.lockTimer = 0;
      this.lockResets = 0;
      this.clearingRows = null;
      this.status = 'playing';
      this.spawnNext();
      this.emitHud();
      this.emitState();
      this.audio.resume();
      this.audio.start();
    }

    togglePause() {
      if (this.status === 'playing') {
        this.status = 'paused';
        this.emitState();
      } else if (this.status === 'paused') {
        this.status = 'playing';
        this.riseAcc = 0; // avoid burst on resume
        this.emitState();
      }
    }

    /** Auto-pause when the tab is backgrounded (req. 3.4.6 / 8.6). */
    autoPause() {
      if (this.status === 'playing') {
        this.status = 'paused';
        this.emitState();
      }
    }

    gameOver() {
      this.status = 'gameover';
      if (this.score > this.high) { this.high = this.score; this.saveHigh(); }
      this.audio.gameOver();
      this.emitHud();
      this.emitState();
    }

    spawnNext() {
      const type = this.nextType;
      this.nextType = this.bag.next();
      this.active = P.makePiece(type);
      this.holdUsed = false;
      this.landed = false;
      this.lockTimer = 0;
      this.lockResets = 0;
      this.riseAcc = 0;
      this.emitPreview();
      // Block-out: collides immediately at the bottom spawn area (req. 3.9.1).
      if (B.collides(this.active.cells, this.active.x, this.active.y, this.grid)) {
        this.gameOver();
      }
    }

    // --------------------------------------------------------------- actions
    move(dir) {
      if (this.status !== 'playing' || !this.active) return false;
      if (!B.collides(this.active.cells, this.active.x + dir, this.active.y, this.grid)) {
        this.active.x += dir;
        this.audio.move();
        this.onPieceMoved();
        return true;
      }
      return false;
    }

    rotate(dir) {
      if (this.status !== 'playing' || !this.active) return false;
      const rotated = P.rotateCells(this.active.cells, dir);
      // Wall-kick table appropriate for small (three-cell) figures (req. 3.6.6).
      const kicks = [
        [0, 0], [-1, 0], [1, 0], [0, -1], [0, 1],
        [-1, -1], [1, -1], [-1, 1], [1, 1], [-2, 0], [2, 0]
      ];
      for (let i = 0; i < kicks.length; i++) {
        const nx = this.active.x + kicks[i][0];
        const ny = this.active.y + kicks[i][1];
        if (!B.collides(rotated, nx, ny, this.grid)) {
          this.active.cells = rotated;
          this.active.x = nx;
          this.active.y = ny;
          this.audio.rotate();
          this.onPieceMoved();
          return true;
        }
      }
      return false; // no valid kick -> rotation rejected, state unchanged (req. 8.3)
    }

    /** One soft-rise step; awards 1 point per cell while soft rising (req. 3.8.5). */
    tickRise() {
      if (this.status !== 'playing' || !this.active) return;
      if (B.canRise(this.active, this.grid)) {
        this.active.y -= 1;
        this.landed = false;
        this.lockTimer = 0;
        if (this.softHeld || this.touchSoft) this.addScore(1);
      } else {
        this.landed = true;
      }
    }

    hardRise() {
      if (this.status !== 'playing' || !this.active) return;
      const ly = B.landingY(this.active, this.grid);
      const dist = this.active.y - ly;
      this.active.y = ly;
      if (dist > 0) this.addScore(dist * 2); // 2 points per cell (req. 3.8.5)
      this.lockPiece();
    }

    hold() {
      if (this.status !== 'playing' || !this.active || this.holdUsed) return;
      const cur = this.active.type;
      if (this.holdType === null) {
        this.holdType = cur;
        this.spawnNext();
      } else {
        const swap = this.holdType;
        this.holdType = cur;
        this.active = P.makePiece(swap);
        this.landed = false;
        this.lockTimer = 0;
        this.lockResets = 0;
        this.riseAcc = 0;
        if (B.collides(this.active.cells, this.active.x, this.active.y, this.grid)) {
          this.gameOver();
          return;
        }
      }
      this.holdUsed = true;
      this.audio.rotate();
      this.emitPreview();
    }

    onPieceMoved() {
      // While in lock delay, a successful move/rotate resets the timer (bounded).
      if (this.landed) {
        if (B.canRise(this.active, this.grid)) {
          this.landed = false;
          this.lockTimer = 0;
        } else if (this.lockResets < MAX_LOCK_RESETS) {
          this.lockTimer = 0;
          this.lockResets++;
        }
      }
    }

    lockPiece() {
      if (!this.active) return;
      B.lock(this.active, this.grid);
      this.audio.land();
      this.active = null;
      this.landed = false;
      this.lockTimer = 0;

      const rows = B.fullRows(this.grid);
      if (rows.length === 0) {
        this.spawnNext();
        return;
      }
      this.resolveClears(rows);
    }

    resolveClears(rows) {
      const count = Math.min(rows.length, 3); // at most three rows per lock (req. 3.7.4)
      this.addScore(LINE_SCORE[count] * this.level);
      this.lines += count;
      const newLevel = 1 + Math.floor(this.lines / P.LINES_PER_LEVEL);
      this.level = newLevel;
      this._hudDirty = true;

      if (count >= 3) this.audio.tripleClear(); else this.audio.clear();

      const set = new Set(rows);
      const finalize = () => {
        this.grid = B.clearRows(this.grid, set);
        this.clearingRows = null;
        this.status = 'playing';
        this.spawnNext();
      };

      if (this.reduceMotion) {
        finalize(); // no flashing for reduced-motion users (req. 6.5)
        return;
      }

      // Brief flash animation, then collapse (req. 5.5.4 / 3.11.2).
      this.status = 'clearing';
      this.clearingRows = set;
      this.clearFlashOn = true;
      let flashes = 0;
      this.time.addEvent({
        delay: 60, repeat: 3,
        callback: () => {
          this.clearFlashOn = !this.clearFlashOn;
          flashes++;
          if (flashes >= 4) finalize();
        }
      });
      if (count >= 3) this.cameras.main.shake(150, 0.004);
    }

    // ------------------------------------------------------------ main loop
    update(time, delta) {
      this.handleActionKeys();

      if (this.status === 'playing') {
        delta = Math.min(delta, DELTA_CLAMP);
        this.softHeld = this.keys.up.isDown;
        this.handleHorizontal(delta);

        const base = this.getInterval();
        const interval = (this.softHeld || this.touchSoft) ? Math.min(SOFT_INTERVAL, base) : base;
        this.riseAcc += delta;
        let guard = 0;
        while (this.riseAcc >= interval && this.status === 'playing' && guard++ < 64) {
          this.riseAcc -= interval;
          this.tickRise();
        }
        if (this.landed && this.status === 'playing') {
          this.lockTimer += delta;
          if (this.lockTimer >= LOCK_DELAY) this.lockPiece();
        }
      }

      if (this._hudDirty) { this.emitHud(); this._hudDirty = false; }
      this.draw(time);
    }

    handleActionKeys() {
      const JD = Phaser.Input.Keyboard.JustDown;
      const k = this.keys;
      if (!k) return;

      // Pause / restart work outside active play too.
      if (JD(k.esc) || JD(k.p)) this.togglePause();
      if (JD(k.r)) {
        if (this.status !== 'menu') this.restart();
      }
      if (this.status !== 'playing') return;

      if (JD(k.x) || JD(k.ctrl)) this.rotate(1);
      if (JD(k.z)) this.rotate(-1);
      if (JD(k.space)) this.hardRise();
      if (JD(k.c) || JD(k.shift)) this.hold();
      // A discrete Up press also nudges one cell up immediately.
      if (JD(k.up)) this.tickRise();
    }

    handleHorizontal(delta) {
      const k = this.keys;
      const dir = (k.right.isDown ? 1 : 0) - (k.left.isDown ? 1 : 0);
      if (dir === 0) { this.dasDir = 0; return; }
      if (dir !== this.dasDir) {
        this.dasDir = dir;
        this.dasCharge = 0;
        this.arrAcc = 0;
        this.move(dir); // immediate first move on press
      } else {
        this.dasCharge += delta;
        if (this.dasCharge >= DAS) {
          this.arrAcc += delta;
          let guard = 0;
          while (this.arrAcc >= ARR && guard++ < 32) {
            this.arrAcc -= ARR;
            this.move(dir);
          }
        }
      }
    }

    getInterval() {
      // Rise rate increases with level; clamped to the minimum (req. 3.8.4).
      return Math.max(P.MIN_INTERVAL, Math.floor(P.BASE_INTERVAL / this.level));
    }

    addScore(n) {
      this.score += n; // monotonic non-decreasing (req. 3.8.1)
      this._hudDirty = true;
    }

    // --------------------------------------------------------------- events
    emitHud() {
      this.game.events.emit('it-hud', {
        score: this.score, lines: this.lines, level: this.level, high: this.high
      });
    }
    emitPreview() {
      this.game.events.emit('it-preview', { next: this.nextType, hold: this.holdType });
    }
    emitState() {
      this.game.events.emit('it-state', { status: this.status, score: this.score, high: this.high });
    }

    // ------------------------------------------------------- persistence
    loadHigh() {
      try {
        const v = global.localStorage.getItem(HS_KEY);
        const n = parseInt(v, 10);
        return (isFinite(n) && n >= 0) ? n : 0; // validate / fall back (req. 8.7/8.8)
      } catch (e) { return 0; }
    }
    saveHigh() {
      try { global.localStorage.setItem(HS_KEY, String(this.high)); } catch (e) { /* ignore */ }
    }

    // ----------------------------------------------------------- rendering
    onResize(gameSize) {
      const w = gameSize.width, h = gameSize.height;
      this.cell = Math.max(4, Math.floor(Math.min(w / FIELD_W, h / FIELD_H)));
      this.fieldW = this.cell * FIELD_W;
      this.fieldH = this.cell * FIELD_H;
      this.offX = Math.floor((w - this.fieldW) / 2);
      this.offY = Math.floor((h - this.fieldH) / 2);
    }

    draw(time) {
      const g = this.gfx;
      const cell = this.cell, ox = this.offX, oy = this.offY;
      g.clear();

      // Playfield background + outer frame.
      g.fillStyle(0x0e1320, 1);
      g.fillRect(ox, oy, this.fieldW, this.fieldH);
      g.lineStyle(2, 0x39507a, 1);
      g.strokeRect(ox - 1, oy - 1, this.fieldW + 2, this.fieldH + 2);

      // Subtle grid lines.
      g.lineStyle(1, 0x1b2540, 0.7);
      for (let c = 1; c < FIELD_W; c++) {
        g.lineBetween(ox + c * cell, oy, ox + c * cell, oy + this.fieldH);
      }
      for (let r = 1; r < FIELD_H; r++) {
        g.lineBetween(ox, oy + r * cell, ox + this.fieldW, oy + r * cell);
      }

      // Locked cells (slightly darkened — req. 5.4).
      for (let r = 0; r < FIELD_H; r++) {
        for (let c = 0; c < FIELD_W; c++) {
          const id = this.grid[r][c];
          if (id !== 0) this.drawCell(g, c, r, COLOR_DARK[id], COLOR_INT[id], 1);
        }
      }

      // Clearing flash.
      if (this.status === 'clearing' && this.clearingRows && this.clearFlashOn) {
        g.fillStyle(0xffffff, 0.9);
        this.clearingRows.forEach((r) => g.fillRect(ox, oy + r * cell, this.fieldW, cell));
      }

      // Ghost (hard-rise landing) + active piece.
      if (this.active && (this.status === 'playing' || this.status === 'paused')) {
        const ly = B.landingY(this.active, this.grid);
        const ghostInt = COLOR_INT[this.active.colorId];
        for (let i = 0; i < this.active.cells.length; i++) {
          const c = this.active.x + this.active.cells[i][0];
          const r = ly + this.active.cells[i][1];
          this.drawGhost(g, c, r, ghostInt);
        }
        const pulse = this.reduceMotion ? 1 : (0.85 + 0.15 * Math.sin(time / 160));
        for (let i = 0; i < this.active.cells.length; i++) {
          const c = this.active.x + this.active.cells[i][0];
          const r = this.active.y + this.active.cells[i][1];
          this.drawCell(g, c, r, ghostInt, 0xffffff, pulse);
        }
      }
    }

    drawCell(g, c, r, fillInt, borderInt, alpha) {
      const cell = this.cell;
      const x = this.offX + c * cell;
      const y = this.offY + r * cell;
      g.fillStyle(fillInt, alpha);
      g.fillRect(x + 1, y + 1, cell - 2, cell - 2);
      g.lineStyle(Math.max(1, Math.floor(cell * 0.08)), borderInt, Math.min(1, alpha + 0.1));
      g.strokeRect(x + 1.5, y + 1.5, cell - 3, cell - 3);
    }

    drawGhost(g, c, r, borderInt) {
      const cell = this.cell;
      const x = this.offX + c * cell;
      const y = this.offY + r * cell;
      g.fillStyle(borderInt, 0.12);
      g.fillRect(x + 1, y + 1, cell - 2, cell - 2);
      g.lineStyle(1, borderInt, 0.8);
      g.strokeRect(x + 2, y + 2, cell - 4, cell - 4);
    }
  }

  global.IT_GameScene = GameScene;
})(window);
