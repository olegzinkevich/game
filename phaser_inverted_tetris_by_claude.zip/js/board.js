/*
 * board.js — Pure grid logic: collision, locking, and inverted line clearing.
 *
 * The board is a 2D array grid[row][col] (req. 3.10.2) sized FIELD_H x FIELD_W.
 * Each cell is 0 (empty) or a colorId 1..4. row 0 is the TOP, row FIELD_H-1 the
 * bottom. Gravity is INVERTED: figures rise (row decreases) and the stack grows
 * from the top downward.
 */
(function (global) {
  'use strict';

  const P = global.IT_Pieces;
  const FIELD_W = P.FIELD_W;
  const FIELD_H = P.FIELD_H;

  function createGrid(w, h) {
    w = w || FIELD_W;
    h = h || FIELD_H;
    const g = new Array(h);
    for (let r = 0; r < h; r++) g[r] = new Array(w).fill(0);
    return g;
  }

  /**
   * collision check (req. 3.10.3): a placement collides if any cell falls
   * outside the field (x < 0, x >= width, y < 0 at the top, y >= height at the
   * bottom) or overlaps a non-empty cell.
   */
  function collides(cells, x, y, grid) {
    for (let i = 0; i < cells.length; i++) {
      const gx = x + cells[i][0];
      const gy = y + cells[i][1];
      if (gx < 0 || gx >= FIELD_W || gy < 0 || gy >= FIELD_H) return true;
      if (grid[gy][gx] !== 0) return true;
    }
    return false;
  }

  /** Can the piece rise one row (move toward the top)? */
  function canRise(piece, grid) {
    return !collides(piece.cells, piece.x, piece.y - 1, grid);
  }

  /**
   * Topmost landing row for a hard rise / ghost: rise until the next step
   * would collide with the top wall or the underside of the stack.
   */
  function landingY(piece, grid) {
    let y = piece.y;
    while (!collides(piece.cells, piece.x, y - 1, grid)) y--;
    return y;
  }

  /** Write a piece's cells into the grid (locking). */
  function lock(piece, grid) {
    for (let i = 0; i < piece.cells.length; i++) {
      const gx = piece.x + piece.cells[i][0];
      const gy = piece.y + piece.cells[i][1];
      grid[gy][gx] = piece.colorId;
    }
  }

  /** Indices of fully filled rows (all FIELD_W cells non-empty) — req. 3.7 / 3.9. */
  function fullRows(grid) {
    const rows = [];
    for (let r = 0; r < FIELD_H; r++) {
      let full = true;
      for (let c = 0; c < FIELD_W; c++) {
        if (grid[r][c] === 0) { full = false; break; }
      }
      if (full) rows.push(r);
    }
    return rows;
  }

  /**
   * Remove the given rows and settle remaining rows UPWARD (req. 2.3 / 3.10.4).
   * Because gravity is inverted, surviving rows are packed toward the top,
   * preserving their order and any horizontal gaps (req. 3.7.5). Returns a new
   * grid. `clearSet` is a Set of row indices to remove.
   */
  function clearRows(grid, clearSet) {
    const next = createGrid();
    let writeRow = 0;
    for (let r = 0; r < FIELD_H; r++) {
      if (clearSet.has(r)) continue;       // dropped
      next[writeRow] = grid[r];            // keep, packed toward the top
      writeRow++;
    }
    // rows writeRow..FIELD_H-1 stay as the fresh empty rows from createGrid().
    return next;
  }

  global.IT_Board = { createGrid, collides, canRise, landingY, lock, fullRows, clearRows };
})(window);
