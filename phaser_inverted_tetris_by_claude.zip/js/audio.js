/*
 * audio.js — Tiny WebAudio synthesiser for UI/game feedback (req. 5.7).
 *
 * No asset files are loaded: every sound is generated on the fly. The whole
 * module degrades gracefully when WebAudio is unavailable or blocked
 * (req. 3.12.4). Audio must be unlocked by a user gesture, hence resume().
 */
(function (global) {
  'use strict';

  class AudioManager {
    constructor() {
      this.ctx = null;
      this.master = null;
      this.enabled = false;
      this.muted = false;
    }

    init() {
      try {
        const AC = global.AudioContext || global.webkitAudioContext;
        if (!AC) return; // no WebAudio -> silent, game stays playable
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.18;
        this.master.connect(this.ctx.destination);
        this.enabled = true;
      } catch (e) {
        this.enabled = false;
      }
    }

    /** Resume a suspended context after the first user gesture. */
    resume() {
      try {
        if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
      } catch (e) { /* ignore */ }
    }

    setMuted(m) { this.muted = !!m; }
    toggleMute() { this.muted = !this.muted; return this.muted; }

    _blip(freq, dur, type, vol, when) {
      if (!this.enabled || this.muted || !this.ctx) return;
      try {
        const t = (when || this.ctx.currentTime);
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type || 'square';
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, vol || 0.5), t + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        osc.connect(gain);
        gain.connect(this.master);
        osc.start(t);
        osc.stop(t + dur + 0.02);
      } catch (e) { /* ignore individual sound failures */ }
    }

    _chord(freqs, dur, type, vol) {
      if (!this.enabled || !this.ctx) return;
      const t = this.ctx.currentTime;
      freqs.forEach((f, i) => this._blip(f, dur, type || 'triangle', (vol || 0.5), t + i * 0.04));
    }

    // Short "click" for movement / rotation.
    move() { this._blip(220, 0.05, 'square', 0.35); }
    rotate() { this._blip(330, 0.05, 'square', 0.4); }
    // Soft landing thud when a figure freezes.
    land() { this._blip(150, 0.12, 'sine', 0.6); }
    // Pleasant chime for a normal line clear.
    clear() { this._chord([523, 659, 784], 0.2, 'triangle', 0.5); }
    // Brighter sound for the maximum (three-line) clear.
    tripleClear() { this._chord([659, 880, 1175, 1568], 0.3, 'triangle', 0.55); }
    // Low signal for game over.
    gameOver() {
      if (!this.enabled || !this.ctx) return;
      const t = this.ctx.currentTime;
      this._blip(196, 0.25, 'sawtooth', 0.5, t);
      this._blip(147, 0.35, 'sawtooth', 0.5, t + 0.2);
      this._blip(98, 0.6, 'sawtooth', 0.5, t + 0.45);
    }
    start() { this._chord([392, 523, 659], 0.15, 'triangle', 0.5); }
  }

  global.IT_Audio = new AudioManager();
})(window);
