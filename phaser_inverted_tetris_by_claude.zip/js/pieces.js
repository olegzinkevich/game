/*
 * pieces.js — Figure definitions, rotation, and the 4-bag randomizer.
 *
 * Inverted Tetris uses exactly four figures, each composed of exactly THREE
 * cells (req. 3.2 / 3.5.1). Coordinates are (col, row) with row 0 at the TOP of
 * the figure's bounding box, in standard (spawn) orientation.
 */
(function (global) {
  'use strict';

  // Field geometry (req. 3.1 / 3.3).
  const FIELD_W = 15;
  const FIELD_H = 35;

  // Default configuration (req. 3.3).
  const BASE_INTERVAL = 500; // base rise interval in ms
  const MIN_INTERVAL = 50;   // fastest rise interval in ms
  const LINES_PER_LEVEL = 10;

  // The four figures. colorId (1..4) is what gets stored in the grid; the hex
  // string drives both the Phaser fill and the DOM HUD swatches.
  const SHAPES = {
    I: { cells: [[0, 0], [0, 1], [0, 2]], colorId: 1, color: '#30b5c5' }, // cyan, vertical line
    P: { cells: [[1, 0], [0, 1], [0, 2]], colorId: 2, color: '#c00000' }, // red
    L: { cells: [[0, 0], [0, 1], [1, 2]], colorId: 3, color: '#ED6D00' }, // orange
    C: { cells: [[0, 0], [0, 1], [1, 1]], colorId: 4, color: '#a0d183' }  // green, 2x2 missing top-right
  };

  const TYPES = ['I', 'P', 'L', 'C'];

  // colorId -> hex, used by the renderer for locked cells.
  const COLOR_BY_ID = { 0: '#0e1320' };
  TYPES.forEach((t) => { COLOR_BY_ID[SHAPES[t].colorId] = SHAPES[t].color; });

  /**
   * Rotate a set of relative cells 90 degrees about the shape centre, then
   * normalise so the bounding box starts at (0,0). dir = +1 CW, -1 CCW.
   * Uses a rotation matrix (req. 3.6.5): CW (x,y)->(-y,x), CCW (x,y)->(y,-x).
   */
  function rotateCells(cells, dir) {
    const rotated = cells.map(([x, y]) => (dir > 0 ? [-y, x] : [y, -x]));
    const minX = Math.min.apply(null, rotated.map((c) => c[0]));
    const minY = Math.min.apply(null, rotated.map((c) => c[1]));
    return rotated.map(([x, y]) => [x - minX, y - minY]);
  }

  function pieceWidth(cells) { return Math.max.apply(null, cells.map((c) => c[0])) + 1; }
  function pieceHeight(cells) { return Math.max.apply(null, cells.map((c) => c[1])) + 1; }

  /**
   * Build a fresh active piece at the standard bottom-centre spawn position
   * and orientation (req. 3.2 / 3.5.2).
   */
  function makePiece(type) {
    const def = SHAPES[type];
    const cells = def.cells.map((c) => [c[0], c[1]]);
    const w = pieceWidth(cells);
    const h = pieceHeight(cells);
    return {
      type: type,
      colorId: def.colorId,
      cells: cells,
      x: Math.floor(FIELD_W / 2) - Math.floor(w / 2), // centred horizontally
      y: FIELD_H - h                                  // bottom of piece on the last row
    };
  }

  /**
   * 4-bag randomizer (req. 3.5.3 / 3.10.5): each bag is a shuffled permutation
   * of the four figures, so no figure is starved or duplicated within a bag.
   */
  class Bag {
    constructor() {
      this.queue = [];
      this._refill();
    }
    _refill() {
      const bag = TYPES.slice();
      for (let i = bag.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const tmp = bag[i]; bag[i] = bag[j]; bag[j] = tmp;
      }
      this.queue.push.apply(this.queue, bag);
    }
    next() {
      if (this.queue.length === 0) this._refill();
      const t = this.queue.shift();
      if (this.queue.length === 0) this._refill(); // keep peek() valid
      return t;
    }
    peek() {
      if (this.queue.length === 0) this._refill();
      return this.queue[0];
    }
  }

  global.IT_Pieces = {
    FIELD_W, FIELD_H, BASE_INTERVAL, MIN_INTERVAL, LINES_PER_LEVEL,
    SHAPES, TYPES, COLOR_BY_ID,
    rotateCells, makePiece, pieceWidth, pieceHeight, Bag
  };
})(window);
