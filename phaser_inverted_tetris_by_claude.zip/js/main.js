/*
 * main.js — Phaser bootstrap + DOM wiring.
 *
 * Phaser renders the playfield; the surrounding HUD, previews, overlays and
 * touch controls are plain accessible DOM. This file connects the two: it
 * forwards DOM button presses into the scene and reflects scene events back
 * into the HUD / overlays / aria-live region.
 */
(function (global) {
  'use strict';

  const P = global.IT_Pieces;
  const A = global.IT_Audio;

  // ---- DOM helpers -------------------------------------------------------
  const $ = (id) => document.getElementById(id);

  function setText(el, v) { if (el) el.textContent = String(v); }

  function announce(msg) {
    const live = $('aria-live');
    if (live) live.textContent = msg;
  }

  // Build a small grid preview (Next / Hold) from a shape type.
  function renderPreview(el, type) {
    if (!el) return;
    el.innerHTML = '';
    if (!type) { el.setAttribute('aria-label', 'empty'); return; }
    const def = P.SHAPES[type];
    const w = P.pieceWidth(def.cells);
    const h = P.pieceHeight(def.cells);
    const filled = {};
    def.cells.forEach((c) => { filled[c[0] + ',' + c[1]] = true; });
    el.style.gridTemplateColumns = 'repeat(' + w + ', 1fr)';
    el.style.gridTemplateRows = 'repeat(' + h + ', 1fr)';
    for (let r = 0; r < h; r++) {
      for (let c = 0; c < w; c++) {
        const cellEl = document.createElement('div');
        cellEl.className = 'mini-cell';
        if (filled[c + ',' + r]) cellEl.style.background = def.color;
        el.appendChild(cellEl);
      }
    }
    el.setAttribute('aria-label', 'figure ' + type);
  }

  // ---- Phaser config -----------------------------------------------------
  const config = {
    type: Phaser.AUTO,
    parent: 'game-container',
    backgroundColor: '#0b0e14',
    scale: {
      mode: Phaser.Scale.RESIZE,
      autoCenter: Phaser.Scale.CENTER_BOTH,
      width: '100%',
      height: '100%'
    },
    render: { antialias: true, roundPixels: true, powerPreference: 'high-performance' },
    scene: [global.IT_GameScene]
  };

  // Surface uncaught errors gracefully instead of a white screen (req. 8.10).
  global.addEventListener('error', (e) => {
    const banner = $('error-banner');
    if (banner) {
      banner.textContent = 'Something went wrong, but the game keeps running.';
      banner.hidden = false;
    }
  });

  A.init();

  const game = new Phaser.Game(config);
  global.ITGame = game;

  // ---- wire scene events -> DOM ------------------------------------------
  game.events.on('it-hud', (d) => {
    setText($('score-val'), d.score);
    setText($('lines-val'), d.lines);
    setText($('level-val'), d.level);
    setText($('high-val'), d.high);
    setText($('go-score'), d.score);
    setText($('go-high'), d.high);
  });

  game.events.on('it-preview', (d) => {
    renderPreview($('next-preview'), d.next);
    renderPreview($('hold-preview'), d.hold);
  });

  game.events.on('it-state', (d) => {
    showOverlay(d.status);
    if (d.status === 'playing') announce('Game running');
    else if (d.status === 'paused') announce('Game paused');
    else if (d.status === 'gameover') announce('Game over. Final score ' + d.score);
  });

  function showOverlay(status) {
    toggle($('menu-overlay'), status === 'menu');
    toggle($('pause-overlay'), status === 'paused');
    toggle($('gameover-overlay'), status === 'gameover');
    const pauseBtn = $('btn-pause');
    if (pauseBtn) pauseBtn.textContent = (status === 'paused') ? 'Resume' : 'Pause';
  }
  function toggle(el, on) { if (el) el.hidden = !on; }

  // ---- DOM -> scene ------------------------------------------------------
  function scene() { return game.itScene; }

  function withScene(fn) { const s = scene(); if (s) fn(s); }

  // Primary buttons.
  bindClick('btn-start', () => withScene((s) => s.startGame()));
  bindClick('btn-restart-menu', () => withScene((s) => s.restart()));
  bindClick('btn-resume', () => withScene((s) => s.togglePause()));
  bindClick('btn-restart-pause', () => withScene((s) => s.restart()));
  bindClick('btn-restart-go', () => withScene((s) => s.restart()));
  bindClick('btn-pause', () => withScene((s) => s.togglePause()));
  bindClick('btn-newgame', () => withScene((s) => s.restart()));
  bindClick('btn-mute', () => {
    const muted = A.toggleMute();
    const b = $('btn-mute');
    if (b) { b.textContent = muted ? '🔇 Sound off' : '🔊 Sound on'; b.setAttribute('aria-pressed', String(muted)); }
  });

  function bindClick(id, fn) {
    const el = $(id);
    if (!el) return;
    el.addEventListener('click', () => { A.resume(); fn(); });
  }

  // Touch / on-screen control buttons. Press-and-hold repeats for move & soft.
  setupHoldButton('tc-left', () => withScene((s) => s.action('left')), true);
  setupHoldButton('tc-right', () => withScene((s) => s.action('right')), true);
  setupHoldButton('tc-soft', () => withScene((s) => s.action('soft')), true);
  setupTapButton('tc-ccw', () => withScene((s) => s.action('ccw')));
  setupTapButton('tc-cw', () => withScene((s) => s.action('cw')));
  setupTapButton('tc-hard', () => withScene((s) => s.action('hard')));
  setupTapButton('tc-hold', () => withScene((s) => s.action('hold')));

  function setupTapButton(id, fn) {
    const el = $(id);
    if (!el) return;
    el.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      A.resume();
      fn();
    });
  }

  function setupHoldButton(id, fn, repeat) {
    const el = $(id);
    if (!el) return;
    let timer = null;
    const start = (e) => {
      e.preventDefault();
      A.resume();
      fn();
      if (repeat) {
        let delay = 180;
        const tick = () => { fn(); delay = 50; timer = setTimeout(tick, delay); };
        timer = setTimeout(tick, delay);
      }
    };
    const stop = () => { if (timer) { clearTimeout(timer); timer = null; } };
    el.addEventListener('pointerdown', start);
    el.addEventListener('pointerup', stop);
    el.addEventListener('pointerleave', stop);
    el.addEventListener('pointercancel', stop);
  }

  // ---- auto-pause on tab background (req. 3.4.6 / 8.6) --------------------
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) withScene((s) => s.autoPause());
  });
  global.addEventListener('blur', () => withScene((s) => s.autoPause()));

  // Prevent context menu / pinch zoom interfering with play (req. 5.2.5).
  const container = $('game-container');
  if (container) {
    container.addEventListener('contextmenu', (e) => e.preventDefault());
  }
})(window);
