# Inverted Tetris (Phaser 3)

A web-based **Inverted Tetris** game built with **Phaser 3**. Figures are made of
**exactly three cells**, spawn at the **bottom-centre**, and **rise upward**. The
stack grows from the top down — clear full horizontal lines before it reaches the
bottom spawn area.

Implements 100% of the acceptance criteria in
`../requirements_doc/acceptance_criteria_inverted_tetris.md`.

## Run it

It is a fully static site (no build step, no server runtime). Phaser is loaded
from a CDN.

- **Easiest:** open `index.html` in a modern browser.
- **Recommended (avoids any browser file:// quirks):** serve the folder, e.g.

  ```sh
  npx serve .
  # or
  python -m http.server 8000
  ```

  then open the printed URL.

Static-host it anywhere (GitHub Pages, Netlify, S3, …) — no backend required.

## Controls

| Action            | Keyboard        | Touch                                  |
|-------------------|-----------------|----------------------------------------|
| Move left / right | ← / →           | ◀ / ▶ buttons, or horizontal swipe     |
| Soft rise         | ↑               | ▲ button, or swipe up                  |
| Hard rise         | Space           | ⤒ button, or swipe down                |
| Rotate CW / CCW   | X / Z (or Ctrl) | ⟳ / ⟲ buttons, or tap the field        |
| Hold              | C / Shift       | ⇄ button                               |
| Pause / resume    | P / Esc         | Pause button                           |
| Restart           | R               | New Game / Restart buttons             |

## Project layout

```
index.html        markup, HUD, overlays, touch controls, accessibility hooks
css/style.css     responsive dark theme (320px → desktop, portrait & landscape)
js/pieces.js      figure definitions, rotation, 4-bag randomizer
js/board.js       pure grid logic: collision, locking, inverted line clear
js/audio.js       WebAudio synth feedback (graceful fallback if unavailable)
js/game-scene.js  Phaser scene: inverted game loop, input, rendering
js/main.js        Phaser bootstrap + DOM wiring (HUD / overlays / touch)
```

`pieces.js` and `board.js` are framework-agnostic and unit-tested in isolation.

## Figures

| Figure | Colour          | Cells (col,row), row 0 = top  |
|--------|-----------------|-------------------------------|
| I      | cyan `#30b5c5`  | (0,0)(0,1)(0,2)               |
| P      | red `#c00000`   | (1,0)(0,1)(0,2)               |
| L      | orange `#ED6D00`| (0,0)(0,1)(1,2)               |
| C      | green `#a0d183` | (0,0)(0,1)(1,1)               |

## Rules & scoring

- **Field:** 15 × 35. **Spawn:** bottom-centre, standard orientation.
- **Randomizer:** 4-bag (shuffled permutation of I, P, L, C).
- **Inverted gravity:** figures rise; soft rise accelerates; hard rise is
  instant. Locking occurs when a figure can no longer ascend (top wall or the
  underside of the stack), subject to a bounded ~500 ms lock delay.
- **Line clear:** any fully filled row is removed and rows below settle **upward**;
  up to three rows clear per lock (a 3-cell figure spans at most three rows, so a
  four-line clear is impossible).
- **Score:** 1 line = 100 × level, 2 = 300 × level, 3 = 500 × level.
  Soft rise = 1 pt/cell, hard rise = 2 pts/cell.
- **Leveling:** +1 level per 10 lines. Rise interval = `max(50, 500 / level)` ms.
  Level starts at 1, so the base interval is 500 ms. (The spec offers level 0/1
  and a `500/(level+1)` variant; this `level` starting at 1 is the equivalent
  consistent choice that keeps the 500 ms base and non-zero line scoring.)
- **High score** persists via `localStorage` (degrades gracefully if blocked).
- **Game over:** a freshly spawned figure that collides at the bottom spawn area.

## Notes

- Auto-pauses when the tab is backgrounded; the loop uses a clamped delta so a
  refocus never produces a burst of rise ticks.
- Respects `prefers-reduced-motion` (no flashing line-clear / shake effects).
- Crisp on HiDPI; layout maintains the 15:35 aspect ratio with all rows visible.
```
