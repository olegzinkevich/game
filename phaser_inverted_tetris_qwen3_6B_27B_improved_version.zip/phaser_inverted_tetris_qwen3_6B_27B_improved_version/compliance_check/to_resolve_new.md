# To Resolve — Compliance Gaps (improved_version)

Compiled from 9 LLM-judge CSVs in `compliance_check/improved_version/` plus the human/LLM
verdict notes. Each atom id below was marked **not-satisfied** or **partial** by at least one
judge (`not-found` verdicts excluded). IDs are grouped by cross-judge agreement so the
high-consensus, code-confirmed issues can be fixed first.

Source file under review: `js/game.js`, `index.html`.

Judges: claude_opus_4_8, claude_sonnet_5, deepseek_v4_flash, deepseek_v4_pro,
glm_4_7_flash, kimi_2_7_code, mimo_2_5, minimax_2_7, qwen_35B_A3B.

---

## Tier 1 — High consensus, code-confirmed (fix these)

### FR-LEVEL-002 — Rise speed formula wrong `[not-satisfied ×6, partial ×1]`
**Problem:** Requirement: rise interval = `max(50, 500 / (level + 1))` ms. Code
(`js/game.js:281`) computes `Math.max(MIN_RISE_INTERVAL, Math.floor(BASE_RISE_INTERVAL / this.level))`
= `max(50, 500 / level)`. At level 1 both give 500 ms, but from level 2 on the game runs
faster than spec (level 2 → 250 ms in code vs required ~167 ms).
**Resolve:** In `riseInterval()` at `js/game.js:281`, change the divisor from `this.level` to
`(this.level + 1)` so it reads `Math.max(MIN_RISE_INTERVAL, Math.floor(BASE_RISE_INTERVAL / (this.level + 1)))`. Verify the value at levels 1, 2, and 10 matches `max(50, 500/(level+1))`.

### FR-ERR-008 — No global error handler `[not-satisfied ×5, partial ×2]`
**Problem:** No `window.onerror`, no `window.addEventListener('error', …)`, and no
`unhandledrejection` handler exist anywhere. An uncaught runtime error propagates unhandled
with no graceful surfacing (risking a white-screen / error loop).
**Resolve:** Add a global error boundary early in `js/game.js` (module top level): register
`window.addEventListener('error', …)` and `window.addEventListener('unhandledrejection', …)`
that log the error and fail gracefully (e.g. surface a non-fatal on-screen message / safe-pause)
instead of letting the game crash silently. Do not swallow errors silently — surface them.

### NFR-A11Y-004 — Canvas lacks accessible name `[partial ×7]`
**Problem:** `#game-container` has `role="application"` + `aria-label` (`index.html:28`), but the
Phaser-generated `<canvas>` itself has no `aria-label`/`role`, and the canvas-drawn touch
controls/buttons have no DOM accessible names.
**Resolve:** After Phaser creates the canvas, set an `aria-label` and appropriate `role` on the
`<canvas>` element (e.g. via the Phaser game's `canvas` reference, or query it after boot).
Provide accessible names for interactive touch zones — either real DOM controls with labels
layered over the canvas, or `aria-label`/off-screen text describing each control.

### FR-CTRL-001 — Ctrl bound to wrong rotation direction `[partial ×4, not-satisfied ×1]`
**Problem:** Spec: rotate CCW = `Z` **or** `Ctrl`; rotate CW = `X`. Code (`js/game.js:560`) sets
`kCw = JD(keys.x) || JD(keys.ctrl) || buf.rotateCw` and `kCcw = JD(keys.z)` — so Ctrl triggers
**clockwise** rotation instead of counter-clockwise.
**Resolve:** In `js/game.js:560`, move `JD(keys.ctrl)` from the `kCw` expression into the `kCcw`
expression so `kCcw = JD(keys.z) || JD(keys.ctrl)` and `kCw = JD(keys.x) || buf.rotateCw`.

### FR-ERR-006 — Corrupt high score yields NaN `[partial ×3, not-satisfied ×1]`
**Problem:** `loadHighScore()` (`js/game.js:218-223`) does `Math.max(0, parseInt(v, 10))`. For
corrupt non-numeric localStorage data (e.g. `"abc"`), `parseInt` returns `NaN` and
`Math.max(0, NaN)` = `NaN`, which then cascades into scoring/HUD instead of falling back to a
clean default of 0. The `try/catch` only guards access, not bad values.
**Resolve:** In `loadHighScore()`, validate the parsed number: `const n = parseInt(v, 10);
return Number.isFinite(n) && n > 0 ? n : 0;` so corrupt data falls back to 0.

---

## Tier 2 — Confirmed real bug (low judge count, verified in code)

### FR-SPAWN-003 — Hold swap loses the active piece `[partial ×1, not-satisfied ×1]`
**Problem:** `holdPiece()` (`js/game.js:377-388`): when a held piece already exists, it spawns
the held shape but then sets `this.holdShape = null` instead of storing the current active
piece (`prev`). The active figure is discarded and the hold slot is emptied, so a subsequent
swap has nothing to swap back. (The `else` branch correctly does `this.holdShape = prev`.)
**Resolve:** In the `if (this.holdShape)` branch at `js/game.js:377-388`, change
`this.holdShape = null;` to `this.holdShape = prev;` so the outgoing active piece is stored in
the hold slot. Verify that repeatedly pressing Hold alternates the two pieces without loss.

---

## Tier 3 — Moderate consensus (verify, then fix if confirmed)

### FR-CTRL-003 — No auto-repeat for held movement keys `[partial ×2]`
**Problem:** Input is deterministic and collision-safe, but auto-repeat (DAS/ARR-style) for a
held movement key is not implemented, so holding Left/Right moves only once per press. Spec
requires handling key repeat without missed/doubled input.
**Resolve:** Add a held-key repeat mechanism for horizontal movement (initial delay then
repeat interval) driven off the frame/update loop, keeping the existing collision invariants
and deterministic simultaneous-key resolution.

### FR-CLEAR-005 — Inverted-gravity settle direction unverified `[partial ×1, not-satisfied ×1]`
**Problem:** Clear logic filters full rows and re-packs, but for inverted gravity the
"settle remaining blocks upward, preserving partial-row gaps" behavior for non-contiguous gaps
is not clearly correct — code preserves order without an explicit directional (upward) settle
step.
**Resolve:** Confirm the row-collapse in the clear routine settles surviving rows toward the
top (inverted gravity) and preserves partial-row gaps as required. Add/adjust the settle
direction if it currently collapses toward the bottom. Add a test with non-contiguous filled
rows to confirm.

### FR-MOVE-004 — Soft rise not faster at high levels `[partial ×1]`
**Problem:** Soft rise uses a fixed 50 ms tick. At high levels the base interval already reaches
50 ms (`500/10`), so soft rise is no longer faster than the normal rate — the "accelerate
beyond normal rise rate" guarantee fails at the top levels.
**Resolve:** Make soft-rise speed a function of the current normal interval (e.g. a fixed
fraction of `riseInterval()`, or `min(50, riseInterval()/2)`) so it is always strictly faster
than the normal ascent regardless of level.

### FR-ARCH-001 — Timer-driven cycle not explicit `[partial ×1]`
**Problem:** One judge found the timer-driven game cycle (via Phaser) not explicit enough to
confirm the architecture requirement.
**Resolve:** Verify the rise cycle is driven by a single Phaser timer/`update` loop with no
duplicate loops; this is likely already satisfied (8/9 judges agree) — confirm and close if so.

---

## Tier 4 — Single-judge outliers (likely false positives — verify before acting)

All IDs below were flagged **only** by `glm_4_7_flash`, whose verdicts diverge sharply from the
other 8 judges (it also emitted many `not-found` results). Every other judge marked these
**satisfied**. Treat as low priority; verify against code before spending effort.

- **FR-LIFE-006** (glm not-satisfied) — resume-from-identical-state. All others satisfied.
- **FR-LIFE-008** (glm not-satisfied) — tab blur auto-pause / no runaway timers. All others satisfied.
- **FR-SPAWN-001** (glm not-satisfied) — spawn at bottom-center. All others satisfied.
- **FR-SPAWN-002** (glm not-satisfied) — spawn timing. All others satisfied.
- **FR-LOCK-002** (glm not-satisfied) — lock delay ~500 ms movement window. All others satisfied.
- **FR-GHOST-001** (glm not-satisfied) — ghost landing cells. All others satisfied.

**Resolve (if pursued):** Spot-check each against `js/game.js`; only open a fix if a concrete
defect is found. Otherwise dismiss as judge noise.

---

## Summary of flagged atom ids (union, deduplicated)

Tier 1: FR-LEVEL-002, FR-ERR-008, NFR-A11Y-004, FR-CTRL-001, FR-ERR-006
Tier 2: FR-SPAWN-003
Tier 3: FR-CTRL-003, FR-CLEAR-005, FR-MOVE-004, FR-ARCH-001
Tier 4 (single-judge outliers): FR-LIFE-006, FR-LIFE-008, FR-SPAWN-001, FR-SPAWN-002, FR-LOCK-002, FR-GHOST-001
