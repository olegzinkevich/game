# Fix Prompt — FR-SCORE-002 (Line-clear scoring scale) — CODE-ONLY

Requirements are frozen. Fix the **code** so it literally satisfies FR-SCORE-002 as
written. Do exactly what is described below — no refactors, no spec edits, no unrelated
changes.

## Files
- Code: `js/game.js`  (only file to change)
- Spec (read-only, do NOT edit): `requirements_doc/requirements.md`

## What FR-SCORE-002 literally requires
> Given the current level L, when 1/2/3 lines clear on a lock, the score increases by
> 100×L / 300×L / 500×L respectively.

## Why level stays 0-indexed (do not change the level's start value)
The starting level is pinned to **0** by two other frozen requirements, and the code
already satisfies them — do not disturb this:
- FR-CFG-001: base rise interval is 500 ms "at the starting level".
- FR-LEVEL-002: rise = `max(50, 500 / (level + 1))`.
- Solving `500 / (L + 1) = 500` ⟹ `L = 0`. Code at `js/game.js:315` already uses
  `(this.level + 1)` and is correct. Leave it alone.

Because level is 0-indexed, "level L" in FR-SCORE-002 is `this.level` (0 at game start).

## The one change
`js/game.js:497` currently reads:
```js
this.score += LINE_SCORES[fullRows.length] * (this.level + 1);
```
Change it to drop the `+1` so the code matches `100×level` literally:
```js
this.score += LINE_SCORES[fullRows.length] * this.level;
```
`LINE_SCORES = [0, 100, 300, 500]` (`js/game.js:32`) is correct — do not touch it.
This is the ONLY line to change. Do not modify the rise formula, the HUD, or `this.level`.

## Accepted consequence (intended — do not "fix" it)
With level 0-indexed, a line clear while at level 0 (the first 10 lines) now awards
`100×0 = 0` points; scoring begins at level 1. This is exactly what FR-SCORE-002 states
and is required for literal compliance. Do NOT re-add a `+1` or otherwise deviate.

## Do NOT
- Do NOT edit `requirements_doc/requirements.md` (requirements are frozen).
- Do NOT change the rise-interval formula (`js/game.js:315`) — it is already correct.
- Do NOT change the level display to `level + 1`. The on-screen level must equal the
  `level` used in `100×level`, so it keeps showing the 0-indexed value.
- Do NOT change `this.level`'s starting value (must remain 0).

## Verify
1. `grep` confirms `js/game.js:497` now multiplies by `this.level` (no `+1`).
2. At level 0: 1/2/3-line clears each add 0 points (matches `100×0` / `300×0` / `500×0`).
3. At level 1: 1/2/3-line clears add 100 / 300 / 500 (matches `100×1` etc.).
4. At level 2: they add 200 / 600 / 1000.
5. Rise interval is unchanged: 500 ms at level 0, `500/(level+1)` above.
6. FR-SCORE-001 still holds: score never decreases and is never negative.
7. No other FR's behavior changed.

## Out of scope
FR-SCORE-002 only. Do not touch hold/spawn/clear/rise/error-handling logic.
