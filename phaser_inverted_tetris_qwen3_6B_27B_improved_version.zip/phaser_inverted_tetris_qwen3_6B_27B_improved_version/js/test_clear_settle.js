/* ============================================================
   Inverted Tetris — Row-collapse / upward-settle tests
   Run standalone in a browser: open test_clear_settle.html
   ============================================================ */

const TEST_COLS = 15;
const TEST_ROWS = 10;

/** Simulate the clear-and-settle logic extracted from game.js. */
function collapseRows(grid, clearRows) {
  const fullSet = new Set(clearRows);
  const surviving = [];
  for (let r = 0; r < grid.length; r++) {
    if (!fullSet.has(r)) {
      surviving.push(grid[r]);
    }
  }
  while (surviving.length < grid.length) {
    surviving.push(new Uint8Array(TEST_COLS));
  }
  return surviving;
}

/** Build a test grid from row definitions. */
function buildGrid(rowDefs) {
  const grid = [];
  for (const def of rowDefs) {
    const row = new Uint8Array(TEST_COLS);
    for (const col of def) row[col] = 1;
    grid.push(row);
  }
  while (grid.length < TEST_ROWS) {
    grid.push(new Uint8Array(TEST_COLS));
  }
  return grid;
}

/** Check whether a row is completely empty. */
function isEmpty(row) {
  for (let i = 0; i < row.length; i++) { if (row[i]) return false; }
  return true;
}

/** Check whether a row is completely full. */
function isFull(row) {
  for (let i = 0; i < row.length; i++) { if (!row[i]) return false; }
  return true;
}

/** Deep-equal two grids. */
function gridsEqual(a, b) {
  if (a.length !== b.length) return false;
  for (let r = 0; r < a.length; r++) {
    for (let c = 0; c < a[r].length; c++) {
      if (a[r][c] !== b[r][c]) return false;
    }
  }
  return true;
}

/* ---- test suite ---- */
const results = [];

function assert(label, condition) {
  results.push({ label, pass: !!condition });
  console.log((condition ? '  PASS' : '  FAIL') + ` — ${label}`);
}

/* Test 1: Single full row in middle — blocks above stay, blocks below shift up */
(function() {
  // Row 4 is full, rows 5-6 have blocks.
  const grid = buildGrid([
    [],           // 0 empty
    [],           // 1 empty
    [0,1,2],      // 2 partial
    [],           // 3 empty
    [...Array(TEST_COLS).keys()], // 4 FULL
    [0,1,2],      // 5 partial (should shift to row 4)
    [3,4,5],      // 6 partial (should shift to row 5)
    [],           // 7 empty
    [],           // 8 empty
    [],           // 9 empty
  ]);
  const result = collapseRows(grid, [4]);

  // Row 4 should now hold what was row 5
  assert('T1: row 4 holds former row 5 pattern', result[4][0]===1 && result[4][1]===1 && result[4][2]===1);
  // Row 5 should now hold what was row 6
  assert('T1: row 5 holds former row 6 pattern', result[5][3]===1 && result[5][4]===1 && result[5][5]===1);
  // Rows 7-9 should be empty (padded at bottom)
  assert('T1: rows 7-9 are empty (bottom padding)', isEmpty(result[7]) && isEmpty(result[8]) && isEmpty(result[9]));
  // Rows 0-2 unchanged
  assert('T1: rows 0-2 unchanged above cleared row', isEmpty(result[0]) && isEmpty(result[1]) && result[2][0]===1 && result[2][1]===1 && result[2][2]===1);
})();

/* Test 2: Non-contiguous full rows — upward settle preserves gaps */
(function() {
  // Rows 2, 5, 8 are full.  Rows 3-4 and 6-7 have blocks.
  const grid = buildGrid([
    [],                        // 0 empty
    [0],                       // 1 partial
    [...Array(TEST_COLS).keys()], // 2 FULL
    [1,2],                     // 3 partial (should shift to row 2)
    [3,4],                     // 4 partial (should stay at row 3)
    [...Array(TEST_COLS).keys()], // 5 FULL
    [5,6],                     // 6 partial (should shift to row 4)
    [7,8],                     // 7 partial (should shift to row 5)
    [...Array(TEST_COLS).keys()], // 8 FULL
    [9],                       // 9 partial (should shift to row 6)
  ]);
  const result = collapseRows(grid, [2, 5, 8]);

  // 3 surviving rows with blocks + 1 partial from row 1 = 4 non-empty rows at top
  // row 0: empty (was row 0)
  // row 1: [0] (was row 1)
  // row 2: [1,2] (was row 3)
  // row 3: [3,4] (was row 4)
  // row 4: [5,6] (was row 6)
  // row 5: [7,8] (was row 7)
  // row 6: [9] (was row 9)
  // row 7-9: empty padding

  assert('T2: row 0 empty', isEmpty(result[0]));
  assert('T2: row 1 has [0]', result[1][0]===1 && result[1][1]===0);
  assert('T2: row 2 has [1,2]', result[2][1]===1 && result[2][2]===1);
  assert('T2: row 3 has [3,4]', result[3][3]===1 && result[3][4]===1);
  assert('T2: row 4 has [5,6]', result[4][5]===1 && result[4][6]===1);
  assert('T2: row 5 has [7,8]', result[5][7]===1 && result[5][8]===1);
  assert('T2: row 6 has [9]', result[6][9]===1);
  assert('T2: rows 7-9 empty padding', isEmpty(result[7]) && isEmpty(result[8]) && isEmpty(result[9]));
})();

/* Test 3: Adjacent full rows — compact correctly */
(function() {
  const grid = buildGrid([
    [0],                       // 0 partial
    [...Array(TEST_COLS).keys()], // 1 FULL
    [...Array(TEST_COLS).keys()], // 2 FULL
    [...Array(TEST_COLS).keys()], // 3 FULL
    [1],                       // 4 partial (should shift to row 1)
    [2],                       // 5 partial (should shift to row 2)
    [],                        // 6 empty
    [],                        // 7 empty
    [],                        // 8 empty
    [],                        // 9 empty
  ]);
  const result = collapseRows(grid, [1, 2, 3]);

  assert('T3: row 0 unchanged [0]', result[0][0]===1);
  assert('T3: row 1 has former row 4 [1]', result[1][1]===1);
  assert('T3: row 2 has former row 5 [2]', result[2][2]===1);
  assert('T3: rows 3-9 empty',
    [3,4,5,6,7,8,9].every(i => isEmpty(result[i])));
})();

/* Test 4: All rows full — everything clears */
(function() {
  const grid = buildGrid(Array(TEST_ROWS).fill(null).map(() => [...Array(TEST_COLS).keys()]));
  const fullRows = Array.from({length: TEST_ROWS}, (_, i) => i);
  const result = collapseRows(grid, fullRows);
  assert('T4: all rows empty after clearing all', result.every(isEmpty));
})();

/* Test 5: No full rows — grid unchanged */
(function() {
  const grid = buildGrid([[0,1],[2,3],[],[],[],[],[],[],[],[]]);
  const result = collapseRows(grid, []);
  assert('T5: grid unchanged when no rows cleared', gridsEqual(grid, result));
})();

/* Test 6: Full row at bottom edge */
(function() {
  const grid = buildGrid([
    [0], [], [], [], [], [], [], [], [],
    [...Array(TEST_COLS).keys()], // 9 FULL — bottom edge
  ]);
  const result = collapseRows(grid, [9]);
  assert('T6: row 0 unchanged', result[0][0]===1);
  assert('T6: rows 1-9 empty after clearing bottom', [1,2,3,4,5,6,7,8,9].every(i => isEmpty(result[i])));
})();

/* Test 7: Full row at top edge */
(function() {
  const grid = buildGrid([
    [...Array(TEST_COLS).keys()], // 0 FULL — top edge
    [1], [2], [3], [], [], [], [], [], [],
  ]);
  const result = collapseRows(grid, [0]);
  // After clearing row 0, surviving rows shift upward:
  // row 0 gets former row 1 [1], row 1 gets former row 2 [2], etc.
  assert('T7: row 0 has former row 1 [1]', result[0][1]===1);
  assert('T7: row 1 has former row 2 [2]', result[1][2]===1);
  assert('T7: row 2 has former row 3 [3]', result[2][3]===1);
  assert('T7: rows 3-9 empty', [3,4,5,6,7,8,9].every(i => isEmpty(result[i])));
})();

/* ---- summary ---- */
const passed = results.filter(r => r.pass).length;
const total = results.length;
console.log(`\n${passed}/${total} tests passed`);

// Report to document if running in browser
if (typeof document !== 'undefined') {
  const div = document.createElement('div');
  div.style.cssText = 'padding:20px;font-family:monospace;background:#1a1a2a;color:#eee;';
  for (const r of results) {
    const p = document.createElement('p');
    p.style.color = r.pass ? '#4f4' : '#f44';
    p.textContent = (r.pass ? 'PASS' : 'FAIL') + ' — ' + r.label;
    div.appendChild(p);
  }
  const summary = document.createElement('p');
  summary.style.cssText = 'font-size:1.2em;font-weight:bold;margin-top:10px;';
  summary.style.color = passed === total ? '#4f4' : '#f44';
  summary.textContent = `${passed}/${total} tests passed`;
  div.appendChild(summary);
  document.body.appendChild(div);
}