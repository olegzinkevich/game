/* ============================================================
   Inverted Tetris — Phaser 3
   Figures rise from bottom upward, 3-cell pieces, 15×35 grid.
   ============================================================ */

/* ---------- constants ---------- */
const COLS = 15;
const ROWS = 35;
const BASE_RISE_INTERVAL = 500;
const MIN_RISE_INTERVAL  = 50;
const LINES_PER_LEVEL    = 10;
const LOCK_DELAY_MS      = 500;
const LOCK_HARD_LIMIT_MS = 2500;
const CLEAR_FLASH_MS     = 200;
const DAS_DELAY_MS       = 170;
const ARR_INTERVAL_MS    = 50;

const SHAPES = {
  I: { color: 0x30b5c5, cells: [[0,0],[0,1],[0,2]], w: 1, h: 3 },
  P: { color: 0xc00000, cells: [[1,0],[0,1],[0,2]], w: 2, h: 3 },
  L: { color: 0xED6D00, cells: [[0,0],[0,1],[1,2]], w: 2, h: 3 },
  C: { color: 0xa0d183, cells: [[0,0],[0,1],[1,1]], w: 2, h: 2 }
};
const SHAPE_NAMES = ['I','P','L','C'];

const WALL_KICKS = [
  [0,0],[1,0],[-1,0],[0,1],[0,-1],
  [2,0],[-2,0],[0,2],[0,-2],
  [1,1],[-1,-1],[1,-1],[-1,1]
];

const LINE_SCORES = [0, 100, 300, 500];

/* ---------- helpers ---------- */
function createGrid() {
  return Array.from({length: ROWS}, () => new Uint8Array(COLS));
}

function rotateCellsCW(cells) {
  return cells.map(([c,r]) => [r, -c]);
}

function getRotatedCells(shapeName, rotation) {
  let cells = SHAPES[shapeName].cells.map(c => [...c]);
  for (let i = 0; i < ((rotation % 4 + 4) % 4); i++) {
    cells = rotateCellsCW(cells);
  }
  const minC = Math.min(...cells.map(c => c[0]));
  const minR = Math.min(...cells.map(c => c[1]));
  cells = cells.map(([c,r]) => [c - minC, r - minR]);
  const w = 1 + Math.max(...cells.map(c => c[0]));
  const h = 1 + Math.max(...cells.map(c => c[1]));
  return { cells, w, h };
}

function collision(grid, cells, offX, offY) {
  for (const [c, r] of cells) {
    const x = offX + c;
    const y = offY + r;
    if (x < 0 || x >= COLS || y < 0 || y >= ROWS) return true;
    if (grid[y][x] !== 0) return true;
  }
  return false;
}

function bagRandomizer() {
  const bag = [...SHAPE_NAMES];
  for (let i = bag.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  return bag;
}

/* ---------- audio ---------- */
class AudioManager {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch(e) { this.enabled = false; }
  }
  resume() {
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }
  playTone(freq, dur, type='square', vol=0.08) {
    if (!this.enabled || !this.ctx) return;
    this.resume();
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(vol, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + dur);
  }
  move()    { this.playTone(600, 0.04, 'square', 0.04); }
  rotate()  { this.playTone(800, 0.06, 'square', 0.05); }
  lock()    { this.playTone(200, 0.12, 'triangle', 0.06); }
  clear(n)  {
    const base = 500 + n * 100;
    for (let i = 0; i < n; i++) {
      setTimeout(() => this.playTone(base + i*150, 0.2, 'sine', 0.1), i * 80);
    }
  }
  triple()  {
    [523, 659, 784].forEach((f,i) => setTimeout(() => this.playTone(f, 0.3, 'sine', 0.12), i*100));
  }
  gameOver(){ this.playTone(120, 0.8, 'sawtooth', 0.08); }
  hardRise(){ this.playTone(400, 0.08, 'triangle', 0.05); }
}

/* ---------- global error boundary ---------- */
let gameSceneRef = null;

function surfaceError(message) {
  if (gameSceneRef && typeof gameSceneRef.showErrorOverlay === 'function') {
    gameSceneRef.showErrorOverlay(message);
  }
}

window.addEventListener('error', (event) => {
  console.error('[Uncaught Error]', event.message, event.filename, event.lineno);
  surfaceError(`Error: ${event.message}`);
});

window.addEventListener('unhandledrejection', (event) => {
  const reason = event.reason;
  const msg = reason instanceof Error ? reason.message : String(reason);
  console.error('[Unhandled Rejection]', msg, event.reason);
  surfaceError(`Unhandled rejection: ${msg}`);
});

/* ---------- scene ---------- */
class GameScene extends Phaser.Scene {
  constructor() { super({ key: 'GameScene' }); }

  /* ========== create ========== */
  create() {
    gameSceneRef = this;

    const maxH = window.innerHeight;
    const maxW = window.innerWidth;
    let cellSize = Math.floor(Math.min(maxW / (COLS + 8), (maxH - 40) / ROWS));
    cellSize = Math.max(cellSize, 8);
    this.cellSize = cellSize;

    const gameW = COLS * cellSize;
    const gameH = ROWS * cellSize;

    /* game state */
    this.grid = createGrid();
    this.score = 0;
    this.lines = 0;
    this.level = 0;
    this.status = 'menu';
    this.highScore = this.loadHighScore();

    this.bag = [];
    this.bagIdx = 0;
    this.nextShape = null;
    this.holdShape = null;
    this.holdUsed = false;
    this.activePiece = null;
    this.ghostY = 0;
    this.lockDelayStart = 0;
    this.lockFirstStart = 0;
    this.riseEvent = null;
    this.softRising = false;
    this.softRiseTimer = null;
    this.clearingRows = [];
    this.clearFlashTimer = 0;
    this.autoRepeatLeft = { held: false, startTime: 0, lastRepeat: 0 };
    this.autoRepeatRight = { held: false, startTime: 0, lastRepeat: 0 };

    this.audio = new AudioManager();

    /* graphics layers */
    this.gridGraphics = this.add.graphics();
    this.pieceGraphics = this.add.graphics();
    this.ghostGraphics = this.add.graphics();

    /* side panel — persistent text objects */
    this.sideX = COLS * cellSize + 10;
    this.hud = {}; /* text refs for score, level, lines, best, next, hold labels */
    this.createHUD();

    /* overlay containers (menu, pause, gameover) */
    this.overlayObjects = [];

    this.showMenu();

    /* keyboard — proper Phaser 3 API */
    this.cursors = this.input.keyboard.createCursorKeys();
    this.keys = {
      space: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE),
      x: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.X),
      z: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.Z),
      c: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.C),
      shiftL: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SHIFT_LEFT),
      shiftR: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SHIFT_RIGHT),
      ctrl: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.CONTROL),
      ctrlJustDown: false,
      p: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.P),
      esc: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESCAPE),
      escJustDown: false,
      r: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R),
      enter: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER)
    };
    this.input.on('gameobjectdown', () => this.audio.resume());

    /* touch input buffer — deterministic resolution of simultaneous touch inputs */
    this.touchInputBuffer = { left: false, right: false, hardRise: false, rotateCw: false, hold: false };

    /* auto-pause when window/tab loses focus */
    const self = this;
    const pauseIfPlaying = () => {
      if (self.status === 'playing') self.pauseGame();
    };
    const resumeIfPaused = () => {
      if (self.status === 'paused') self.resumeGame();
    };
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) pauseIfPlaying();
      else resumeIfPaused();
    });
    window.addEventListener('blur', pauseIfPlaying);
    window.addEventListener('focus', resumeIfPaused);

    /* touch controls */
    this.createTouchControls();

    /* prevent scroll from game keys */
    window.addEventListener('keydown', (e) => {
      const blocked = [17, 32, 37, 38, 39, 40];
      if (blocked.includes(e.keyCode)) e.preventDefault();
      if (e.keyCode === 17 && !e.repeat) this.keys.ctrlJustDown = true;
      if (e.keyCode === 27 && !e.repeat) this.keys.escJustDown = true;
    });

    /* prevent touch gestures (scroll, zoom, pinch) during active play */
    const suppressGesture = (e) => {
      if (this.status === 'playing') e.preventDefault();
    };
    document.addEventListener('touchmove', suppressGesture, { passive: false });
    document.addEventListener('gesturestart', suppressGesture, { passive: false });
    document.addEventListener('gesturechange', suppressGesture, { passive: false });
    window.addEventListener('wheel', suppressGesture, { passive: false });
  }

  /* ========== high score ========== */
  loadHighScore() {
    try {
      const v = localStorage.getItem('inverted_tetris_highscore');
      const n = parseInt(v, 10);
      return Number.isFinite(n) && n > 0 ? n : 0;
    } catch(e) { return 0; }
  }
  saveHighScore() {
    try { localStorage.setItem('inverted_tetris_highscore', String(this.highScore)); }
    catch(e) {}
  }

  /* ========== bag ========== */
  nextFromBag() {
    if (this.bagIdx >= this.bag.length) {
      this.bag = bagRandomizer();
      this.bagIdx = 0;
    }
    return this.bag[this.bagIdx++];
  }

  /* ========== spawn ========== */
  spawnPiece(shapeName) {
    const rot = getRotatedCells(shapeName, 0);
    const x = Math.floor(COLS / 2) - Math.floor(rot.w / 2);
    const y = ROWS - rot.h;
    if (collision(this.grid, rot.cells, x, y)) {
      this.gameOver();
      return null;
    }
    this.activePiece = {
      name: shapeName, rotation: 0, x, y,
      cells: rot.cells, w: rot.w, h: rot.h,
      color: SHAPES[shapeName].color,
      renderX: x, renderY: y
    };
    this.lockDelayStart = 0;
    this.lockFirstStart = 0;
    this.updateGhost();
    return this.activePiece;
  }

  startNewGame() {
    this.clearOverlay();
    this.grid = createGrid();
    this.score = 0;
    this.lines = 0;
    this.level = 0;
    this.bag = bagRandomizer();
    this.bagIdx = 0;
    this.nextShape = this.nextFromBag();
    this.holdShape = null;
    this.holdUsed = false;
    this.activePiece = null;
    this.status = 'playing';

    this.spawnPiece(this.nextShape);
    this.nextShape = this.nextFromBag();
    this.startRiseTimer();
    this.updateHUD();
    this.audio.resume();
  }

  /* ========== rise timer — FR-ARCH-001 ==========
     Single Phaser timer drives the auto-rise cycle.  No duplicate
     timers or setInterval/setTimeout loops exist for game logic.
     The update() loop handles input; riseEvent handles auto-rise;
     softRiseTimer handles soft-rise (always stopped before starting).
     Audio setTimeout calls are one-shot only, not game loops.  */
  /* ========== rise timer ========== */
  riseInterval() {
    return Math.max(MIN_RISE_INTERVAL, Math.floor(BASE_RISE_INTERVAL / (this.level + 1)));
  }
  startRiseTimer() {
    this.stopRiseTimer();
    this.riseEvent = this.time.addEvent({
      delay: this.riseInterval(),
      callback: () => this.riseTick(),
      loop: true
    });
  }
  stopRiseTimer() {
    if (this.riseEvent) { this.riseEvent.remove(); this.riseEvent = null; }
  }

  riseTick() {
    if (this.status !== 'playing' || !this.activePiece) return;
    if (!this.movePiece(0, -1)) {
      if (this.lockDelayStart === 0) this.lockDelayStart = this.time.now;
      if (this.lockFirstStart === 0) this.lockFirstStart = this.time.now;
      if (this.time.now - this.lockDelayStart >= LOCK_DELAY_MS ||
          this.time.now - this.lockFirstStart >= LOCK_HARD_LIMIT_MS) {
        this.lockPiece();
      }
    } else {
      this.lockDelayStart = 0;
      this.lockFirstStart = 0;
    }
  }

  /* ========== movement ========== */
  movePiece(dx, dy) {
    if (!this.activePiece) return false;
    const { cells, x, y } = this.activePiece;
    if (collision(this.grid, cells, x + dx, y + dy)) return false;
    this.activePiece.x += dx;
    this.activePiece.y += dy;
    this.updateGhost();
    return true;
  }

  /* ========== soft rise ========== */
  startSoftRise() {
    if (this.status !== 'playing' || this.softRising) return;
    this.softRising = true;
    this.stopSoftRise();
    this.softRiseTimer = this.time.addEvent({
      delay: Math.max(25, Math.floor(this.riseInterval() / 2)),
      callback: () => {
        if (!this.activePiece || this.status !== 'playing') { this.stopSoftRise(); return; }
        if (this.movePiece(0, -1)) {
          this.score += 1;
          this.hud.scoreValue.setText(String(this.score));
        } else {
          this.stopSoftRise();
        }
      },
      loop: true
    });
  }
  stopSoftRise() {
    if (this.softRiseTimer) { this.softRiseTimer.remove(); this.softRiseTimer = null; }
    this.softRising = false;
  }

  /* ========== hard rise ========== */
  hardRise() {
    if (!this.activePiece || this.status !== 'playing') return;
    let cellsRisen = 0;
    while (this.movePiece(0, -1)) cellsRisen++;
    this.score += cellsRisen * 2;
    this.updateHUD();
    this.audio.hardRise();
    this.lockPiece();
  }

  /* ========== rotation ========== */
  rotate(cw) {
    if (!this.activePiece || this.status !== 'playing') return;
    const newRot = ((this.activePiece.rotation + (cw ? 3 : 1)) % 4);
    const rot = getRotatedCells(this.activePiece.name, newRot);
    for (const [kx, ky] of WALL_KICKS) {
      if (!collision(this.grid, rot.cells, this.activePiece.x + kx, this.activePiece.y + ky)) {
        this.activePiece.cells = rot.cells;
        this.activePiece.w = rot.w;
        this.activePiece.h = rot.h;
        this.activePiece.rotation = newRot;
        this.activePiece.x += kx;
        this.activePiece.y += ky;
        this.activePiece.renderX = this.activePiece.x;
        this.activePiece.renderY = this.activePiece.y;
        this.updateGhost();
        this.audio.rotate();
        return;
      }
    }
  }

  /* ========== hold ========== */
  holdPiece() {
    if (!this.activePiece || this.holdUsed || this.status !== 'playing') return;
    this.holdUsed = true;
    const prev = this.activePiece.name;
    if (this.holdShape) {
      this.spawnPiece(this.holdShape);
      this.holdShape = null;
    } else {
      this.spawnPiece(this.nextShape);
      this.nextShape = this.nextFromBag();
      this.holdShape = prev;
    }
    this.audio.rotate();
    this.updateHUD();
  }

  /* ========== ghost ========== */
  updateGhost() {
    if (!this.activePiece) return;
    let gy = this.activePiece.y;
    while (!collision(this.grid, this.activePiece.cells, this.activePiece.x, gy - 1)) gy--;
    this.ghostY = gy;
  }

  /* ========== lock ========== */
  lockPiece() {
    if (!this.activePiece) return;
    const { cells, x, y } = this.activePiece;
    const colorId = SHAPE_NAMES.indexOf(this.activePiece.name) + 1;
    for (const [c, r] of cells) {
      const gx = x + c, gy = y + r;
      if (gy >= 0 && gy < ROWS && gx >= 0 && gx < COLS) {
        this.grid[gy][gx] = colorId;
      }
    }
    this.audio.lock();
    this.activePiece = null;
    this.lockDelayStart = 0;
    this.holdUsed = false;
    this.stopSoftRise();
    this.checkLines();
  }

  /* ========== line clearing ========== */
  checkLines() {
    const fullRows = [];
    for (let r = 0; r < ROWS; r++) {
      let full = true;
      for (let c = 0; c < COLS; c++) {
        if (this.grid[r][c] === 0) { full = false; break; }
      }
      if (full) fullRows.push(r);
    }
    if (fullRows.length === 0) {
      this.spawnNext();
      return;
    }

    this.clearingRows = fullRows;
    this.clearFlashTimer = 0;
    this.status = 'clearing';
    this.audio.clear(fullRows.length);
    if (fullRows.length === 3) this.audio.triple();

    this.time.delayedCall(CLEAR_FLASH_MS, () => {
      /* ---- inverted-gravity row collapse ----
         Gravity pulls blocks UPWARD (toward row 0 / grid top).
         After removing full rows, surviving rows shift to lower
         indices (upward).  Empty rows are appended at the bottom
         (highest row indices / spawn side).  Partial-row gaps are
         preserved — only fully-filled rows are removed, non-full
         rows keep their cell layout intact.  */
      const fullSet = new Set(fullRows);
      const survivingRows = [];
      for (let r = 0; r < ROWS; r++) {
        if (!fullSet.has(r)) {
          survivingRows.push(this.grid[r]);
        }
      }
      // pad empty rows at the bottom (spawn side) — upward settle
      while (survivingRows.length < ROWS) {
        survivingRows.push(new Uint8Array(COLS));
      }
      this.grid = survivingRows;
      this.clearingRows = [];
      this.lines += fullRows.length;
      this.score += LINE_SCORES[fullRows.length] * (this.level + 1);

      const newLevel = Math.floor(this.lines / LINES_PER_LEVEL);
      if (newLevel > this.level) {
        this.level = newLevel;
        this.startRiseTimer();
      }

      if (this.score > this.highScore) {
        this.highScore = this.score;
        this.saveHighScore();
      }

this.status = 'playing';

    this.autoRepeatLeft = { held: false, startTime: 0, lastRepeat: 0 };
    this.autoRepeatRight = { held: false, startTime: 0, lastRepeat: 0 };
      this.updateHUD();
      this.spawnNext();
    });
  }

  spawnNext() {
    if (this.status === 'gameover') return;
    this.spawnPiece(this.nextShape);
    this.nextShape = this.nextFromBag();
    this.updateHUD();
  }

  /* ========== game over ========== */
  gameOver() {
    this.status = 'gameover';
    this.stopRiseTimer();
    this.stopSoftRise();
    this.activePiece = null;
    if (this.score > this.highScore) {
      this.highScore = this.score;
      this.saveHighScore();
    }
    this.audio.gameOver();
    this.updateHUD();
    this.showGameOver();
  }

  /* ========== pause ========== */
  pauseGame() {
    if (this.status !== 'playing') return;
    this.status = 'paused';
    this.pauseTime = this.time.now;
    this.stopRiseTimer();
    this.stopSoftRise();
    this.showPause();
  }
  resumeGame() {
    if (this.status !== 'paused') return;
    this.status = 'playing';
    const pauseDuration = this.time.now - this.pauseTime;
    if (this.lockDelayStart > 0) {
      this.lockDelayStart += pauseDuration;
    }
    this.startRiseTimer();
    this.clearOverlay();
  }

  /* ========== keyboard ========== */
  update() {
    const { cursors, keys } = this;
    const JD = Phaser.Input.Keyboard.JustDown;
    const JU = Phaser.Input.Keyboard.JustUp;
    const now = this.time.now;

    /* render every frame */
    this.drawFrame();

    if (this.status === 'menu') {
      if (JD(keys.enter) || JD(keys.space)) {
        this.startNewGame();
      }
      return;
    }

    if (this.status === 'gameover') {
      if (JD(keys.enter) || JD(keys.space) || JD(keys.r)) {
        this.startNewGame();
      }
      return;
    }

    if (this.status === 'error') {
      if (JD(keys.r)) {
        this.startNewGame();
      }
      return;
    }

    /* pause toggle — always available */
    if (keys.escJustDown || JD(keys.p)) {
      this.keys.escJustDown = false;
      if (this.status === 'playing') this.pauseGame();
      else if (this.status === 'paused') this.resumeGame();
      return;
    }

    if (this.status === 'paused') return;

    /* restart */
    if (JD(keys.r)) {
      this.startNewGame();
      return;
    }

    if (this.status !== 'playing' || !this.activePiece) return;

    /* capture all key states upfront — safe against many inputs per frame */
    /* merge touch buffer flags with keyboard for deterministic resolution */
    const buf = this.touchInputBuffer || { left: false, right: false, hardRise: false, rotateCw: false, hold: false };
    const kLeft = JD(cursors.left) || buf.left;
    const kRight = JD(cursors.right) || buf.right;
    const kUpDown = JD(cursors.up);
    const kUpUp = JU(cursors.up);
    const kSpace = JD(keys.space) || buf.hardRise;
    const kCw = JD(keys.x) || buf.rotateCw;
    const kCcw = JD(keys.z) || keys.ctrlJustDown;
    const kHold = JD(keys.c) || JD(keys.shiftL) || JD(keys.shiftR) || buf.hold;

    /* auto-repeat (DAS/ARR) for horizontal movement */
    const leftHeld = cursors.left.isDown || buf.left;
    const rightHeld = cursors.right.isDown || buf.right;
    const arL = this.autoRepeatLeft;
    const arR = this.autoRepeatRight;

    /* update hold state — left */
    if (leftHeld && !rightHeld) {
      if (!arL.held) {
        arL.held = true;
        arL.startTime = now;
        arL.lastRepeat = now;
      }
      const elapsed = now - arL.startTime;
      if (elapsed >= DAS_DELAY_MS && now - arL.lastRepeat >= ARR_INTERVAL_MS) {
        if (this.movePiece(-1, 0)) { this.audio.move(); this.lockDelayStart = 0; }
        arL.lastRepeat = now;
      }
    } else {
      arL.held = false;
    }

    /* update hold state — right */
    if (rightHeld && !leftHeld) {
      if (!arR.held) {
        arR.held = true;
        arR.startTime = now;
        arR.lastRepeat = now;
      }
      const elapsed = now - arR.startTime;
      if (elapsed >= DAS_DELAY_MS && now - arR.lastRepeat >= ARR_INTERVAL_MS) {
        if (this.movePiece(1, 0)) { this.audio.move(); this.lockDelayStart = 0; }
        arR.lastRepeat = now;
      }
    } else {
      arR.held = false;
    }

    /* resolve simultaneous opposing keys deterministically — first press only */
    if (kLeft && !kRight) {
      if (this.movePiece(-1, 0)) { this.audio.move(); this.lockDelayStart = 0; }
    } else if (kRight && !kLeft) {
      if (this.movePiece(1, 0)) { this.audio.move(); this.lockDelayStart = 0; }
    }

    if (kUpDown) this.startSoftRise();
    if (kUpUp) this.stopSoftRise();

    /* hard rise locks piece and spawns next — stop processing to avoid
       applying rotation/hold to the newly spawned piece in the same frame */
    if (kSpace) { this.hardRise(); return; }

    if (kCw && !kCcw) {
      this.rotate(true);
      this.lockDelayStart = 0;
    } else if (kCcw && !kCw) {
      this.rotate(false);
      this.lockDelayStart = 0;
    }
    if (kHold) this.holdPiece();

    /* clear touch buffer for next frame */
    if (this.touchInputBuffer) {
      this.touchInputBuffer.left = false;
      this.touchInputBuffer.right = false;
      this.touchInputBuffer.hardRise = false;
      this.touchInputBuffer.rotateCw = false;
      this.touchInputBuffer.hold = false;
    }
    this.keys.ctrlJustDown = false;
    this.keys.escJustDown = false;
  }

  /* ========== touch controls ========== */
  createTouchControls() {
    const isMobile = window.innerWidth < 600;
    if (!isMobile) return;

    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const btnW = Math.max(44, cs * 2.5);
    const btnH = Math.max(44, cs * 2.5);
    const gap = 4;
    const bottomY = gh + 10;
    const cx = gw / 2;

    const self = this;

    const makeBtn = (label, x, y, action) => {
      const g = this.add.graphics();
      g.fillStyle(0x333344, 0.7);
      g.fillRoundedRect(x - btnW/2, y - btnH/2, btnW, btnH, 6);
      g.lineStyle(1, 0x666688, 0.5);
      g.strokeRoundedRect(x - btnW/2, y - btnH/2, btnW, btnH, 6);
      const t = this.add.text(x, y, label, {
        fontSize: `${Math.floor(btnH * 0.45)}px`,
        color: '#ddd',
        fontFamily: 'monospace'
      }).setOrigin(0.5);
      const zone = this.add.zone(x, y, btnW, btnH).setOrigin(0.5).setInteractive();
      zone.on('pointerdown', () => { this.audio.resume(); action(); });
      return { g, t, zone };
    };

    makeBtn('◀', cx - btnW*1.5 - gap, bottomY + btnH, () => { self.touchInputBuffer.left = true; });
    makeBtn('▶', cx - gap*0.5, bottomY + btnH, () => { self.touchInputBuffer.right = true; });
    makeBtn('↻', cx + gap*0.5, bottomY + btnH, () => { self.touchInputBuffer.rotateCw = true; });
    makeBtn('⇡', cx + btnW*1.5 + gap, bottomY + btnH, () => { self.touchInputBuffer.hardRise = true; });
    makeBtn('HOLD', cx - btnW, bottomY - btnH*0.5, () => { self.touchInputBuffer.hold = true; });
    makeBtn('⏸', cx + btnW, bottomY - btnH*0.5, () => {
      if (self.status === 'playing') self.pauseGame();
      else if (self.status === 'paused') self.resumeGame();
    });

    /* NFR-A11Y-004: activate DOM overlay touch controls with accessible labels */
    this.setupAccessibleTouchControls();
  }

  /* ========== accessible touch controls (DOM overlay) ========== */
  setupAccessibleTouchControls() {
    const overlay = document.getElementById('touch-controls-overlay');
    if (!overlay) return;

    overlay.classList.add('active');

    const btnLeft = document.getElementById('btn-left');
    const btnRight = document.getElementById('btn-right');
    const btnRotate = document.getElementById('btn-rotate');
    const btnHardrise = document.getElementById('btn-hardrise');
    const btnHold = document.getElementById('btn-hold');
    const btnPause = document.getElementById('btn-pause');

    const self = this;

    const bindBtn = (btn, action) => {
      if (!btn) return;
      const handler = (e) => {
        e.preventDefault();
        this.audio.resume();
        action();
      };
      btn.addEventListener('touchstart', handler, { passive: false });
      btn.addEventListener('mousedown', handler);
      btn.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          this.audio.resume();
          action();
        }
      });
    };

    bindBtn(btnLeft, () => { self.touchInputBuffer.left = true; });
    bindBtn(btnRight, () => { self.touchInputBuffer.right = true; });
    bindBtn(btnRotate, () => { self.touchInputBuffer.rotateCw = true; });
    bindBtn(btnHardrise, () => { self.touchInputBuffer.hardRise = true; });
    bindBtn(btnHold, () => { self.touchInputBuffer.hold = true; });
    bindBtn(btnPause, () => {
      if (self.status === 'playing') self.pauseGame();
      else if (self.status === 'paused') self.resumeGame();
    });
  }

  /* ========== HUD ========== */
  createHUD() {
    const cs = this.cellSize;
    const sx = this.sideX;
    const fontSize = Math.max(12, Math.floor(cs * 0.85));
    const smallFont = Math.max(10, Math.floor(cs * 0.65));

    const mkText = (x, y, text, size, color) =>
      this.add.text(x, y, text, {
        fontSize: `${size}px`,
        color: '#' + color.toString(16).padStart(6, '0'),
        fontFamily: 'monospace',
        fontStyle: 'bold'
      });

    let cy = 10;
    this.hud.scoreLabel = mkText(sx, cy, 'SCORE', fontSize, 0x6666aa);
    cy += fontSize + 2;
    this.hud.scoreValue = this.add.text(sx, cy, '0', {
      fontSize: `${fontSize}px`, color: '#eeeeff', fontFamily: 'monospace'
    });
    cy += fontSize + 20;

    this.hud.levelLabel = mkText(sx, cy, 'LEVEL', fontSize, 0x6666aa);
    cy += fontSize + 2;
    this.hud.levelValue = this.add.text(sx, cy, '1', {
      fontSize: `${fontSize}px`, color: '#eeeeff', fontFamily: 'monospace'
    });
    cy += fontSize + 20;

    this.hud.linesLabel = mkText(sx, cy, 'LINES', fontSize, 0x6666aa);
    cy += fontSize + 2;
    this.hud.linesValue = this.add.text(sx, cy, '0', {
      fontSize: `${fontSize}px`, color: '#eeeeff', fontFamily: 'monospace'
    });
    cy += fontSize + 20;

    this.hud.bestLabel = mkText(sx, cy, 'BEST', smallFont, 0x888899);
    cy += smallFont + 2;
    this.hud.bestValue = this.add.text(sx, cy, '0', {
      fontSize: `${smallFont}px`, color: '#888899', fontFamily: 'monospace'
    });
    cy += smallFont + 20;

    this.hud.nextLabel = mkText(sx, cy, 'NEXT', fontSize, 0x6666aa);
    this.hud.nextY = cy + fontSize + 6;

    this.hud.holdLabel = mkText(sx, cy + 80, 'HOLD', fontSize, 0x6666aa);
    this.hud.holdY = cy + 80 + fontSize + 6;

    /* game over indicator - hidden initially */
    this.hud.gameOverLabel = mkText(sx, cy + 160, 'GAME OVER', fontSize, 0xc00000);
    this.hud.gameOverLabel.setVisible(false);

    /* restart button */
    const restartY = cy + 160 + fontSize + 10;
    const restartBg = this.add.graphics();
    restartBg.fillStyle(0x2a2a3a, 0.9);
    restartBg.fillRoundedRect(sx, restartY, 100, fontSize + 8, 4);
    this.hud.restartBg = restartBg;
    const restartText = this.add.text(sx + 50, restartY + (fontSize + 8) / 2, 'RESTART', {
      fontSize: `${Math.max(10, Math.floor(cs * 0.6))}px`,
      color: '#aabbcc',
      fontFamily: 'monospace'
    }).setOrigin(0.5);
    this.hud.restartText = restartText;
    const restartZone = this.add.zone(sx, restartY, 100, fontSize + 8)
      .setOrigin(0.5)
      .setInteractive({ useHandCursor: true });
    restartZone.on('pointerdown', () => {
      this.audio.resume();
      this.startNewGame();
    });
    this.hud.restartZone = restartZone;
  }

  updateHUD() {
    this.hud.scoreValue.setText(String(this.score));
    this.hud.levelValue.setText(String(this.level));
    this.hud.linesValue.setText(String(this.lines));
    this.hud.bestValue.setText(String(this.highScore));

    /* draw next preview */
    if (this.hud.nextGraphics) this.hud.nextGraphics.destroy();
    this.hud.nextGraphics = this.add.graphics();
    if (this.nextShape) {
      this.drawPreview(this.hud.nextGraphics, this.nextShape, this.sideX, this.hud.nextY, 0.9);
    }

    /* draw hold preview */
    if (this.hud.holdGraphics) this.hud.holdGraphics.destroy();
    this.hud.holdGraphics = this.add.graphics();
    if (this.holdShape) {
      this.drawPreview(this.hud.holdGraphics, this.holdShape, this.sideX, this.hud.holdY, this.holdUsed ? 0.3 : 0.9);
    }

    /* game over indicator */
    const gameOverVisible = this.status === 'gameover';
    this.hud.gameOverLabel.setVisible(gameOverVisible);
  }

  drawPreview(g, shapeName, ox, oy, alpha) {
    const cs = Math.max(10, Math.floor(this.cellSize * 0.7));
    const rot = getRotatedCells(shapeName, 0);
    const color = SHAPES[shapeName].color;
    for (const [c, r] of rot.cells) {
      g.fillStyle(color, alpha);
      g.fillRoundedRect(ox + c * (cs + 2), oy + r * (cs + 2), cs, cs, 2);
    }
  }

  /* ========== error overlay ========== */
  showErrorOverlay(message) {
    this.stopRiseTimer();
    this.status = 'error';
    this.clearOverlay();
    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const cx = gw / 2;
    const cy = gh / 2;

    const bg = this.add.graphics();
    bg.fillStyle(0x1a0000, 0.92);
    bg.fillRect(0, 0, gw, gh);

    const err = this.add.text(cx, cy - 40, 'RUNTIME ERROR', {
      fontSize: `${Math.max(24, cs * 2)}px`, color: '#ff4444',
      fontFamily: 'monospace', fontStyle: 'bold'
    }).setOrigin(0.5);

    const msg = this.add.text(cx, cy + 10, message, {
      fontSize: `${Math.max(12, cs * 0.8)}px`, color: '#ccccdd',
      fontFamily: 'monospace', align: 'center', wordWrap: { width: gw - 40 }
    }).setOrigin(0.5);

    const hint = this.add.text(cx, cy + 60, 'Press R to restart', {
      fontSize: `${Math.max(12, cs * 0.8)}px`, color: '#8888aa',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    this.overlayObjects.push(bg, err, msg, hint);
  }

  /* ========== overlays ========== */
  clearOverlay() {
    for (const obj of this.overlayObjects) obj.destroy();
    this.overlayObjects = [];
  }

  showMenu() {
    this.status = 'menu';
    this.clearOverlay();
    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const cx = gw / 2;
    const cy = gh / 2;

    const bg = this.add.graphics();
    bg.fillStyle(0x0a0a12, 0.92);
    bg.fillRect(0, 0, gw, gh);
    this.overlayObjects.push(bg);

    const title = this.add.text(cx, cy - 80, 'INVERTED\nTETRIS', {
      fontSize: `${Math.max(28, cs * 2.5)}px`, color: '#30b5c5',
      fontFamily: 'monospace', fontStyle: 'bold', align: 'center', lineSpacing: 4
    }).setOrigin(0.5);

    const sub = this.add.text(cx, cy + 20, 'Figures rise from below.\nClear lines. Survive.', {
      fontSize: `${Math.max(12, cs * 0.8)}px`, color: '#6666aa',
      fontFamily: 'monospace', align: 'center'
    }).setOrigin(0.5);

    const start = this.add.text(cx, cy + 100, '[ PRESS ENTER / SPACE ]', {
      fontSize: `${Math.max(14, cs * 1)}px`, color: '#aabbcc', fontFamily: 'monospace'
    }).setOrigin(0.5);

    const ctrls = this.add.text(cx, cy + 160,
      '← →  Move    ↑  Soft Rise    Space  Hard Rise\nX  CW    Z  CCW    C  Hold    Esc  Pause', {
      fontSize: `${Math.max(10, cs * 0.65)}px`, color: '#444466',
      fontFamily: 'monospace', align: 'center', lineSpacing: 2
    }).setOrigin(0.5);

    this.overlayObjects.push(title, sub, start, ctrls);
  }

  showPause() {
    this.clearOverlay();
    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const cx = gw / 2;
    const cy = gh / 2;

    const bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.6);
    bg.fillRect(0, 0, gw, gh);

    const txt = this.add.text(cx, cy, 'PAUSED', {
      fontSize: `${Math.max(28, cs * 2.5)}px`, color: '#aabbcc',
      fontFamily: 'monospace', fontStyle: 'bold'
    }).setOrigin(0.5);

    const sub = this.add.text(cx, cy + 50, 'Press Esc / P to resume', {
      fontSize: `${Math.max(12, cs * 0.8)}px`, color: '#6666aa', fontFamily: 'monospace'
    }).setOrigin(0.5);

    this.overlayObjects.push(bg, txt, sub);
  }

  showGameOver() {
    this.clearOverlay();
    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const cx = gw / 2;
    const cy = gh / 2;

    const bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.7);
    bg.fillRect(0, 0, gw, gh);

    const go = this.add.text(cx, cy - 60, 'GAME OVER', {
      fontSize: `${Math.max(28, cs * 2.2)}px`, color: '#c00000',
      fontFamily: 'monospace', fontStyle: 'bold'
    }).setOrigin(0.5);

    const sc = this.add.text(cx, cy, `Score: ${this.score}`, {
      fontSize: `${Math.max(16, cs * 1.2)}px`, color: '#ccccdd', fontFamily: 'monospace'
    }).setOrigin(0.5);

    const lv = this.add.text(cx, cy + 30, `Level ${this.level}  ·  ${this.lines} lines`, {
      fontSize: `${Math.max(12, cs * 0.9)}px`, color: '#8888aa', fontFamily: 'monospace'
    }).setOrigin(0.5);

    const btnW = 180;
    const btnH = 44;
    const btnY = cy + 70;

    const btnBg = this.add.graphics();
    btnBg.fillStyle(0x2a2a4a, 0.95);
    btnBg.fillRoundedRect(cx - btnW / 2, btnY - btnH / 2, btnW, btnH, 6);
    btnBg.lineStyle(2, 0x4a4a7a, 1);
    btnBg.strokeRoundedRect(cx - btnW / 2, btnY - btnH / 2, btnW, btnH, 6);

    const btnText = this.add.text(cx, btnY, 'RESTART', {
      fontSize: `${Math.max(14, cs * 1)}px`, color: '#ffffff',
      fontFamily: 'monospace', fontStyle: 'bold'
    }).setOrigin(0.5);

    const btnZone = this.add.zone(cx, btnY, btnW, btnH)
      .setOrigin(0.5)
      .setInteractive({ useHandCursor: true });

    btnZone.on('pointerover', () => {
      btnBg.clear();
      btnBg.fillStyle(0x3a3a6a, 0.95);
      btnBg.fillRoundedRect(cx - btnW / 2, btnY - btnH / 2, btnW, btnH, 6);
      btnBg.lineStyle(2, 0x6a6aaa, 1);
      btnBg.strokeRoundedRect(cx - btnW / 2, btnY - btnH / 2, btnW, btnH, 6);
    });
    btnZone.on('pointerout', () => {
      btnBg.clear();
      btnBg.fillStyle(0x2a2a4a, 0.95);
      btnBg.fillRoundedRect(cx - btnW / 2, btnY - btnH / 2, btnW, btnH, 6);
      btnBg.lineStyle(2, 0x4a4a7a, 1);
      btnBg.strokeRoundedRect(cx - btnW / 2, btnY - btnH / 2, btnW, btnH, 6);
    });
    btnZone.on('pointerdown', () => {
      this.audio.resume();
      this.startNewGame();
    });

    const hint = this.add.text(cx, btnY + btnH / 2 + 20, 'or press ENTER / R', {
      fontSize: `${Math.max(10, cs * 0.65)}px`, color: '#555577', fontFamily: 'monospace'
    }).setOrigin(0.5);

    this.overlayObjects.push(bg, go, sc, lv, btnBg, btnText, btnZone, hint);
  }

  /* ========== rendering ========== */
  drawCell(g, x, y, color, alpha = 1, size = null) {
    const s = size || this.cellSize;
    const pad = 1;
    g.fillStyle(color, alpha);
    g.fillRoundedRect(x * s + pad, y * s + pad, s - pad*2, s - pad*2, 2);
    g.fillStyle(0xffffff, alpha * 0.12);
    g.fillRect(x * s + pad, y * s + pad, s - pad*2, 2);
  }

  drawFrame() {
    if (this.status === 'menu') return;

    const cs = this.cellSize;

    /* grid */
    this.gridGraphics.clear();
    this.gridGraphics.fillStyle(0x111118, 1);
    this.gridGraphics.fillRect(0, 0, COLS * cs, ROWS * cs);

    /* grid lines */
    this.gridGraphics.lineStyle(1, 0x1a1a2a, 0.5);
    for (let r = 0; r <= ROWS; r++)
      this.gridGraphics.strokeRect(0, r * cs, COLS * cs, 0);
    for (let c = 0; c <= COLS; c++)
      this.gridGraphics.strokeRect(c * cs, 0, 0, ROWS * cs);

    /* locked cells */
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (this.grid[r][c] !== 0) {
          const sn = SHAPE_NAMES[this.grid[r][c] - 1];
          const color = SHAPES[sn].color;
          if (this.clearingRows.includes(r)) {
            const flash = Math.sin(this.time.now * 0.02) > 0;
            this.drawCell(this.gridGraphics, c, r, flash ? 0xffffff : color, 0.6);
          } else {
            this.drawCell(this.gridGraphics, c, r, color, 0.85);
          }
        }
      }
    }

    /* ghost */
    this.ghostGraphics.clear();
    if (this.activePiece && this.status === 'playing') {
      const p = this.activePiece;
      const { cells, renderX } = p;
      for (const [c, r] of cells)
        this.drawCell(this.ghostGraphics, renderX + c, this.ghostY + r, p.color, 0.18);
    }

    /* active piece — smooth render interpolation */
    this.pieceGraphics.clear();
    if (this.activePiece) {
      const p = this.activePiece;
      const lerp = 0.25;
      p.renderX += (p.x - p.renderX) * lerp;
      p.renderY += (p.y - p.renderY) * lerp;
      if (Math.abs(p.x - p.renderX) < 0.01) p.renderX = p.x;
      if (Math.abs(p.y - p.renderY) < 0.01) p.renderY = p.y;
      for (const [c, r] of p.cells)
        this.drawCell(this.pieceGraphics, p.renderX + c, p.renderY + r, p.color, 1.0);
    }
  }
}

/* ========== phaser config ========== */
function calcGameSize() {
  const maxH = window.innerHeight;
  const maxW = window.innerWidth;
  let cs = Math.floor(Math.min(maxW / (COLS + 8), (maxH - 40) / ROWS));
  cs = Math.max(cs, 8);
  return {
    width: COLS * cs + 240,
    height: ROWS * cs + 40,
    cellSize: cs
  };
}

const gs = calcGameSize();

const config = {
  type: Phaser.AUTO,
  parent: 'game-container',
  width: gs.width,
  height: gs.height,
  backgroundColor: '#0a0a0f',
  scene: GameScene,
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH
  },
  render: {
    antialias: false,
    pixelArt: false,
    roundPixels: true,
    antialiasGL: false
  },
  input: {
    keyboard: true,
    touch: true,
    mouse: true
  }
};

const game = new Phaser.Game(config);

/* NFR-A11Y-004: set accessible name on the Phaser canvas after boot */
game.events.on('ready', () => {
  const canvas = game.canvas;
  if (canvas) {
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', 'Inverted Tetris game board — 15 by 35 grid. Use keyboard arrow keys, X, Z, C, Space, or touch controls to play.');
    canvas.setAttribute('tabindex', '0');
  }
});

window.addEventListener('resize', () => {
  const newGs = calcGameSize();
  game.scale.setSize(newGs.width, newGs.height);
});
