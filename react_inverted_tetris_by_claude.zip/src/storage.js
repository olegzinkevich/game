import { HIGH_SCORE_KEY } from './game/constants'

// High-score persistence (FR-SCORE-005) that degrades gracefully when
// localStorage is unavailable, throws, is in private mode, or holds corrupt data
// (FR-ERR-005, FR-ERR-006). Every access is guarded; failures never crash play.

export function loadHighScore() {
  try {
    const raw = window.localStorage.getItem(HIGH_SCORE_KEY)
    if (raw == null) return 0
    const value = Number.parseInt(raw, 10)
    if (!Number.isFinite(value) || value < 0) return 0 // corrupt → default
    return value
  } catch {
    return 0
  }
}

export function saveHighScore(score) {
  try {
    window.localStorage.setItem(HIGH_SCORE_KEY, String(Math.max(0, Math.floor(score))))
    return true
  } catch {
    return false // quota exceeded / private mode / unavailable — ignore silently
  }
}
