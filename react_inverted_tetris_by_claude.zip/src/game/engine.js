// Pure game logic for inverted Tetris. No React, no DOM — every function here is
// deterministic given its inputs (FR-ERR-002), which keeps collision invariants
// (FR-COL-001) testable and reasoned about in one place.
import {
  WIDTH,
  HEIGHT,
  BASE_RISE_MS,
  MIN_RISE_MS,
  LINE_SCORES,
} from './constants'
import { ORIENTATIONS, TYPE_TO_ID, orientationSize } from './pieces'

export function createGrid() {
  return Array.from({ length: HEIGHT }, () => new Array(WIDTH).fill(0))
}

// Absolute field cells occupied by a piece at (rot, x, y).
export function pieceCells(type, rot, x, y) {
  return ORIENTATIONS[type][rot].map(([c, r]) => [x + c, y + r])
}

export function cellsOf(piece) {
  return pieceCells(piece.type, piece.rot, piece.x, piece.y)
}

// True if any cell is out of the left/right/top/bottom bounds or overlaps an
// occupied cell. The active figure may never violate this (FR-COL-001).
export function collides(grid, cells) {
  for (const [c, r] of cells) {
    if (c < 0 || c >= WIDTH || r < 0 || r >= HEIGHT) return true
    if (grid[r][c] !== 0) return true
  }
  return false
}

// Spawn at the bottom of the field, horizontally centered (FR-PIECE-004,
// FR-LIFE-002). x = floor(fieldWidth/2) - floor(pieceWidth/2); the figure sits
// flush with the bottom edge in its standard orientation.
export function spawnPiece(type) {
  const [w, h] = orientationSize(type, 0)
  const x = Math.floor(WIDTH / 2) - Math.floor(w / 2)
  const y = HEIGHT - h
  return { type, rot: 0, x, y }
}

// Can the figure ascend one cell? (Rising = decreasing row — inverted gravity,
// FR-MOVE-006.)
export function canRise(grid, piece) {
  return !collides(grid, pieceCells(piece.type, piece.rot, piece.x, piece.y - 1))
}

// Topmost landing row for a hard rise / ghost (FR-MOVE-005, FR-GHOST-001).
export function landingPiece(grid, piece) {
  let y = piece.y
  while (!collides(grid, pieceCells(piece.type, piece.rot, piece.x, y - 1))) y--
  return { ...piece, y }
}

// Kick table for three-cell figures (FR-ROT-002). The first offset that yields a
// non-colliding placement wins; if none do, the caller rejects the rotation
// (FR-ROT-003). Vertical kicks are included because gravity is inverted.
const KICKS = [
  [0, 0],
  [-1, 0], [1, 0],
  [0, -1], [0, 1],
  [-2, 0], [2, 0],
  [-1, -1], [1, -1], [-1, 1], [1, 1],
  [0, -2], [0, 2],
]

// Returns a rotated piece (with applied kick) or null if no kick is valid.
export function tryRotate(grid, piece, dir) {
  const newRot = (piece.rot + (dir > 0 ? 1 : 3)) % 4
  for (const [dx, dy] of KICKS) {
    const nx = piece.x + dx
    const ny = piece.y + dy
    if (!collides(grid, pieceCells(piece.type, newRot, nx, ny))) {
      return { ...piece, rot: newRot, x: nx, y: ny }
    }
  }
  return null
}

// Returns a moved piece or null if the move is blocked (FR-MOVE-001, FR-MOVE-002).
export function tryMove(grid, piece, dx) {
  const moved = { ...piece, x: piece.x + dx }
  if (collides(grid, cellsOf(moved))) return null
  return moved
}

// Stamp a piece's cells into the grid, returning a new grid (immutable).
export function lockPiece(grid, piece) {
  const next = grid.map((row) => row.slice())
  const id = TYPE_TO_ID[piece.type]
  for (const [c, r] of cellsOf(piece)) next[r][c] = id
  return next
}

// Clear fully-filled rows. Because the stack is anchored at the TOP in this
// inverted variant, kept rows retain their order and empty rows are appended at
// the BOTTOM, so remaining blocks settle upward and partial-row gaps are
// preserved (FR-CLEAR-001..006).
export function clearLines(grid) {
  const kept = grid.filter((row) => row.some((cell) => cell === 0))
  const cleared = HEIGHT - kept.length
  while (kept.length < HEIGHT) kept.push(new Array(WIDTH).fill(0))
  return { grid: kept, cleared }
}

// Rise interval for a level: max(50, 500 / (level + 1)) ms (FR-LEVEL-002,
// FR-CFG-001 base 500 at level 0, FR-CFG-002 floor 50).
export function riseInterval(level) {
  return Math.max(MIN_RISE_MS, BASE_RISE_MS / (level + 1))
}

// Points awarded for clearing `n` rows at `level` (FR-SCORE-002).
export function lineScore(n, level) {
  return (LINE_SCORES[n] || 0) * level
}
