// Playfield dimensions — 15 wide × 35 high (FR-GRID-001, FR-ARCH-002).
export const WIDTH = 15
export const HEIGHT = 35

// Rise timing (FR-CFG-001, FR-CFG-002, FR-LEVEL-002).
export const BASE_RISE_MS = 500 // base interval at the starting level
export const MIN_RISE_MS = 50 // interval is never allowed below this
export const SOFT_RISE_DIVISOR = 8 // soft rise accelerates ascent (FR-MOVE-004)

// Progression (FR-CFG-003, FR-LEVEL-001).
export const LINES_PER_LEVEL = 10

// Locking (FR-LOCK-002): bounded lock delay with a cap on resets so a figure
// cannot stall indefinitely.
export const LOCK_DELAY_MS = 500
export const MAX_LOCK_RESETS = 15

// Line-clear scoring scale (FR-SCORE-002). Index = rows cleared.
// Max three rows are possible in this variant (FR-CLEAR-004).
export const LINE_SCORES = [0, 100, 300, 500]

// Rise scoring (FR-SCORE-004).
export const SOFT_RISE_POINTS = 1 // per cell travelled via soft rise
export const HARD_RISE_POINTS = 2 // per cell travelled via hard rise

// Figure color ids stored in the field grid: 0 = empty, 1..4 = figure (FR-ARCH-002, FR-GRID-002).
export const COLORS = {
  0: 'transparent',
  1: '#30b5c5', // I — cyan
  2: '#c00000', // P — red
  3: '#ED6D00', // L — orange
  4: '#a0d183', // C — green
}

// localStorage key for the persisted high score (FR-SCORE-005).
export const HIGH_SCORE_KEY = 'inverted-tetris.highScore.v1'
