import {
  createGrid,
  spawnPiece,
  cellsOf,
  collides,
  canRise,
  landingPiece,
  tryMove,
  tryRotate,
  lockPiece,
  clearLines,
  riseInterval,
  lineScore,
} from './engine'
import {
  LINES_PER_LEVEL,
  LOCK_DELAY_MS,
  MAX_LOCK_RESETS,
  SOFT_RISE_DIVISOR,
  SOFT_RISE_POINTS,
  HARD_RISE_POINTS,
} from './constants'
import { drawFromBag, freshBag } from './bag'

export function initialState(highScore = 0, reducedMotion = false) {
  return {
    status: 'menu', // 'menu' | 'playing' | 'paused' | 'gameover'
    grid: createGrid(),
    active: null,
    hold: null,
    holdUsed: false,
    queue: [], // upcoming types; queue[0] is the Next preview (FR-SPAWN-002)
    bag: [],
    score: 0,
    level: 0, // starting level (base 500ms interval — FR-CFG-001)
    lines: 0,
    highScore,
    softRise: false,
    lastRiseTime: 0,
    lockStart: null, // ms timestamp when the figure first became unable to rise
    lockResets: 0,
    flash: null, // { rows: number[], until: ms } — line-clear feedback (UI-HUD-003)
    events: [], // queued sound effect names, drained by the hook
    reducedMotion,
  }
}

// Pull the next type from the queue and refill the preview + bag, returning a
// freshly spawned piece plus the advanced queue/bag.
function pullSpawn(state) {
  const queue = state.queue.slice()
  const type = queue.shift()
  let [refill, bag] = drawFromBag(state.bag)
  queue.push(refill)
  return { piece: spawnPiece(type), queue, bag }
}

function withEvents(state, ...names) {
  return { ...state, events: [...state.events, ...names] }
}

// Lock the active figure, clear lines, update score/level/lines, then spawn the
// next figure — detecting block-out game over (FR-LOCK-001, FR-CLEAR-*, FR-OVER-001).
function lockAndContinue(state, riseBonus = 0) {
  const grid1 = lockPiece(state.grid, state.active)
  const { grid, cleared } = clearLines(grid1)

  const gained = lineScore(cleared, state.level) + riseBonus
  const score = state.score + gained
  const lines = state.lines + cleared
  const level = Math.floor(lines / LINES_PER_LEVEL) // +1 every 10 lines (FR-LEVEL-001)
  const highScore = Math.max(state.highScore, score)

  const events = ['lock']
  if (cleared === 3) events.push('tripleClear')
  else if (cleared > 0) events.push('clear')

  // Spawn the next figure; if it immediately collides at the bottom spawn area,
  // it is a block-out → game over (FR-OVER-001).
  const { piece, queue, bag } = pullSpawn(state)

  let next = {
    ...state,
    grid,
    score,
    lines,
    level,
    highScore,
    queue,
    bag,
    holdUsed: false,
    lockStart: null,
    lockResets: 0,
    events: [...state.events, ...events],
  }

  if (collides(grid, cellsOf(piece))) {
    return { ...next, active: piece, status: 'gameover', softRise: false, events: [...next.events, 'gameOver'] }
  }

  // Brief screen pulse on a line clear for visual feedback (UI-HUD-003); skipped
  // under prefers-reduced-motion (NFR-A11Y-005). The hook clears it on a timer.
  const flash = cleared > 0 && !state.reducedMotion ? { cleared, id: (state.flash?.id || 0) + 1 } : state.flash

  return { ...next, active: piece, flash }
}

// Start a fresh game (FR-LIFE-002, FR-LIFE-007).
function startGame(state) {
  let bag = freshBag()
  let queue = []
  let first
  ;[first, bag] = drawFromBag(bag)
  let preview
  ;[preview, bag] = drawFromBag(bag)
  queue = [preview]
  const active = spawnPiece(first)
  return {
    ...initialState(state.highScore, state.reducedMotion),
    status: 'playing',
    active,
    queue,
    bag,
    lastRiseTime: 0,
    events: [],
  }
}

export function reducer(state, action) {
  switch (action.type) {
    case 'CLEAR_EVENTS':
      return state.events.length ? { ...state, events: [] } : state

    case 'START':
      if (state.status !== 'menu' && state.status !== 'gameover') return state
      return startGame(state)

    case 'RESTART':
      return startGame(state)

    case 'TOGGLE_PAUSE':
      if (state.status === 'playing') return { ...state, status: 'paused', softRise: false }
      if (state.status === 'paused')
        // Resume from the identical pre-pause state (FR-LIFE-006); reset the rise
        // clock so no skipped ticks avalanche after the pause.
        return { ...state, status: 'playing', lastRiseTime: action.now ?? state.lastRiseTime }
      return state

    case 'BLUR':
      // Auto-pause on tab blur without runaway loops (FR-LIFE-008).
      if (state.status === 'playing') return { ...state, status: 'paused', softRise: false }
      return state

    case 'TICK': {
      if (state.status !== 'playing' || !state.active) return state
      const { now } = action
      let s = state

      // First tick of the game / after a long gap: anchor the clock so a
      // backgrounded tab does not apply an avalanche of rises (FR-LIFE-008).
      if (s.lastRiseTime === 0 || now - s.lastRiseTime > 1000) {
        s = { ...s, lastRiseTime: now }
      }

      const interval = s.softRise
        ? Math.max(20, riseInterval(s.level) / SOFT_RISE_DIVISOR)
        : riseInterval(s.level)

      if (canRise(s.grid, s.active)) {
        s = s.lockStart != null ? { ...s, lockStart: null } : s
        if (now - s.lastRiseTime >= interval) {
          const moved = { ...s.active, y: s.active.y - 1 }
          const score = s.softRise ? s.score + SOFT_RISE_POINTS : s.score
          const highScore = Math.max(s.highScore, score)
          s = { ...s, active: moved, lastRiseTime: now, score, highScore }
        }
        return s
      }

      // Resting against the top wall or the underside of the stack.
      if (s.lockStart == null) return { ...s, lockStart: now }
      if (now - s.lockStart >= LOCK_DELAY_MS) return lockAndContinue(s)
      return s
    }

    case 'MOVE': {
      if (state.status !== 'playing' || !state.active) return state
      const moved = tryMove(state.grid, state.active, action.dir)
      if (!moved) return state // blocked move rejected (FR-MOVE-002)
      return resetLock(withEvents({ ...state, active: moved }, 'move'))
    }

    case 'ROTATE': {
      if (state.status !== 'playing' || !state.active) return state
      const rotated = tryRotate(state.grid, state.active, action.dir)
      if (!rotated) return state // impossible rotation rejected (FR-ROT-003)
      return resetLock(withEvents({ ...state, active: rotated }, 'rotate'))
    }

    case 'SOFT_RISE': {
      if (state.status !== 'playing') return state
      return state.softRise === action.on ? state : { ...state, softRise: action.on }
    }

    case 'HARD_RISE': {
      if (state.status !== 'playing' || !state.active) return state
      const landed = landingPiece(state.grid, state.active)
      const dist = state.active.y - landed.y
      const bonus = dist * HARD_RISE_POINTS // 2 points per cell (FR-SCORE-004)
      return lockAndContinue({ ...state, active: landed }, bonus)
    }

    case 'HOLD': {
      // Swap active with held figure, at most once per figure (FR-SPAWN-003).
      if (state.status !== 'playing' || !state.active || state.holdUsed) return state
      const currentType = state.active.type
      if (state.hold == null) {
        const { piece, queue, bag } = pullSpawn(state)
        return {
          ...state,
          hold: currentType,
          active: piece,
          queue,
          bag,
          holdUsed: true,
          lockStart: null,
          lockResets: 0,
        }
      }
      return {
        ...state,
        hold: currentType,
        active: spawnPiece(state.hold),
        holdUsed: true,
        lockStart: null,
        lockResets: 0,
      }
    }

    case 'CLEAR_FLASH':
      return state.flash ? { ...state, flash: null } : state

    case 'SET_REDUCED_MOTION':
      return { ...state, reducedMotion: action.value }

    default:
      return state
  }
}

// On a successful move/rotate while resting, refresh the lock delay up to a
// bounded number of times so the figure cannot stall indefinitely (FR-LOCK-002).
function resetLock(state) {
  if (state.lockStart != null && state.lockResets < MAX_LOCK_RESETS) {
    return { ...state, lockStart: null, lockResets: state.lockResets + 1 }
  }
  return state
}
