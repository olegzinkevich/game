// The four figures and their rotation states (FR-PIECE-001, FR-PIECE-003).
//
// Coordinates are [col, row] with row 0 at the TOP of the figure's bounding box,
// in the figure's standard (spawn) orientation — exactly as the requirements
// reference geometry specifies. Every figure is composed of exactly three cells.
//
//   I  (cyan)    P (red)      L (orange)    C (green)
//    █            · █          █ ·           █ ·
//    █            █ ·          █ ·           █ █
//    █            █ ·          · █
//
const BASE = {
  I: [[0, 0], [0, 1], [0, 2]], // vertical line of three
  P: [[1, 0], [0, 1], [0, 2]],
  L: [[0, 0], [0, 1], [1, 2]],
  C: [[0, 0], [0, 1], [1, 1]], // 2×2 box missing the top-right cell
}

export const TYPES = ['I', 'P', 'L', 'C']

// Field color id per figure type (FR-PIECE-002, FR-ARCH-002).
export const TYPE_TO_ID = { I: 1, P: 2, L: 3, C: 4 }

function normalize(cells) {
  const minC = Math.min(...cells.map((p) => p[0]))
  const minR = Math.min(...cells.map((p) => p[1]))
  return cells
    .map(([c, r]) => [c - minC, r - minR])
    .sort((a, b) => a[1] - b[1] || a[0] - b[0])
}

// Rotate 90° clockwise about the origin, then normalize to non-negative coords.
// CCW is the inverse, reachable as three CW steps, so a single precomputed
// 4-state table serves both directions (FR-ROT-001).
function rotateCW(cells) {
  return normalize(cells.map(([c, r]) => [-r, c]))
}

// ORIENTATIONS[type] = [state0, state1, state2, state3]; state0 is spawn.
export const ORIENTATIONS = {}
for (const t of TYPES) {
  let cur = normalize(BASE[t])
  const states = [cur]
  for (let i = 1; i < 4; i++) {
    cur = rotateCW(cur)
    states.push(cur)
  }
  ORIENTATIONS[t] = states
}

// [width, height] of a given orientation.
export function orientationSize(type, rot) {
  const cells = ORIENTATIONS[type][rot]
  return [
    Math.max(...cells.map((p) => p[0])) + 1,
    Math.max(...cells.map((p) => p[1])) + 1,
  ]
}
