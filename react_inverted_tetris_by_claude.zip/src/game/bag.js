import { TYPES } from './pieces'

// 4-bag randomizer (FR-SPAWN-001): each bag is a shuffled permutation of the
// four figures, so within every group of four spawns each figure appears exactly
// once — no duplication and no starvation.
function shuffle(arr) {
  const a = arr.slice()
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

// Draw one figure type from `bag`, refilling with a fresh shuffled bag when empty.
// Returns [type, remainingBag].
export function drawFromBag(bag) {
  let b = bag.length ? bag : shuffle(TYPES)
  const type = b[0]
  return [type, b.slice(1)]
}

export function freshBag() {
  return shuffle(TYPES)
}
