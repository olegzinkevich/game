import { useEffect } from 'react'
import { useGame } from './hooks/useGame'
import { useKeyboard } from './hooks/useKeyboard'
import { Board } from './components/Board'
import { SidePanel } from './components/SidePanel'
import { Overlay } from './components/Overlay'
import { TouchControls } from './components/TouchControls'

export default function App() {
  const { state, stateRef, actions } = useGame()
  useKeyboard(stateRef, actions)

  // Surface otherwise-unhandled async errors without an infinite loop (FR-ERR-008).
  useEffect(() => {
    const onError = (e) => {
      // eslint-disable-next-line no-console
      console.error('Unhandled error:', e.error || e.reason || e.message)
    }
    window.addEventListener('error', onError)
    window.addEventListener('unhandledrejection', onError)
    return () => {
      window.removeEventListener('error', onError)
      window.removeEventListener('unhandledrejection', onError)
    }
  }, [])

  return (
    <div className="app">
      <main className="game-area">
        <div className="board-wrap">
          <Board stateRef={stateRef} />
          <Overlay state={state} actions={actions} />
        </div>
        <SidePanel state={state} actions={actions} />
      </main>
      <TouchControls actions={actions} />
    </div>
  )
}
