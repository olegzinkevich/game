import { useEffect, useRef } from 'react'

// Maps the keyboard control scheme (FR-CTRL-001) onto game actions, suppresses
// browser default scrolling/zoom for game keys (FR-CTRL-005), and handles key
// repeat deterministically without doubled soft-rise toggles (FR-CTRL-003).
export function useKeyboard(stateRef, actions) {
  const softHeld = useRef(false)

  useEffect(() => {
    const GAME_KEYS = new Set([' ', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'])

    const onKeyDown = (e) => {
      if (GAME_KEYS.has(e.key)) e.preventDefault() // no page scroll on arrows/Space

      const status = stateRef.current.status

      // Pause / Resume — allowed in playing & paused (FR-LIFE-004/006).
      if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') {
        if (status === 'playing' || status === 'paused') actions.togglePause()
        return
      }

      // Restart — available from any state via R (FR-LIFE-007).
      if (e.key === 'r' || e.key === 'R') {
        actions.restart()
        return
      }

      if (status === 'menu') {
        if (e.key === 'Enter' || e.key === ' ') actions.start()
        return
      }

      // While paused, ignore all gameplay input except Resume/Restart (FR-LIFE-005).
      if (status !== 'playing') return

      switch (e.key) {
        case 'ArrowLeft':
          actions.move(-1)
          break
        case 'ArrowRight':
          actions.move(1)
          break
        case 'ArrowUp':
          if (!softHeld.current) {
            softHeld.current = true
            actions.softRise(true)
          }
          break
        case ' ':
          if (!e.repeat) actions.hardRise()
          break
        case 'x':
        case 'X':
          if (!e.repeat) actions.rotate(1)
          break
        case 'z':
        case 'Z':
        case 'Control':
          if (!e.repeat) actions.rotate(-1)
          break
        case 'c':
        case 'C':
        case 'Shift':
          if (!e.repeat) actions.hold()
          break
        default:
          break
      }
    }

    const onKeyUp = (e) => {
      if (e.key === 'ArrowUp') {
        softHeld.current = false
        actions.softRise(false)
      }
    }

    window.addEventListener('keydown', onKeyDown, { passive: false })
    window.addEventListener('keyup', onKeyUp)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
    }
  }, [stateRef, actions])
}
