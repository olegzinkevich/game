import { useReducer, useEffect, useRef, useCallback } from 'react'
import { reducer, initialState } from '../game/reducer'
import { loadHighScore, saveHighScore } from '../storage'
import { sfx, resumeAudio } from '../audio'

const prefersReducedMotion = () => {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches
  } catch {
    return false
  }
}

export function useGame() {
  const [state, dispatch] = useReducer(
    reducer,
    undefined,
    () => initialState(loadHighScore(), prefersReducedMotion()),
  )

  // Keep a ref to the latest state so the single rAF loop reads current values
  // without re-subscribing (FR-LIFE-008: exactly one loop, no duplicates).
  const stateRef = useRef(state)
  stateRef.current = state

  // ---- Single timer-driven game loop (FR-ARCH-001, FR-LIFE-003) ----
  useEffect(() => {
    let raf
    const loop = (now) => {
      dispatch({ type: 'TICK', now })
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [])

  // ---- Drain queued sound effects (FR-AUDIO-001..005) ----
  useEffect(() => {
    if (!state.events.length) return
    for (const name of state.events) {
      if (typeof sfx[name] === 'function') sfx[name]()
    }
    dispatch({ type: 'CLEAR_EVENTS' })
  }, [state.events])

  // ---- Persist high score across reloads (FR-SCORE-005) ----
  const lastSaved = useRef(state.highScore)
  useEffect(() => {
    if (state.highScore !== lastSaved.current) {
      lastSaved.current = state.highScore
      saveHighScore(state.highScore)
    }
  }, [state.highScore])

  // ---- Line-clear flash auto-expires (UI-HUD-003) ----
  useEffect(() => {
    if (!state.flash) return
    const t = setTimeout(() => dispatch({ type: 'CLEAR_FLASH' }), 260)
    return () => clearTimeout(t)
  }, [state.flash])

  // ---- Auto-pause on tab blur; refit handled by layout (FR-LIFE-008, FR-ERR-004) ----
  useEffect(() => {
    const onVisibility = () => {
      if (document.hidden) dispatch({ type: 'BLUR' })
    }
    window.addEventListener('blur', onVisibility)
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      window.removeEventListener('blur', onVisibility)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [])

  // ---- React to prefers-reduced-motion changes live (NFR-A11Y-005) ----
  useEffect(() => {
    let mq
    try {
      mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    } catch {
      return
    }
    const handler = () => dispatch({ type: 'SET_REDUCED_MOTION', value: mq.matches })
    mq.addEventListener?.('change', handler)
    return () => mq.removeEventListener?.('change', handler)
  }, [])

  // ---- Action creators (stable identities) ----
  const start = useCallback(() => {
    resumeAudio()
    dispatch({ type: 'START' })
  }, [])
  const restart = useCallback(() => {
    resumeAudio()
    dispatch({ type: 'RESTART' })
  }, [])
  const move = useCallback((dir) => dispatch({ type: 'MOVE', dir }), [])
  const rotate = useCallback((dir) => dispatch({ type: 'ROTATE', dir }), [])
  const hardRise = useCallback(() => dispatch({ type: 'HARD_RISE' }), [])
  const softRise = useCallback((on) => dispatch({ type: 'SOFT_RISE', on }), [])
  const hold = useCallback(() => dispatch({ type: 'HOLD' }), [])
  const togglePause = useCallback(
    () => dispatch({ type: 'TOGGLE_PAUSE', now: performance.now() }),
    [],
  )

  return {
    state,
    stateRef,
    actions: { start, restart, move, rotate, hardRise, softRise, hold, togglePause },
  }
}
