// Minimal WebAudio sound effects (FR-AUDIO-001..005), synthesized with
// oscillators so the bundle carries no audio assets. Everything is feature-
// detected and wrapped in try/catch: when the Web Audio API is unavailable the
// game stays fully playable and never crashes (NFR-COMPAT-003).

let ctx = null
let enabled = true

function getCtx() {
  if (ctx) return ctx
  try {
    const AC = window.AudioContext || window.webkitAudioContext
    if (!AC) return null
    ctx = new AC()
    return ctx
  } catch {
    return null
  }
}

// Must be called from a user gesture (e.g. Start) to satisfy autoplay policies.
export function resumeAudio() {
  const c = getCtx()
  try {
    if (c && c.state === 'suspended') c.resume()
  } catch {
    /* ignore */
  }
}

export function setAudioEnabled(on) {
  enabled = on
}

export function isAudioEnabled() {
  return enabled
}

function tone({ freq = 440, type = 'square', duration = 0.06, gain = 0.05, slideTo = null }) {
  if (!enabled) return
  const c = getCtx()
  if (!c) return
  try {
    const now = c.currentTime
    const osc = c.createOscillator()
    const amp = c.createGain()
    osc.type = type
    osc.frequency.setValueAtTime(freq, now)
    if (slideTo != null) osc.frequency.exponentialRampToValueAtTime(slideTo, now + duration)
    amp.gain.setValueAtTime(0.0001, now)
    amp.gain.exponentialRampToValueAtTime(gain, now + 0.005)
    amp.gain.exponentialRampToValueAtTime(0.0001, now + duration)
    osc.connect(amp).connect(c.destination)
    osc.start(now)
    osc.stop(now + duration + 0.02)
  } catch {
    /* ignore — audio is non-essential */
  }
}

export const sfx = {
  move: () => tone({ freq: 220, type: 'square', duration: 0.03, gain: 0.03 }),
  rotate: () => tone({ freq: 330, type: 'square', duration: 0.04, gain: 0.035 }),
  lock: () => tone({ freq: 160, type: 'sine', duration: 0.08, gain: 0.05 }),
  clear: () => tone({ freq: 520, type: 'triangle', duration: 0.12, gain: 0.06, slideTo: 780 }),
  tripleClear: () => tone({ freq: 660, type: 'triangle', duration: 0.18, gain: 0.07, slideTo: 1320 }),
  gameOver: () => tone({ freq: 200, type: 'sawtooth', duration: 0.5, gain: 0.06, slideTo: 60 }),
}
