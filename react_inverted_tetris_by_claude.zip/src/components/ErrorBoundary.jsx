import { Component } from 'react'

// Catches unhandled render/runtime errors and surfaces them gracefully — no
// white-screen-of-death and no infinite console error loop (FR-ERR-008).
export class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { error: null }
  }

  static getDerivedStateFromError(error) {
    return { error }
  }

  componentDidCatch(error, info) {
    // Log once; do not re-throw (avoids an error loop).
    // eslint-disable-next-line no-console
    console.error('Game error caught by boundary:', error, info)
  }

  handleReload = () => {
    try {
      window.location.reload()
    } catch {
      this.setState({ error: null })
    }
  }

  render() {
    if (this.state.error) {
      return (
        <div className="error-screen" role="alert">
          <div className="overlay-card">
            <h1 className="title">Something went wrong</h1>
            <p className="subtitle">The game hit an unexpected error but did not crash the page.</p>
            <button type="button" className="btn btn-large" onClick={this.handleReload}>
              Reload
            </button>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}
