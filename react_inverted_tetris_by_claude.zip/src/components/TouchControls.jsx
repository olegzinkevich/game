import { useRef } from 'react'

// On-screen touch controls for every must-have action with ≥44×44px targets
// (FR-CTRL-004). touch-action:none on the buttons (see CSS) suppresses default
// gestures so taps do not scroll or zoom the page (FR-CTRL-005).
export function TouchControls({ actions }) {
  const repeatRef = useRef(null)

  const startRepeat = (fn) => (e) => {
    e.preventDefault()
    fn()
    stopRepeat()
    // Delayed auto-repeat for horizontal movement.
    repeatRef.current = setTimeout(() => {
      repeatRef.current = setInterval(fn, 70)
    }, 220)
  }
  const stopRepeat = () => {
    if (repeatRef.current) {
      clearTimeout(repeatRef.current)
      clearInterval(repeatRef.current)
      repeatRef.current = null
    }
  }

  const tap = (fn) => (e) => {
    e.preventDefault()
    fn()
  }

  return (
    <div className="touch-controls" aria-label="Touch controls">
      <div className="touch-row">
        <button
          type="button"
          className="tbtn"
          aria-label="Move left"
          onPointerDown={startRepeat(() => actions.move(-1))}
          onPointerUp={stopRepeat}
          onPointerLeave={stopRepeat}
          onPointerCancel={stopRepeat}
        >
          ◀
        </button>
        <button
          type="button"
          className="tbtn"
          aria-label="Rotate counter-clockwise"
          onPointerDown={tap(() => actions.rotate(-1))}
        >
          ⟲
        </button>
        <button
          type="button"
          className="tbtn"
          aria-label="Rotate clockwise"
          onPointerDown={tap(() => actions.rotate(1))}
        >
          ⟳
        </button>
        <button
          type="button"
          className="tbtn"
          aria-label="Move right"
          onPointerDown={startRepeat(() => actions.move(1))}
          onPointerUp={stopRepeat}
          onPointerLeave={stopRepeat}
          onPointerCancel={stopRepeat}
        >
          ▶
        </button>
      </div>
      <div className="touch-row">
        <button
          type="button"
          className="tbtn"
          aria-label="Soft rise"
          onPointerDown={tap(() => actions.softRise(true))}
          onPointerUp={tap(() => actions.softRise(false))}
          onPointerLeave={tap(() => actions.softRise(false))}
          onPointerCancel={tap(() => actions.softRise(false))}
        >
          ▲ soft
        </button>
        <button
          type="button"
          className="tbtn tbtn-wide"
          aria-label="Hard rise"
          onPointerDown={tap(actions.hardRise)}
        >
          ⤒ hard
        </button>
        <button
          type="button"
          className="tbtn"
          aria-label="Hold figure"
          onPointerDown={tap(actions.hold)}
        >
          hold
        </button>
      </div>
    </div>
  )
}
