import { MiniPiece } from './MiniPiece'

// Side panel: score, level, lines, Next preview, Hold, New Game/Restart, and a
// Game Over indicator (UI-LAYOUT-001, UI-HUD-001).
export function SidePanel({ state, actions }) {
  const { score, level, lines, highScore, queue, hold, status } = state
  const next = queue[0] || null

  return (
    <aside className="side-panel" aria-label="Game status and controls">
      <div className="stat-grid">
        <Stat label="Score" value={score} />
        <Stat label="High" value={highScore} />
        <Stat label="Level" value={level} />
        <Stat label="Lines" value={lines} />
      </div>

      <div className="preview-row">
        <div className="preview-box">
          <h2 className="panel-h">Next</h2>
          <MiniPiece type={next} label="Next figure" />
        </div>
        <div className="preview-box">
          <h2 className="panel-h">Hold</h2>
          <MiniPiece type={hold} label="Held figure" />
        </div>
      </div>

      {status === 'gameover' && (
        <div className="gameover-indicator" role="status">
          GAME OVER
        </div>
      )}

      <div className="panel-actions">
        <button type="button" className="btn" onClick={actions.restart}>
          {status === 'menu' ? 'New Game' : 'Restart'}
        </button>
        {(status === 'playing' || status === 'paused') && (
          <button type="button" className="btn btn-secondary" onClick={actions.togglePause}>
            {status === 'paused' ? 'Resume' : 'Pause'}
          </button>
        )}
      </div>

      <details className="help">
        <summary>Controls</summary>
        <ul>
          <li><b>← →</b> move</li>
          <li><b>↑</b> soft rise</li>
          <li><b>Space</b> hard rise</li>
          <li><b>X</b> / <b>Z</b> rotate</li>
          <li><b>C</b> / <b>Shift</b> hold</li>
          <li><b>P</b> / <b>Esc</b> pause</li>
          <li><b>R</b> restart</li>
        </ul>
      </details>
    </aside>
  )
}

function Stat({ label, value }) {
  return (
    <div className="stat">
      <span className="stat-label">{label}</span>
      <span className="stat-value">{value.toLocaleString()}</span>
    </div>
  )
}
