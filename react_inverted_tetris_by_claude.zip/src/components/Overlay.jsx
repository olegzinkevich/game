// Full-board overlays for start menu, pause, and game over (FR-LIFE-002,
// FR-LIFE-004, FR-OVER-002). Buttons are keyboard-operable with visible focus
// (NFR-A11Y-001) via the shared .btn styles.
export function Overlay({ state, actions }) {
  const { status, score, highScore } = state
  if (status === 'playing') return null

  if (status === 'menu') {
    return (
      <div className="overlay" role="dialog" aria-label="Start screen">
        <div className="overlay-card">
          <h1 className="title">Inverted Tetris</h1>
          <p className="subtitle">Three-cell figures rise from the bottom. Lock them against the top.</p>
          <button type="button" className="btn btn-large" onClick={actions.start} autoFocus>
            Start
          </button>
          <p className="hint">Press Enter or Space</p>
        </div>
      </div>
    )
  }

  if (status === 'paused') {
    return (
      <div className="overlay" role="dialog" aria-label="Paused">
        <div className="overlay-card">
          <h1 className="title">Paused</h1>
          <button type="button" className="btn btn-large" onClick={actions.togglePause} autoFocus>
            Resume
          </button>
          <p className="hint">Press P or Esc</p>
        </div>
      </div>
    )
  }

  // game over
  return (
    <div className="overlay" role="dialog" aria-label="Game over">
      <div className="overlay-card">
        <h1 className="title">Game Over</h1>
        <p className="final-score">
          Score <strong>{score.toLocaleString()}</strong>
        </p>
        <p className="subtitle">Best {highScore.toLocaleString()}</p>
        <button type="button" className="btn btn-large" onClick={actions.restart} autoFocus>
          Restart
        </button>
        <p className="hint">Press R</p>
      </div>
    </div>
  )
}
