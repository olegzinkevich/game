import { useEffect, useRef } from 'react'
import { WIDTH, HEIGHT, COLORS } from '../game/constants'
import { cellsOf, landingPiece } from '../game/engine'

// Canvas playfield. Renders in its own requestAnimationFrame loop reading the
// latest game state from a ref, which decouples smooth 60 FPS drawing
// (NFR-PERF-001) from the logic tick and keeps the line-clear flash animating.
// The backing store is scaled by devicePixelRatio for crisp HiDPI output
// (NFR-COMPAT-005) and the aspect ratio 15:35 is preserved by the container
// (UI-RESP-002).
export function Board({ stateRef }) {
  const canvasRef = useRef(null)
  const sizeRef = useRef({ cell: 10, w: 150, h: 350, dpr: 1 })

  // Resize the backing store to match the rendered size and DPR.
  useEffect(() => {
    const canvas = canvasRef.current
    const resize = () => {
      const rect = canvas.getBoundingClientRect()
      const dpr = Math.min(window.devicePixelRatio || 1, 3)
      const cssW = Math.max(1, rect.width)
      const cssH = Math.max(1, rect.height)
      canvas.width = Math.round(cssW * dpr)
      canvas.height = Math.round(cssH * dpr)
      sizeRef.current = { cell: cssW / WIDTH, w: cssW, h: cssH, dpr }
    }
    resize()
    let ro
    if ('ResizeObserver' in window) {
      ro = new ResizeObserver(resize)
      ro.observe(canvas)
    }
    window.addEventListener('resize', resize)
    window.addEventListener('orientationchange', resize)
    return () => {
      ro?.disconnect()
      window.removeEventListener('resize', resize)
      window.removeEventListener('orientationchange', resize)
    }
  }, [])

  // Draw loop.
  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    let raf

    const drawCell = (cell, col, row, mode, color) => {
      const x = col * cell
      const y = row * cell
      if (mode === 'ghost') {
        ctx.strokeStyle = color
        ctx.globalAlpha = 0.55
        ctx.lineWidth = Math.max(1, cell * 0.12)
        ctx.strokeRect(x + cell * 0.12, y + cell * 0.12, cell * 0.76, cell * 0.76)
        ctx.globalAlpha = 1
        return
      }
      // Body
      ctx.fillStyle = color
      ctx.fillRect(x + 0.5, y + 0.5, cell - 1, cell - 1)
      // Bevel highlight (shape/position cue beyond color — NFR-A11Y-002)
      ctx.fillStyle = 'rgba(255,255,255,0.28)'
      ctx.fillRect(x + 0.5, y + 0.5, cell - 1, Math.max(1, cell * 0.16))
      ctx.fillStyle = 'rgba(0,0,0,0.22)'
      ctx.fillRect(x + 0.5, y + cell - 1 - Math.max(1, cell * 0.16), cell - 1, Math.max(1, cell * 0.16))
      if (mode === 'active') {
        ctx.strokeStyle = 'rgba(255,255,255,0.9)'
        ctx.lineWidth = Math.max(1, cell * 0.08)
        ctx.strokeRect(x + 1, y + 1, cell - 2, cell - 2)
      }
    }

    const render = () => {
      const s = stateRef.current
      const { cell, w, h, dpr } = sizeRef.current
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, w, h)

      // Background
      ctx.fillStyle = '#0b1020'
      ctx.fillRect(0, 0, w, h)

      // Grid lines
      ctx.strokeStyle = 'rgba(255,255,255,0.05)'
      ctx.lineWidth = 1
      for (let c = 0; c <= WIDTH; c++) {
        ctx.beginPath()
        ctx.moveTo(Math.round(c * cell) + 0.5, 0)
        ctx.lineTo(Math.round(c * cell) + 0.5, h)
        ctx.stroke()
      }
      for (let r = 0; r <= HEIGHT; r++) {
        ctx.beginPath()
        ctx.moveTo(0, Math.round(r * cell) + 0.5)
        ctx.lineTo(w, Math.round(r * cell) + 0.5)
        ctx.stroke()
      }

      // Locked cells
      const grid = s.grid
      for (let r = 0; r < HEIGHT; r++) {
        for (let c = 0; c < WIDTH; c++) {
          const id = grid[r][c]
          if (id !== 0) drawCell(cell, c, r, 'locked', COLORS[id])
        }
      }

      // Ghost (hard-rise landing) + active figure
      if (s.active && (s.status === 'playing' || s.status === 'paused')) {
        const color = COLORS[{ I: 1, P: 2, L: 3, C: 4 }[s.active.type]]
        const ghost = landingPiece(grid, s.active)
        if (ghost.y !== s.active.y) {
          for (const [c, r] of cellsOf(ghost)) drawCell(cell, c, r, 'ghost', color)
        }
        for (const [c, r] of cellsOf(s.active)) drawCell(cell, c, r, 'active', color)
      }

      // Line-clear flash overlay (UI-HUD-003)
      if (s.flash) {
        ctx.fillStyle = 'rgba(255,255,255,0.18)'
        ctx.fillRect(0, 0, w, h)
      }

      raf = requestAnimationFrame(render)
    }
    raf = requestAnimationFrame(render)
    return () => cancelAnimationFrame(raf)
  }, [stateRef])

  return (
    <canvas
      ref={canvasRef}
      className="board"
      role="img"
      aria-label="Inverted Tetris playfield, 15 columns by 35 rows. Figures rise from the bottom."
    />
  )
}
