import { useEffect, useRef } from 'react'
import { COLORS } from '../game/constants'
import { ORIENTATIONS, TYPE_TO_ID, orientationSize } from '../game/pieces'

// Small canvas showing a single figure in its spawn orientation, used for the
// Next preview (FR-SPAWN-002) and Hold slot (FR-SPAWN-003).
export function MiniPiece({ type, label }) {
  const ref = useRef(null)

  useEffect(() => {
    const canvas = ref.current
    const ctx = canvas.getContext('2d')
    const dpr = Math.min(window.devicePixelRatio || 1, 3)
    const rect = canvas.getBoundingClientRect()
    const cssW = Math.max(1, rect.width)
    const cssH = Math.max(1, rect.height)
    canvas.width = Math.round(cssW * dpr)
    canvas.height = Math.round(cssH * dpr)
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx.clearRect(0, 0, cssW, cssH)

    if (!type) return
    const cells = ORIENTATIONS[type][0]
    const [w, h] = orientationSize(type, 0)
    const cell = Math.min(cssW / (w + 1), cssH / (h + 1), 18)
    const offX = (cssW - w * cell) / 2
    const offY = (cssH - h * cell) / 2
    const color = COLORS[TYPE_TO_ID[type]]
    for (const [c, r] of cells) {
      const x = offX + c * cell
      const y = offY + r * cell
      ctx.fillStyle = color
      ctx.fillRect(x + 0.5, y + 0.5, cell - 1, cell - 1)
      ctx.fillStyle = 'rgba(255,255,255,0.25)'
      ctx.fillRect(x + 0.5, y + 0.5, cell - 1, Math.max(1, cell * 0.16))
    }
  }, [type])

  return (
    <canvas
      ref={ref}
      className="mini-piece"
      role="img"
      aria-label={type ? `${label}: figure ${type}` : `${label}: empty`}
    />
  )
}
