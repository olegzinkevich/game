import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Static-hosting compatible build (NFR-COMPAT-004): relative base so the
// production bundle works from any path on plain static HTTPS hosting.
export default defineConfig({
  base: './',
  plugins: [react()],
  server: {
    // Bind to IPv4 so http://localhost / http://127.0.0.1 resolve.
    // Without this, Vite was binding to IPv6 (::1) only, causing
    // "This site can't be reached" in the browser.
    host: '127.0.0.1',
    port: 5173,
  },
  build: {
    target: 'es2018',
    sourcemap: false,
  },
})
