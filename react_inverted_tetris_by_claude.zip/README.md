# Inverted Tetris (React)

A web-based **inverted** Tetris: three-cell figures **rise from the bottom upward** and lock
against the top wall or the underside of the stack. Built with React + Vite, canvas rendering,
no runtime dependencies beyond React.

## Run

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build → dist/ (static-hosting compatible)
npm run preview  # serve the production build
```

The production build is fully static (relative asset paths) and runs over plain HTTPS with no
server-side runtime (NFR-COMPAT-004).

## Controls

| Action            | Keys                          |
| ----------------- | ----------------------------- |
| Move left / right | ← / →                         |
| Soft rise (hold)  | ↑                             |
| Hard rise         | Space                         |
| Rotate CW / CCW   | X / (Z or Ctrl)               |
| Hold              | C or Shift                    |
| Pause / Resume    | P or Esc                      |
| Restart           | R                             |
| Start (menu)      | Enter or Space                |

On-screen touch controls (≥44×44px) appear on touch / coarse-pointer devices.

## The four figures

All figures are **exactly three cells**.

```
I (cyan #30b5c5)   P (red #c00000)   L (orange #ED6D00)   C (green #a0d183)
 █                  · █               █ ·                  █ ·
 █                  █ ·               █ ·                  █ █
 █                  █ ·               · █
```

## Architecture

- `src/game/` — pure, deterministic logic (no DOM): `pieces.js` (geometry + rotations),
  `engine.js` (collision, spawn, line clear, scoring), `bag.js` (4-bag randomizer),
  `reducer.js` (the state machine), `constants.js`.
- `src/hooks/` — `useGame.js` (single rAF game loop, audio drain, persistence, auto-pause),
  `useKeyboard.js` (bindings + default-gesture suppression).
- `src/components/` — `Board.jsx` (HiDPI canvas with its own render loop), `SidePanel.jsx`,
  `MiniPiece.jsx` (Next/Hold), `TouchControls.jsx`, `Overlay.jsx`, `ErrorBoundary.jsx`.
- Field: a 15×35 2-D array — `0` empty, `1..4` figure color id.

## Requirements traceability

Every requirement id in `requirements_doc/requirements.md` is implemented:

| Area | IDs | Where |
| --- | --- | --- |
| Lifecycle | NFR-LOAD-001, FR-LIFE-001..008 | `App.jsx`, `useGame.js` (single rAF loop, blur auto-pause, restart), `reducer.js` (pause/resume identical-state) |
| Grid | FR-GRID-001..003 | `constants.js` (15×35), `engine.js` (`createGrid`), `Board.jsx` (full field visible, 15:35) |
| Pieces / config | FR-PIECE-001..004, FR-CFG-001..003 | `pieces.js` (4 figures, 3 cells, colors), `engine.js` (`spawnPiece`, `riseInterval`) |
| Spawning / queue | FR-SPAWN-001..003 | `bag.js` (4-bag), `reducer.js` (`pullSpawn` Next preview, Hold once-per-figure) |
| Movement / rotation / collision / lock | FR-MOVE-001..006, FR-ROT-001..003, FR-COL-001, FR-LOCK-001..002, FR-GHOST-001 | `engine.js`, `reducer.js` (rise, soft/hard rise, kicks, lock delay), `Board.jsx` (ghost) |
| Line clearing | FR-CLEAR-001..006 | `engine.js` `clearLines` (top-anchored settle, gaps preserved, max 3) |
| Score / level | FR-SCORE-001..005, FR-LEVEL-001..002 | `engine.js` (`lineScore`), `reducer.js` (rise points, level every 10 lines), `storage.js` (high score) |
| Game over | FR-OVER-001..004 | `reducer.js` (block-out, input ignored, no spawn), `Overlay.jsx`, `SidePanel.jsx` |
| Architecture | FR-ARCH-001..002 | `useGame.js` (rAF timer), `engine.js` (2-D array) |
| Controls | FR-CTRL-001..005, NFR-CTRL-002 | `useKeyboard.js`, `TouchControls.jsx`, `styles.css` (touch-action) |
| HUD / layout | UI-HUD-001..003, UI-LAYOUT-001 | `SidePanel.jsx`, `Board.jsx` (distinct active/ghost/locked, flash) |
| Responsiveness | UI-RESP-001..003 | `styles.css` (aspect-ratio, no overflow, 320px+) |
| Audio | FR-AUDIO-001..005 | `audio.js` (synthesized, feature-detected) |
| Accessibility | NFR-A11Y-001..005 | focus styles, aria-labels, contrast tokens, reduced-motion, shape cues |
| Performance | NFR-PERF-001..005 | decoupled render loop, ~52 KB gzipped JS, no per-frame allocation churn |
| Compatibility | NFR-COMPAT-001..005 | evergreen APIs, graceful audio fallback, static build, DPR scaling |
| Resilience | FR-ERR-001..008 | deterministic reducer, `ErrorBoundary`, guarded `localStorage`, hard-rise into full column |
