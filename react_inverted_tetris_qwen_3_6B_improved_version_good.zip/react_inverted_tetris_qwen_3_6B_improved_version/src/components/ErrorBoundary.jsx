import { Component } from 'react';

export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100vh',
          background: '#0a0a1a',
          fontFamily: "'Courier New', Courier, monospace",
          color: '#fff',
          gap: '16px',
          padding: '20px',
          textAlign: 'center',
        }}>
          <div style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#ff4444',
            textTransform: 'uppercase',
            letterSpacing: '3px',
          }}>
            Something went wrong
          </div>
          <pre style={{
            fontSize: '12px',
            color: '#888',
            background: 'rgba(255,255,255,0.05)',
            padding: '12px',
            borderRadius: '4px',
            maxWidth: '100%',
            overflow: 'auto',
            maxHeight: '200px',
          }}>
            {this.state.error?.toString()}
          </pre>
          <button
            onClick={() => {
              this.setState({ hasError: false, error: null });
              window.location.reload();
            }}
            style={{
              padding: '12px 24px',
              fontFamily: 'inherit',
              fontSize: '14px',
              fontWeight: 'bold',
              border: '2px solid #30b5c5',
              borderRadius: '6px',
              background: 'rgba(48, 181, 197, 0.2)',
              color: '#30b5c5',
              cursor: 'pointer',
              textTransform: 'uppercase',
              letterSpacing: '1px',
              marginTop: '8px',
            }}
          >
            Reload
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}