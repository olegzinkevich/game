export default function TouchControls({
  onLeft, onRight, onSoftRise, onHardRise, onReleaseSoftRise,
  onRotateCW, onRotateCCW, onHold, onPause,
  pressedKeysRef,
  isPaused = false,
}) {
  const btnStyle = {
    width: '64px',
    height: '64px',
    fontSize: '22px',
    fontWeight: 'bold',
    border: '2px solid rgba(255,255,255,0.3)',
    borderRadius: '12px',
    backgroundColor: 'rgba(255,255,255,0.1)',
    color: '#fff',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    userSelect: 'none',
    WebkitUserSelect: 'none',
    touchAction: 'manipulation',
    WebkitTapHighlightColor: 'transparent',
  };

  return (
    <div className="touch-controls" role="group" aria-label="Touch controls">
      <div className="touch-row">
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); if (!isPaused) onRotateCCW(); }}
          onMouseDown={(e) => { e.preventDefault(); if (!isPaused) onRotateCCW(); }}
          aria-label="Rotate counter-clockwise"
          disabled={isPaused}
        >
          ↶
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); if (!isPaused) onRotateCW(); }}
          onMouseDown={(e) => { e.preventDefault(); if (!isPaused) onRotateCW(); }}
          aria-label="Rotate clockwise"
          disabled={isPaused}
        >
          ↷
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); if (!isPaused) onHold(); }}
          onMouseDown={(e) => { e.preventDefault(); if (!isPaused) onHold(); }}
          aria-label="Hold piece"
          disabled={isPaused}
        >
          H
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onClick={(e) => { e.preventDefault(); onPause(); }}
          aria-label="Pause"
        >
          ⏸
        </button>
      </div>
      <div className="touch-row">
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); if (!isPaused && pressedKeysRef) pressedKeysRef.current.add('left'); }}
          onTouchEnd={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.delete('left'); }}
          onMouseDown={(e) => { e.preventDefault(); if (!isPaused && pressedKeysRef) pressedKeysRef.current.add('left'); }}
          onMouseUp={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.delete('left'); }}
          onMouseLeave={(e) => { if (pressedKeysRef) pressedKeysRef.current.delete('left'); }}
          aria-label="Move left"
          disabled={isPaused}
        >
          ←
        </button>
        <button
          className="touch-btn"
          style={{ ...btnStyle, width: '90px' }}
          onTouchStart={(e) => { e.preventDefault(); if (!isPaused) onSoftRise(); }}
          onTouchEnd={(e) => { e.preventDefault(); if (onReleaseSoftRise) onReleaseSoftRise(); if (pressedKeysRef) pressedKeysRef.current.delete('softRise'); }}
          onMouseDown={(e) => { e.preventDefault(); if (!isPaused) onSoftRise(); }}
          onMouseUp={(e) => { e.preventDefault(); if (onReleaseSoftRise) onReleaseSoftRise(); if (pressedKeysRef) pressedKeysRef.current.delete('softRise'); }}
          onMouseLeave={(e) => { if (onReleaseSoftRise) onReleaseSoftRise(); if (pressedKeysRef) pressedKeysRef.current.delete('softRise'); }}
          aria-label="Soft rise"
          disabled={isPaused}
        >
          ↑
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); if (!isPaused && pressedKeysRef) pressedKeysRef.current.add('right'); }}
          onTouchEnd={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.delete('right'); }}
          onMouseDown={(e) => { e.preventDefault(); if (!isPaused && pressedKeysRef) pressedKeysRef.current.add('right'); }}
          onMouseUp={(e) => { e.preventDefault(); if (pressedKeysRef) pressedKeysRef.current.delete('right'); }}
          onMouseLeave={(e) => { if (pressedKeysRef) pressedKeysRef.current.delete('right'); }}
          aria-label="Move right"
          disabled={isPaused}
        >
          →
        </button>
        <button
          className="touch-btn"
          style={{ ...btnStyle, backgroundColor: 'rgba(255,80,80,0.25)' }}
          onTouchStart={(e) => { e.preventDefault(); if (!isPaused) onHardRise(); }}
          onMouseDown={(e) => { e.preventDefault(); if (!isPaused) onHardRise(); }}
          aria-label="Hard rise"
          disabled={isPaused}
        >
          ⏫
        </button>
      </div>
    </div>
  );
}
