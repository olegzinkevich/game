import { useEffect, useState } from 'react';
import { PIECES } from '../utils/pieces';

export default function SidePanel({ stateRef, onStart, onRestart, onPause }) {
  const [, setTick] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 100);
    return () => clearInterval(interval);
  }, []);

  const s = stateRef.current;

  const renderMiniPiece = (name, cellSize) => {
    if (!name) return null;
    const piece = PIECES[name];
    const cells = piece.cells;
    const maxX = Math.max(...cells.map(([x]) => x));
    const maxY = Math.max(...cells.map(([, y]) => y));
    const minX = Math.min(...cells.map(([x]) => x));
    const minY = Math.min(...cells.map(([, y]) => y));
    const w = maxX - minX + 1;
    const h = maxY - minY + 1;

    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        {Array.from({ length: h }, (_, dy) => (
          <div key={dy} style={{ display: 'flex' }}>
            {Array.from({ length: w }, (_, dx) => {
              const hasCell = cells.some(([cx, cy]) => cx - minX === dx && cy - minY === dy);
              return (
                <div
                  key={dx}
                  style={{
                    width: cellSize,
                    height: cellSize,
                    backgroundColor: hasCell ? piece.color : 'transparent',
                    border: hasCell ? `1px solid ${piece.darkColor}` : '1px solid transparent',
                    borderRadius: 2,
                  }}
                />
              );
            })}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="side-panel" role="complementary" aria-label="Game information">
      <div className="panel-section">
        <div className="label">SCORE</div>
        <div className="value score-value" aria-label={`Score: ${s.score}`}>{s.score.toLocaleString()}</div>
      </div>

      <div className="panel-section">
        <div className="label">HIGH SCORE</div>
        <div className="value" aria-label={`High score: ${s.highScore}`}>{s.highScore.toLocaleString()}</div>
      </div>

      <div className="panel-row">
        <div className="panel-section">
          <div className="label">LEVEL</div>
          <div className="value" aria-label={`Level: ${s.level + 1}`}>{s.level + 1}</div>
        </div>
        <div className="panel-section">
          <div className="label">LINES</div>
          <div className="value" aria-label={`Lines: ${s.lines}`}>{s.lines}</div>
        </div>
      </div>

      <div className="panel-section">
        <div className="label">NEXT</div>
        <div className="preview-box">{renderMiniPiece(s.nextPieceName, 18)}</div>
      </div>

      <div className="panel-section">
        <div className="label">HOLD</div>
        <div className="preview-box">{renderMiniPiece(s.holdPieceName, 18)}</div>
      </div>

      <div className="button-group">
        {s.status === 'menu' ? (
          <button
            className="btn btn-start"
            onClick={onStart}
            aria-label="Start new game"
            tabIndex={0}
          >
            START
          </button>
        ) : s.status === 'gameover' ? (
          <>
            <div className="game-over-title">GAME OVER</div>
            <button
              className="btn btn-restart"
              onClick={onRestart}
              aria-label="New Game"
              tabIndex={0}
            >
              RESTART
            </button>
          </>
        ) : (
          <>
            <button
              className="btn btn-pause"
              onClick={onPause}
              aria-label={s.status === 'paused' ? 'Resume game' : 'Pause game'}
              tabIndex={0}
            >
              {s.status === 'paused' ? 'RESUME' : 'PAUSE'}
            </button>
            <button
              className="btn btn-restart"
              onClick={onRestart}
              aria-label="Restart game"
              tabIndex={0}
              disabled={s.status === 'paused'}
            >
              RESTART
            </button>
          </>
        )}
      </div>

      <div className="controls-help">
        <div className="help-title">CONTROLS</div>
        <div className="help-row"><span>← →</span> Move</div>
        <div className="help-row"><span>↑</span> Soft Rise</div>
        <div className="help-row"><span>Space</span> Hard Rise</div>
        <div className="help-row"><span>X</span> Rotate CW</div>
        <div className="help-row"><span>Z / Ctrl</span> Rotate CCW</div>
        <div className="help-row"><span>C / Shift</span> Hold</div>
        <div className="help-row"><span>Esc / P</span> Pause</div>
        <div className="help-row"><span>R</span> Restart</div>
      </div>
    </div>
  );
}