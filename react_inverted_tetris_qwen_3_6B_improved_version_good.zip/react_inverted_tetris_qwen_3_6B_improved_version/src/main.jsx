import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';
import ErrorBoundary from './components/ErrorBoundary.jsx';

let errorBanner = null;

function showErrorBanner(message) {
  if (errorBanner) return;
  errorBanner = document.createElement('div');
  errorBanner.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0;
    background: rgba(255,68,68,0.9); color: #fff;
    font-family: 'Courier New', Courier, monospace;
    font-size: 13px; padding: 8px 16px; text-align: center;
    z-index: 9999; pointer-events: auto;
  `;
  errorBanner.textContent = `Error: ${message} [click to dismiss]`;
  errorBanner.addEventListener('click', () => {
    errorBanner.remove();
    errorBanner = null;
  });
  document.body.appendChild(errorBanner);
}

window.addEventListener('error', (event) => {
  if (event.error) {
    showErrorBanner(event.error.message || 'An unexpected error occurred');
  }
  event.preventDefault();
});

window.addEventListener('unhandledrejection', (event) => {
  const reason = event.reason;
  showErrorBanner(reason?.message || reason?.toString() || 'Unhandled promise rejection');
  event.preventDefault();
});

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);