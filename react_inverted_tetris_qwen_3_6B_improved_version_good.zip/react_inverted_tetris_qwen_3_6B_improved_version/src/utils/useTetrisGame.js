import { useRef, useCallback, useEffect } from 'react';
import {
  PIECES,
  COLS,
  ROWS,
  createGrid,
  getInterval,
  getScoreForLines,
  getSpawnX,
  getSpawnY,
  createBag,
  collision,
  clearLines,
  normalizeCells,
  rotateCellsCW,
  rotateCellsCCW,
  calcGhostY,
  getHighScore,
  setHighScore,
  LINES_PER_LEVEL,
} from '../utils/pieces';
import { playSound } from '../utils/audio';

const WALL_KICKS = [
  [0, 0], [-1, 0], [1, 0], [-2, 0], [2, 0],
  [0, -1], [0, 1], [0, -2], [0, 2],
  [-1, -1], [1, -1], [-1, 1], [1, 1],
];

const LOCK_DELAY_MS = 500;
const MAX_LOCK_RESETS = 10;

function canMoveVertically(s) {
  return !collision(s.grid, s.pieceCells, s.pieceX, s.pieceY - 1);
}

function resetLockDelay(s) {
  if (canMoveVertically(s) && s.lockResetCount < MAX_LOCK_RESETS) {
    s.lockDelay = null;
    s.lockResetCount++;
  }
}

export default function useTetrisGame(_canvasRef) {
  const stateRef = useRef({
    grid: createGrid(),
    status: 'menu',
    piece: null,
    pieceX: 0,
    pieceY: 0,
    pieceName: '',
    pieceCells: [],
    pieceRotation: 0,
    bag: [],
    bagIndex: 0,
    nextPieceName: '',
    holdPieceName: null,
    holdUsed: false,
    score: 0,
    level: 0,
    lines: 0,
    highScore: getHighScore(),
    lockDelay: null,
    lockResetCount: 0,
    softRiseActive: false,
    lastTick: 0,
    softRiseAccum: 0,
    lastMoveTick: 0,
    moveInterval: 150,
    moveRepeatInterval: 100,
    moveFirstPress: 0,
    clearedRows: [],
    clearAnimFrame: 0,
    shakeTimer: 0,
  });

  const drawCallbackRef = useRef(null);
  const gameLoopRef = useRef(null);
  const focusRef = useRef(true);
  const pressedKeysRef = useRef(new Set());

  const draw = useCallback((cb) => {
    drawCallbackRef.current = cb;
  }, []);

  const getPieceCells = useCallback((name, rotation) => {
    const piece = PIECES[name];
    let cells = [...piece.cells];
    for (let i = 0; i < (rotation % 4 + 4) % 4; i++) {
      cells = rotateCellsCW(cells, piece.pivotX, piece.pivotY);
    }
    return normalizeCells(cells);
  }, []);

  const getNextPieceName = useCallback(() => {
    const s = stateRef.current;
    if (s.bagIndex >= s.bag.length) {
      s.bag = createBag();
      s.bagIndex = 0;
    }
    const name = s.bag[s.bagIndex++];
    return name;
  }, []);

  const spawnPiece = useCallback((name) => {
    const s = stateRef.current;
    const piece = PIECES[name];
    const cells = getPieceCells(name, 0);
    const spawnX = getSpawnX(piece);
    const spawnY = getSpawnY() - piece.height + 1;

    if (collision(s.grid, cells, spawnX, spawnY)) {
      s.status = 'gameover';
      playSound('gameover');
      if (s.score > s.highScore) {
        s.highScore = s.score;
        setHighScore(s.highScore);
      }
      return false;
    }

    s.pieceName = name;
    s.pieceCells = cells;
    s.pieceX = spawnX;
    s.pieceY = spawnY;
    s.pieceRotation = 0;
    s.piece = piece;
    s.lockDelay = null;
    s.lockResetCount = 0;
    return true;
  }, [getPieceCells]);

  const startGame = useCallback(() => {
    const s = stateRef.current;
    s.grid = createGrid();
    s.score = 0;
    s.level = 0;
    s.lines = 0;
    s.status = 'playing';
    s.bag = createBag();
    s.bagIndex = 0;
    s.holdPieceName = null;
    s.clearedRows = [];
    s.clearAnimFrame = 0;
    s.shakeTimer = 0;
    s.lastMoveTick = 0;
    s.moveFirstPress = 0;

    const nextName = getNextPieceName();
    s.nextPieceName = getNextPieceName();
    spawnPiece(nextName);
  }, [getNextPieceName, spawnPiece]);

  const pauseGame = useCallback(() => {
    const s = stateRef.current;
    if (s.status === 'playing') {
      s.status = 'paused';
    } else if (s.status === 'paused') {
      s.status = 'playing';
      s.lastTick = performance.now();
    }
  }, []);

  const moveLeft = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing' || !s.pieceName) return;
    if (s.lockDelay !== null && performance.now() - s.lockDelay >= LOCK_DELAY_MS) return;
    if (!collision(s.grid, s.pieceCells, s.pieceX - 1, s.pieceY)) {
      s.pieceX--;
      resetLockDelay(s);
      playSound('move');
    }
  }, []);

  const moveRight = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing' || !s.pieceName) return;
    if (s.lockDelay !== null && performance.now() - s.lockDelay >= LOCK_DELAY_MS) return;
    if (!collision(s.grid, s.pieceCells, s.pieceX + 1, s.pieceY)) {
      s.pieceX++;
      resetLockDelay(s);
      playSound('move');
    }
  }, []);

  const rotateCW = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing' || !s.pieceName) return;
    if (s.lockDelay !== null && performance.now() - s.lockDelay >= LOCK_DELAY_MS) return;
    const piece = PIECES[s.pieceName];
    const newCells = normalizeCells(
      rotateCellsCW(s.pieceCells, piece.pivotX, piece.pivotY)
    );
    const newRot = (s.pieceRotation + 1) % 4;

    if (!collision(s.grid, newCells, s.pieceX, s.pieceY)) {
      s.pieceCells = newCells;
      s.pieceRotation = newRot;
      resetLockDelay(s);
      playSound('rotate');
      return;
    }

    for (const [kx, ky] of WALL_KICKS) {
      if (!collision(s.grid, newCells, s.pieceX + kx, s.pieceY + ky)) {
        s.pieceCells = newCells;
        s.pieceX += kx;
        s.pieceY += ky;
        s.pieceRotation = newRot;
        resetLockDelay(s);
        playSound('rotate');
        return;
      }
    }
  }, []);

  const rotateCCW = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing' || !s.pieceName) return;
    if (s.lockDelay !== null && performance.now() - s.lockDelay >= LOCK_DELAY_MS) return;
    const piece = PIECES[s.pieceName];
    const newCells = normalizeCells(
      rotateCellsCCW(s.pieceCells, piece.pivotX, piece.pivotY)
    );
    const newRot = (s.pieceRotation + 3) % 4;

    if (!collision(s.grid, newCells, s.pieceX, s.pieceY)) {
      s.pieceCells = newCells;
      s.pieceRotation = newRot;
      resetLockDelay(s);
      playSound('rotate');
      return;
    }

    for (const [kx, ky] of WALL_KICKS) {
      if (!collision(s.grid, newCells, s.pieceX + kx, s.pieceY + ky)) {
        s.pieceCells = newCells;
        s.pieceX += kx;
        s.pieceY += ky;
        s.pieceRotation = newRot;
        resetLockDelay(s);
        playSound('rotate');
        return;
      }
    }
  }, []);

  const softRise = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing' || !s.pieceName) return;
    s.softRiseActive = true;
  }, []);

  const releaseSoftRise = useCallback(() => {
    const s = stateRef.current;
    s.softRiseActive = false;
  }, []);

  const lockPiece = useCallback(() => {
    const s = stateRef.current;
    if (!s.pieceName) return;

    for (const [cx, cy] of s.pieceCells) {
      const x = s.pieceX + cx;
      const y = s.pieceY + cy;
      if (y >= 0 && y < ROWS && x >= 0 && x < COLS) {
        s.grid[y][x] = s.piece.id;
      }
    }
    playSound('lock');

    const { newGrid, clearedRows } = clearLines(s.grid);
    s.grid = newGrid;

    if (clearedRows.length > 0) {
      const linesCleared = clearedRows.length;
      s.lines += linesCleared;
      s.score += getScoreForLines(linesCleared, s.level);
      s.clearedRows = clearedRows;
      s.clearAnimFrame = 10;
      s.shakeTimer = 5;

      if (linesCleared === 3) {
        playSound('triple');
      } else {
        playSound('clear');
      }

      const newLevel = Math.floor(s.lines / LINES_PER_LEVEL);
      if (newLevel > s.level) {
        s.level = newLevel;
      }
    }

    if (s.score > s.highScore) {
      s.highScore = s.score;
      setHighScore(s.highScore);
    }

    s.pieceName = '';
    s.pieceCells = [];
    s.lockDelay = null;
    s.holdUsed = false;

    const spawnName = s.nextPieceName;
    s.nextPieceName = getNextPieceName();
    spawnPiece(spawnName);
  }, [getNextPieceName, spawnPiece]);

  const hardRise = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing' || !s.pieceName) return;

    const ghostY = calcGhostY(s.grid, s.pieceCells, s.pieceX, s.pieceY);
    const cellsMoved = s.pieceY - ghostY;
    s.score += Math.max(0, cellsMoved) * 2;
    s.pieceY = ghostY;
    s.lockDelay = null;
    playSound('hardrise');
    lockPiece();
  }, [lockPiece]);

  const holdPiece = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing' || s.holdUsed || !s.pieceName) return;

    const currentName = s.pieceName;
    s.holdUsed = true;

    if (s.holdPieceName !== null) {
      // Swap: store current in hold, spawn previously held piece
      const holdName = s.holdPieceName;
      s.holdPieceName = currentName;
      spawnPiece(holdName);
    } else {
      // Store current to hold, spawn the previewed piece
      s.holdPieceName = currentName;
      const spawnName = s.nextPieceName;
      s.nextPieceName = getNextPieceName();
      spawnPiece(spawnName);
    }
    playSound('move');
  }, [getNextPieceName, spawnPiece]);

  const processImmediateInput = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing') return;

    const keys = pressedKeysRef.current;

    if (keys.has('hardrise')) {
      hardRise();
      keys.delete('hardrise');
      return;
    }

    if (keys.has('hold')) {
      holdPiece();
      keys.delete('hold');
      return;
    }

    if (keys.has('rotateCW')) {
      rotateCW();
      keys.delete('rotateCW');
      return;
    }

    if (keys.has('rotateCCW')) {
      rotateCCW();
      keys.delete('rotateCCW');
      return;
    }
  }, [hardRise, holdPiece, rotateCW, rotateCCW]);

  const processMovementInput = useCallback(() => {
    const s = stateRef.current;
    if (s.status !== 'playing') return;

    const keys = pressedKeysRef.current;

    if (keys.has('left')) {
      moveLeft();
    } else if (keys.has('right')) {
      moveRight();
    }
  }, [moveLeft, moveRight]);

  const gameLoop = useCallback((now) => {
    try {
      const s = stateRef.current;
      if (s.status !== 'playing') {
        if (drawCallbackRef.current) drawCallbackRef.current(s);
        gameLoopRef.current = requestAnimationFrame(gameLoop);
        return;
      }

      const keys = pressedKeysRef.current;

      processImmediateInput();

      const hasMovement = keys.has('left') || keys.has('right');

      if (hasMovement) {
        if (s.moveFirstPress === 0) {
          s.moveFirstPress = now;
          processMovementInput();
        } else if (now - s.moveFirstPress >= s.moveInterval) {
          if (now - s.lastMoveTick >= s.moveRepeatInterval) {
            processMovementInput();
            s.lastMoveTick = now;
          }
        }
      } else {
        s.moveFirstPress = 0;
      }

      if (s.clearAnimFrame > 0) {
        s.clearAnimFrame--;
      }

      if (s.shakeTimer > 0) {
        s.shakeTimer--;
      }

      if (s.pieceName && s.lockDelay !== null && now - s.lockDelay >= LOCK_DELAY_MS) {
        lockPiece();
      }

      const normalInterval = getInterval(s.level);
      const softInterval = Math.max(15, Math.floor(normalInterval / 10));
      const interval = s.softRiseActive ? softInterval : normalInterval;

      if (now - s.lastTick >= interval) {
        s.lastTick = now;

        if (s.pieceName) {
          const nextY = s.pieceY - 1;
          if (s.lockDelay === null && !collision(s.grid, s.pieceCells, s.pieceX, nextY)) {
            s.pieceY = nextY;
            s.lockResetCount = 0;
            if (s.softRiseActive) {
              s.score += 1;
            }
          } else if (s.lockDelay === null) {
            s.lockDelay = now;
            s.lockResetCount = 0;
          }
        }
      }

      if (drawCallbackRef.current) drawCallbackRef.current(s);
      gameLoopRef.current = requestAnimationFrame(gameLoop);
    } catch (err) {
      console.error('[TetrisGame] Game loop error:', err);
      const s = stateRef.current;
      s.status = 'error';
    }
  }, [lockPiece, processImmediateInput, processMovementInput]);

  useEffect(() => {
    const handleFocus = () => {
      focusRef.current = true;
      const s = stateRef.current;
      if (s.status === 'playing') {
        s.lastTick = performance.now();
      }
    };
    const handleBlur = () => {
      focusRef.current = false;
      const s = stateRef.current;
      if (s.status === 'playing') {
        s.status = 'paused';
      }
    };

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        handleBlur();
      } else {
        handleFocus();
      }
    });
    window.addEventListener('focus', handleFocus);
    window.addEventListener('blur', handleBlur);

    return () => {
      document.removeEventListener('visibilitychange', () => {});
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('blur', handleBlur);
    };
  }, []);

  useEffect(() => {
    const keyMap = {
      ArrowLeft: 'left',
      ArrowRight: 'right',
      ArrowUp: 'softRise',
      ' ': 'hardrise',
      x: 'rotateCW',
      X: 'rotateCW',
      Control: 'rotateCCW',
      z: 'rotateCCW',
      Z: 'rotateCCW',
      c: 'hold',
      C: 'hold',
      Shift: 'hold',
      Escape: 'pause',
      p: 'pause',
      P: 'pause',
      r: 'restart',
      R: 'restart',
      Enter: 'start',
    };

    const handleKeyDown = (e) => {
      if (!focusRef.current) return;
      if (e.repeat) {
        e.preventDefault();
        return;
      }

      const action = keyMap[e.key];
      if (!action) return;

      const s = stateRef.current;
      const isPaused = s.status === 'paused';

      if (isPaused && action !== 'pause') {
        e.preventDefault();
        return;
      }

      e.preventDefault();
      const keys = pressedKeysRef.current;

      if (action === 'softRise') {
        softRise();
        keys.add('softRise');
      } else if (action === 'pause') {
        pauseGame();
      } else if (action === 'restart') {
        startGame();
      } else if (action === 'start') {
        if (s.status === 'menu' || s.status === 'gameover') {
          startGame();
        }
      } else {
        keys.add(action);
      }
    };

    const handleKeyUp = (e) => {
      const action = keyMap[e.key];
      if (action === 'softRise') {
        releaseSoftRise();
        pressedKeysRef.current.delete('softRise');
      } else if (action) {
        pressedKeysRef.current.delete(action);
      }
    };

    window.addEventListener('keydown', handleKeyDown, { passive: false });
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [softRise, releaseSoftRise, pauseGame, startGame]);

  useEffect(() => {
    gameLoopRef.current = requestAnimationFrame(gameLoop);
    return () => {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [gameLoop]);

  return {
    stateRef,
    pressedKeysRef,
    draw,
    startGame,
    pauseGame,
    moveLeft,
    moveRight,
    softRise,
    releaseSoftRise,
    hardRise,
    rotateCW,
    rotateCCW,
    holdPiece,
  };
}
