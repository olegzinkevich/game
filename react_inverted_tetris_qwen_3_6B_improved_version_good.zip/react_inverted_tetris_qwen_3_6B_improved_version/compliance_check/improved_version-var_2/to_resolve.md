# Issues to resolve — compliance audit follow-up

Deduplicated from `compliance_check/improved_version/output.txt` (aggregated findings of several audit runs).
One entry per requirement ID, with a short prompt describing how to fix it.

---

## 1. FR-SPAWN-002 — Next preview must match the spawned piece (hold path)

**Problem:** In `holdPiece()` (`src/utils/useTetrisGame.js:319-323`), when the hold slot is empty the code draws **two fresh pieces from the bag** (one to spawn, one for the new preview) instead of spawning the previewed `s.nextPieceName`. The preview shown right before Hold does not match what spawns, the previewed figure is silently discarded, and a bag member can be skipped from ever appearing — which also distorts the 4-bag guarantee (FR-SPAWN-001).

**Fix prompt:**
> In `holdPiece()`, in the branch where the hold slot is empty, spawn `s.nextPieceName` (the piece currently shown in the Next preview) instead of calling `getNextPieceName()` for the spawn. Then refill `s.nextPieceName` with one new `getNextPieceName()` call. Ensure every piece drawn from the bag is eventually spawned so the Next preview always matches the actual next spawn.
>
DONE

---

## 2. FR-SPAWN-003 — Hold must truly swap active ↔ held

**Problem:** In `holdPiece()` (`src/utils/useTetrisGame.js:313-317`), when a piece is already held, the code spawns the held piece and sets `holdPieceName = null` — the active piece (`currentName` is captured but never stored) is discarded instead of being placed into the hold slot.

**Fix prompt:**
> In `holdPiece()`, when `s.holdPieceName !== null`, perform a real swap: store the current active piece name into `s.holdPieceName` and spawn the previously held piece. The active piece must never be lost. Keep the `holdUsed` once-per-figure gate, and verify `spawnPiece()` does not reset `holdUsed` in a way that defeats the gate (reset `holdUsed = false` only when a piece locks, not on every spawn).

DONE
---

## 3. FR-LOCK-002 — Lock delay must be bounded (no indefinite stalling)

**Problem:** `moveLeft`/`moveRight`/`rotateCCW` reset `lockDelay = null` on every successful action (`src/utils/useTetrisGame.js:154, :165, :213/:224`) — unconditionally, even if the piece is still vertically blocked — and the game loop starts a fresh 500 ms window whenever it is null, so repeated side-taps while resting stall locking indefinitely. Also inconsistent: `rotateCCW` resets the delay but `rotateCW` does not.

**Fix prompt:**
> Bound the lock delay: keep the ~500 ms lock-delay reset on successful move/rotate, but cap it (e.g. max 10–15 resets per piece, or a hard cap of ~2–3 s total time at the resting position) so the piece always locks within a bounded time. Make `rotateCW` and `rotateCCW` behave identically regarding the lock-delay reset. Verify the lock trigger in the game loop and the input-gating check use the same 500 ms constant (extract it to a named constant).


DONE

---

## 4. FR-SCORE-002 — Line-clear scoring formula vs. level indexing

**Problem:** `getScoreForLines()` (`src/utils/pieces.js:66-68`) awards `100/300/500 × (level + 1)` while the displayed level starts at 0. The requirement's literal formula is `100×L / 300×L / 500×L` for the current level L, so at HUD level L the code awards 100×(L+1), not 100×L.

**Fix prompt:**
> Reconcile the level indexing between HUD and scoring: either (a) display the level as 1-based (`level + 1`) in the HUD/game-over screen so the shown level L matches the `SCORE_TABLE[lines] × L` award, or (b) keep the 0-based internal level but make the award literally `SCORE_TABLE[lines] × level` per spec (note: this gives 0 points at level 0 — if that is unintended, prefer option (a) and/or clarify the requirement). Choose one interpretation and make code + display consistent with the spec text.

DONE

---

## 5. FR-CTRL-001 — Ctrl key must rotate counter-clockwise

**Problem:** The keymap (`src/utils/useTetrisGame.js:478`) binds `Control` to `rotateCW`; the spec requires rotate CW = X, rotate CCW = Z **or Ctrl**.

**Fix prompt:**
> In the `keyMap` in `useTetrisGame.js`, change `Control: 'rotateCW'` to `Control: 'rotateCCW'` so Ctrl acts as an alternate CCW rotation paired with Z. Update the on-screen controls help in `SidePanel.jsx` (currently shows "X / Ctrl — Rotate CW") to reflect the corrected mapping.

DONE

---

## 6. FR-LIFE-005 — Pause must ignore all input except Resume (verify Restart paths)

**Problem:** One audit run claims the R key restarts while paused. The keyboard handler *does* appear to guard this (`if (isPaused && action !== 'pause') return;`), but the side-panel RESTART button (`SidePanel.jsx`) remains clickable while paused, so a paused game's board state can still be mutated via UI.

**Fix prompt:**
> Verify all Restart entry points while paused: confirm the keyboard `restart` action is blocked when `status === 'paused'` (it appears to be), and disable (or require confirmation for) the side-panel RESTART button while the game is paused so no input other than Resume can change game state. Add the same guard to any touch-control path that can mutate state during pause.

DONE

---

## 7. FR-PIECE-002 — Locked cells rendered with darker color variant

**Problem:** Active/ghost/preview pieces use the exact assigned colors, but locked cells are drawn with `darkColor` (`TetrisCanvas.jsx:60`), so locked figures do not match the assigned color mapping exactly.

**Fix prompt:**
> Decide whether locked cells should keep the exact assigned figure colors (I=#30b5c5, P=#c00000, L=#ED6D00, C=#a0d183). If yes, render locked cells with `piece.color` and differentiate active vs. locked by another cue (border, brightness overlay, saturation) instead of a different base color — this also helps UI-HUD-002 (distinguishable visuals) without violating the color mapping. If the darker variant is intentional, document it as a deliberate deviation.
>

DONE

---

## 8. FR-MOVE-004 — Soft rise stops accelerating at high levels

**Problem:** The soft-rise interval is a fixed 50 ms (`src/utils/useTetrisGame.js:53`), while the normal rise interval is `max(50, floor(500/(level+1)))` (`src/utils/pieces.js:62-64`). Once level ≥ 9 the normal interval also reaches 50 ms, so holding Soft Rise no longer accelerates the ascent — the spec requires acceleration *beyond* the normal rate.

**Fix prompt:**
> Make the soft-rise interval relative to the current level's normal interval instead of a fixed 50 ms — e.g. `softRiseInterval = max(MIN_SOFT, normalInterval / K)` for some factor K (commonly 10–20×), or move the piece multiple cells per soft-rise tick at high levels. Ensure soft rise is strictly faster than the normal rise rate at every level, and that soft-rise scoring (1 point per cell) still counts each cell travelled.


DONE

---

## 9. UI-LAYOUT-001 — Side panel must keep a Restart control during game over

**Problem:** In `SidePanel.jsx` (button-group, `:93-94`), the game-over state replaces the buttons with only a "GAME OVER" label; the actual Restart button lives in the separate canvas-overlay modal (`TetrisGame.jsx`), not in the side panel. The spec requires the side panel itself to contain a New Game/Restart control (alongside the Game Over indicator).

**Fix prompt:**
> In `SidePanel.jsx`, when `status === 'gameover'`, render both the "GAME OVER" indicator **and** a RESTART (New Game) button in the side panel's button group, wired to the same `onRestart` handler. Keep the game-over modal's Restart button too — the requirement is about side-panel completeness, not exclusivity.
>
DONE

---

## 10. FR-ERR-008 — Graceful unhandled-error handling

**Problem:** No React ErrorBoundary, no `window.onerror` / `unhandledrejection` handler anywhere in `src/`. An uncaught render error white-screens the app (React unmounts the tree); an error thrown inside the rAF game loop silently kills the loop.

**Fix prompt:**
> Add a top-level React ErrorBoundary component wrapping `<App />` in `main.jsx` that renders a friendly fallback screen with a "Reload / Restart" action instead of a white screen. Additionally, register `window.addEventListener('error', …)` and `('unhandledrejection', …)` handlers that surface a non-blocking error message (and avoid infinite error loops), and wrap the `requestAnimationFrame` game-loop body in a try/catch that reports the error and stops or safely restarts the loop rather than dying silently.
>

DONE

---

## Summary table

| # | ID | Severity (audit consensus) | Area | One-line fix |
|---|----|---------------------------|------|--------------|
| 1 | FR-SPAWN-002 | partial | Spawning | Spawn the previewed `nextPieceName` in the hold path |
| 2 | FR-SPAWN-003 | partial | Spawning | Store active piece into hold slot on swap |
| 3 | FR-LOCK-002 | partial | Locking | Cap lock-delay resets; unify CW/CCW behavior |
| 4 | FR-SCORE-002 | partial / disputed | Scoring | Align level indexing between HUD and score formula |
| 5 | FR-CTRL-001 | partial | Controls | Rebind Ctrl to rotate CCW; update help text |
| 6 | FR-LIFE-005 | disputed (one run) | Lifecycle | Guard side-panel/touch Restart while paused |
| 7 | FR-PIECE-002 | partial (one run) | Rendering | Use exact assigned colors for locked cells |
| 8 | FR-MOVE-004 | partial (one run) | Movement | Scale soft-rise interval with level so it stays faster |
| 9 | UI-LAYOUT-001 | partial (one run) | Layout | Keep a Restart button in the side panel at game over |
| 10 | FR-ERR-008 | not-satisfied | Resilience | Add ErrorBoundary + global error handlers |

**Note on disputed items:** run disagreements found in `output.txt` — one run claims lock fires at 1000 ms (code shows 500 ms at `useTetrisGame.js:411`) and one claims R restarts while paused (the keydown handler guards this). Items 3 and 6 above reflect what the code actually shows, with verification steps included.
