# Tetris Game

**Document type:** Acceptance Criteria / Definition of Done (DoD)
**Product:** Web-based Tetris game (browser, desktop + mobile), classic version
**Genre:** Puzzle / Falling blocks

**The key rule:** Collect horizontal lines from falling shapes so that they disappear, preventing the blocks from reaching the top of the field.

## 1. Scope

- Single-player, single-session web Tetris game, playable entirely in the browser with no install.
- Standard Tetris core loop: spawn → move/rotate → soft/hard drop → lock → line clear → scoring/leveling → game over.
- Keyboard controls (desktop) and touch controls (mobile), responsive layout, basic audio/visual feedback, pause/restart, and a score/level/lines HUD.
- Reliable load and play on current evergreen browsers, desktop and mobile.

## 2. General game cycle

### 2.1 Spawn a new shape:
- If the figure intersects with existing blocks after spawn, the game ends (Game Over).

### 2.2 While the figure is falling:
- Process player input.
- Gravity tick: Every N milliseconds (depends on the speed level), the piece moves down 1 square. If a shift is not possible, the figure "freezes" (becomes part of the field).

### 2.3 After freezing:
- Check the filled lines (all 10 cells in the row are not empty). Remove such lines and move the top rows down.
- Earn points (see the table).
- Increase the game speed after a certain number of lines.
- Spawn of the next figure (continuation of the cycle).

## 3. Functional Acceptance Criteria

### 3.1 Game Field (Grid)
**Size:** 10 cells wide × 20 cells high.
Each cell can be either **empty** or **filled** (with a specific color/shape type).
The visible area is the entire field.

### 3.2 Figures (Tetrimino)

7 standard shapes:
- I (4×1) — cyanide
- O (2x2) — yellow
- T (3x2) — purple
- S (3x2) — green
- Z (3x2) — red
- L (3x2) — orange
- J (3x2) — Blue

Each shape consists of 4 squares (except O, which has 4 blocks in the form of a square).

The shapes appear at the top of the field (usually centered horizontally: offset for an even field width). Starting position: Y = 0 (or 1 if the coordinates are from 0) and X = floor(width/2) - floor(width of the shape/2).

### 3.3. Default configuration

- The base drop interval is 500 ms.
- The minimum interval is 50 ms.
- 10 lines to level up
- Field width = 10 cells
- Field height = 20 cells

### 3.4 Startup & lifecycle

| # | Criterion |
|---|-----------|
| 3.4.1 | Given a supported browser, When the user opens the game URL, Then the game reaches an interactive state (menu or first piece) within ≤ 3 s, with zero uncaught exceptions and zero console errors. |
| 3.4.2 | Given the start screen, When the user triggers Start, Then the first tetromino spawns at the top-center and the gravity timer begins. |
| 3.4.3 | When the game is running, Then a continuous game loop advances state at a stable cadence (no stalls > 100 ms. during normal play). |
| 3.4.4 | Given an active game, When the user pauses, Then the piece stops falling, input is ignored except resume, and the timer stops; When resumed, play continues from the identical state. |
| 3.4.5 | Given game over, When the user selects Restart, Then board, score, level, and lines reset to initial values and a fresh game begins. |
| 3.4.6 | When the browser tab loses focus / is backgrounded, Then the game auto-pauses (or continues deterministically) without runaway timers or duplicated loops on refocus. |

### 3.5 Tetromino spawning

| # | Criterion |
|---|-----------|
| 3.5.1 | All seven tetrominoes (I, O, T, S, Z, J, L) exist with correct shapes and standard colors. |
| 3.5.2 | Pieces spawn at the standard top-center spawn position and orientation. |
| 3.5.3 | Spawn order follows the 7-bag randomizer; no piece is starved or duplicated within a bag. |
| 3.5.4 | A Next preview shows the upcoming piece(s) and matches the actual next spawn. |
| 3.5.5 | Hold swaps the active piece with the held piece, allowed once per piece until lock. |

### 3.6 Movement, rotation, collision, locking

| # | Criterion |
|---|-----------|
| 3.6.1 | When Left/Right is pressed, Then the active piece moves exactly one column (1 square), unless blocked by a wall or stack (then no move). It does not go beyond the boundaries of the field or does not intersect with other blocks. |
| 3.6.2 | If pressed Down – fall is accelerated by 1 square. A constant drop occurs automatically every game tick. |
| 3.6.3 | Soft drop accelerates descent while held and awards soft-drop points; hard drop instantly drops the piece to its landing position and locks it. |
| 3.6.4 | Drop (hard drop) – the instantaneous fall of a piece before the first collision with the bottom or blocks. |
| 3.6.5 | Rotation (Clock wise and Counter clock wise) rotates the piece about its standard pivot. Rotation is the rotation of a shape by 90° clockwise (relative to the center of the shape). Use a rotation matrix or predefined states. Check for collisions with borders and blocks – if rotation is not possible, do not perform. |
| 3.6.6 | Wall kicks (SRS - Super Rotation System): Given a rotation that would collide with a wall, floor, or stack, When rotated, Then the piece is offset per the SRS kick table to a valid position if one exists, else the rotation is rejected. |
| 3.6.7 | Collision integrity: at no point may any active-piece cell overlap an occupied cell or exit the playfield bounds (left/right/bottom). |
| 3.6.8 | A piece locks when it cannot move further down (rests on floor or stack). After lock, its cells become part of the board and a new piece spawns. |
| 3.6.9 | Lock delay: a landed piece has a brief, bounded lock delay (e.g. ~500 ms) during which movement/rotation of this block can still occur; lock delay does not allow indefinite stalling. |
| 3.6.10 | Ghost piece indicates the hard-drop landing column/position and matches the actual landing. |

### 3.7 Line clearing

| # | Criterion | Scenario |
|---|-----------|----------|
| 3.7.1 | Single clear | Given exactly one fully-filled row, When the piece locks, Then that row clears. Rows positioned above, shift down by one, and score increases per the single-line value. |
| 3.7.2 | Double clear | Two simultaneous full rows clear together; scoring uses the double-line value (> 2× single). |
| 3.7.3 | Triple clear | Three simultaneous full rows clear; scoring uses the triple value. |
| 3.7.4 | Tetris (quad) | Four simultaneous full rows clear; scoring uses the Tetris value (highest per-line reward). |
| 3.7.5 | Non-contiguous clears | Given filled rows separated by partial rows, When they clear, Then only filled rows are removed and remaining blocks fall correctly to preserve gaps. |
| 3.7.6 | No false clear | A row with any empty cell never clears. |

### 3.8 Score, level, and progression

**Scoring system:**
Lines at a time points (classic scale):
- 1, 100 × level
- 2, 300 × level
- 3, 500 × level
- 4, (Tetris) 800 × level

The level starts at 0 or 1. The drop rate (delay between ticks) = base value / (level + 1) or according to the formula: max(50, 500 / (level+1)) ms. The level increases every 10 lines collected.

| # | Criterion |
|---|-----------|
| 3.8.1 | Score is monotonic non-decreasing during play and never goes negative. |
| 3.8.2 | Line-clear scoring scales with the number of lines cleared in one lock (1 < 2 < 3 < 4 per-line reward), and with current level. |
| 3.8.3 | `linesCleared` increments by exactly the number of rows cleared per lock. |
| 3.8.4 | Level increases according to a defined rule (every 10 lines), and gravity speed increases with level. |
| 3.8.5 | Soft drop and hard drop award points: Soft drop - 1 point for every cell the piece falls, Hard Drop - 2 points for every cell the piece falls. |
| 3.8.6 | High score persists across reloads via `localStorage` and survives a refresh. |

### 3.9 Game over

| # | Criterion |
|---|-----------|
| 3.9.1 | Given a newly spawned piece that immediately collides with the existing stack (block-out), Then `status` becomes `'gameover'` and the gravity loop stops. |
| 3.9.2 | A clear game-over screen appears showing final score and a Restart action button. |
| 3.9.3 | After game over, gameplay input no longer mutates the board (no zombie movement). |
| 3.9.4 | No new piece spawns after game over until Restart. |

### 3.10 Logic and Architecture

**3.10.1** The game cycle is based on a **timer** (setInterval / requestAnimationFrame with time check / Time.deltaTime).

**3.10.2** The state of the field is a two–dimensional array (10×20), where each cell contains:
- 0 – empty
- The color id (1..7) is the occupied cell.
- The current shape is an object with coordinates (x, y) and shape (matrix).
- The next piece is a random selection of 7 types (you can use a "Random Generator" with a fair distribution or a bag of 7 pieces).

**3.10.3 Collision handling**
- The collision(shape, offsetX, offsetY) function checks the intersection with the boundaries of the field (x <0 or x+width >10, y+height>20, y<0) or with non-empty cells of the field.

**3.10.4 Deleting lines**
- Going through the rows from bottom to top, if the row is completely filled, delete it, move all the overlying rows down by 1.

**3.10.5 Random numbers**
- Use the bag generator of 7 shapes to avoid long series of identical shapes. After emptying the bag, a new bag is added.

### 3.11 Recommendations for implementation under different pipelines

**3.11.1 Unity (C#)**
- Use GameObject for a field (Tilemap) or a simple UI Image.
- Timer – InvokeRepeating or Coroutine with yield return new WaitForSeconds(...) + change the interval dynamically.
- Input via Input.GetKeyDown in the Update.
- Separate scripts: GameManager, Spawner, Grid, Tetromino.
- Rendering: A grid of sprites with colors.

**3.11.2 Phaser (JavaScript, version 3)**
- The Phaser scene, use this.time.addEvent for gravity.
- Key handling via this.input.keyboard.
- Drawing via the Graphics API or TileSprite.
- Store the field matrix in a regular array, and redraw each frame or event (it's easier to redraw the entire grid with each change).
- Line removal animations are performed using timers or Tween.

**3.11.3 React (without additional game engines)**
- Use React + Canvas (the most productive for rendering the game loop).
- Store the game state in hooks (useState, useRef for timer).
- Rendering the field on each frame via canvas.getContext('2d').
- Game loop – useEffect with requestAnimationFrame (for smooth animation) or setInterval for ticks.
- Key handling – useEffect with window.addEventListener.
- For Next, Score, and Level, there are separate React components that receive props.
- Important: do not redraw the React tree with each tick, just the Canvas. Use useRef for canvas and the update function.

The approximate structure of the components:
- TetrisGame is the main component that holds the state.
- TetrisCanvas is responsible for rendering the field and the current shape.
- SidePanel – shows the score, lines, level, and next shape.

### 3.12 Browser / Platform Compatibility

| # | Criterion |
|---|-----------|
| 3.12.1 | Fully playable on latest Chrome, Firefox, Safari, Edge (desktop). |
| 3.12.2 | Fully playable on latest mobile Safari (iOS) and Chrome (Android). |
| 3.12.3 | Functions on the last 2 major versions of each supported browser. |
| 3.12.4 | No dependency on experimental/flagged APIs; graceful fallback if an optional API (e.g. audio, vibration) is unavailable. |
| 3.12.5 | Works over plain HTTPS with no server-side runtime dependency (static hosting compatible). |
| 3.12.6 | Renders correctly at common device pixel ratios (1×, 2×, 3×) — crisp, not blurry on Retina/HiDPI. |

## 4. Gameplay Rules

- **Playfield:** 10 columns × 20 visible rows; spawn occurs in hidden rows above the visible field.
- **Randomizer:** 7-bag — each bag is a shuffled permutation of the 7 tetrominoes.
- **Rotation system:** SRS, including wall-kick offset tables; 4 rotation states per piece.
- **Gravity:** pieces fall at a level-dependent rate; soft drop multiplies fall speed; hard drop is instantaneous.
- **Locking:** occurs on inability to descend, subject to bounded lock delay; **top-out** ends the game.
- **Line clear:** any fully occupied row is removed; rows positioned above shift down; multiple simultaneous clears resolve in a single step.
- **Leveling:** +1 level per 10 lines cleared

## 5. UI / UX Criteria

### 5.1 Controls

| # | Action | Keyboard (desktop) | Touch (mobile) |
|---|--------|--------------------|----------------|
| 5.1.1 | Move left / right | ← / → | Swipe or tap L/R and on-screen buttons |
| 5.1.2 | Soft drop | ↓ | Swipe down and button |
| 5.1.3 | Hard drop | Space | button |
| 5.1.4 | Rotate CW / CCW | ↑ or X / Z or Ctrl | Tap and dedicated buttons |
| 5.1.5 | Hold | C / Shift | Button |
| 5.1.6 | Pause | Esc or P | Button |
| 5.1.7 | Restart the game | R | Button |

### 5.2 Additional controls requirements:

| # | Criterion |
|---|-----------|
| 5.2.1 | All Must-have controls (move, rotate, soft drop, hard drop, pause, restart) work on keyboard. |
| 5.2.2 | Input latency from keypress to visible response is ≤ 100 ms under normal load. |
| 5.2.3 | Key repeat does not cause missed or doubled inputs; simultaneous keys resolve deterministically. |
| 5.2.4 | On touch devices, all must-have actions are reachable; touch targets are ≥ 44×44 px. |
| 5.2.5 | Browser default behaviors are suppressed during play (arrow/space do not scroll the page; gestures do not zoom). |

### 5.3 Screen design

**Main Screen** (positioned at Right or left) have these areas:
- Current Score
- Level
- Number of lines assembled (Lines)
- The "Next" window (showing the next shape)
- The "New Game" / "Restart" button
- Game Over indicator (dimming and text "Game Over" + restart button)

### 5.4 Visual style (recommendations)

- The cells can be square, with or without a thin border.
- Each shape has its own color (according to the standard).
- For frozen blocks – the same color, but possibly with a slightly darkened texture.
- Animations: flash or short delay when deleting lines; the "shake" effect is optional.

### 5.5 HUD & feedback

| # | Criterion |
|---|-----------|
| 5.5.1 | Score, level, and lines-cleared are always visible during play and update immediately on change. |
| 5.5.2 | Next-piece preview is visible and accurate. Exists a small 4×4 or 4×6 window where the next shape is shown. You can store a queue of 1 figure (or 3 for advanced mode). |
| 5.5.3 | Active piece, ghost, and locked cells are visually distinguishable; standard per-piece colors are used. |
| 5.5.4 | Line clears and game over have clear visual feedback (flash/animation/screen). |

### 5.6 Responsiveness & layout

| # | Criterion |
|---|-----------|
| 5.6.1 | Layout adapts without overflow/clipping from 320 px wide up to large desktop; portrait and landscape both usable. |
| 5.6.2 | The playfield maintains correct aspect ratio and remains fully visible at all supported sizes (no off-screen rows). |
| 5.6.3 | No layout shift after load (CLS, Cumulative Layout Shift ≈ 0); no horizontal scrollbar during play. |

### 5.7 Sounds

- Movement/rotation activates a short "click" sound.
- When the figure is frozen appears the soft sound of landing.
- Deleting a line produces a pleasant chime.
- Tetris (4 lines) produces brighter sound.
- Game Over produces low signal.

## 6. Accessibility

| # | Criterion |
|---|-----------|
| 6.1 | All interactive menu controls are keyboard-reachable and operable (tab order, Enter/Space activation), with visible focus states. |
| 6.2 | Color is never the *only* signal for critical info; game state is distinguishable by shape/text/position. |
| 6.3 | Text and UI meet **WCAG AA** contrast (≥ 4.5:1 for normal text). |
| 6.4 | Interactive elements have accessible names/labels; canvas has a meaningful `aria-label`/role and the game is announced. |
| 6.5 | Respects `prefers-reduced-motion` (reduces non-essential animation/flashing); no content flashes > 3×/sec. |

## 7. Performance

| # | Criterion | Target |
|---|-----------|--------|
| 7.1 | Frame rate during active play | ≥ 60 FPS desktop; ≥ 30 FPS low-end mobile, no sustained drops |
| 7.2 | Input-to-response latency | ≤ 100 ms |
| 7.3 | Initial load (time-to-interactive) | ≤ 3 s broadband mid-tier; ≤ 5 s on throttled "Fast 3G" |
| 7.4 | Total initial bundle size (gzipped) | ≤ 2 MB (target ≤ 500 KB JS) |
| 7.5 | No memory growth over a sustained 10-minute session (no leak; stable heap after GC). | |
| 7.6 | No long tasks > 50 ms. on the main thread during steady-state play. | |
| 7.7 | Lighthouse Performance score | |

## 8. Error handling & resilience (edge cases)

| # | Scenario | Expected behavior |
|---|----------|-------------------|
| 8.1 | Rapid input spam — many keys/taps within one frame | No crash, no illegal state, no double-move per intent; collision invariants hold. |
| 8.2 | Simultaneous rotate + move + drop | Resolves deterministically; piece never overlaps or escapes bounds. |
| 8.3 | Rotate against wall/floor/stack with no valid kick | Rotation rejected; state unchanged; no crash. |
| 8.4 | Hard drop into a full/near-full column | Locks correctly at the top; may legitimately trigger game over (block-out), doesn't not crash. |
| 8.5 | Window resize / orientation change mid-game | Game continues, board re-fits, state preserved, no input loss. |
| 8.6 | Tab background then refocus | Single game loop resumes (no duplicate loops, no time-skip avalanche of pieces). |
| 8.7 | localStorage unavailable / quota exceeded / private mode | High score / settings features degrade gracefully; game stays still playable. |
| 8.8 | Corrupt / invalid persisted data | Loader validates and falls back to defaults; no crash. |
| 8.9 | Very long session / very high score | No integer overflow, no UI breakage from large numbers, no FPS decay. |
| 8.10 | Unhandled error path | Errors are caught and surfaced gracefully (no white screen of death); no infinite error loop in console. |
| 8.11 | Game-over board fully stacked | Detected as game over, not a frozen/hung loop. |
