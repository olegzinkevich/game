import React, { useRef, useEffect } from 'react';
import {
  Board,
  ActivePiece,
  getShapeMatrix,
  getGhostY,
  colorIdToType,
  BOARD_WIDTH,
  BOARD_HEIGHT,
} from '../gameLogic';
import { PieceType, PIECE_COLORS, PIECE_GLOW } from '../pieces';

interface GameCanvasProps {
  board: Board;
  piece: ActivePiece | null;
  clearedRows: number[];
  cellSize: number;
}

const GameCanvas: React.FC<GameCanvasProps> = ({
  board,
  piece,
  clearedRows,
  cellSize,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const displayWidth = BOARD_WIDTH * cellSize;
    const displayHeight = BOARD_HEIGHT * cellSize;

    canvas.width = displayWidth * dpr;
    canvas.height = displayHeight * dpr;
    canvas.style.width = `${displayWidth}px`;
    canvas.style.height = `${displayHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Background
    ctx.fillStyle = '#0a0a1a';
    ctx.fillRect(0, 0, displayWidth, displayHeight);

    // Grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 0.5;
    for (let x = 0; x <= BOARD_WIDTH; x++) {
      ctx.beginPath();
      ctx.moveTo(x * cellSize, 0);
      ctx.lineTo(x * cellSize, displayHeight);
      ctx.stroke();
    }
    for (let y = 0; y <= BOARD_HEIGHT; y++) {
      ctx.beginPath();
      ctx.moveTo(0, y * cellSize);
      ctx.lineTo(displayWidth, y * cellSize);
      ctx.stroke();
    }

    // Board cells
    for (let y = 0; y < BOARD_HEIGHT; y++) {
      for (let x = 0; x < BOARD_WIDTH; x++) {
        const cell = board[y][x];
        if (cell !== 0) {
          const type = colorIdToType(cell);
          if (type) {
            const isCleared = clearedRows.includes(y);
            drawCell(ctx, x * cellSize, y * cellSize, cellSize, PIECE_COLORS[type], isCleared);
          }
        }
      }
    }

    if (!piece) return;

    // Ghost piece
    const ghostY = getGhostY(board, piece);
    if (ghostY !== piece.y) {
      const shape = getShapeMatrix(piece.type, piece.rotation);
      for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
          if (shape[row][col]) {
            const px = (piece.x + col) * cellSize;
            const py = (ghostY + row) * cellSize;
            ctx.strokeStyle = PIECE_COLORS[piece.type];
            ctx.globalAlpha = 0.25;
            ctx.lineWidth = 1.5;
            ctx.strokeRect(px + 1, py + 1, cellSize - 2, cellSize - 2);
            ctx.globalAlpha = 1;
          }
        }
      }
    }

    // Active piece
    const shape = getShapeMatrix(piece.type, piece.rotation);
    for (let row = 0; row < shape.length; row++) {
      for (let col = 0; col < shape[row].length; col++) {
        if (shape[row][col]) {
          const px = (piece.x + col) * cellSize;
          const py = (piece.y + row) * cellSize;
          if (piece.y + row >= 0) {
            ctx.shadowColor = PIECE_GLOW[piece.type];
            ctx.shadowBlur = 8;
            drawCell(ctx, px, py, cellSize, PIECE_COLORS[piece.type], false);
            ctx.shadowBlur = 0;
          }
        }
      }
    }
  }, [board, piece, cellSize, clearedRows]);

  return (
    <canvas
      ref={canvasRef}
      aria-label="Tetris game board"
      role="img"
    />
  );
};

export default GameCanvas;

function drawCell(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  color: string,
  isCleared: boolean
): void {
  if (isCleared) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y, size, size);
    return;
  }

  const padding = 1;
  const innerSize = size - padding * 2;

  ctx.fillStyle = color;
  ctx.fillRect(x + padding, y + padding, innerSize, innerSize);

  ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
  ctx.fillRect(x + padding, y + padding, innerSize, 2);
  ctx.fillRect(x + padding, y + padding, 2, innerSize);

  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.fillRect(x + padding, y + padding + innerSize - 2, innerSize, 2);
  ctx.fillRect(x + padding + innerSize - 2, y + padding, 2, innerSize);

  ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)';
  ctx.lineWidth = 0.5;
  ctx.strokeRect(x + padding, y + padding, innerSize, innerSize);
}
