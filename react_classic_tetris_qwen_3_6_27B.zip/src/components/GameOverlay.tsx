import React from 'react';

interface GameOverlayProps {
  status: 'menu' | 'playing' | 'paused' | 'gameover';
  score: number;
  highScore: number;
  level: number;
  lines: number;
  onStart: () => void;
  onResume: () => void;
  onRestart: () => void;
}

const GameOverlay: React.FC<GameOverlayProps> = ({
  status,
  score,
  highScore,
  level,
  lines,
  onStart,
  onResume,
  onRestart,
}) => {
  if (status === 'playing') return null;

  return (
    <div className={`game-overlay ${status === 'gameover' ? 'overlay-gameover' : 'overlay-menu'}`}>
      <div className="overlay-content">
        {status === 'menu' && (
          <>
            <h1 className="overlay-title">TETRIS</h1>
            <p className="overlay-subtitle">Classic Arcade</p>
            <button className="overlay-btn" onClick={onStart} autoFocus aria-label="Start new game">
              START GAME
            </button>
            <div className="overlay-controls-info">
              <p className="controls-title">Controls</p>
              <div className="controls-grid">
                <span>← → Move</span>
                <span>↑ Rotate</span>
                <span>↓ Soft Drop</span>
                <span>Space Hard Drop</span>
                <span>C Hold</span>
                <span>P Pause</span>
                <span>R Restart</span>
              </div>
            </div>
            {highScore > 0 && (
              <p className="high-score-label">HIGH SCORE: {highScore.toLocaleString()}</p>
            )}
          </>
        )}

        {status === 'paused' && (
          <>
            <h2 className="overlay-title">PAUSED</h2>
            <button className="overlay-btn" onClick={onResume} autoFocus aria-label="Resume game">
              RESUME
            </button>
            <button className="overlay-btn secondary" onClick={onRestart} aria-label="Restart game">
              RESTART
            </button>
          </>
        )}

        {status === 'gameover' && (
          <>
            <h2 className="overlay-title">GAME OVER</h2>
            <div className="final-stats">
              <p className="stat-row">Score: <span className="stat-value">{score.toLocaleString()}</span></p>
              <p className="stat-row">Level: <span className="stat-value">{level}</span></p>
              <p className="stat-row">Lines: <span className="stat-value">{lines}</span></p>
              {score >= highScore && score > 0 && (
                <p className="new-high-score">★ NEW HIGH SCORE ★</p>
              )}
            </div>
            <button className="overlay-btn" onClick={onRestart} autoFocus aria-label="Play again">
              PLAY AGAIN
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default GameOverlay;
