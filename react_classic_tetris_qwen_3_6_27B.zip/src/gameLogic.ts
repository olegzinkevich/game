import {
  PieceType,
  PIECE_SHAPES,
  SRS_KICK_DATA,
  SRS_KICK_DATA_I,
  BOARD_WIDTH as PW,
  BOARD_HEIGHT as PH,
} from './pieces';

export const BOARD_WIDTH = PW;
export const BOARD_HEIGHT = PH;

export interface ActivePiece {
  type: PieceType;
  x: number;
  y: number;
  rotation: number; // 0-3
}

export type Board = number[][]; // 0 = empty, 1-7 = color id

export function createEmptyBoard(): Board {
  return Array.from({ length: BOARD_HEIGHT }, () => Array(BOARD_WIDTH).fill(0));
}

export function getShapeMatrix(type: PieceType, rotation: number): number[][] {
  return PIECE_SHAPES[type][rotation];
}

export function getSpawnPosition(type: PieceType): { x: number; y: number } {
  const shape = getShapeMatrix(type, 0);
  const shapeW = shape[0].length;
  return {
    x: Math.floor(BOARD_WIDTH / 2) - Math.floor(shapeW / 2),
    y: 0,
  };
}

export function pieceToColorId(type: PieceType): number {
  const types = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];
  return types.indexOf(type) + 1; // 1-7
}

export function colorIdToType(id: number): PieceType | null {
  const types: PieceType[] = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];
  return id >= 1 && id <= 7 ? types[id - 1] : null;
}

export function collision(
  board: Board,
  type: PieceType,
  rotation: number,
  x: number,
  y: number
): boolean {
  const shape = getShapeMatrix(type, rotation);
  for (let row = 0; row < shape.length; row++) {
    for (let col = 0; col < shape[row].length; col++) {
      if (shape[row][col]) {
        const boardX = x + col;
        const boardY = y + row;
        if (boardX < 0 || boardX >= BOARD_WIDTH || boardY >= BOARD_HEIGHT) {
          return true;
        }
        if (boardY >= 0 && board[boardY][boardX] !== 0) {
          return true;
        }
      }
    }
  }
  return false;
}

export function placePiece(board: Board, piece: ActivePiece): Board {
  const newBoard = board.map(row => [...row]);
  const shape = getShapeMatrix(piece.type, piece.rotation);
  const colorId = pieceToColorId(piece.type);
  for (let row = 0; row < shape.length; row++) {
    for (let col = 0; col < shape[row].length; col++) {
      if (shape[row][col]) {
        const boardY = piece.y + row;
        const boardX = piece.x + col;
        if (boardY >= 0 && boardY < BOARD_HEIGHT && boardX >= 0 && boardX < BOARD_WIDTH) {
          newBoard[boardY][boardX] = colorId;
        }
      }
    }
  }
  return newBoard;
}

export function clearLines(board: Board): { newBoard: Board; linesCleared: number; clearedRows: number[] } {
  const clearedRows: number[] = [];
  for (let row = BOARD_HEIGHT - 1; row >= 0; row--) {
    if (board[row].every(cell => cell !== 0)) {
      clearedRows.push(row);
    }
  }
  const linesCleared = clearedRows.length;
  if (linesCleared === 0) {
    return { newBoard: board, linesCleared: 0, clearedRows: [] };
  }

  // Remove cleared rows and add empty rows at top
  const remainingRows = board.filter((_, idx) => !clearedRows.includes(idx));
  const emptyRows = Array.from({ length: linesCleared }, () => Array(BOARD_WIDTH).fill(0));
  const newBoard: Board = [...emptyRows, ...remainingRows];
  return { newBoard, linesCleared, clearedRows };
}

export function getGhostY(board: Board, piece: ActivePiece): number {
  let ghostY = piece.y;
  while (!collision(board, piece.type, piece.rotation, piece.x, ghostY + 1)) {
    ghostY++;
  }
  return ghostY;
}

export function tryRotate(
  board: Board,
  piece: ActivePiece,
  direction: 1 | -1 // 1 = CW, -1 = CCW
): ActivePiece | null {
  const newRotation = (piece.rotation + direction + 4) % 4;
  if (!collision(board, piece.type, newRotation, piece.x, piece.y)) {
    return { ...piece, rotation: newRotation };
  }

  // SRS Wall Kicks
  const kickData = piece.type === 'I' ? SRS_KICK_DATA_I : SRS_KICK_DATA;
  // For CW: use index = piece.rotation
  // For CCW: use index = newRotation
  const kickIndex = direction === 1 ? piece.rotation : newRotation;
  const kicks = kickData[kickIndex];

  for (const [dx, dy] of kicks) {
    if (!collision(board, piece.type, newRotation, piece.x + dx, piece.y - dy)) {
      return {
        ...piece,
        x: piece.x + dx,
        y: piece.y - dy,
        rotation: newRotation,
      };
    }
  }

  return null; // Rotation rejected
}

export function getDropInterval(level: number): number {
  return Math.max(50, Math.floor(500 / (level + 1)));
}
