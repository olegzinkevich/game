// Tetromino definitions with standard colors
export type PieceType = 'I' | 'O' | 'T' | 'S' | 'Z' | 'J' | 'L';

export const PIECE_COLORS: Record<PieceType, string> = {
  I: '#00f0f0',
  O: '#f0f000',
  T: '#a000f0',
  S: '#00f000',
  Z: '#f00000',
  L: '#f0a000',
  J: '#0000f0',
};

export const PIECE_GLOW: Record<PieceType, string> = {
  I: 'rgba(0, 240, 240, 0.4)',
  O: 'rgba(240, 240, 0, 0.4)',
  T: 'rgba(160, 0, 240, 0.4)',
  S: 'rgba(0, 240, 0, 0.4)',
  Z: 'rgba(240, 0, 0, 0.4)',
  L: 'rgba(240, 160, 0, 0.4)',
  J: 'rgba(0, 0, 240, 0.4)',
};

// Each piece: array of rotation states (4 states each), each state is a 2D matrix
export const PIECE_SHAPES: Record<PieceType, number[][][]> = {
  I: [
    [[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]],
    [[0,0,1,0],[0,0,1,0],[0,0,1,0],[0,0,1,0]],
    [[0,0,0,0],[0,0,0,0],[1,1,1,1],[0,0,0,0]],
    [[0,1,0,0],[0,1,0,0],[0,1,0,0],[0,1,0,0]],
  ],
  O: [
    [[1,1],[1,1]],
    [[1,1],[1,1]],
    [[1,1],[1,1]],
    [[1,1],[1,1]],
  ],
  T: [
    [[0,1,0],[1,1,1],[0,0,0]],
    [[0,1,0],[0,1,1],[0,1,0]],
    [[0,0,0],[1,1,1],[0,1,0]],
    [[0,1,0],[1,1,0],[0,1,0]],
  ],
  S: [
    [[0,1,1],[1,1,0],[0,0,0]],
    [[0,1,0],[0,1,1],[0,0,1]],
    [[0,0,0],[0,1,1],[1,1,0]],
    [[1,0,0],[1,1,0],[0,1,0]],
  ],
  Z: [
    [[1,1,0],[0,1,1],[0,0,0]],
    [[0,0,1],[0,1,1],[0,1,0]],
    [[0,0,0],[1,1,0],[0,1,1]],
    [[0,1,0],[1,1,0],[1,0,0]],
  ],
  L: [
    [[0,0,1],[1,1,1],[0,0,0]],
    [[0,1,0],[0,1,0],[0,1,1]],
    [[0,0,0],[1,1,1],[1,0,0]],
    [[1,1,0],[0,1,0],[0,1,0]],
  ],
  J: [
    [[1,0,0],[1,1,1],[0,0,0]],
    [[0,1,1],[0,1,0],[0,1,0]],
    [[0,0,0],[1,1,1],[0,0,1]],
    [[0,1,0],[0,1,0],[1,1,0]],
  ],
};

// SRS Wall Kick Data
// For J, L, S, T, Z pieces (0→1, 1→2, 2→3, 3→0 and reverse)
export const SRS_KICK_DATA: number[][][] = [
  // 0→1
  [[0, 0], [-1, 0], [-1, -1], [0, 2], [-1, 2]],
  // 1→2
  [[0, 0], [1, 0], [1, 1], [0, -2], [1, -2]],
  // 2→3
  [[0, 0], [1, 0], [1, -1], [0, 2], [1, 2]],
  // 3→0
  [[0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]],
];

// I piece wall kick data (special cases)
export const SRS_KICK_DATA_I: number[][][] = [
  // 0→1
  [[0, 0], [-2, 0], [1, 0], [-2, 1], [1, -2]],
  // 1→2
  [[0, 0], [-1, 0], [2, 0], [-1, -2], [2, 1]],
  // 2→3
  [[0, 0], [2, 0], [-1, 0], [2, -1], [-1, 2]],
  // 3→0
  [[0, 0], [1, 0], [-2, 0], [1, 2], [-2, -1]],
];

export const PIECE_TYPES: PieceType[] = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];

export const BOARD_WIDTH = 10;
export const BOARD_HEIGHT = 20;
export const BASE_DROP_INTERVAL = 500; // ms
export const MIN_DROP_INTERVAL = 50; // ms
export const LINES_PER_LEVEL = 10;
export const LOCK_DELAY = 500; // ms

// Scoring
export const LINE_SCORES = [0, 100, 300, 500, 800];
export const SOFT_DROP_SCORE = 1;
export const HARD_DROP_SCORE = 2;
