// Audio manager using Web Audio API for synthesized sounds
export class AudioManager {
  private ctx: AudioContext | null = null;
  private enabled: boolean = true;

  private getCtx(): AudioContext | null {
    if (!this.ctx) {
      try {
        this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      } catch {
        return null;
      }
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public playMove(): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    this.playTone(ctx, 300, 0.05, 'square', 0.08);
  }

  public playRotate(): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    this.playTone(ctx, 400, 0.06, 'square', 0.08);
  }

  public playLock(): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    this.playTone(ctx, 150, 0.1, 'triangle', 0.12);
  }

  public playSoftDrop(): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    this.playTone(ctx, 200, 0.03, 'triangle', 0.05);
  }

  public playHardDrop(): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    this.playTone(ctx, 120, 0.12, 'sawtooth', 0.1);
  }

  public playLineClear(lines: number): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    const baseFreq = lines >= 4 ? 600 : 400;
    for (let i = 0; i < lines; i++) {
      setTimeout(() => {
        this.playTone(ctx, baseFreq + i * 100, 0.15, 'sine', 0.15);
      }, i * 80);
    }
  }

  public playGameOver(): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    const notes = [400, 350, 300, 250, 200];
    notes.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(ctx, freq, 0.2, 'sawtooth', 0.1);
      }, i * 150);
    });
  }

  public playHold(): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    this.playTone(ctx, 500, 0.08, 'sine', 0.1);
  }

  public playLevelUp(): void {
    if (!this.enabled) return;
    const ctx = this.getCtx();
    if (!ctx) return;
    const notes = [523, 659, 784, 1047];
    notes.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(ctx, freq, 0.12, 'sine', 0.15);
      }, i * 100);
    });
  }

  private playTone(ctx: AudioContext, freq: number, duration: number, type: OscillatorType, volume: number): void {
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(volume, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Graceful degradation
    }
  }

  public toggle(): void {
    this.enabled = !this.enabled;
  }
}
