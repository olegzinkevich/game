import { PieceType, PIECE_TYPES } from './pieces';

export class BagRandomizer {
  private bag: PieceType[] = [];

  public next(): PieceType {
    if (this.bag.length === 0) {
      this.fillBag();
    }
    return this.bag.shift()!;
  }

  public peek(count: number): PieceType[] {
    const result: PieceType[] = [];
    // Build a temporary bag if needed
    const temp = [...this.bag];
    while (result.length < count) {
      while (temp.length < 7) {
        temp.push(...this.shuffle([...PIECE_TYPES]));
      }
      result.push(temp.shift()!);
    }
    return result;
  }

  public reset(): void {
    this.bag = [];
  }

  private fillBag(): void {
    this.bag = this.shuffle([...PIECE_TYPES]);
  }

  private shuffle(array: PieceType[]): PieceType[] {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
}
