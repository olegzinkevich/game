import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Board,
  ActivePiece,
  createEmptyBoard,
  collision,
  placePiece,
  clearLines,
  tryRotate,
  getSpawnPosition,
  getDropInterval,
  getGhostY,
  BOARD_WIDTH,
  BOARD_HEIGHT,
} from './gameLogic';
import {
  PieceType,
  PIECE_COLORS,
  PIECE_SHAPES,
  LINE_SCORES,
  SOFT_DROP_SCORE,
  HARD_DROP_SCORE,
  LINES_PER_LEVEL,
  LOCK_DELAY,
} from './pieces';
import { BagRandomizer } from './bagRandomizer';
import { AudioManager } from './audio';
import GameCanvas from './components/GameCanvas';
import GameOverlay from './components/GameOverlay';
import './App.css';

type GameStatus = 'menu' | 'playing' | 'paused' | 'gameover';
const HIGH_SCORE_KEY = 'tetris_high_score';

function getHighScore(): number {
  try {
    const val = localStorage.getItem(HIGH_SCORE_KEY);
    if (val) {
      const parsed = parseInt(val, 10);
      if (!isNaN(parsed) && parsed >= 0) return parsed;
    }
  } catch { /* graceful degradation */ }
  return 0;
}

function saveHighScore(score: number): void {
  try {
    localStorage.setItem(HIGH_SCORE_KEY, String(score));
  } catch { /* graceful degradation */ }
}

const App: React.FC = () => {
  const [board, setBoard] = useState<Board>(createEmptyBoard);
  const [piece, setPiece] = useState<ActivePiece | null>(null);
  const [nextPieces, setNextPieces] = useState<PieceType[]>([]);
  const [heldPiece, setHeldPiece] = useState<PieceType | null>(null);
  const [canHold, setCanHold] = useState(true);
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(0);
  const [lines, setLines] = useState(0);
  const [highScore, setHighScore] = useState(getHighScore);
  const [status, setStatus] = useState<GameStatus>('menu');
  const [clearedRows, setClearedRows] = useState<number[]>([]);
  const [cellSize, setCellSize] = useState(28);

  const bagRef = useRef(new BagRandomizer());
  const audioRef = useRef(new AudioManager());
  const animFrameRef = useRef<number>(0);
  const lastDropRef = useRef(0);
  const lockDelayRef = useRef(0);
  const lockMovesRef = useRef(0);
  const softDropActiveRef = useRef(false);
  const statusRef = useRef(status);
  const pieceRef = useRef(piece);
  const boardRef = useRef(board);
  const scoreRef = useRef(score);
  const levelRef = useRef(level);
  const linesRef = useRef(lines);
  const heldPieceRef = useRef(heldPiece);
  const canHoldRef = useRef(canHold);

  useEffect(() => { statusRef.current = status; }, [status]);
  useEffect(() => { pieceRef.current = piece; }, [piece]);
  useEffect(() => { boardRef.current = board; }, [board]);
  useEffect(() => { scoreRef.current = score; }, [score]);
  useEffect(() => { levelRef.current = level; }, [level]);
  useEffect(() => { linesRef.current = lines; }, [lines]);
  useEffect(() => { heldPieceRef.current = heldPiece; }, [heldPiece]);
  useEffect(() => { canHoldRef.current = canHold; }, [canHold]);

  useEffect(() => {
    const updateSize = () => {
      const isMobile = window.innerWidth < 600;
      if (isMobile) {
        const availH = window.innerHeight - 280;
        const availW = window.innerWidth - 16;
        setCellSize(Math.max(14, Math.min(
          Math.floor(availW / BOARD_WIDTH),
          Math.floor(availH / BOARD_HEIGHT),
          28
        )));
      } else {
        const availH = window.innerHeight - 80;
        setCellSize(Math.max(20, Math.min(
          30,
          Math.floor(availH / BOARD_HEIGHT)
        )));
      }
    };
    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  useEffect(() => {
    const handleBlur = () => {
      if (statusRef.current === 'playing') {
        setStatus('paused');
      }
    };
    window.addEventListener('blur', handleBlur);
    return () => window.removeEventListener('blur', handleBlur);
  }, []);

  const spawnNext = useCallback((currentBoard: Board, currentBag: BagRandomizer): { piece: ActivePiece; nextQueue: PieceType[] } | null => {
    const type = currentBag.next();
    const pos = getSpawnPosition(type);
    const newPiece: ActivePiece = { type, x: pos.x, y: pos.y, rotation: 0 };

    if (collision(currentBoard, newPiece.type, newPiece.rotation, newPiece.x, newPiece.y)) {
      return null;
    }

    const remaining: PieceType[] = [];
    while (remaining.length < 3) {
      remaining.push(currentBag.next());
    }

    return { piece: newPiece, nextQueue: remaining };
  }, []);

  const lockPiece = useCallback(() => {
    const currentPiece = pieceRef.current;
    const currentBoard = boardRef.current;
    if (!currentPiece) return;

    const newBoard = placePiece(currentBoard, currentPiece);
    const { newBoard: clearedBoard, linesCleared, clearedRows: clearedRowIndices } = clearLines(newBoard);

    if (linesCleared > 0) {
      setClearedRows(clearedRowIndices);
      setBoard(clearedBoard);

      const newLines = linesRef.current + linesCleared;
      const newLevel = Math.floor(newLines / LINES_PER_LEVEL);
      const lineScore = LINE_SCORES[linesCleared] * (levelRef.current + 1);
      const newScore = scoreRef.current + lineScore;
      setScore(newScore);
      setLines(newLines);
      if (newLevel > levelRef.current) {
        setLevel(newLevel);
        audioRef.current.playLevelUp();
      }
      audioRef.current.playLineClear(linesCleared);

      setTimeout(() => {
        setClearedRows([]);
        const result = spawnNext(clearedBoard, bagRef.current);
        if (!result) {
          finishGame();
          return;
        }
        setBoard(clearedBoard);
        setPiece(result.piece);
        setNextPieces(result.nextQueue);
        setCanHold(true);
        lockDelayRef.current = 0;
        lockMovesRef.current = 0;
        lastDropRef.current = performance.now();
      }, 200);
    } else {
      setBoard(newBoard);
      audioRef.current.playLock();

      const result = spawnNext(newBoard, bagRef.current);
      if (!result) {
        finishGame();
        return;
      }
      setPiece(result.piece);
      setNextPieces(result.nextQueue);
      setCanHold(true);
      lockDelayRef.current = 0;
      lockMovesRef.current = 0;
      lastDropRef.current = performance.now();
    }
  }, [spawnNext]);

  const finishGame = useCallback(() => {
    setStatus('gameover');
    audioRef.current.playGameOver();
    const finalScore = scoreRef.current;
    const hs = getHighScore();
    if (finalScore > hs) {
      saveHighScore(finalScore);
      setHighScore(finalScore);
    }
  }, []);

  const startGame = useCallback(() => {
    const newBoard = createEmptyBoard();
    const newBag = new BagRandomizer();
    bagRef.current = newBag;

    const result = spawnNext(newBoard, newBag);
    if (!result) {
      setStatus('gameover');
      return;
    }

    setBoard(newBoard);
    setPiece(result.piece);
    setNextPieces(result.nextQueue);
    setHeldPiece(null);
    setCanHold(true);
    setScore(0);
    setLevel(0);
    setLines(0);
    setClearedRows([]);
    lockDelayRef.current = 0;
    lockMovesRef.current = 0;
    softDropActiveRef.current = false;
    lastDropRef.current = performance.now();
    setStatus('playing');
  }, [spawnNext]);

  const moveDown = useCallback(() => {
    const p = pieceRef.current;
    const b = boardRef.current;
    if (!p || statusRef.current !== 'playing') return;

    if (!collision(b, p.type, p.rotation, p.x, p.y + 1)) {
      setPiece({ ...p, y: p.y + 1 });
      if (softDropActiveRef.current) {
        setScore(s => s + SOFT_DROP_SCORE);
      }
      if (lockMovesRef.current > 0) {
        lockDelayRef.current = performance.now();
      }
    } else {
      if (lockDelayRef.current === 0) {
        lockDelayRef.current = performance.now();
      }
    }
  }, []);

  const moveLeft = useCallback(() => {
    const p = pieceRef.current;
    const b = boardRef.current;
    if (!p || statusRef.current !== 'playing') return;
    if (!collision(b, p.type, p.rotation, p.x - 1, p.y)) {
      setPiece({ ...p, x: p.x - 1 });
      audioRef.current.playMove();
      if (lockDelayRef.current > 0) {
        lockDelayRef.current = performance.now();
        lockMovesRef.current++;
        if (lockMovesRef.current >= 15) lockPiece();
      }
    }
  }, [lockPiece]);

  const moveRight = useCallback(() => {
    const p = pieceRef.current;
    const b = boardRef.current;
    if (!p || statusRef.current !== 'playing') return;
    if (!collision(b, p.type, p.rotation, p.x + 1, p.y)) {
      setPiece({ ...p, x: p.x + 1 });
      audioRef.current.playMove();
      if (lockDelayRef.current > 0) {
        lockDelayRef.current = performance.now();
        lockMovesRef.current++;
        if (lockMovesRef.current >= 15) lockPiece();
      }
    }
  }, [lockPiece]);

  const rotateCW = useCallback(() => {
    const p = pieceRef.current;
    const b = boardRef.current;
    if (!p || statusRef.current !== 'playing') return;
    const rotated = tryRotate(b, p, 1);
    if (rotated) {
      setPiece(rotated);
      audioRef.current.playRotate();
      if (lockDelayRef.current > 0) {
        lockDelayRef.current = performance.now();
        lockMovesRef.current++;
        if (lockMovesRef.current >= 15) lockPiece();
      }
    }
  }, [lockPiece]);

  const rotateCCW = useCallback(() => {
    const p = pieceRef.current;
    const b = boardRef.current;
    if (!p || statusRef.current !== 'playing') return;
    const rotated = tryRotate(b, p, -1);
    if (rotated) {
      setPiece(rotated);
      audioRef.current.playRotate();
      if (lockDelayRef.current > 0) {
        lockDelayRef.current = performance.now();
        lockMovesRef.current++;
        if (lockMovesRef.current >= 15) lockPiece();
      }
    }
  }, [lockPiece]);

  const hardDrop = useCallback(() => {
    const p = pieceRef.current;
    const b = boardRef.current;
    if (!p || statusRef.current !== 'playing') return;
    const ghostY = getGhostY(b, p);
    const dropCells = ghostY - p.y;
    setScore(s => s + HARD_DROP_SCORE * dropCells);
    setPiece({ ...p, y: ghostY });
    audioRef.current.playHardDrop();
    setTimeout(() => lockPiece(), 0);
  }, [lockPiece]);

  const holdPiece = useCallback(() => {
    const p = pieceRef.current;
    if (!p || !canHoldRef.current || statusRef.current !== 'playing') return;

    audioRef.current.playHold();
    const currentType = p.type;

    if (heldPieceRef.current !== null) {
      const swapType = heldPieceRef.current;
      const pos = getSpawnPosition(swapType);
      const newPiece: ActivePiece = { type: swapType, x: pos.x, y: pos.y, rotation: 0 };
      if (collision(boardRef.current, newPiece.type, newPiece.rotation, newPiece.x, newPiece.y)) {
        finishGame();
        return;
      }
      setPiece(newPiece);
      setHeldPiece(currentType);
    } else {
      setHeldPiece(currentType);
      const result = spawnNext(boardRef.current, bagRef.current);
      if (!result) {
        finishGame();
        return;
      }
      setPiece(result.piece);
      setNextPieces(result.nextQueue);
    }
    setCanHold(false);
    lockDelayRef.current = 0;
    lockMovesRef.current = 0;
    lastDropRef.current = performance.now();
  }, [spawnNext, finishGame]);

  // Game loop
  useEffect(() => {
    if (status !== 'playing') return;

    const loop = (now: number) => {
      if (statusRef.current !== 'playing') return;

      const p = pieceRef.current;
      if (!p) {
        animFrameRef.current = requestAnimationFrame(loop);
        return;
      }

      const dropInterval = getDropInterval(levelRef.current);
      const effectiveInterval = softDropActiveRef.current ? Math.min(dropInterval, 50) : dropInterval;

      if (now - lastDropRef.current >= effectiveInterval) {
        lastDropRef.current = now;
        moveDown();
      }

      if (lockDelayRef.current > 0) {
        const b = boardRef.current;
        const cp = pieceRef.current;
        if (cp && collision(b, cp.type, cp.rotation, cp.x, cp.y + 1)) {
          if (now - lockDelayRef.current >= LOCK_DELAY) {
            lockPiece();
            lockDelayRef.current = 0;
            lockMovesRef.current = 0;
          }
        } else {
          lockDelayRef.current = 0;
        }
      }

      animFrameRef.current = requestAnimationFrame(loop);
    };

    lastDropRef.current = performance.now();
    animFrameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [status, moveDown, lockPiece]);

  // Keyboard
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      const s = statusRef.current;
      if (['ArrowLeft', 'ArrowRight', 'ArrowDown', 'ArrowUp', 'Space', 'KeyR', 'KeyP', 'Escape', 'KeyC', 'ShiftLeft', 'ShiftRight', 'KeyX', 'KeyZ'].includes(e.code)) {
        e.preventDefault();
      }

      if (e.code === 'KeyR') { startGame(); return; }
      if ((e.code === 'KeyP' || e.code === 'Escape') && s === 'playing') { setStatus('paused'); return; }
      if ((e.code === 'KeyP' || e.code === 'Escape' || e.code === 'Enter') && s === 'paused') { setStatus('playing'); return; }
      if (e.code === 'Enter' && (s === 'menu' || s === 'gameover')) { startGame(); return; }
      if (s !== 'playing') return;

      switch (e.code) {
        case 'ArrowLeft': moveLeft(); break;
        case 'ArrowRight': moveRight(); break;
        case 'ArrowDown': softDropActiveRef.current = true; moveDown(); break;
        case 'ArrowUp': case 'KeyX': case 'ControlRight': rotateCW(); break;
        case 'KeyZ': case 'ControlLeft': rotateCCW(); break;
        case 'Space': hardDrop(); break;
        case 'KeyC': case 'ShiftLeft': case 'ShiftRight': holdPiece(); break;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ArrowDown') softDropActiveRef.current = false;
    };

    window.addEventListener('keydown', handleKey, { passive: false });
    window.addEventListener('keyup', handleKeyUp, { passive: false });
    return () => {
      window.removeEventListener('keydown', handleKey);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [moveLeft, moveRight, moveDown, rotateCW, rotateCCW, hardDrop, holdPiece, startGame]);

  const handleTouchMove = useCallback((dir: 'left' | 'right') => {
    if (dir === 'left') moveLeft(); else moveRight();
  }, [moveLeft, moveRight]);

  const handleTouchRotate = useCallback((dir: 'cw' | 'ccw') => {
    if (dir === 'cw') rotateCW(); else rotateCCW();
  }, [rotateCW, rotateCCW]);

  const handleTouchSoftDrop = useCallback(() => {
    softDropActiveRef.current = true;
    moveDown();
  }, [moveDown]);

  const handleTouchHardDrop = useCallback(() => { hardDrop(); }, [hardDrop]);
  const handleTouchHold = useCallback(() => { holdPiece(); }, [holdPiece]);
  const handleTouchPause = useCallback(() => {
    if (statusRef.current === 'playing') setStatus('paused');
    else if (statusRef.current === 'paused') setStatus('playing');
  }, []);

  // Preview grid helper
  const renderPreview = (type: PieceType | null, previewColor?: string) => {
    if (!type) return null;
    const shape = PIECE_SHAPES[type][0];
    const color = previewColor || PIECE_COLORS[type];
    return (
      <div
        className="preview-grid"
        style={{ gridTemplateColumns: `repeat(${shape[0].length}, 14px)` }}
      >
        {shape.flat().map((cell, i) => (
          <div
            key={i}
            className="preview-cell"
            style={{
              backgroundColor: cell ? color : 'transparent',
              boxShadow: cell ? `inset 0 0 6px ${color}, 0 0 4px ${color}` : 'none',
            }}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="app">
      <div className="game-container">
        <div className="game-board-wrapper">
          <GameCanvas
            board={board}
            piece={piece}
            clearedRows={clearedRows}
            cellSize={cellSize}
          />
          <GameOverlay
            status={status}
            score={score}
            highScore={highScore}
            level={level}
            lines={lines}
            onStart={startGame}
            onResume={() => setStatus('playing')}
            onRestart={startGame}
          />
        </div>

        <div className="side-panel">
          <div className="panel-section">
            <h3 className="panel-label">SCORE</h3>
            <p className="panel-value score-value">{score.toLocaleString()}</p>
          </div>

          <div className="panel-section">
            <h3 className="panel-label">HIGH SCORE</h3>
            <p className="panel-value high-score-value">{highScore.toLocaleString()}</p>
          </div>

          <div className="panel-section">
            <h3 className="panel-label">LEVEL</h3>
            <p className="panel-value">{level}</p>
          </div>

          <div className="panel-section">
            <h3 className="panel-label">LINES</h3>
            <p className="panel-value">{lines}</p>
          </div>

          <div className="panel-section">
            <h3 className="panel-label">NEXT</h3>
            <div className="preview-box">
              {nextPieces.map((type, i) => (
                <div key={i} className="preview-item">
                  {renderPreview(type)}
                </div>
              ))}
            </div>
          </div>

          <div className="panel-section">
            <h3 className="panel-label">HOLD{!canHold ? ' ✕' : ''}</h3>
            <div className={`preview-box ${!canHold ? 'preview-used' : ''}`}>
              {renderPreview(heldPiece, canHold ? undefined : '#555')}
            </div>
          </div>

          <div className="panel-section panel-buttons">
            {status === 'playing' && (
              <button className="panel-btn" onClick={() => setStatus('paused')} aria-label="Pause">PAUSE</button>
            )}
            {status === 'paused' && (
              <button className="panel-btn" onClick={() => setStatus('playing')} aria-label="Resume">RESUME</button>
            )}
            <button className="panel-btn" onClick={startGame} aria-label="Restart">RESTART</button>
          </div>
        </div>
      </div>

      <div className="touch-controls" aria-label="Touch controls">
        <div className="touch-row touch-row-top">
          <button className="touch-btn touch-btn-small" onTouchStart={(e) => { e.preventDefault(); handleTouchHold(); }} aria-label="Hold piece">HOLD</button>
          <button className="touch-btn touch-btn-small" onTouchStart={(e) => { e.preventDefault(); handleTouchPause(); }} aria-label="Pause game">⏸</button>
        </div>
        <div className="touch-row touch-row-dir">
          <button className="touch-btn" onTouchStart={(e) => { e.preventDefault(); handleTouchMove('left'); }} aria-label="Move left">◀</button>
          <button className="touch-btn" onTouchStart={(e) => { e.preventDefault(); handleTouchRotate('ccw'); }} aria-label="Rotate CCW">↶</button>
          <button className="touch-btn touch-btn-down" onTouchStart={(e) => { e.preventDefault(); handleTouchSoftDrop(); }} aria-label="Soft drop">▼</button>
          <button className="touch-btn" onTouchStart={(e) => { e.preventDefault(); handleTouchRotate('cw'); }} aria-label="Rotate CW">↷</button>
          <button className="touch-btn" onTouchStart={(e) => { e.preventDefault(); handleTouchMove('right'); }} aria-label="Move right">▶</button>
        </div>
        <div className="touch-row touch-row-drop">
          <button className="touch-btn touch-btn-hard" onTouchStart={(e) => { e.preventDefault(); handleTouchHardDrop(); }} aria-label="Hard drop">⏬ DROP</button>
        </div>
      </div>
    </div>
  );
};

export default App;
