# Qwen Image 2.1: one character, many scenes (native reference)

Workflow file: `qwen_image_ipadapter.json`

Goal: take one reference image of a character and generate many scenes from plot descriptions. Face, outfit and details stay the same; pose and movement are free.

Status: the JSON is valid and every link connects, but the workflow hasn't been run in ComfyUI yet.

## Despite the file name, there's no IP-Adapter

No IP-Adapter is trained for Qwen Image 2.1. This workflow uses the model's **built-in reference conditioning** instead: the encoder `TextEncodeQwenImage21` takes up to 16 images, and Qwen3-VL reads them together with the prompt. That does the job of an IP-Adapter: the model takes the appearance from the reference and the pose from the text.

This is the simplest of the three workflows, and the only one that follows the official templates exactly. The other two add IP-Adapter-style control on top of it:

| Workflow | Approach | Start/end control | Strength | Custom nodes |
|---|---|---|---|---|
| `qwen_image_ipadapter.json` (this one) | Native reference for all steps | No | No | None |
| `qwen_image_timestep_reference.json` | Vision tokens first, then native reference | Yes (REF START) | No | None |
| `qwen_image_reference_latent.json` | Vision tokens + Reference Latent+ | Yes, per image | Yes | comfyui-ReferenceLatentPlus |

## Installation

Nothing beyond ComfyUI with Qwen Image 2.1 support.

### Models (Hugging Face: `Comfy-Org/Qwen-Image-2.1`)

| Folder | File |
|---|---|
| `models/diffusion_models/` | `qwen_image_2.1_int8_convrot.safetensors` (or `_bf16`) |
| `models/text_encoders/` | `qwen3vl_8b_int8_convrot.safetensors` (or `_bf16`) |
| `models/vae/` | `qwen_image_2.1_vae_bf16.safetensors` |

## Pipeline

1. **CHARACTER REFERENCE** (`LoadImage`, file `character_reference.png`): `<image1>` in the prompts. A sharp full-body shot with a neutral pose and plain background works best. The image goes straight into the encoders, which resize it to about 1 MP (`resolution` 1024).
2. **Stage A: turnaround sheet.** Generates front, three-quarter and back views of the character on a 1536×1024 canvas. It's saved as `qwen21_char/turnaround` and becomes `<image2>` in every scene, so the model knows what the sides and back of the outfit look like.
3. **Stage B: 4 scenes.** Each scene is a separate image of 1344×768, from a single size node shared by all scenes. Each scene runs this chain:
   1. The shared **IDENTITY LOCK** text is joined to the scene's plot text (`StringConcatenate`).
   2. `TextEncodeQwenImage21` receives the joined text, `<image1>` and `<image2>`, with a **VAE connected**: the standard reference path.
   3. `KSampler` on an empty canvas: the composition doesn't copy the reference, so the pose is free.
   4. `VAEDecode` → `SaveImage` (`qwen21_char/scene_01` … `scene_04`).
4. The `Qwen Image 2.1 Cache` node reuses the reference processing between steps.

### IDENTITY LOCK

The text shared by all scenes says: same face, hair, body, outfit, colors, prints and accessories; nothing added or removed; take side and back details from `<image2>`; don't copy the reference's pose, camera angle, lighting or background; keep the rendering style of `<image1>`; create a new image with a new pose and clear movement. The scene's plot text follows it.

### Sampling

- euler, simple scheduler, 25 steps (the official pipeline uses 40–50 for maximum quality).
- CFG 1, so the negative prompt has no effect.
- The same fixed seed (42) in every sampler helps consistency.

## Writing the scene text

- Describe the **action, pose and camera** explicitly. That's what gives the character movement.
- **Don't** describe the face or clothes in words: point at `<image1>`. Words make the model redraw the outfit.
- To add a scene, copy one scene row (6 nodes), paste with Ctrl+Shift+V (this keeps the input links), and change the text.
- For a different image size, change the shared Scene canvas node (multiples of 32, about 1 MP; up to about 4 MP / 2048×2048 natively).

## Tuning

| Problem | What to change |
|---|---|
| The turnaround sheet drifts | Change the Stage A seed, or disconnect `images.image_2` in the scene encoders and remove the `<image2>` sentence from IDENTITY LOCK |
| The pose copies the reference | Describe the action and camera in more detail; use a reference with a neutral pose. Otherwise move to `qwen_image_timestep_reference.json` |
| The reference's background leaks in | Use a reference with a plain background, or the cutout from the other two workflows |
| Clothing details drift | Add an outfit close-up as `images.image_3` and mention `<image3>` in IDENTITY LOCK |
| Poses look too similar | Give each scene its own seed |
| Speed | Turbo: `qwen_image_2.1_turbo_*.safetensors`, 8 steps (the official turbo template uses ManualSigmas) |
| Errors or out of memory | Set `device = off` on the `Qwen Image 2.1 Cache` node |

## Limitations

- **No reference strength or start/end control.** The reference acts on every step at full strength. If the pose sticks to the reference, use one of the other two workflows.
- **No background isolation.** The original background of the reference can leak into scenes.
- **Older than the other two.** This workflow still uses the turnaround sheet, 4 scenes and one shared canvas. The other two were rebuilt as start image → cutout → 3 scenes, each with its own size node.

## Sources

- [ComfyUI docs: Qwen Image 2.1](https://docs.comfy.org/tutorials/image/qwen/qwen-image-2-1.md)
- [Official Qwen Image 2.1 image edit template](https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_qwen_image_2_1_image_edit.json)
- [ComfyUI source code](https://github.com/comfyanonymous/ComfyUI): `comfy_extras/nodes_qwen.py`
- [Qwen/Qwen-Image-2.1 model card](https://huggingface.co/Qwen/Qwen-Image-2.1)
