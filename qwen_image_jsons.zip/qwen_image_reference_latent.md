# Qwen Image 2.1 + Reference Latent+: start image → cutout → 3 scenes

Workflow file: `qwen_image_reference_latent.json`

Goal: take one start image of a character, cut the character out, and use that cutout as the reference for 3 separate scene images. Face, outfit and details stay the same; pose and movement are free.

Status: the JSON is valid and every link connects, but the workflow hasn't been run in ComfyUI yet.

## Why not an IP-Adapter

No IP-Adapter is trained for Qwen Image 2.1. A community IP-Adapter was announced for the original Qwen-Image, but the two models don't share an architecture: the original is 20B and 2.1 is 7B. Adapters built for one won't load on the other.

The closest IP-Adapter-style control on 2.1 is the custom node **Reference Latent+**. It gives each reference image its own strength, a start/end range of denoising steps, and a mask.

## Installation

1. Clone [comfyui-ReferenceLatentPlus](https://github.com/shootthesound/comfyui-ReferenceLatentPlus) into `ComfyUI/custom_nodes/`.
2. Restart ComfyUI.

You don't need mediapipe for this workflow: the mask comes from the cutout's transparency, not from automatic face/body detection.

### Models (Hugging Face: `Comfy-Org/Qwen-Image-2.1`)

| Folder | File |
|---|---|
| `models/diffusion_models/` | `qwen_image_2.1_int8_convrot.safetensors` (or `_bf16`) |
| `models/text_encoders/` | `qwen3vl_8b_int8_convrot.safetensors` (or `_bf16`) |
| `models/vae/` | `qwen_image_2.1_vae_bf16.safetensors` |

## Pipeline

### Stage 1: start image → character cutout

1. **START IMAGE** (`LoadImage`, file `start_image.png`): the character in any background.
2. `ImageScaleToTotalPixels`: about 1 MP, multiple of 32.
3. Qwen 2.1 removes the background itself, using the prompt from the official template: *"Remove the background, and output a PNG image"*. The encoder gets the image with a VAE, and the sampler works on the encoder's latent, so the output keeps the start image's size.
4. The Qwen 2.1 VAE has 4 channels (RGBA), so `VAEDecode` returns a real transparent PNG. It's saved as `qwen21_char/cutout`. **Check it before the scenes:** the outfit and accessories must be intact.

Already have a cutout PNG? Load it with your own `LoadImage` and connect it wherever the cutout's `VAEDecode` output goes.

### Stage 2: 3 separate scene images

Each scene is a **separate image** with its own size node (default 1344×768, which you can change per scene). The cutout goes into every scene through two channels:

| Channel | Source | Role | Controls |
|---|---|---|---|
| Semantic | Vision tokens from `TextEncodeQwenImage21` (vae **not connected**) | General identity and outfit, like the image embedding of an IP-Adapter | Always on |
| Detail | Reference Latent+ (VAE-encoded cutout) | Fabric, prints, buttons, face | Strength, start/end, mask |

Each scene runs this chain:

1. The shared **IDENTITY LOCK** text is joined to the scene's plot text (`StringConcatenate`).
2. `TextEncodeQwenImage21` receives the joined text and the cutout (RGBA), with no VAE.
3. **Reference Latent+** receives the cutout from `SplitImageWithAlpha` and the alpha mask from `InvertMask` as `mask_1`. Settings: strength 0.9, active from 0.2 to 1.0, `pixel_grey` fill. Everything outside the character turns grey, so no background reaches the scene.
4. `KSampler` → `VAEDecode` → `SaveImage` (`qwen21_char/scene_01`, `_02`, `_03`).

**Never connect `vae` to the scene encoders.** If you do, the encoder adds its own reference latents and Reference Latent+ adds a second copy.

Why the mask is inverted: `SplitImageWithAlpha` outputs the mask as `1 − alpha`, which is ComfyUI's convention for transparency. Reference Latent+ expects `1` where the character is, hence `InvertMask`.

### Reference Latent+ settings in the scenes

| Parameter | Value | IP-Adapter equivalent |
|---|---|---|
| `image1_strength` | 0.9 | weight |
| `image1_start_percent` | 0.2 | start_at |
| `image1_end_percent` | 1.0 | end_at |
| `mask_1` | Cutout alpha | attention mask |
| `max_megapixels` | 1.0 | |
| `mask_fill_mode` | `pixel_grey` | |

For the first 20% of denoising there are no reference latents, so the text and vision tokens set the pose and composition. After that, the latents lock in the details.

### Sampling

- euler, simple scheduler, 25 steps (the official pipeline uses 40–50 for maximum quality).
- CFG 1, so the negative prompt has no effect.
- The same fixed seed (42) in every scene helps consistency.

## Writing the scene text

- Describe the **action, pose and camera** explicitly. That's what gives the character movement.
- **Don't** describe the face or clothes in words: point at `<image1>`. Words make the model redraw the outfit.
- To add a scene, copy one scene row (8 nodes), paste with Ctrl+Shift+V (this keeps the input links), and change the text.

## Tuning

| Problem | What to change |
|---|---|
| The pose copies the reference | Raise `image1_start_percent` to 0.3–0.5, or lower `strength` to 0.7 |
| Clothing details drift | Lower `start_percent` to 0.1, raise `strength` to 1.0–1.2 |
| The cutout clipped part of the outfit | Change the cutout seed, or load your own cutout PNG |
| Grey halo around the character | Try `mask_fill_mode = latent_zero` |
| Vision tokens dominate | Lower `strength` only if the details are already holding, or raise `start_percent` |
| Poses look too similar | Give each scene its own seed |
| Errors or out of memory | Set `device = off` on the `Qwen Image 2.1 Cache` node |

Start with a sweep: run one scene with the fixed seed at `start_percent` 0.0, 0.2 and 0.4, then pick a value.

## Risks

- **Reference Latent+ was tuned on Flux2/Klein.** Its README lists "Qwen-Image" but not 2.1, so the best values on 2.1 may differ.
- **The reference latents sit in a non-standard position.** Qwen 2.1 normally inserts each reference latent at its image's position in the prompt. With no VAE on the encoder there are no such positions, so the model places the latents after the text. The code supports this (`build_sequence` in `comfy/ldm/qwen_image21/model.py`), but the official templates don't use it.
- **Reference Latent+ drops the alpha channel** before VAE encoding (`img[:, :, :, :3]`). That's why the mask is wired explicitly: without it, the RGB under the transparent pixels would go into the reference.
- **Caching with step ranges.** The conditioning changes partway through sampling, so the cache node keeps a separate cache for each range. If memory runs short, turn the cache off.

## Sources

- [comfyui-ReferenceLatentPlus (GitHub)](https://github.com/shootthesound/comfyui-ReferenceLatentPlus)
- [ComfyUI docs: Qwen Image 2.1](https://docs.comfy.org/tutorials/image/qwen/qwen-image-2-1.md)
- [Official Qwen Image 2.1 background removal template](https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_qwen_image_2_1_background_removal.json)
- [Official Qwen Image 2.1 image edit template](https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_qwen_image_2_1_image_edit.json)
- [ComfyUI source code](https://github.com/comfyanonymous/ComfyUI): `comfy_extras/nodes_qwen.py`, `comfy_extras/nodes_compositing.py`, `comfy/text_encoders/qwen_image21.py`, `comfy/ldm/qwen_image21/model.py`, `comfy/sd.py` (RGBA VAE)
- [Qwen/Qwen-Image-2.1 model card](https://huggingface.co/Qwen/Qwen-Image-2.1)
