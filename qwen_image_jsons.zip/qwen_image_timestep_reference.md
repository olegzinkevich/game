# Qwen Image 2.1: start image → cutout → 3 scenes (built-in nodes only)

Workflow file: `qwen_image_timestep_reference.json`

Goal: take one start image of a character, cut the character out, and use that cutout as the reference for 3 separate scene images. Face, outfit and details stay the same; pose and movement are free. Unlike `qwen_image_reference_latent.json`, this version needs **no custom nodes**: everything is core ComfyUI.

Status: the JSON is valid and every link connects, but the workflow hasn't been run in ComfyUI yet.

## The idea

IP-Adapter has `start_at` / `end_at`: the reference doesn't act from the first step, so the text has time to set the pose and composition. This workflow builds the same effect from two encodings of the same prompt, switched partway through sampling:

| Phase | Steps | Encoder | What the model gets |
|---|---|---|---|
| 1 | 0 → REF START | `TextEncodeQwenImage21` with the cutout, **no VAE** | The reference as Qwen3-VL vision tokens only: general identity and outfit, no pixel latents. Pose follows the text. |
| 2 | REF START → 1 | `TextEncodeQwenImage21` with the cutout **and VAE** | The native Qwen 2.1 path: reference latents at their image slots in the prompt. Fine details (face, fabric, prints) lock in. |

`ConditioningSetTimestepRange` limits each encoding to its phase, and `ConditioningCombine` joins them into one `positive` for the KSampler.

This relies on ComfyUI's Qwen 2.1 code (`comfy_extras/nodes_qwen.py`, `comfy/text_encoders/qwen_image21.py`): without a VAE the encoder keeps the vision tokens and adds no reference latents; with a VAE it drops the vision tokens and puts reference latents in their place.

## Installation

Nothing beyond ComfyUI with Qwen Image 2.1 support.

### Models (Hugging Face: `Comfy-Org/Qwen-Image-2.1`)

| Folder | File |
|---|---|
| `models/diffusion_models/` | `qwen_image_2.1_int8_convrot.safetensors` (or `_bf16`) |
| `models/text_encoders/` | `qwen3vl_8b_int8_convrot.safetensors` (or `_bf16`) |
| `models/vae/` | `qwen_image_2.1_vae_bf16.safetensors` |

## Pipeline

### Stage 1: start image → character cutout

1. **START IMAGE** (`LoadImage`, file `start_image.png`): the character in any background.
2. `ImageScaleToTotalPixels`: about 1 MP, multiple of 32.
3. Qwen 2.1 removes the background itself, using the prompt from the official template: *"Remove the background, and output a PNG image"*. The output keeps the start image's size.
4. The Qwen 2.1 VAE has 4 channels (RGBA), so `VAEDecode` returns a real transparent PNG. It's saved as `qwen21_char/cutout`. **Check it before the scenes:** the outfit and accessories must be intact.

Already have a cutout PNG? Load it with your own `LoadImage` and connect it wherever the cutout's `VAEDecode` output goes.

### Stage 2: 3 separate scene images

Each scene is a **separate image** with its own size node (default 1344×768, which you can change per scene). **REF START** (red `Float` node, default **0.2**) sets the switch point for all scenes at once.

Each scene runs this chain:

1. The shared **IDENTITY LOCK** text is joined to the scene's plot text (`StringConcatenate`).
2. The joined text and the cutout go to two encoders: phase 1 (no VAE) and phase 2 (with VAE).
3. `ConditioningSetTimestepRange` sets phase 1 to `0 → REF START` and phase 2 to `REF START → 1`.
4. `ConditioningCombine` → `KSampler` (negative from the phase 2 encoder) → `VAEDecode` → `SaveImage` (`qwen21_char/scene_01`, `_02`, `_03`).

The cutout goes in as RGBA, with no extra nodes. The encoder handles transparency itself: the vision tower sees the character over white, and the VAE keeps all 4 channels. The model therefore gets only the character, without the original background.

### Sampling

- euler, simple scheduler, 25 steps (the official pipeline uses 40–50 for maximum quality).
- CFG 1, so the negative prompt has no effect.
- The same fixed seed (42) in every scene helps consistency.

## Writing the scene text

- Describe the **action, pose and camera** explicitly. That's what gives the character movement.
- **Don't** describe the face or clothes in words: point at `<image1>`. Words make the model redraw the outfit.
- To add a scene, copy one scene row (11 nodes), paste with Ctrl+Shift+V (this keeps the input links), and change the text.

## Tuning

| Problem | What to change |
|---|---|
| The pose copies the reference | Raise REF START to 0.3–0.5 |
| Clothing or face details drift | Lower REF START to 0.1. At 0.0 it's the plain native reference |
| The cutout clipped part of the outfit | Change the cutout seed, or load your own cutout PNG |
| A white or empty background appears in the scene | The scene text needs a more detailed setting; or raise REF START |
| Poses look too similar | Give each scene its own seed |
| Errors or out of memory | Set `device = off` on the `Qwen Image 2.1 Cache` node |

Start with a sweep: run one scene with the fixed seed at REF START 0.0, 0.2 and 0.4, then pick a value.

## Comparison with Reference Latent+

| | This workflow (built-in) | `qwen_image_reference_latent.json` |
|---|---|---|
| Custom nodes | None | comfyui-ReferenceLatentPlus |
| Start/end control | Yes, one switch point | Yes, separate for each image |
| Strength (weight) | No | Yes |
| Background isolation | The cutout's transparency, handled by the encoder | The cutout's alpha as an explicit mask, grey fill |
| Reference latent placement | Native: at the image slots in the prompt | After the text (not the official layout) |
| Survives ComfyUI updates | Yes, core nodes only | Depends on the custom node |

## Limitations

- **No strength control.** The only lever is REF START.
- **Phase 1 with vision tokens only is an alternative path.** ComfyUI supports it (the image is then conditioned through the text encoder alone), but the official templates always connect a VAE. How strong it is on its own hasn't been tested.
- **A transparent reference is an input the templates don't show.** The encoder supports alpha by design, but the official examples use opaque references. If scenes come out with an empty or white background, describe the setting in more detail.
- **Two encoders per scene.** Text encoding takes about twice as long, and the cache node keeps a separate cache for each phase.

## Sources

- [ComfyUI docs: Qwen Image 2.1](https://docs.comfy.org/tutorials/image/qwen/qwen-image-2-1.md)
- [Official Qwen Image 2.1 background removal template](https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_qwen_image_2_1_background_removal.json)
- [Official Qwen Image 2.1 image edit template](https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_qwen_image_2_1_image_edit.json)
- [ComfyUI source code](https://github.com/comfyanonymous/ComfyUI): `nodes.py` (`ConditioningSetTimestepRange`, `ConditioningCombine`), `comfy_extras/nodes_qwen.py`, `comfy/text_encoders/qwen_image21.py`, `comfy/sd.py` (RGBA VAE)
- [Qwen/Qwen-Image-2.1 model card](https://huggingface.co/Qwen/Qwen-Image-2.1)
