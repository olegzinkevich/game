export default function TouchControls({
  onLeft, onRight, onSoftRise, onHardRise,
  onRotateCW, onRotateCCW, onHold, onPause,
}) {
  const btnStyle = {
    width: '64px',
    height: '64px',
    fontSize: '22px',
    fontWeight: 'bold',
    border: '2px solid rgba(255,255,255,0.3)',
    borderRadius: '12px',
    backgroundColor: 'rgba(255,255,255,0.1)',
    color: '#fff',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    userSelect: 'none',
    WebkitUserSelect: 'none',
    touchAction: 'manipulation',
    WebkitTapHighlightColor: 'transparent',
  };

  return (
    <div className="touch-controls" role="group" aria-label="Touch controls">
      <div className="touch-row">
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); onRotateCCW(); }}
          onMouseDown={onRotateCCW}
          aria-label="Rotate counter-clockwise"
        >
          ↶
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); onRotateCW(); }}
          onMouseDown={onRotateCW}
          aria-label="Rotate clockwise"
        >
          ↷
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); onHold(); }}
          onMouseDown={onHold}
          aria-label="Hold piece"
        >
          H
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onClick={onPause}
          aria-label="Pause"
        >
          ⏸
        </button>
      </div>
      <div className="touch-row">
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); onLeft(); }}
          onMouseDown={onLeft}
          aria-label="Move left"
        >
          ←
        </button>
        <button
          className="touch-btn"
          style={{ ...btnStyle, width: '90px' }}
          onTouchStart={(e) => { e.preventDefault(); onSoftRise(); }}
          onMouseDown={onSoftRise}
          aria-label="Soft rise"
        >
          ↑
        </button>
        <button
          className="touch-btn"
          style={btnStyle}
          onTouchStart={(e) => { e.preventDefault(); onRight(); }}
          onMouseDown={onRight}
          aria-label="Move right"
        >
          →
        </button>
        <button
          className="touch-btn"
          style={{ ...btnStyle, backgroundColor: 'rgba(255,80,80,0.25)' }}
          onTouchStart={(e) => { e.preventDefault(); onHardRise(); }}
          onMouseDown={onHardRise}
          aria-label="Hard rise"
        >
          ⏫
        </button>
      </div>
    </div>
  );
}
