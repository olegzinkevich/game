import { useRef, useCallback } from 'react';
import useTetrisGame from '../utils/useTetrisGame';
import TetrisCanvas from './TetrisCanvas';
import SidePanel from './SidePanel';
import TouchControls from './TouchControls';

export default function TetrisGame() {
  const canvasRef = useRef(null);

  const {
    stateRef,
    draw,
    startGame,
    pauseGame,
    moveLeft,
    moveRight,
    softRise,
    hardRise,
    rotateCW,
    rotateCCW,
    holdPiece,
  } = useTetrisGame(canvasRef);

  const handleRestart = useCallback(() => {
    startGame();
  }, [startGame]);

  const handleStart = useCallback(() => {
    startGame();
  }, [startGame]);

  return (
    <div className="game-container">
      <div className="game-main">
        <div className="canvas-wrapper">
          <canvas
            ref={canvasRef}
            className="tetris-canvas"
            aria-label="Inverted Tetris game board"
            role="img"
          />
          <TetrisCanvas canvasRef={canvasRef} stateRef={stateRef} draw={draw} />
        </div>

        <TouchControls
          onLeft={moveLeft}
          onRight={moveRight}
          onSoftRise={softRise}
          onHardRise={hardRise}
          onRotateCW={rotateCW}
          onRotateCCW={rotateCCW}
          onHold={holdPiece}
          onPause={pauseGame}
        />
      </div>

      <SidePanel
        stateRef={stateRef}
        onStart={handleStart}
        onRestart={handleRestart}
        onPause={pauseGame}
      />
    </div>
  );
}
