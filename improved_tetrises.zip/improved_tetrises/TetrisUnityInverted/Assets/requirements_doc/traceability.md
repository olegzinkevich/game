# Traceability & compliance report — scaffold

One row per requirement atom in [`requirements.md`](./requirements.md). The verifying
agent fills `status`, `evidence`, and `notes` for every row, then completes the summary.

**`status` legend:** `satisfied` · `partial` · `not-satisfied` · `needs-manual` · `not-found`
- `satisfied` — the EARS statement holds and the Gherkin scenario would pass (cite evidence).
- `partial` — partially met; state the gap in `notes`.
- `not-satisfied` — implemented but wrong/absent behavior.
- `needs-manual` — `verify_method: manual`, or `llm-judge` couldn't conclude from code; say what to check.
- `not-found` — no corresponding implementation located.

**`evidence`** — `path:line` (preferred) or a concrete observation.

| ID | Title | Priority | Verify | Status | Evidence | Notes |
|---|---|---|---|---|---|---|
| NFR-LOAD-001 | Time to interactive | must | manual | | | |
| FR-LIFE-001 | Clean startup | must | manual | | | |
| FR-LIFE-002 | Start spawns first figure + rise | must | llm-judge | | | |
| FR-LIFE-003 | Stable game-loop cadence | must | manual | | | |
| FR-LIFE-004 | Pause stops rise and timer | must | llm-judge | | | |
| FR-LIFE-005 | Pause ignores gameplay input | must | llm-judge | | | |
| FR-LIFE-006 | Resume restores identical state | must | llm-judge | | | |
| FR-LIFE-007 | Restart resets state | must | llm-judge | | | |
| FR-LIFE-008 | Tab blur auto-pause | should | llm-judge | | | |
| FR-GRID-001 | Playfield dimensions (15×35) | must | llm-judge | | | |
| FR-GRID-002 | Cell state | must | llm-judge | | | |
| FR-GRID-003 | Entire field visible (35 rows) | should | manual | | | |
| FR-PIECE-001 | Exactly four figures exist | must | llm-judge | | | |
| FR-PIECE-002 | Figure colors | should | llm-judge | | | |
| FR-PIECE-003 | Three cells per figure | must | llm-judge | | | |
| FR-PIECE-004 | Spawn position centered at bottom | must | llm-judge | | | |
| FR-CFG-001 | Base rise interval | must | llm-judge | | | |
| FR-CFG-002 | Minimum rise interval | must | llm-judge | | | |
| FR-CFG-003 | Lines per level | must | llm-judge | | | |
| FR-SPAWN-001 | 4-bag randomizer | must | llm-judge | | | |
| FR-SPAWN-002 | Next preview matches spawn | must | llm-judge | | | |
| FR-SPAWN-003 | Hold swap once per figure | should | llm-judge | | | |
| FR-MOVE-006 | Inverted gravity — figures rise | must | llm-judge | | | |
| FR-MOVE-001 | Horizontal move by one column | must | llm-judge | | | |
| FR-MOVE-002 | Blocked horizontal move rejected | must | llm-judge | | | |
| FR-MOVE-003 | Automatic rise ascent | must | llm-judge | | | |
| FR-MOVE-004 | Soft rise accelerates ascent | must | llm-judge | | | |
| FR-MOVE-005 | Hard rise locks instantly | must | llm-judge | | | |
| FR-ROT-001 | Rotate 90° about pivot | must | llm-judge | | | |
| FR-ROT-002 | Wall kicks | should | llm-judge | | | |
| FR-ROT-003 | Impossible rotation rejected | must | llm-judge | | | |
| FR-COL-001 | Collision integrity invariant | must | llm-judge | | | |
| FR-LOCK-001 | Lock on landing and spawn next | must | llm-judge | | | |
| FR-LOCK-002 | Bounded lock delay | should | llm-judge | | | |
| FR-GHOST-001 | Ghost figure matches landing | should | llm-judge | | | |
| FR-CLEAR-001 | Single line clear | must | llm-judge | | | |
| FR-CLEAR-002 | Double line clear | must | llm-judge | | | |
| FR-CLEAR-003 | Triple line clear | must | llm-judge | | | |
| FR-CLEAR-004 | Maximum three rows per lock | must | llm-judge | | | |
| FR-CLEAR-005 | Non-contiguous clears preserve gaps | must | llm-judge | | | |
| FR-CLEAR-006 | No false clear | must | llm-judge | | | |
| FR-SCORE-001 | Score monotonic and non-negative | must | llm-judge | | | |
| FR-SCORE-002 | Line-clear scoring scale (1/2/3) | must | llm-judge | | | |
| FR-SCORE-003 | Lines counter increments exactly | must | llm-judge | | | |
| FR-SCORE-004 | Soft/hard rise points | should | llm-judge | | | |
| FR-SCORE-005 | High score persists across reloads | should | llm-judge | | | |
| FR-LEVEL-001 | Level increases every 10 lines | must | llm-judge | | | |
| FR-LEVEL-002 | Rise speeds up with level | must | llm-judge | | | |
| FR-OVER-001 | Block-out ends game | must | llm-judge | | | |
| FR-OVER-002 | Game-over screen w/ score + restart | must | llm-judge | | | |
| FR-OVER-003 | No board mutation after game over | must | llm-judge | | | |
| FR-OVER-004 | No spawn after game over until restart | must | llm-judge | | | |
| FR-ARCH-001 | Timer-driven game cycle | must | llm-judge | | | |
| FR-ARCH-002 | 2D array field (15×35, 1..4) | should | llm-judge | | | |
| FR-CTRL-001 | Keyboard bindings | must | llm-judge | | | |
| NFR-CTRL-002 | Input latency | must | manual | | | |
| FR-CTRL-003 | Deterministic repeat / simultaneous keys | should | llm-judge | | | |
| FR-CTRL-004 | Touch controls reachable | should | manual | | | |
| FR-CTRL-005 | Suppress browser default gestures | must | llm-judge | | | |
| UI-HUD-001 | HUD shows/updates score/level/lines | must | llm-judge | | | |
| UI-HUD-002 | Distinguishable figure/ghost/locked | should | manual | | | |
| UI-HUD-003 | Visual feedback clears / game over | should | manual | | | |
| UI-LAYOUT-001 | Side panel content | must | llm-judge | | | |
| UI-RESP-001 | Adaptive layout without overflow | must | manual | | | |
| UI-RESP-002 | Playfield aspect ratio preserved | must | manual | | | |
| UI-RESP-003 | No layout shift / horizontal scroll | should | manual | | | |
| FR-AUDIO-001 | Move/rotate click | could | manual | | | |
| FR-AUDIO-002 | Landing sound | could | manual | | | |
| FR-AUDIO-003 | Line-clear chime (1–2) | could | manual | | | |
| FR-AUDIO-004 | Triple-clear sound | could | manual | | | |
| FR-AUDIO-005 | Game-over sound | could | manual | | | |
| NFR-A11Y-001 | Keyboard-operable menus w/ focus | should | manual | | | |
| NFR-A11Y-002 | Color not the only signal | should | manual | | | |
| NFR-A11Y-003 | WCAG AA contrast | should | manual | | | |
| NFR-A11Y-004 | Accessible names + canvas label | should | llm-judge | | | |
| NFR-A11Y-005 | Respect reduced motion; limit flashing | should | manual | | | |
| NFR-PERF-001 | Frame rate | must | manual | | | |
| NFR-PERF-002 | Time to interactive (throttled) | should | manual | | | |
| NFR-PERF-003 | Bundle size | should | manual | | | |
| NFR-PERF-004 | No memory growth | should | manual | | | |
| NFR-PERF-005 | No long main-thread tasks | should | manual | | | |
| NFR-COMPAT-001 | Desktop browsers | must | manual | | | |
| NFR-COMPAT-002 | Mobile browsers | must | manual | | | |
| NFR-COMPAT-003 | Graceful optional-API fallback | should | llm-judge | | | |
| NFR-COMPAT-004 | Static HTTPS hosting | must | llm-judge | | | |
| NFR-COMPAT-005 | HiDPI crispness | should | manual | | | |
| FR-ERR-001 | Input spam safe | must | llm-judge | | | |
| FR-ERR-002 | Concurrent rotate+move+rise deterministic | must | llm-judge | | | |
| FR-ERR-003 | Hard rise into full column | must | llm-judge | | | |
| FR-ERR-004 | Resize / orientation mid-game | should | manual | | | |
| FR-ERR-005 | localStorage unavailable degrades | should | llm-judge | | | |
| FR-ERR-006 | Corrupt persisted data falls back | should | llm-judge | | | |
| FR-ERR-007 | Large numbers / long session safe | could | manual | | | |
| FR-ERR-008 | Graceful unhandled-error handling | must | llm-judge | | | |

## Coverage summary (fill after grading)

- Total atoms: **94**
- `satisfied`: ___
- `partial`: ___
- `not-satisfied`: ___
- `needs-manual`: ___
- `not-found`: ___

### Must-have status
- Must-have atoms total: ___ / satisfied: ___ / outstanding: ___

### Outstanding items (every `partial` / `not-satisfied` / `not-found`)
| ID | Status | Gap |
|---|---|---|
| | | |
