# `requirements_doc/` — Dual-use requirements spec

This folder is the rewritten, **atomic, traceable** version of
[`../acceptance_criteria_tetris.md`](../acceptance_criteria_tetris.md), produced according
to the standard in [`../requirements_doc_standard.md`](../requirements_doc_standard.md)
(§5 "What good looks like" and §6 "Migration plan").

## Inverted variant (this folder)

The records here have been **adapted from classic Tetris into an inverted variant**. Four
deliberate changes drive the adaptation (see the "Adaptation note" at the top of
[`requirements.md`](./requirements.md) for the per-atom impact):

1. **Inverted gravity** — figures spawn at the **bottom-center** and **rise upward**, locking
   against the top wall / underside of the stack; the stack grows from the top down.
2. **Exactly four figures, three cells each** — the set is **I** (`#30b5c5`), **P** (`#c00000`),
   **L** (`#ED6D00`), **C** "cube-without-one-cell" (`#a0d183`); no other figures, no four-cell
   pieces. Geometry is illustrated in [`Figures.png`](./Figures.png) and tabulated in
   `requirements.md`.
3. **Larger field** — the playfield is **15 wide × 35 high** (was 10×20).
4. **No quad clears** — a three-cell figure spans at most three rows, so a single lock clears
   **at most three** rows (scoring, clearing, and audio atoms adapted accordingly).

## Files
| File | Role |
|---|---|
| [`requirements.md`](./requirements.md) | The source of truth. One **atomic** requirement per record, each carrying an **EARS** statement (drives generation) and **Gherkin** acceptance (drives compliance), keyed by a **stable ID**. |
| [`traceability.md`](./traceability.md) | The report scaffold. One row per requirement ID for the verifying agent to fill with a verdict + evidence. |

## How the verifying agent should use this folder
1. Read every record in `requirements.md`. Each record is **one atom** with a unique `id`.
2. For each atom, determine compliance against the codebase per its `verify_method`:
   - **`llm-judge`** — inspect the code/behavior and reason about whether the EARS
     statement holds and the Gherkin scenario would pass. Cite the file(s)/line(s) as evidence.
   - **`manual`** — cannot be confirmed by code reasoning alone (needs a real device,
     a running browser, visual/audio/perf measurement, or human judgement). Mark
     `needs-manual` and state exactly what a human must check.
3. Emit a report by copying `traceability.md` and filling each row with one `status`:
   `satisfied | partial | not-satisfied | needs-manual | not-found`,
   plus `evidence` (file:line or observation) and a short `notes`.
4. End the report with a coverage summary: counts per status and a list of every
   `not-satisfied` / `partial` atom with the gap.

> **No tests yet.** Records intentionally omit any `test_ref`. `verify_method` is limited
> to `llm-judge` or `manual`. When automated tests are added later, add a `test_ref:` field
> and an `automated` verify method per the standard.

## Conventions
- **ID is permanent.** Never renumber or reuse an ID; it is the traceability anchor.
- **Atomic.** One `SHALL` / one pass-fail per record. Compound source criteria were split.
- **`source:`** points back to the original section in `acceptance_criteria_tetris.md`.
- **Non-normative material** from the source (§3.11 per-engine implementation
  recommendations, §5.4 visual-style suggestions) is **not** turned into requirements; see
  the note at the end of `requirements.md`.
