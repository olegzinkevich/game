using UnityEngine;

/// <summary>
/// Static library with all figure definitions for Inverted Tetris.
/// 4 figures: I (cyan), P (red), L (orange), C (green).
/// Each figure has 4 rotation states (0°, 90°, 180°, 270° CW).
/// Cells are relative to a pivot point; pivot is near the visual centre of the piece.
/// Coordinates are (col, row) where col increases right and row increases up.
/// </summary>
public static class Figures
{
    public const string I_NAME = "I";
    public const string P_NAME = "P";
    public const string L_NAME = "L";
    public const string C_NAME = "C";

    public const int FIGURE_COUNT = 4;
    public const int CELLS_PER_FIGURE = 3;

    // Standard (index 0) dimensions
    public const int I_WIDTH = 1;
    public const int I_HEIGHT = 3;
    public const int P_WIDTH = 2;
    public const int P_HEIGHT = 3;
    public const int L_WIDTH = 2;
    public const int L_HEIGHT = 3;
    public const int C_WIDTH = 2;
    public const int C_HEIGHT = 2;

    // Assigned colors
    public static readonly Color I_COLOR = new Color(0.1882f, 0.7098f, 0.7725f);   // #30b5c5 cyan
    public static readonly Color P_COLOR = new Color(0.7529f, 0f, 0f);              // #c00000 red
    public static readonly Color L_COLOR = new Color(0.9294f, 0.4275f, 0f);          // #ED6D00 orange
    public static readonly Color C_COLOR = new Color(0.6275f, 0.8196f, 0.5137f);     // #a0d183 green

    // Color id 1 = I, 2 = P, 3 = L, 4 = C
    public const byte COLOR_ID_I = 1;
    public const byte COLOR_ID_P = 2;
    public const byte COLOR_ID_L = 3;
    public const byte COLOR_ID_C = 4;

    public static string Name(int index)
    {
        return index switch
        {
            0 => I_NAME,
            1 => P_NAME,
            2 => L_NAME,
            3 => C_NAME,
            _ => "Unknown"
        };
    }

    public static Color ColorFor(int index)
    {
        return index switch
        {
            0 => I_COLOR,
            1 => P_COLOR,
            2 => L_COLOR,
            3 => C_COLOR,
            _ => Color.magenta
        };
    }

    public static byte ColorId(int index)
    {
        return (byte)(index + 1);
    }

    public static int IndexFromColorId(byte id)
    {
        return id - 1;
    }

    /// <summary>
    /// Width of figure in its standard (rotation 0) orientation.
    /// </summary>
    public static int SpawnWidth(int index)
    {
        return index switch
        {
            0 => I_WIDTH,
            1 => P_WIDTH,
            2 => L_WIDTH,
            3 => C_WIDTH,
            _ => 1
        };
    }

    /// <summary>
    /// Cell offsets for each rotation state of each figure.
    /// rotations[figureIndex][rotationState] = Vector2Int[col, row]
    /// rotationState 0 = standard spawn, 1 = 90° CW, 2 = 180°, 3 = 270° CW.
    /// Cells are relative to the pivot.
    /// </summary>
    public static Vector2Int[][][] Rotations = new Vector2Int[FIGURE_COUNT][][]
    {
        // --- Figure I ---
        new Vector2Int[]
        {
            new Vector2Int[] { new Vector2Int( 0,  0), new Vector2Int( 0,  1), new Vector2Int( 0,  2) }, // 0°  vertical
            new Vector2Int[] { new Vector2Int(-1,  0), new Vector2Int( 0,  0), new Vector2Int( 1,  0) }, // 90° horizontal
            new Vector2Int[] { new Vector2Int( 0,  0), new Vector2Int( 0,  1), new Vector2Int( 0,  2) }, // 180° vertical
            new Vector2Int[] { new Vector2Int(-1,  0), new Vector2Int( 0,  0), new Vector2Int( 1,  0) }, // 270° horizontal
        },
        // --- Figure P ---
        new Vector2Int[]
        {
            new Vector2Int[] { new Vector2Int( 1,  1), new Vector2Int( 0,  0), new Vector2Int( 0,  1) }, // 0°
            new Vector2Int[] { new Vector2Int( 0,  1), new Vector2Int(-1,  0), new Vector2Int( 0,  0) }, // 90° CW
            new Vector2Int[] { new Vector2Int(-1, -1), new Vector2Int( 0,  0), new Vector2Int( 0, -1) }, // 180°
            new Vector2Int[] { new Vector2Int( 0, -1), new Vector2Int( 1,  0), new Vector2Int( 0,  0) }, // 270° CW
        },
        // --- Figure L ---
        new Vector2Int[]
        {
            new Vector2Int[] { new Vector2Int( 0,  1), new Vector2Int( 0,  0), new Vector2Int( 1, -1) }, // 0°
            new Vector2Int[] { new Vector2Int(-1,  0), new Vector2Int( 0,  0), new Vector2Int( 1,  1) }, // 90° CW
            new Vector2Int[] { new Vector2Int( 0, -1), new Vector2Int( 0,  0), new Vector2Int(-1,  1) }, // 180°
            new Vector2Int[] { new Vector2Int( 1,  0), new Vector2Int( 0,  0), new Vector2Int(-1, -1) }, // 270° CW
        },
        // --- Figure C ---
        new Vector2Int[]
        {
            new Vector2Int[] { new Vector2Int( 0,  0), new Vector2Int( 0,  1), new Vector2Int( 1,  1) }, // 0°
            new Vector2Int[] { new Vector2Int(-1,  0), new Vector2Int( 0,  0), new Vector2Int( 0,  1) }, // 90° CW
            new Vector2Int[] { new Vector2Int( 0, -1), new Vector2Int( 0, -2), new Vector2Int(-1, -2) }, // 180°
            new Vector2Int[] { new Vector2Int( 1,  0), new Vector2Int( 0,  0), new Vector2Int( 0, -1) }, // 270° CW
        },
    };

    /// <summary>
    /// Width of a figure at a given rotation state.
    /// </summary>
    public static int WidthAtRotation(int figureIdx, int rotation)
    {
        var cells = Rotations[figureIdx][rotation];
        int minX = int.MaxValue, maxX = int.MinValue;
        foreach (var c in cells)
        {
            if (c.x < minX) minX = c.x;
            if (c.x > maxX) maxX = c.x;
        }
        return maxX - minX + 1;
    }

    /// <summary>
    /// Height of a figure at a given rotation state.
    /// </summary>
    public static int HeightAtRotation(int figureIdx, int rotation)
    {
        var cells = Rotations[figureIdx][rotation];
        int minY = int.MaxValue, maxY = int.MinValue;
        foreach (var c in cells)
        {
            if (c.y < minY) minY = c.y;
            if (c.y > maxY) maxY = c.y;
        }
        return maxY - minY + 1;
    }
}
