using System.Collections.Generic;
public static class Board
{
    public const int W = 15, H = 35;
    public static byte[,] New() => new byte[W, H];

    public static bool Hit(byte[,] bd, int t, int r, int px, int py)
    {
        var c = Figures.Rotations[t][r];
        foreach (var v in c)
        {
            int cx = px + v.x, cy = py + v.y;
            if (cx < 0 || cx >= W || cy >= H) return true;
            if (cy >= 0 && bd[cx, cy] != 0) return true;
        }
        return false;
    }

    public static void Lock(byte[,] bd, int t, int r, int px, int py)
    {
        var c = Figures.Rotations[t][r];
        byte id = (byte)(t + 1);
        foreach (var v in c) { int cx = px + v.x, cy = py + v.y; if (cx >= 0 && cx < W && cy >= 0 && cy < H) bd[cx, cy] = id; }
    }

    public static int Clear(byte[,] bd)
    {
        HashSet<int> full = new HashSet<int>();
        for (int r = 0; r < H; r++) { bool ok = true; for (int c = 0; c < W; c++) { if (bd[c, r] == 0) { ok = false; break; } } if (ok) full.Add(r); }
        if (full.Count == 0) return 0;
        // Inverted gravity: rows BELOW cleared row shift UP (toward row H-1). Empty gaps at bottom.
        byte[,] tmp = new byte[W, H];
        int src = 0, dst = 0;
        while (src < H && full.Contains(src)) src++;
        while (dst < H)
        {
            if (full.Contains(dst)) { dst++; continue; }
            if (src < H)
            {
                for (int c = 0; c < W; c++) tmp[c, dst] = bd[c, src];
                src++; dst++;
                while (src < H && full.Contains(src)) src++;
            }
            else { dst++; }
        }
        for (int r = 0; r < H; r++) for (int c = 0; c < W; c++) bd[c, r] = tmp[c, r];
        return full.Count;
    }

    public static int GhostY(byte[,] bd, int t, int r, int px, int py)
    {
        int gy = py;
        while (!Hit(bd, t, r, px, gy + 1)) gy++;
        return gy;
    }

    public static int HardTarget(byte[,] bd, int t, int r, int px, int py)
    {
        int ty = py;
        while (!Hit(bd, t, r, px, ty + 1)) ty++;
        return ty;
    }

    public static int HardDist(byte[,] bd, int t, int r, int px, int py)
    {
        int ty = py;
        while (!Hit(bd, t, r, px, ty + 1)) ty++;
        return ty - py;
    }
}
