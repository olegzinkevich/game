using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void AutoInit()
    {
        if (_instance == null)
        {
            var go = new GameObject("GameManager");
            _instance = go.AddComponent<GameManager>();
            DontDestroyOnLoad(go);
        }
    }

    private const int W = 15, H = 35;
    private static GameManager _instance;
    private void Awake()
    {
        if (_instance != null && _instance != this) { Destroy(gameObject); return; }
        _instance = this;
        DontDestroyOnLoad(gameObject);
        InitGame();
    }

    private const float BASE_RI = 0.5f, MIN_RI = 0.05f;
    private const float LOCK_DUR = 0.5f, SOFT_RI = 0.055f;
    private const float REP_INIT = 0.17f, REP_DL = 0.05f;
    private enum State { MENU, PLAYING, PAUSED, OVER }
    private State state = State.MENU;
    private byte[,] board;
    private int score = 0, level = 1, linesCleared = 0, hiScore = 0, linesThisLevel = 0;
    private int fType = 0, fRot = 0, fX = 0, fY = 0;
    private bool fAlive = false, lockStarted = false;
    private float lockT = 0f, riseA = 0f, softA = 0f;
    private bool softRise = false, downL = false, downR = false;
    private float leftRep = 0f, rightRep = 0f;
    private int ghostY = 0;
    private int heldType = -1, holdUsed = 0;
    private Queue<int> bag = new Queue<int>();
    private bool isFlash = false;
    private float flashT = 0f;
    private int flashLines = 0;
    private Canvas canvas;
    private Image[,] cellImgs;
    private Image flashImg;
    private TextMeshProUGUI txtScore, txtLevel, txtLines, txtHigh;
    private Transform nextPrev, holdPrev;
    internal GameObject scrStart, scrPause, scrOver;
    private TextMeshProUGUI txtOverScore;

    void InitGame()
    {
        board = new byte[W, H];
        GameUI.Build(out canvas, out cellImgs, out flashImg, out txtScore, out txtLevel, out txtLines, out txtHigh,
            out nextPrev, out holdPrev, out scrStart, out scrPause, out scrOver, out txtOverScore);
        LoadHi(); UpdateHUD(); GameUI.ShowStart(true);
    }

    void Update()
    {
        DoInput();
        if (state != State.PLAYING) { RenderBoardOnly(); return; }
        float dt = Time.deltaTime;
        if (softRise && fAlive)
        {
            softA += dt;
            if (softA >= SOFT_RI)
            {
                softA = 0f;
                if (TryMv(0, 1)) { score += 1; lockStarted = false; lockT = 0f; }
            }
        }
        else if (fAlive)
        {
            riseA += dt;
            if (riseA >= GetRI())
            {
                riseA = 0f;
                if (!TryMv(0, 1))
                {
                    if (!lockStarted) { lockStarted = true; lockT = 0f; }
                }
                else { lockStarted = false; lockT = 0f; }
            }
        }
        if (lockStarted && fAlive) { lockT += dt; if (lockT >= LOCK_DUR) DoLock(); }
        if (downL) { leftRep += dt; if (leftRep >= REP_INIT) { TryMv(-1, 0); leftRep = REP_DL; } }
        if (downR) { rightRep += dt; if (rightRep >= REP_INIT) { TryMv(1, 0); rightRep = REP_DL; } }
        if (isFlash)
        {
            flashT += dt;
            if (flashT >= 0.25f) { isFlash = false; flashImg.color = Color.clear; }
            else { flashImg.color = new Color(1, 1, 1, 0.7f * Mathf.Max(0, 1f - flashT / 0.25f)); }
        }
        Draw();
    }

    void OnApplicationFocus(bool f) { if (!f && state == State.PLAYING) DoPause(); }
    float GetRI() { float v = BASE_RI / (level + 1); return Mathf.Max(v, MIN_RI); }

    void DoInput()
    {
        if (state == State.MENU)
        {
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space)) DoStart();
            if (Input.GetKeyDown(KeyCode.R)) DoRestart();
            return;
        }
        if (state == State.OVER)
        {
            if (Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space)) DoRestart();
            return;
        }
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            if (state == State.PLAYING) DoPause();
            else if (state == State.PAUSED) DoResume();
            return;
        }
        if (state != State.PLAYING) return;
        if (Input.GetKeyDown(KeyCode.LeftArrow)) { TryMv(-1, 0); leftRep = REP_INIT; downL = true; downR = false; }
        if (Input.GetKeyDown(KeyCode.RightArrow)) { TryMv(1, 0); rightRep = REP_INIT; downR = true; downL = false; }
        if (Input.GetKeyUp(KeyCode.LeftArrow)) { downL = false; leftRep = 0f; }
        if (Input.GetKeyUp(KeyCode.RightArrow)) { downR = false; rightRep = 0f; }
        bool prevSoft = softRise;
        softRise = Input.GetKey(KeyCode.UpArrow);
        if (softRise && !prevSoft) softA = 0f;
        if (!softRise) softA = 0f;
        if (Input.GetKeyDown(KeyCode.Space)) DoHard();
        if (Input.GetKeyDown(KeyCode.X)) DoRot(1);
        if (Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown(KeyCode.LeftControl) || Input.GetKeyDown(KeyCode.RightControl)) DoRot(-1);
        if (Input.GetKeyDown(KeyCode.C) || Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift)) DoHold();
        if (Input.GetKeyDown(KeyCode.R)) DoRestart();
    }

    void FillBag()
    {
        int[] a = { 0, 1, 2, 3 };
        for (int i = 3; i > 0; i--) { int j = UnityEngine.Random.Range(0, i + 1); int tmp = a[i]; a[i] = a[j]; a[j] = tmp; }
        foreach (int v in a) bag.Enqueue(v);
    }

    int NextFig() { if (bag.Count == 0) FillBag(); return bag.Dequeue(); }

    void SpawnFigure()
    {
        fType = NextFig();
        int w = Figures.WidthAtRotation(fType, 0);
        fX = (W / 2) - (w / 2); fY = 0; fRot = 0;
        fAlive = true; lockStarted = false; lockT = 0f; holdUsed = 0;
        if (Board.Hit(board, fType, fRot, fX, fY)) { fAlive = false; DoGameOver(); return; }
        ghostY = Board.GhostY(board, fType, fRot, fX, fY);
    }

    bool TryMv(int dx, int dy)
    {
        if (!fAlive) return false;
        int nx = fX + dx, ny = fY + dy;
        if (Board.Hit(board, fType, fRot, nx, ny)) return false;
        fX = nx; fY = ny;
        if (dx != 0 || dy > 0) { lockStarted = false; lockT = 0f; }
        ghostY = Board.GhostY(board, fType, fRot, fX, fY);
        return true;
    }

    void DoHard()
    {
        if (!fAlive) return;
        int ty = Board.HardTarget(board, fType, fRot, fX, fY);
        int dist = ty - fY;
        score += dist * 2;
        fY = ty;
        DoLock();
    }

    void DoRot(int dir)
    {
        if (!fAlive) return;
        int nr = (fRot + dir); if (nr < 0) nr += 4; nr %= 4;
        if (!Board.Hit(board, fType, nr, fX, fY))
        {
            fRot = nr; lockStarted = false; lockT = 0f;
            ghostY = Board.GhostY(board, fType, fRot, fX, fY); return;
        }
        int[] kx = { 1, -1, 2, -2, 3, -3 };
        foreach (int ox in kx)
            if (!Board.Hit(board, fType, nr, fX + ox, fY))
            { fX += ox; fRot = nr; lockStarted = false; lockT = 0f; ghostY = Board.GhostY(board, fType, fRot, fX, fY); return; }
        foreach (int oy in new int[] { -1, 1 })
            foreach (int ox in new int[] { 1, -1 })
                if (!Board.Hit(board, fType, nr, fX + ox, fY + oy))
                { fX += ox; fY += oy; fRot = nr; lockStarted = false; lockT = 0f; ghostY = Board.GhostY(board, fType, fRot, fX, fY); return; }
    }

    void DoLock()
    {
        if (!fAlive) return;
        fAlive = false;
        Board.Lock(board, fType, fRot, fX, fY);
        int cleared = Board.Clear(board);
        if (cleared > 0) DoScore(cleared);
        SpawnFigure();
    }

    void DoScore(int n)
    {
        int[] pts = { 0, 100, 300, 500 };
        score += pts[n] * level;
        linesCleared += n; linesThisLevel += n;
        if (linesThisLevel >= 10) { linesThisLevel -= 10; level++; }
        if (score > hiScore) { hiScore = score; SaveHi(); }
        isFlash = true; flashT = 0f; flashLines = n;
        UpdateHUD();
    }

    void DoHold()
    {
        if (!fAlive || holdUsed == 1) return;
        int swap = heldType;
        heldType = fType;
        holdUsed = 1;
        if (swap >= 0)
        {
            fType = swap; fRot = 0;
            int w = Figures.WidthAtRotation(fType, fRot);
            fX = (W / 2) - (w / 2); fY = 0;
            lockStarted = false; lockT = 0f;
            if (Board.Hit(board, fType, fRot, fX, fY)) { fAlive = false; DoGameOver(); return; }
            ghostY = Board.GhostY(board, fType, fRot, fX, fY);
        }
        else { SpawnFigure(); }
    }

    public void DoStart()
    {
        state = State.PLAYING; score = 0; level = 1; linesCleared = 0; linesThisLevel = 0;
        board = Board.New(); bag.Clear(); heldType = -1; holdUsed = 0;
        riseA = 0f; softA = 0f; softRise = false;
        GameUI.ShowStart(false); GameUI.ShowPause(false); GameUI.ShowOver(false);
        UpdateHUD(); SpawnFigure();
    }

    public void DoPause()
    {
        if (state != State.PLAYING) return;
        state = State.PAUSED; GameUI.ShowPause(true);
    }

    void DoResume() { if (state == State.PAUSED) { state = State.PLAYING; GameUI.ShowPause(false); } }

    public void DoRestart() { DoStart(); }

    void DoGameOver()
    {
        state = State.OVER;
        GameUI.ShowStart(false); GameUI.ShowPause(false);
        if (score > hiScore) { hiScore = score; SaveHi(); }
        GameUI.ShowOver(true, score);
        if (txtOverScore) txtOverScore.text = "Score: " + score.ToString();
        if (txtHigh) txtHigh.text = hiScore.ToString();
    }

    void LoadHi() { hiScore = Mathf.Max(0, PlayerPrefs.GetInt("InvertedTetris_Hi", 0)); }
    void SaveHi() { PlayerPrefs.SetInt("InvertedTetris_Hi", hiScore); PlayerPrefs.Save(); }

    void RenderBoardOnly()
    {
        for (int r = 0; r < H; r++)
            for (int c = 0; c < W; c++)
                cellImgs[c, r].color = board[c, r] != 0 ? Figures.ColorFor(Figures.IndexFromColorId(board[c, r])) : new Color(0.06f, 0.06f, 0.1f);
    }

    void Draw()
    {
        Color ac = fAlive ? Figures.ColorFor(fType) : Color.clear;
        Color gc = fAlive ? new Color(Figures.ColorFor(fType).r, Figures.ColorFor(fType).g, Figures.ColorFor(fType).b, 0.25f) : Color.clear;
        GameUI.DrawBoard(cellImgs, board, fType, fRot, fX, fY, ghostY, gc, ac);
        GameUI.DrawPrev(nextPrev, bag.Count > 0 ? bag.Peek() : -1, 0);
        GameUI.DrawHold(holdPrev, heldType);
    }

    void UpdateHUD()
    {
        if (txtScore) txtScore.text = score.ToString();
        if (txtLevel) txtLevel.text = level.ToString();
        if (txtLines) txtLines.text = linesCleared.ToString();
        if (txtHigh) txtHigh.text = hiScore.ToString();
    }
}
