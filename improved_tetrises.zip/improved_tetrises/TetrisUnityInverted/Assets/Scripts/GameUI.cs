using TMPro;using UnityEngine;using UnityEngine.EventSystems;using UnityEngine.UI;
public static class GameUI
{
    private const int W=15,H=35,CE=32,GA=1,ST=33;
    private static readonly Vector2 BP=new(W*ST,H*ST);

    public static void Build(out Canvas cv,out Image[,] ce,out Image fl,out TextMeshProUGUI tS,out TextMeshProUGUI tL,out TextMeshProUGUI tLn,out TextMeshProUGUI tHi,
        out Transform nP,out Transform hP,out GameObject sSt,out GameObject sPa,out GameObject sOv,out TextMeshProUGUI tOS)
    {
        ce=new Image[W,H];cv=MkCv();BuildGrid(cv,ce);BuildPn(cv,out tS,out tL,out tLn,out tHi,out nP,out hP);BuildFl(cv,out fl);BuildOv(cv,out sSt,out sPa,out sOv,out tOS);
    }

    private static Canvas MkCv(){
        var g=new GameObject("C");var c=g.AddComponent<Canvas>();c.renderMode=RenderMode.ScreenSpaceOverlay;
        var s=g.AddComponent<CanvasScaler>();s.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;
        s.referenceResolution=new Vector2(1280,720);s.matchWidthOrHeight=0.5f;g.AddComponent<GraphicRaycaster>();
        if(!Object.FindObjectOfType<EventSystem>())new GameObject("ES").AddComponent<EventSystem>();return c;}

    private static void BuildGrid(Canvas cv,Image[,] ce){
        var g=MkRT(cv);var bg=MkImg(g);bg.GetComponent<RectTransform>().sizeDelta=BP;
        bg.GetComponent<Image>().color=new Color(0.04f,0.04f,0.07f);
        var br=MkImg(g);br.GetComponent<RectTransform>().sizeDelta=BP+Vector2.one*4;br.GetComponent<Image>().color=new Color(0.25f,0.25f,0.35f);
        bg.transform.SetSiblingIndex(1);
        for(int r=0;r<H;r++)for(int c=0;c<W;c++){var o=MkImg(g);var rt=o.GetComponent<RectTransform>();
            float x=c*ST-BP.x/2+ST/2,y=r*ST-BP.y/2+ST/2;
            rt.anchoredPosition=new Vector2(x,y);rt.sizeDelta=new Vector2(CE,CE);
            rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.pivot=Vector2.zero;
            o.GetComponent<Image>().color=new Color(0.06f,0.06f,0.1f);ce[c,r]=o.GetComponent<Image>();}}

    private static void BuildPn(Canvas cv,out TextMeshProUGUI tS,out TextMeshProUGUI tL,out TextMeshProUGUI tLn,out TextMeshProUGUI tHi,out Transform nP,out Transform hP){
        float px=BP.x/2+40f,pw=170f,cw=cv.GetComponent<RectTransform>().rect.width;
        tS=MkTXT(cv,cw,px,pw,110f,"0");tL=MkTXT(cv,cw,px,pw,40f,"1");tLn=MkTXT(cv,cw,px,pw,-30f,"0");tHi=MkTXT(cv,cw,px,pw,-90f,"0");
        nP=MkPV(cv,cw,px,-155f);hP=MkPV(cv,cw,px,-225f);
        var gm=Object.FindObjectOfType<GameManager>();
        MkBTN(cv,cw,BP.x/2+40f,-270f,"NEW GAME",()=>gm?.DoStart());
        MkBTN(cv,cw,BP.x/2+40f,-310f,"PAUSE",()=>gm?.DoPause());
        MkBTN(cv,cw,BP.x/2+40f,-350f,"RESTART",()=>gm?.DoRestart());}

    private static TextMeshProUGUI MkTXT(Canvas cv,float cw,float px,float pw,float yp,string txt){
        var g=new GameObject("T");g.transform.SetParent(cv.transform,false);var t=g.AddComponent<TextMeshProUGUI>();
        t.text=txt;t.fontSize=18;t.font=TMP_FontAsset.CreateDefaultFont();t.color=Color.white;t.alignment=TextAlignmentOptions.Center;
        var rt=g.GetComponent<RectTransform>();rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.pivot=Vector2.right;
        rt.anchoredPosition=new Vector2(cw/2+px,yp);rt.sizeDelta=new Vector2(pw,28f);return t;}

    private static Transform MkPV(Canvas cv,float cw,float px,float yp){
        var g=new GameObject("PV");g.transform.SetParent(cv.transform,false);
        var rt=g.GetComponent<RectTransform>();rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.pivot=Vector2.right;
        rt.anchoredPosition=new Vector2(cw/2+px,yp);rt.sizeDelta=new Vector2(170f,64f);
        for(int i=0;i<9;i++){var o=MkImg(rt);var cr=o.GetComponent<RectTransform>();
            cr.anchoredPosition=new Vector2((i%3-1)*26f,(1-i/3)*26f);
            cr.sizeDelta=Vector2.one*22;cr.anchorMin=Vector2.zero;cr.anchorMax=Vector2.one;cr.pivot=Vector2.zero;
            o.GetComponent<Image>().color=new Color(0.03f,0.03f,0.05f);}
        return rt;}

    private static void MkBTN(Canvas cv,float cw,float px,float yp,string lb,UnityEngine.Events.UnityAction onC){
        var g=new GameObject("B");g.transform.SetParent(cv.transform,false);
        g.AddComponent<Image>().color=new Color(0.18f,0.18f,0.32f);
        var rt=g.GetComponent<RectTransform>();rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.pivot=Vector2.right;
        rt.anchoredPosition=new Vector2(cw/2+px,yp);rt.sizeDelta=new Vector2(170f,34f);
        var b=g.AddComponent<Button>();b.onClick.AddListener(onC);
        var lg=new GameObject("L");lg.transform.SetParent(g.transform,false);
        var t=lg.AddComponent<TextMeshProUGUI>();t.text=lb;t.fontSize=13;t.font=TMP_FontAsset.CreateDefaultFont();
        t.color=Color.white;t.alignment=TextAlignmentOptions.Center;
        var lr=lg.GetComponent<RectTransform>();lr.anchorMin=Vector2.zero;lr.anchorMax=Vector2.one;
        lr.anchoredPosition=Vector2.zero;lr.sizeDelta=Vector2.zero;}

    private static void BuildFl(Canvas cv,out Image fl){
        var g=new GameObject("FL");g.transform.SetParent(cv.transform,false);fl=g.AddComponent<Image>();fl.color=Color.clear;
        var rt=g.GetComponent<RectTransform>();rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.anchoredPosition=Vector2.zero;rt.sizeDelta=Vector2.zero;}

    private static void BuildOv(Canvas cv,out GameObject sSt,out GameObject sPa,out GameObject sOv,out TextMeshProUGUI tOS){
        sSt=MkOv(cv,"INVERTED\nTETRIS","Enter to start",Color.black);sSt.SetActive(true);
        sPa=MkOv(cv,"PAUSED","Esc to resume",new Color(0.1f,0.1f,0.16f,0.88f));sPa.SetActive(false);
        sOv=MkOv(cv,"GAME OVER","",new Color(0.09f,0.03f,0.03f,0.93f));sOv.SetActive(false);
        tOS=null;var gm=Object.FindObjectOfType<GameManager>();
        var sg=new GameObject("SC");sg.transform.SetParent(sOv.transform,false);
        tOS=sg.AddComponent<TextMeshProUGUI>();tOS.fontSize=22;tOS.font=TMP_FontAsset.CreateDefaultFont();
        tOS.color=Color.white;tOS.text="Score: 0";
        var sr=sg.GetComponent<RectTransform>();sr.anchoredPosition=new Vector2(0,-40f);sr.sizeDelta=new Vector2(300f,40f);
        var rb=new GameObject("RB");rb.transform.SetParent(sOv.transform,false);rb.AddComponent<Image>().color=new Color(0.6f,0.12f,0.12f);
        var rbt=rb.GetComponent<RectTransform>();rbt.anchoredPosition=new Vector2(0,-90f);rbt.sizeDelta=new Vector2(180f,44f);
        var bn=rb.AddComponent<Button>();bn.onClick.AddListener(()=>gm?.DoRestart());
        var rl=new GameObject("L");rl.transform.SetParent(rb.transform,false);
        var rt=rl.AddComponent<TextMeshProUGUI>();rt.text="RESTART";rt.fontSize=17;rt.font=TMP_FontAsset.CreateDefaultFont();
        rt.color=Color.white;var rlr=rl.GetComponent<RectTransform>();rlr.anchorMin=Vector2.zero;rlr.anchorMax=Vector2.one;rlr.sizeDelta=Vector2.zero;}

    private static GameObject MkOv(Canvas cv,string tl,string sb,Color bg){
        var g=new GameObject("O");g.transform.SetParent(cv.transform,false);
        var im=g.AddComponent<Image>();im.color=bg;
        var rt=g.GetComponent<RectTransform>();rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.anchoredPosition=Vector2.zero;rt.sizeDelta=Vector2.zero;
        var tg=new GameObject("T");tg.transform.SetParent(g.transform,false);
        var tt=tg.AddComponent<TextMeshProUGUI>();tt.text=tl;tt.fontSize=38;tt.font=TMP_FontAsset.CreateDefaultFont();
        tt.color=new Color(0.9f,0.3f,0.3f);tt.alignment=TextAlignmentOptions.Center;
        var tr=tg.GetComponent<RectTransform>();tr.anchoredPosition=new Vector2(0,40f);tr.sizeDelta=new Vector2(400f,110f);
        var sg=new GameObject("S");sg.transform.SetParent(g.transform,false);
        var st=sg.AddComponent<TextMeshProUGUI>();st.text=sb;st.fontSize=16;st.font=TMP_FontAsset.CreateDefaultFont();
        st.color=Color.white;st.alignment=TextAlignmentOptions.Center;
        var sr=sg.GetComponent<RectTransform>();sr.anchoredPosition=new Vector2(0,-50f);sr.sizeDelta=new Vector2(350f,50f);return g;}

    public static void ShowStart(bool v){
        var g=Object.FindObjectOfType<GameManager>();if(g){
            if(g.sSt)g.sSt.SetActive(v);if(v){if(g.sPa)g.sPa.SetActive(false);if(g.sOv)g.sOv.SetActive(false);}}}
    public static void ShowPause(bool v){var g=Object.FindObjectOfType<GameManager>();if(g&&g.sPa)g.sPa.SetActive(v);}
    public static void ShowOver(bool v,int sc){var g=Object.FindObjectOfType<GameManager>();if(g){if(g.sOv)g.sOv.SetActive(v);}}

    public static void DrawBoard(Image[,] ce,byte[,] bd,int fT,int fR,int fX,int fY,int gY,Color gc,Color ac){
        for(int r=0;r<H;r++)for(int c=0;c<W;c++)
            ce[c,r].color=bd[c,r]!=0?Figures.ColorFor(Figures.IndexFromColorId(bd[c,r])):new Color(0.06f,0.06f,0.1f);
        if(fT>=0){var ro=Figures.Rotations[fT][fR];
            // Draw ghost
            var ro2=Figures.Rotations[fT][fR];
            foreach(var v in ro2){int cx=fX+v.x,cy=gY+v.y;if(cx>=0&&cx<W&&cy>=0&&cy<H&&bd[cx,cy]==0)ce[cx,cy].color=gc;}
            // Draw active
            foreach(var v in ro){int cx=fX+v.x,cy=fY+v.y;if(cx>=0&&cx<W&&cy>=0&&cy<H)ce[cx,cy].color=ac;}}}

    public static void DrawPrev(Transform p,int t,int r){
        if(!p||t<0)return;
        foreach(Transform ch in p){var im=ch.GetComponent<Image>();if(im)im.color=new Color(0.03f,0.03f,0.05f);}
        var cl=Figures.Rotations[t][r];Color co=Figures.ColorFor(t);
        foreach(var v in cl){int idx=(1-v.y)*3+(v.x+1);if(idx>=0&&idx<p.childCount){
            var im=p.GetChild(idx).GetComponent<Image>();if(im)im.color=co;}}}

    public static void DrawHold(Transform p,int t){
        if(!p||t<0)return;DrawPrev(p,t,0);}

    private static Transform MkRT(Canvas cv){var g=new GameObject("BG");g.transform.SetParent(cv.transform,false);var rt=g.GetComponent<RectTransform>();rt.sizeDelta=Vector2.zero;return rt;}
    private static GameObject MkImg(Transform p){var g=new GameObject();g.transform.SetParent(p,false);g.AddComponent<Image>();return g;}
}
