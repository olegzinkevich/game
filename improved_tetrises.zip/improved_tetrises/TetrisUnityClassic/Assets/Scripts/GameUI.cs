using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Creates and manages the entire in-game UI: playfield rendering, HUD,
/// next / hold previews, ghost piece overlay, screens (start/pause/gameover).
/// </summary>
public class GameUI : MonoBehaviour
{
    public enum RenderMode { Texture, Sprites }
    public RenderMode mode = RenderMode.Texture;

    // ── References (auto-created by Setup if null) ──
    public GameManager GameManagerRef;
    public Image        BoardImage;       // the main playfield texture
    public Text         ScoreText;
    public Text         LevelText;
    public Text         LinesText;
    public Text         HighScoreText;
    public GameObject   NextPreviewRoot;
    public GameObject   HoldPreviewRoot;
    public GameObject   OverlayPanel;     // Start/Pause/GameOver overlay
    public Text         OverlayTitleText;
    public Text         OverlaySubText;

    // ── Board rendering ──
    private Texture2D   _boardTexture;
    private const int CELL = 32;           // cell pixel size
    private const int BOARD_TEX_W = GameManager.COLS * CELL;
    private const int BOARD_TEX_H = GameManager.ROWS * CELL;

    internal Texture2D[] _nextTextures;
    internal Texture2D[] _holdTextures;

    private const int PREVIEW = 4;         // 4×4 mini-grid for next/hold
    private const int PCELL  = 16;         // preview cell pixel size
    private const int PREV_TEX = PREVIEW * PCELL;

    // ── State tracking ──
    private GameManager.State _lastState;
    private bool _dirty;
    private bool _needNext;
    private bool _needHold;

    /* ════════ lifecycle ════════ */
    private GameManager _gm;

    private void Awake()
    {
        if (GameManagerRef == null) GameManagerRef = GetComponent<GameManager>();
        _gm = GameManagerRef;

        if (_gm != null)
        {
            _gm.BoardDirty      += () => _dirty  = true;
            _gm.NextQueueChanged += () => _needNext = true;
            _gm.HoldPieceChanged += () => _needHold = true;
            _gm.GameStateChanged += OnStateChanged;
            _gm.ScoreChanged     += s => { if (ScoreText) ScoreText.text = s.ToString("N0"); };
            _gm.LevelChanged     += l => { if (LevelText) LevelText.text = l.ToString(); };
            _gm.LinesChanged     += l => { if (LinesText) LinesText.text = l.ToString(); };
        }

        _lastState = GameManager.State.Idle;
    }

    private void Start()
    {
        if (mode == RenderMode.Texture) CreateTextureBoard();
        _dirty = true;
        _needNext = true;
        _needHold = true;
    }

    private void Update()
    {
        _gm?.GameUpdate(Time.unscaledDeltaTime);
        _gm?.HandleInput();
        RenderFrame();
    }

    /* ════════ render loop ════════ */
    private void RenderFrame()
    {
        if (_dirty && mode == RenderMode.Texture) RenderBoardTexture();
        _dirty = false;
        if (_needNext) { BuildPreview(NextPreviewRoot, _nextTextures, _gm.NextQueue, true); _needNext = false; }
        if (_needHold) { BuildPreview(HoldPreviewRoot, _holdTextures, new[] { _gm.HoldPiece }, false); _needHold = false; }
    }

    /* ════════ texture-based board rendering ════════ */
    private Sprite _boardSprite;

    private void CreateTextureBoard()
    {
        _boardTexture = new Texture2D(BOARD_TEX_W, BOARD_TEX_H, TextureFormat.RGBA32, false);
        _boardTexture.filterMode = FilterMode.Point;
        FillTexture(Color.clear);
        _boardTexture.Apply();
        _boardSprite = Sprite.Create(_boardTexture, new Rect(0, 0, BOARD_TEX_W, BOARD_TEX_H),
            new Vector2(0.5f, 0.5f), 1f);
        //_boardSprite.border = Vector4.zero;
        if (BoardImage) BoardImage.sprite = _boardSprite;
    }

    private void RenderBoardTexture()
    {
        if (_gm == null) return;

        // Background
        FillTexture(new Color32(0x10, 0x10, 0x18, 0xFF));

        // Locked cells
        for (int r = 0; r < GameManager.ROWS; r++)
            for (int c = 0; c < GameManager.COLS; c++)
            {
                byte v = _gm.BoardAt(r, c);
                if (v != 0) DrawCell(c, r, TetrominoData.ColorOf((TetrominoData.Type)v), false);
            }

        // Ghost piece
        DrawGhost();

        // Active piece
        DrawActive();

        // Grid lines (subtle)
        DrawGrid();

        _boardTexture.Apply();
    }

    private void DrawActive()
    {
        var cells = TetrominoData.Cells(_gm.ActiveType, _gm.ActiveRotation);
        var color = TetrominoData.ColorOf(_gm.ActiveType);
        for (int i = 0; i < 4; i++)
        {
            int c = _gm.ActiveCol + cells[i].y;
            int r = _gm.ActiveRow + cells[i].x;
            if (r >= 0 && r < GameManager.ROWS && c >= 0 && c < GameManager.COLS)
                DrawCell(c, r, color, true);
        }
    }

    private void DrawGhost()
    {
        if (_gm.GameState != GameManager.State.Playing) return;
        var cells = TetrominoData.Cells(_gm.ActiveType, _gm.ActiveRotation);
        Color32 ghostColor = new Color32(0x80, 0x80, 0x80, 0x50);
        for (int i = 0; i < 4; i++)
        {
            int c = _gm.ActiveCol + cells[i].y;
            int r = _gm.GhostRow + cells[i].x;
            if (r >= 0 && r < GameManager.ROWS && c >= 0 && c < GameManager.COLS)
            {
                // Only draw where there is no locked cell
                if (_gm.BoardAt(r, c) == 0) DrawCell(c, r, ghostColor, false);
            }
        }
    }

    private void DrawCell(int col, int row, Color32 color, bool highlight)
    {
        int px = col * CELL;
        int py = (GameManager.ROWS - 1 - row) * CELL;

        if (highlight)
        {
            // Brighter version with bevel illusion
            DrawSolidRect(px + 1, py + 1, CELL - 2, CELL - 2, Brighter(color));
        }
        else
        {
            DrawSolidRect(px + 1, py + 1, CELL - 2, CELL - 2, color);
        }
    }

    private void DrawSolidRect(int x, int y, int w, int h, Color32 color)
    {
        for (int py = y; py < y + h; py++)
            for (int px = x; px < x + w; px++)
            {
                _boardTexture.SetPixel(px, py, color);
            }
    }

    private void DrawGrid()
    {
        Color32 gridColor = new Color32(0x20, 0x20, 0x28, 0xFF);
        for (int c = 0; c <= GameManager.COLS; c++)
        {
            int x = c * CELL;
            for (int y = 0; y < BOARD_TEX_H; y++)
                _boardTexture.SetPixel(x, y, gridColor);
        }
        for (int r = 0; r <= GameManager.ROWS; r++)
        {
            int y = r * CELL;
            for (int x = 0; x < BOARD_TEX_W; x++)
                _boardTexture.SetPixel(x, y, gridColor);
        }
    }

    private void FillTexture(Color32 c)
    {
        for (int y = 0; y < BOARD_TEX_H; y++)
            for (int x = 0; x < BOARD_TEX_W; x++)
                _boardTexture.SetPixel(x, y, c);
    }

    private static Color32 Brighter(Color32 c)
    {
        return new Color32(
            (byte) Mathf.Min(255, c.r + 40),
            (byte) Mathf.Min(255, c.g + 40),
            (byte) Mathf.Min(255, c.b + 40),
            c.a);
    }

    /* ════════ next / hold preview (texture per piece slot) ════════ */
    private void BuildPreview(GameObject root, Texture2D[] texs, IEnumerable<TetrominoData.Type> pieces, bool isNext)
    {
        if (root == null) return;
        int maxSlots = isNext ? 4 : 1;
        Image[] slotImages = new Image[maxSlots];

        int si = 0;
        foreach (var img in root.GetComponentsInChildren<Image>(true))
        {
            if (si < maxSlots) slotImages[si++] = img;
        }

        int idx = 0;
        foreach (var t in pieces)
        {
            if (idx >= maxSlots || idx >= texs.Length) break;
            if ((int)t == 0) { idx++; continue; }
            DrawPreviewPiece(texs[idx], t);
            if (slotImages[idx] != null)
            {
                slotImages[idx].sprite = Sprite.Create(texs[idx],
                    new Rect(0, 0, 64, 64), new Vector2(0.5f, 0.5f), 1f);
            }
            idx++;
        }
    }

    private void DrawPreviewPiece(Texture2D tex, TetrominoData.Type t)
    {
        if (tex == null) return;
        Color32 bg = new Color32(0x0A, 0x0A, 0x12, 0xFF);
        for (int y = 0; y < PREV_TEX; y++)
            for (int x = 0; x < PREV_TEX; x++)
                tex.SetPixel(x, y, bg);

        var cells = TetrominoData.Cells(t, 0);
        Color32 col = TetrominoData.ColorOf(t);

        // Center in the preview grid
        int minX = int.MaxValue, maxX = 0, minY = int.MaxValue, maxY = 0;
        foreach (var cell in cells)
        {
            minX = Mathf.Min(minX, cell.y);
            maxX = Mathf.Max(maxX, cell.y);
            minY = Mathf.Min(minY, cell.x);
            maxY = Mathf.Max(maxY, cell.x);
        }

        int offX = (PREVIEW - (maxX - minX + 1)) / 2 - minX;
        int offY = (PREVIEW - (maxY - minY + 1)) / 2 - minY;

        foreach (var cell in cells)
        {
            int px = (cell.y + offX) * PCELL;
            int py = (PREVIEW - 1 - (cell.x + offY)) * PCELL;
            for (int dy = 0; dy < PCELL; dy++)
                for (int dx = 0; dx < PCELL; dx++)
                    tex.SetPixel(px + dx + 1, py + dy + 1, col);
        }

        tex.Apply();
    }

    /* ════════ overlay screen (Start / Pause / GameOver) ════════ */
    private void OnStateChanged()
    {
        if (OverlayPanel == null || OverlayTitleText == null) return;
        var st = _gm.GameState;
        _lastState = st;

        OverlayPanel.SetActive(st != GameManager.State.Playing);

        switch (st)
        {
            case GameManager.State.Idle:
                OverlayTitleText.text = "TETRIS";
                OverlaySubText.text  = "Press ENTER to start";
                break;
            case GameManager.State.Paused:
                OverlayTitleText.text = "PAUSED";
                OverlaySubText.text  = "Press P or ESC to resume";
                break;
            case GameManager.State.GameOver:
                OverlayTitleText.text = "GAME OVER";
                OverlaySubText.text  = $"Score: {GameManagerRef?.Score:N0}\nPress ENTER or R to restart";
                break;
        }
    }

    /* ════════ public setup helpers ════════ */
    public void ShowStartScreen() => OnStateChanged();
}
