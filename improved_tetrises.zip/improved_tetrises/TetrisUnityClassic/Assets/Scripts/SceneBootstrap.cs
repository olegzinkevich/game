using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Single entry-point script.  Drop on an empty GameObject (or the root of the scene).
/// Creates the camera, canvas, board image, HUD texts, next / hold previews, and
/// overlays (Start / Pause / Game Over) — all through code.
/// </summary>
[DefaultExecutionOrder(-100)]
public class SceneBootstrap : MonoBehaviour
{
    // ── created objects ──
    private Canvas _canvas;
    private GameUI _ui;

    private const int CELL = 32;
    private const int BOARD_W = GameManager.COLS * CELL;
    private const int BOARD_H = GameManager.ROWS * CELL;

    /* ════════ entry point ════════ */
    private void Awake()
    {
        CreateGameManagerGameObject();
        SetupCamera();
        SetupCanvas();
        SetupUI();
    }

    /* ════════ game manager ════════ */
    private void CreateGameManagerGameObject()
    {
        var go = new GameObject("GameManager");
        DontDestroyOnLoad(go);
        var gm = go.AddComponent<GameManager>();
        _ui = go.AddComponent<GameUI>();
        _ui.mode = GameUI.RenderMode.Texture;
        _ui.GameManagerRef = gm;
    }

    /* ════════ camera (orthographic) ════════ */
    private void SetupCamera()
    {
        if (FindObjectOfType<Camera>()) return;
        var go = new GameObject("MainCamera");
        var cam = go.AddComponent<Camera>();
        cam.orthographic = true;
        cam.orthographicSize = Screen.height / 2f;
        cam.nearClipPlane = 0f;
        cam.farClipPlane = 1000f;
        cam.backgroundColor = new Color32(0x0A, 0x0A, 0x12, 0xFF);
        cam.transform.position = new Vector3(0, 0, -10);
    }

    /* ════════ canvas ════════ */
    private void SetupCanvas()
    {
        var go = new GameObject("Canvas");
        _canvas = go.AddComponent<Canvas>();
        _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        _canvas.pixelPerfect = false;

        var scaler = go.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280, 720);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        go.AddComponent<GraphicRaycaster>();
    }

    /* ════════ UI elements ════════ */
    private void SetupUI()
    {
        // ── Board image (centered) ──
        var boardGo = new GameObject("Board");
        boardGo.transform.SetParent(_canvas.transform, false);
        var boardRt = boardGo.AddComponent<RectTransform>();
        boardRt.pivot = Vector2.one / 2;
        boardRt.anchorMin = Vector2.zero;
        boardRt.anchorMax = Vector2.one;
        boardRt.sizeDelta = new Vector2(BOARD_W, BOARD_H);
        var boardImg = boardGo.AddComponent<Image>();
        boardImg.color = new Color32(0x10, 0x10, 0x18, 0xFF);
        _ui.BoardImage = boardImg;

        float rightX = BOARD_W / 2f + 40f;
        float hudW = 200f;
        float hudTop = BOARD_H / 2f + 10f;

        // ── Score ──
        AddRightText("ScoreLabel", "SCORE",     rightX, hudTop,      hudW, 28, 14);
        _ui.ScoreText = AddRightText("ScoreValue", "0", rightX, hudTop - 28, hudW, 36, 28, Color.white);

        float y = hudTop - 76f;

        // ── Level ──
        AddRightText("LevelLabel", "LEVEL",     rightX, y,       hudW, 28, 14);
        _ui.LevelText = AddRightText("LevelValue", "1", rightX, y - 28, hudW, 36, 24, Color.white);

        y -= 68f;

        // ── Lines ──
        AddRightText("LinesLabel", "LINES",     rightX, y,       hudW, 28, 14);
        _ui.LinesText = AddRightText("LinesValue", "0", rightX, y - 28, hudW, 36, 24, Color.white);

        y -= 68f;

        // ── High Score ──
        AddRightText("HSLabel", "HIGH SCORE",  rightX, y,       hudW, 28, 14);
        _ui.HighScoreText = AddRightText("HSValue", "0", rightX, y - 28, hudW, 36, 24, Color.yellow);

        y -= 80f;

        // ── Next preview ──
        AddRightText("NextLabel", "NEXT",   rightX, y,   hudW, 28, 14);
        _ui.NextPreviewRoot = MakePreviewPanel("NextPanel", rightX, y - 36, hudW, 4 * 64, true);

        y -= 276f;

        // ── Hold preview ──
        AddRightText("HoldLabel", "HOLD",   rightX, y,   hudW, 28, 14);
        _ui.HoldPreviewRoot = MakePreviewPanel("HoldPanel", rightX, y - 36, hudW, 64, false);

        // ── Controls hint ──
        y -= 136f;
        AddRightText("Controls",
            " ← →  Move\n ↑  Rotate\n ↓  Soft Drop\n SPACE  Hard Drop\n C  Hold\n P  Pause",
            rightX, y, hudW, 140, 10,
            new Color32(0x77, 0x77, 0x99, 0xFF));

        // ── Overlay ──
        SetupOverlay();
    }

    private GameObject MakePreviewPanel(string name, float x, float y, float w, float totalH, bool isNext)
    {
        var root = new GameObject(name);
        root.transform.SetParent(_canvas.transform, false);
        var rt = root.AddComponent<RectTransform>();
        rt.pivot = new Vector2(0.5f, 1f);
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.sizeDelta = new Vector2(w, totalH);
        rt.anchoredPosition = new Vector2(x, y);

        int count = isNext ? 4 : 1;
        for (int i = 0; i < count; i++)
        {
            var slot = new GameObject($"Slot{i}");
            slot.transform.SetParent(root.transform, false);
            var slotRt = slot.AddComponent<RectTransform>();
            slotRt.pivot = new Vector2(0.5f, 1f);
            slotRt.anchorMin = Vector2.zero;
            slotRt.anchorMax = Vector2.one;
            slotRt.sizeDelta = new Vector2(64, 64);
            slotRt.anchoredPosition = new Vector2(0, -(i + 1) * 64);
            slot.AddComponent<Image>().color = new Color32(0x0A, 0x0A, 0x12, 0xFF);
        }

        int texCount = isNext ? 4 : 1;
        Texture2D[] texs = new Texture2D[texCount];
        for (int i = 0; i < texCount; i++) texs[i] = BlankTex();
        if (isNext) _ui._nextTextures = texs;
        else        _ui._holdTextures = texs;

        return root;
    }

    private Texture2D BlankTex()
    {
        var t = new Texture2D(64, 64, TextureFormat.RGBA32, false);
        t.filterMode = FilterMode.Point;
        var bg = new Color32(0x0A, 0x0A, 0x12, 0xFF);
        for (int y = 0; y < 64; y++)
            for (int x = 0; x < 64; x++)
                t.SetPixel(x, y, bg);
        t.Apply();
        return t;
    }

    private void SetupOverlay()
    {
        var panel = new GameObject("OverlayPanel");
        panel.transform.SetParent(_canvas.transform, false);
        var rt = panel.AddComponent<RectTransform>();
        rt.pivot = Vector2.one / 2;
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.sizeDelta = new Vector2(-BOARD_W - 80, -BOARD_H - 60);
        panel.AddComponent<Image>().color = new Color(0, 0, 0, 0.8f);
        _ui.OverlayPanel = panel;

        // Title
        var titleGo = new GameObject("Title");
        titleGo.transform.SetParent(panel.transform, false);
        var titleRt = titleGo.AddComponent<RectTransform>();
        titleRt.pivot = new Vector2(0.5f, 0.65f);
        titleRt.anchorMin = Vector2.zero;
        titleRt.anchorMax = Vector2.one;
        titleRt.sizeDelta = Vector2.zero;
        var titleT = titleGo.AddComponent<Text>();
        titleT.text = "TETRIS";
        // titleT.font = Font();
        titleT.fontSize = 48;
        titleT.fontStyle = FontStyle.Bold;
        titleT.alignment = TextAnchor.MiddleCenter;
        titleT.color = Color.cyan;
        titleT.horizontalOverflow = HorizontalWrapMode.Overflow;
        titleT.verticalOverflow = VerticalWrapMode.Overflow;
        _ui.OverlayTitleText = titleT;

        // Sub text
        var subGo = new GameObject("Sub");
        subGo.transform.SetParent(panel.transform, false);
        var subRt = subGo.AddComponent<RectTransform>();
        subRt.pivot = new Vector2(0.5f, 0.4f);
        subRt.anchorMin = Vector2.zero;
        subRt.anchorMax = Vector2.one;
        subRt.sizeDelta = Vector2.zero;
        var subT = subGo.AddComponent<Text>();
        subT.text = "Press ENTER to start";
        // subT.font = Font();
        subT.fontSize = 20;
        subT.alignment = TextAnchor.MiddleCenter;
        subT.color = Color.white;
        subT.horizontalOverflow = HorizontalWrapMode.Overflow;
        subT.verticalOverflow = VerticalWrapMode.Overflow;
        _ui.OverlaySubText = subT;
    }

    /* ── helpers ── */
    private Text AddRightText(string name, string text, float x, float y,
        float w, float h, int fontSize, Color? color = null)
    {
        Color c = color ?? new Color32(0xBB, 0xBB, 0xCC, 0xFF);
        var go = new GameObject(name);
        go.transform.SetParent(_canvas.transform, false);
        var rt = go.AddComponent<RectTransform>();
        rt.pivot = new Vector2(0.5f, 1f);
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.sizeDelta = new Vector2(w, h);
        rt.anchoredPosition = new Vector2(x, y);

        var t = go.AddComponent<Text>();
        t.text = text;
        // t.font = Font();
        t.fontSize = fontSize;
        t.alignment = TextAnchor.MiddleLeft;
        t.color = c;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        return t;
    }

    private Font Font() => Resources.GetBuiltinResource<Font>("Arial.ttf");
}
