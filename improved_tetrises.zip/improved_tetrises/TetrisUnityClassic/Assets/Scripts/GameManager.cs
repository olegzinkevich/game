using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Full Tetris game logic: board, pieces, movement, rotation, line clearing, scoring, lifecycle.
/// Attach this to a GameObject. Pair with a GameUI instance to render.
/// </summary>
public class GameManager : MonoBehaviour
{
    /* ─── constants ─── */
    public const int COLS = 10;
    public const int ROWS = 20;

    /* ─── grid: 0 = empty, 1..7 = piece type ─── */
    private readonly byte[,] board = new byte[ROWS, COLS];

    /* ─── active piece ─── */
    private TetrominoData.Type _pieceType;
    private int _pieceCol;   // board column for pivot
    private int _pieceRow;   // board row for pivot
    private int _rotation;   // 0..3

    /* ─── bag randomiser (7-bag) ─── */
    private readonly Queue<TetrominoData.Type> _bagQueue = new Queue<TetrominoData.Type>();

    /* ─── next queue (always kept full with at least 3 pieces) ─── */
    private readonly Queue<TetrominoData.Type> _nextQueue = new Queue<TetrominoData.Type>();

    /* ─── hold piece ─── */
    private TetrominoData.Type _holdPiece;
    private bool _holdUsed;

    /* ─── scoring ─── */
    private uint _score;
    private uint _level = 1;
    private uint _lines;

    /* ─── game state ─── */
    public enum State { Idle, Playing, Paused, GameOver }
    public State GameState { get; private set; } = State.Idle;

    /* ─── gravity (FR-CFG-001, FR-CFG-002, FR-LEVEL-002)
     *   Base drop interval 500 ms at starting level.
     *   Formula: max(50, 500 / level) ms  — clamped to 50 ms minimum.           */
    private float _gravityAccumulator;
    private float _dropInterval => Mathf.Max(0.05f, 500f / (float)_level / 1000f);

    /* ─── lock delay ─── */
    private bool _lockedOnGround;
    private float _lockAccumulator;
    private const float LOCK_DELAY = 0.5f;

    /* ─── events for UI ─── */
    public event Action BoardDirty;
    public event Action<uint> ScoreChanged;
    public event Action<uint> LevelChanged;
    public event Action<uint> LinesChanged;
    public event Action NextQueueChanged;
    public event Action HoldPieceChanged;
    public event Action GameStateChanged;
    public event Action<int> LinesCleared;

    /* ─── high score ─── */
    private uint _highScore;
    public uint HighScore
    {
        get => _highScore;
        set
        {
            if (value > _highScore)
            {
                _highScore = value;
                try { PlayerPrefs.SetInt("Tetris_HighScore", (int)value); PlayerPrefs.Save(); }
                catch { /* gracefully degrade */ }
            }
        }
    }

    /* ─── getters for UI ─── */
    public byte BoardAt(int row, int col)
    {
        if (row < 0 || row >= ROWS || col < 0 || col >= COLS) return 0;
        return board[row, col];
    }

    public TetrominoData.Type ActiveType => _pieceType;
    public int ActiveCol => _pieceCol;
    public int ActiveRow => _pieceRow;
    public int ActiveRotation => _rotation;
    public TetrominoData.Type HoldPiece => _holdPiece;
    public bool HasHoldPiece => (int)_holdPiece != 0;
    public uint Score => _score;
    public uint Level => _level;
    public uint Lines => _lines;

    public IEnumerable<TetrominoData.Type> NextQueue => new List<TetrominoData.Type>(_nextQueue);

    /* ─── public actions ─── */
    public void StartGame()
    {
        Array.Clear(board, 0, board.Length);
        _score = 0;
        _level = 1;
        _lines = 0;
        _gravityAccumulator = 0f;
        _lockAccumulator = 0f;
        _lockedOnGround = false;
        _holdPiece = (TetrominoData.Type)0;
        _holdUsed = false;
        _nextQueue.Clear();
        _bagQueue.Clear();

        try { _highScore = (uint)PlayerPrefs.GetInt("Tetris_HighScore", 0); }
        catch { _highScore = 0; }

        GameState = State.Playing;
        GameStateChanged?.Invoke();
        ScoreChanged?.Invoke(_score);
        LevelChanged?.Invoke(_level);
        LinesChanged?.Invoke(_lines);

        FillNextQueue();
        SpawnPiece();
    }

    public void Pause()
    {
        if (GameState != State.Playing && GameState != State.Paused) return;
        GameState = GameState == State.Playing ? State.Paused : State.Playing;
        if (GameState == State.Paused)
        {
            _lockAccumulator = 0f;
            _lockedOnGround = false;
        }
        GameStateChanged?.Invoke();
    }

    public void MoveLeft()
    {
        if (GameState != State.Playing) return;
        if (!Collides(_pieceCol - 1, _pieceRow, _rotation))
        {
            _pieceCol--;
            ResetLockDelay();
            BoardDirty?.Invoke();
        }
    }

    public void MoveRight()
    {
        if (GameState != State.Playing) return;
        if (!Collides(_pieceCol + 1, _pieceRow, _rotation))
        {
            _pieceCol++;
            ResetLockDelay();
            BoardDirty?.Invoke();
        }
    }

    public void SoftDrop()
    {
        if (GameState != State.Playing) return;
        if (!Collides(_pieceCol, _pieceRow + 1, _rotation))
        {
            _pieceRow++;
            _score += 1;
            ScoreChanged?.Invoke(_score);
            ResetLockDelay();
            BoardDirty?.Invoke();
        }
    }

    public void HardDrop()
    {
        if (GameState != State.Playing) return;
        int dropped = 0;
        while (!Collides(_pieceCol, _pieceRow + 1, _rotation))
        {
            _pieceRow++;
            dropped++;
        }
        _score += (uint)(dropped * 2);
        ScoreChanged?.Invoke(_score);
        LockPiece();
    }

    public void RotateCW()
    {
        if (GameState != State.Playing) return;
        if (_pieceType == TetrominoData.Type.O) return;
        TryRotate(1);
    }

    public void RotateCCW()
    {
        if (GameState != State.Playing) return;
        if (_pieceType == TetrominoData.Type.O) return;
        TryRotate(-1);
    }

    public void Hold()
    {
        if (GameState != State.Playing) return;
        if (_holdUsed) return;

        var current = _pieceType;
        if ((int)_holdPiece != 0)
        {
            _pieceType = _holdPiece;
            _holdPiece = current;
        }
        else
        {
            _holdPiece = current;
            HoldPieceChanged?.Invoke();
        }
        _holdUsed = true;
        PlaceSpawnedPiece();
    }

    /* ─── Update / game loop ─── */
    public void GameUpdate(float dt)
    {
        if (GameState != State.Playing) return;

        // Input held keys for gravity
        bool softHeld = Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S);

        float effectiveDt = dt;
        if (softHeld)
        {
            // Soft drop: accelerate descent
            _gravityAccumulator += effectiveDt * 10f;
        }
        else
        {
            _gravityAccumulator += effectiveDt;
        }

        while (_gravityAccumulator >= _dropInterval)
        {
            _gravityAccumulator -= _dropInterval;

            if (!Collides(_pieceCol, _pieceRow + 1, _rotation))
            {
                _pieceRow++;
                ResetLockDelay();
            }
            else
            {
                if (!_lockedOnGround) _lockedOnGround = true;
                _lockAccumulator += _dropInterval;
                if (_lockAccumulator >= LOCK_DELAY)
                {
                    LockPiece();
                    break;
                }
            }
        }

        BoardDirty?.Invoke();
    }

    /* ─── input handling ─── */
    public void HandleInput()
    {
        if (GameState == State.Idle)
        {
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter)) StartGame();
            return;
        }

        if (GameState == State.GameOver)
        {
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.R)) StartGame();
            return;
        }

        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            Pause();
            return;
        }

        if (GameState != State.Playing) return;

        if (Input.GetKeyDown(KeyCode.LeftArrow)  || Input.GetKeyDown(KeyCode.A)) MoveLeft();
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) MoveRight();

        if (Input.GetKeyDown(KeyCode.Space)) HardDrop();
        if (Input.GetKeyDown(KeyCode.UpArrow)  || Input.GetKeyDown(KeyCode.X)) RotateCW();
        if (Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown(KeyCode.LeftControl)) RotateCCW();
        if (Input.GetKeyDown(KeyCode.C) || Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift)) Hold();
    }

    /* ─── 7-bag randomiser ─── */
    private void FillBag()
    {
        var bagList = new List<TetrominoData.Type>(TetrominoData.AllTypes);
        for (int i = bagList.Count - 1; i > 0; i--)
        {
            int j = UnityEngine.Random.Range(0, i + 1);
            (bagList[i], bagList[j]) = (bagList[j], bagList[i]);
        }
        foreach (var t in bagList) _bagQueue.Enqueue(t);
    }

    private TetrominoData.Type DequeuePiece()
    {
        if (_bagQueue.Count == 0) FillBag();
        return _bagQueue.Dequeue();
    }

    private void FillNextQueue()
    {
        while (_nextQueue.Count < 4) _nextQueue.Enqueue(DequeuePiece());
    }

    /* ─── spawning ─── */
    private void SpawnPiece()
    {
        FillNextQueue();
        _pieceType = _nextQueue.Dequeue();
        NextQueueChanged?.Invoke();
        FillNextQueue();

        _pieceCol = COLS / 2 - 1;
        _pieceRow = _pieceType == TetrominoData.Type.I ? -1 : 0;
        _rotation = 0;
        _holdUsed = false;
        _lockedOnGround = false;
        _lockAccumulator = 0f;

        if (Collides(_pieceCol, _pieceRow, _rotation))
        {
            GameOver();
        }

        BoardDirty?.Invoke();
    }

    private void PlaceSpawnedPiece()
    {
        // called after Hold swap — center the new piece
        _pieceCol = COLS / 2 - 1;
        _pieceRow = _pieceType == TetrominoData.Type.I ? -1 : 0;
        _rotation = 0;
        _holdUsed = false;
        _lockedOnGround = false;
        _lockAccumulator = 0f;

        if (Collides(_pieceCol, _pieceRow, _rotation))
        {
            GameOver();
        }

        BoardDirty?.Invoke();
    }

    /* ─── collision ─── */
    public bool Collides(int col, int row, int rot)
    {
        var cells = TetrominoData.Cells(_pieceType, rot);
        for (int i = 0; i < 4; i++)
        {
            int c = col + cells[i].y;
            int r = row + cells[i].x;
            if (c < 0 || c >= COLS || r >= ROWS) return true;
            if (r >= 0 && board[r, c] != 0) return true;
        }
        return false;
    }

    /* ─── rotation with SRS wall kicks ─── */
    private void TryRotate(int dir)
    {
        int newRot = ((_rotation + dir) + 4) % 4;
        var kicks = TetrominoData.KickOffsets(_pieceType, _rotation, newRot);
        foreach (var kick in kicks)
        {
            int nc = _pieceCol + kick.y;
            int nr = _pieceRow + kick.x;
            if (!Collides(nc, nr, newRot))
            {
                _pieceCol = nc;
                _pieceRow = nr;
                _rotation = newRot;
                ResetLockDelay();
                BoardDirty?.Invoke();
                return;
            }
        }
    }

    /* ─── locking ─── */
    private void LockPiece()
    {
        var cells = TetrominoData.Cells(_pieceType, _rotation);
        int typeVal = (int)_pieceType;
        for (int i = 0; i < 4; i++)
        {
            int c = _pieceCol + cells[i].y;
            int r = _pieceRow + cells[i].x;
            if (r >= 0 && r < ROWS && c >= 0 && c < COLS)
            {
                board[r, c] = (byte)typeVal;
            }
        }

        ClearLines();
        SpawnPiece();
    }

    private void ResetLockDelay()
    {
        if (_lockedOnGround)
        {
            _lockedOnGround = false;
            _lockAccumulator = 0f;
        }
    }

    /* ─── line clearing ─── */
    private void ClearLines()
    {
        List<int> fullRows = new List<int>();

        for (int r = 0; r < ROWS; r++)
        {
            bool full = true;
            for (int c = 0; c < COLS; c++)
            {
                if (board[r, c] == 0) { full = false; break; }
            }
            if (full) fullRows.Add(r);
        }

        if (fullRows.Count == 0) return;

        // Remove full rows from highest to lowest so shifting is correct
        int cleared = fullRows.Count;
        for (int i = cleared - 1; i >= 0; i--)
        {
            int rowToRemove = fullRows[i];
            for (int r = rowToRemove; r > 0; r--)
            {
                for (int c = 0; c < COLS; c++)
                {
                    board[r, c] = board[r - 1, c];
                }
            }
            for (int c = 0; c < COLS; c++)
            {
                board[0, c] = 0;
            }
        }

        // Scoring: 100, 300, 500, 800 × level
        uint[] scoreTable = { 0, 100, 300, 500, 800 };
        _score += scoreTable[cleared] * (uint)_level;
        _lines += (uint)cleared;

        // Level up every 10 lines
        uint newLevel = _lines / 10 + 1;
        if (newLevel > _level) _level = newLevel;

        ScoreChanged?.Invoke(_score);
        LevelChanged?.Invoke(_level);
        LinesChanged?.Invoke(_lines);
        LinesCleared?.Invoke(cleared);
    }

    /* ─── game over ─── */
    private void GameOver()
    {
        if (_score > _highScore) HighScore = _score;
        GameState = State.GameOver;
        GameStateChanged?.Invoke();
    }

    /* ─── ghost piece calculation (for UI) ─── */
    public int GhostRow
    {
        get
        {
            int r = _pieceRow;
            while (!Collides(_pieceCol, r + 1, _rotation)) r++;
            return r;
        }
    }
}
