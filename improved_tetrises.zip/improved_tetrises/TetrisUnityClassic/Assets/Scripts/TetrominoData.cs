using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Seven standard tetromino definitions: shapes, colors, SRS wall-kick tables.
/// </summary>
public static class TetrominoData
{
    public enum Type { I = 1, O = 2, T = 3, S = 4, Z = 5, L = 6, J = 7 }

    public static Color32 ColorOf(Type t) => t switch
    {
        Type.I => new Color32(0x00, 0xF5, 0xF5, 0xFF),   // cyan
        Type.O => new Color32(0xF5, 0xF5, 0x00, 0xFF),   // yellow
        Type.T => new Color32(0xA0, 0x00, 0xF5, 0xFF),   // purple
        Type.S => new Color32(0x00, 0xF5, 0x00, 0xFF),   // green
        Type.Z => new Color32(0xF5, 0x00, 0x00, 0xFF),   // red
        Type.L => new Color32(0xF5, 0x95, 0x00, 0xFF),   // orange
        Type.J => new Color32(0x00, 0x60, 0xF5, 0xFF),   // blue
        _      => Color.white
    };

    private static readonly Vector2Int[][][] s_states;
    static TetrominoData()
    {
        s_states = new Vector2Int[8][][];

        // var empty = new Vector2Int[0];
        // s_states[0] = new[] { empty, empty, empty, empty };

        // I piece
        s_states[(int)Type.I] = new[]
        {
            new[] { new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(0,2) },
            new[] { new Vector2Int(-1,0), new Vector2Int( 0,0), new Vector2Int(1,0), new Vector2Int(2,0) },
            new[] { new Vector2Int(0,-2), new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(0,1) },
            new[] { new Vector2Int(-2,0), new Vector2Int(-1,0), new Vector2Int( 0,0), new Vector2Int(1,0) },
        };
        // O piece (same all states)
        var o = new[] { new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,0), new Vector2Int(1,1) };
        s_states[(int)Type.O] = new[] { o, o, o, o };
        // T piece
        s_states[(int)Type.T] = new[]
        {
            new[] { new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,0) },
            new[] { new Vector2Int(-1,0), new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(1,0) },
            new[] { new Vector2Int(-1,0), new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(0,1) },
            new[] { new Vector2Int(-1,0), new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(1,1) },
        };
        // S piece
        s_states[(int)Type.S] = new[]
        {
            new[] { new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(-1,-1), new Vector2Int(-1,0) },
            new[] { new Vector2Int(-1,0), new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(1,-1) },
            new[] { new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(1,0), new Vector2Int(1,1) },
            new[] { new Vector2Int(-1,1), new Vector2Int(0,1), new Vector2Int(0,0), new Vector2Int(1,0) },
        };
        // Z piece
        s_states[(int)Type.Z] = new[]
        {
            new[] { new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(-1,0), new Vector2Int(-1,1) },
            new[] { new Vector2Int(-1,0), new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(1,-1) },
            new[] { new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,-1), new Vector2Int(1,0) },
            new[] { new Vector2Int(-1,1), new Vector2Int(0,1), new Vector2Int(0,0), new Vector2Int(1,0) },
        };
        // L piece
        s_states[(int)Type.L] = new[]
        {
            new[] { new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(-1,1) },
            new[] { new Vector2Int(-1,-1), new Vector2Int(0,-1), new Vector2Int(1,-1), new Vector2Int(1,0) },
            new[] { new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,-1) },
            new[] { new Vector2Int(-1,0), new Vector2Int(-1,1), new Vector2Int(0,1), new Vector2Int(1,1) },
        };
        // J piece
        s_states[(int)Type.J] = new[]
        {
            new[] { new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(-1,-1) },
            new[] { new Vector2Int(-1,-1), new Vector2Int(0,-1), new Vector2Int(1,-1), new Vector2Int(1,0) },
            new[] { new Vector2Int(0,-1), new Vector2Int(0,0), new Vector2Int(0,1), new Vector2Int(1,1) },
            new[] { new Vector2Int(-1,0), new Vector2Int(-1,1), new Vector2Int(0,1), new Vector2Int(1,1) },
        };
    }

    // ─── SRS wall-kick tables ───
    // Transitions indexed as: 0->1, 1->2, 2->3, 3->0
    private static readonly Vector2Int[][] I_Kick = new[]
    {
        new[] { Vector2Int.zero, new Vector2Int(-2,0), new Vector2Int(1,0), new Vector2Int(-2,-1), new Vector2Int(1,1) },
        new[] { Vector2Int.zero, new Vector2Int(-1,0), new Vector2Int(2,0), new Vector2Int(-1,1), new Vector2Int(2,-1) },
        new[] { Vector2Int.zero, new Vector2Int(2,0), new Vector2Int(-1,0), new Vector2Int(2,1), new Vector2Int(-1,-1) },
        new[] { Vector2Int.zero, new Vector2Int(1,0), new Vector2Int(-2,0), new Vector2Int(1,-1), new Vector2Int(-2,1) },
    };
    private static readonly Vector2Int[][] JO_LoT_Kick = new[]
    {
        new[] { Vector2Int.zero, new Vector2Int(1,0), new Vector2Int(-1,0), new Vector2Int(1,1), new Vector2Int(-1,-1) },
        new[] { Vector2Int.zero, new Vector2Int(-1,0), new Vector2Int(1,0), new Vector2Int(-1,-1), new Vector2Int(1,1) },
        new[] { Vector2Int.zero, new Vector2Int(1,0), new Vector2Int(-1,0), new Vector2Int(1,-1), new Vector2Int(-1,1) },
        new[] { Vector2Int.zero, new Vector2Int(-1,0), new Vector2Int(1,0), new Vector2Int(-1,1), new Vector2Int(1,-1) },
    };
    private static readonly Vector2Int[][] SZ_Kick = new[]
    {
        new[] { Vector2Int.zero, new Vector2Int(1,0), new Vector2Int(-1,1), new Vector2Int(1,-1), new Vector2Int(-1,0) },
        new[] { Vector2Int.zero, new Vector2Int(-1,0), new Vector2Int(1,-1), new Vector2Int(-1,1), new Vector2Int(1,0) },
        new[] { Vector2Int.zero, new Vector2Int(1,0), new Vector2Int(-1,1), new Vector2Int(1,-1), new Vector2Int(-1,0) },
        new[] { Vector2Int.zero, new Vector2Int(-1,0), new Vector2Int(1,-1), new Vector2Int(-1,1), new Vector2Int(1,0) },
    };

    public static Vector2Int[] Cells(Type t, int state) => s_states[(int)t][state];

    public static Vector2Int[] KickOffsets(Type t, int from, int to)
    {
        int idx = ((to - from) + 4) % 4;
        if (idx == 0) return new[] { Vector2Int.zero };
        idx--; // 0->1 => idx 0
        Vector2Int[][] table = t switch
        {
            Type.I => I_Kick,
            Type.O => new[] { new[] { Vector2Int.zero }, new[] { Vector2Int.zero }, new[] { Vector2Int.zero }, new[] { Vector2Int.zero } },
            Type.S or Type.Z => SZ_Kick,
            _ => JO_LoT_Kick
        };
        return table[idx];
    }

    public static readonly Type[] AllTypes = { Type.I, Type.O, Type.T, Type.S, Type.Z, Type.L, Type.J };
}
