# Tetris — Requirements (atomic, EARS + Gherkin)

**Product:** Web-based classic Tetris (browser, desktop + mobile)
**Standard:** [`../requirements_doc_standard.md`](../requirements_doc_standard.md) §5–§6
**Source:** [`../acceptance_criteria_tetris.md`](../acceptance_criteria_tetris.md)
**Verify methods in use:** `llm-judge` · `manual` *(no `automated` — no test suite yet)*

Each record is **one atom**. Schema per record:

```
id            stable, never reused — the traceability anchor
title         short label
category      grouping
priority      must | should | could            (MoSCoW)
source        original section in acceptance_criteria_tetris.md
requirement   the EARS statement  (drives generation)
acceptance    Given/When/Then     (drives compliance)
verify_method llm-judge | manual
quality_check ISO/IEC/IEEE 29148 characteristics asserted for this atom
```

A verifying agent should produce one verdict per `id` (see
[`traceability.md`](./traceability.md)).

---

## A. Startup & lifecycle  *(source §3.4)*

```yaml
id: NFR-LOAD-001
title: Time to interactive
category: Lifecycle
priority: must
source: §3.4.1
requirement: >
  When the user opens the game URL in a supported browser, the game shall reach an
  interactive state (menu or first piece) within 3 seconds.
acceptance:
  - |
    Given a supported evergreen browser on a mid-tier broadband connection
    When the user navigates to the game URL
    Then the game becomes interactive within 3 seconds
verify_method: manual
quality_check: [singular, verifiable, unambiguous]
```

```yaml
id: FR-LIFE-001
title: Clean startup
category: Lifecycle
priority: must
source: §3.4.1
requirement: >
  When the game loads, the game shall complete startup with zero uncaught exceptions
  and zero console errors.
acceptance:
  - |
    Given the game URL is opened
    When the page finishes loading and reaches an interactive state
    Then no uncaught exception is thrown and the console shows no errors
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-LIFE-002
title: Start spawns first piece and starts gravity
category: Lifecycle
priority: must
source: §3.4.2
requirement: >
  When the user triggers Start, the game shall spawn the first tetromino at the
  top-center position and start the gravity timer.
acceptance:
  - |
    Given the start screen
    When the user triggers Start
    Then the first tetromino appears at the top-center
    And the gravity timer begins advancing the piece downward
verify_method: llm-judge
quality_check: [singular, verifiable, complete]
```

```yaml
id: FR-LIFE-003
title: Stable game-loop cadence
category: Lifecycle
priority: must
source: §3.4.3
requirement: >
  While the game is running, the game shall advance state at a stable cadence with no
  stall exceeding 100 ms during normal play.
acceptance:
  - |
    Given an active game under normal play
    When the game loop runs
    Then no single frame/update stalls for more than 100 ms
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-LIFE-004
title: Pause stops fall and timer
category: Lifecycle
priority: must
source: §3.4.4
requirement: >
  When the user pauses an active game, the game shall stop the active piece from
  falling and stop the gravity timer.
acceptance:
  - |
    Given an active game with a falling piece
    When the user pauses
    Then the piece stops falling
    And the gravity timer stops
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-LIFE-005
title: Pause ignores gameplay input
category: Lifecycle
priority: must
source: §3.4.4
requirement: >
  While the game is paused, the game shall ignore all input except Resume.
acceptance:
  - |
    Given a paused game
    When the user presses any gameplay control other than Resume
    Then the board state does not change
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-LIFE-006
title: Resume restores identical state
category: Lifecycle
priority: must
source: §3.4.4
requirement: >
  When the user resumes from pause, the game shall continue from the identical state
  that existed before pausing.
acceptance:
  - |
    Given a paused game with a known board, piece, score, level, and lines
    When the user resumes
    Then play continues from the identical pre-pause state
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-LIFE-007
title: Restart resets state
category: Lifecycle
priority: must
source: §3.4.5
requirement: >
  When the user selects Restart after game over, the game shall reset the board,
  score, level, and lines to their initial values and begin a fresh game.
acceptance:
  - |
    Given a game-over state
    When the user selects Restart
    Then board, score, level, and lines reset to initial values
    And a fresh game begins
verify_method: llm-judge
quality_check: [singular, verifiable, complete]
```

```yaml
id: FR-LIFE-008
title: Tab blur auto-pause without runaway loops
category: Lifecycle
priority: should
source: §3.4.6
requirement: >
  When the browser tab loses focus or is backgrounded, the game shall auto-pause or
  continue deterministically, without runaway timers or duplicated loops on refocus.
acceptance:
  - |
    Given an active game
    When the tab is backgrounded and later refocused
    Then exactly one game loop is running
    And no avalanche of skipped gravity ticks is applied
verify_method: llm-judge
quality_check: [singular, verifiable]
```

---

## B. Playfield / grid  *(source §3.1, §3.3)*

```yaml
id: FR-GRID-001
title: Playfield dimensions
category: Grid
priority: must
source: §3.1, §3.3
requirement: The game shall provide a playfield 10 cells wide and 20 cells high.
acceptance:
  - |
    Given the game is loaded
    When the playfield is rendered
    Then the grid is 10 columns wide and 20 rows high
verify_method: llm-judge
quality_check: [singular, verifiable, unambiguous]
```

```yaml
id: FR-GRID-002
title: Cell state
category: Grid
priority: must
source: §3.1
requirement: >
  The game shall represent each cell as either empty or filled with a specific piece
  color/type.
acceptance:
  - |
    Given the playfield
    When a cell is inspected
    Then it is either empty or holds exactly one piece color/type id
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-GRID-003
title: Entire field visible
category: Grid
priority: should
source: §3.1
requirement: The game shall keep the entire 20-row visible field on screen during play.
acceptance:
  - |
    Given an active game
    When the playfield is displayed
    Then all 20 rows of the playable field are visible
verify_method: manual
quality_check: [singular, verifiable]
```

---

## C. Tetrominoes & configuration  *(source §3.2, §3.3)*

```yaml
id: FR-PIECE-001
title: Seven tetrominoes exist
category: Pieces
priority: must
source: §3.2, §3.5.1
requirement: The game shall provide the seven standard tetrominoes I, O, T, S, Z, L, and J.
acceptance:
  - |
    Given the piece definitions
    When the set of tetrominoes is enumerated
    Then exactly the seven shapes I, O, T, S, Z, L, J are present with correct geometry
verify_method: llm-judge
quality_check: [singular, verifiable, complete]
```

```yaml
id: FR-PIECE-002
title: Standard colors
category: Pieces
priority: should
source: §3.2, §3.5.1
requirement: >
  The game shall render each tetromino in its standard color: I cyan, O yellow,
  T purple, S green, Z red, L orange, J blue.
acceptance:
  - |
    Given each tetromino type
    When it is rendered
    Then its color matches the standard mapping (I=cyan, O=yellow, T=purple, S=green, Z=red, L=orange, J=blue)
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-PIECE-003
title: Four cells per piece
category: Pieces
priority: must
source: §3.2
requirement: The game shall compose each tetromino of exactly four cells.
acceptance:
  - |
    Given any tetromino in any rotation state
    When its occupied cells are counted
    Then the count is exactly four
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-PIECE-004
title: Spawn position centered at top
category: Pieces
priority: must
source: §3.2, §3.5.2
requirement: >
  When a piece spawns, the game shall place it at the top of the field horizontally
  centered using x = floor(fieldWidth/2) - floor(pieceWidth/2), in its standard orientation.
acceptance:
  - |
    Given a new piece is spawned
    When its initial position is computed
    Then it is in standard orientation, at the top, horizontally centered per the formula
verify_method: llm-judge
quality_check: [singular, verifiable, unambiguous]
```

```yaml
id: FR-CFG-001
title: Base drop interval
category: Configuration
priority: must
source: §3.3
requirement: The game shall use a base drop interval of 500 ms at the starting level.
acceptance:
  - |
    Given the game at its starting level
    When gravity is applied
    Then the drop interval equals 500 ms
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-CFG-002
title: Minimum drop interval
category: Configuration
priority: must
source: §3.3
requirement: The game shall never let the drop interval fall below 50 ms.
acceptance:
  - |
    Given increasing levels
    When the drop interval is computed
    Then it is clamped to a minimum of 50 ms
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-CFG-003
title: Lines per level
category: Configuration
priority: must
source: §3.3
requirement: The game shall require 10 cleared lines to advance one level.
acceptance:
  - |
    Given the current level
    When 10 lines have been cleared since the last level-up
    Then the level advances by one
verify_method: llm-judge
quality_check: [singular, verifiable]
```

---

## D. Spawning & queue  *(source §3.5)*

```yaml
id: FR-SPAWN-001
title: 7-bag randomizer
category: Spawning
priority: must
source: §3.5.3, §3.10.5
requirement: >
  The game shall generate spawn order using a 7-bag randomizer so that within each bag
  no piece is duplicated or starved.
acceptance:
  - |
    Given a sequence of 7 consecutive spawns (one bag)
    When the spawned pieces are collected
    Then each of the 7 tetrominoes appears exactly once
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-SPAWN-002
title: Next preview matches spawn
category: Spawning
priority: must
source: §3.5.4, §5.5.2
requirement: >
  The game shall display a Next preview whose shown piece(s) match the actual next
  spawned piece.
acceptance:
  - |
    Given the Next preview shows piece P
    When the next piece spawns
    Then the spawned piece is P
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-SPAWN-003
title: Hold swap once per piece
category: Spawning
priority: should
source: §3.5.5
requirement: >
  When the user activates Hold, the game shall swap the active piece with the held
  piece, allowing the swap at most once per piece until that piece locks.
acceptance:
  - |
    Given an active piece and Hold not yet used for it
    When the user activates Hold
    Then the active and held pieces swap
    And a second Hold for the same active piece is rejected until it locks
verify_method: llm-judge
quality_check: [singular, verifiable]
```

---

## E. Movement, rotation, collision, locking  *(source §3.6)*

```yaml
id: FR-MOVE-001
title: Horizontal move by one column
category: Movement
priority: must
source: §3.6.1
requirement: >
  When the user presses Left or Right, the game shall move the active piece exactly one
  column in that direction if the target cells are empty and within bounds.
acceptance:
  - |
    Given an active piece with free space to its side
    When the user presses Left or Right
    Then the piece moves exactly one column in that direction
verify_method: llm-judge
quality_check: [singular, verifiable, unambiguous]
```

```yaml
id: FR-MOVE-002
title: Blocked horizontal move rejected
category: Movement
priority: must
source: §3.6.1, §3.6.7
requirement: >
  If a Left or Right move would cross the field boundary or overlap a locked cell, then
  the game shall reject the move and leave the piece unchanged.
acceptance:
  - |
    Given an active piece adjacent to a wall or locked cell
    When the user presses toward that obstacle
    Then the piece does not move and no overlap or out-of-bounds occurs
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-MOVE-003
title: Automatic gravity descent
category: Movement
priority: must
source: §3.6.2, §2.2
requirement: >
  While the game is running, the game shall move the active piece down one cell
  automatically every gravity tick.
acceptance:
  - |
    Given a running game with a falling piece
    When one gravity interval elapses
    Then the piece descends by exactly one cell (if not blocked)
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-MOVE-004
title: Soft drop accelerates descent
category: Movement
priority: must
source: §3.6.2, §3.6.3
requirement: >
  While the user holds Soft Drop, the game shall accelerate the active piece's descent
  beyond the normal gravity rate.
acceptance:
  - |
    Given a falling piece
    When the user holds Soft Drop
    Then the piece descends faster than the normal gravity rate
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-MOVE-005
title: Hard drop locks instantly
category: Movement
priority: must
source: §3.6.3, §3.6.4
requirement: >
  When the user presses Hard Drop, the game shall instantly move the active piece to
  its landing position and lock it there.
acceptance:
  - |
    Given a falling piece
    When the user presses Hard Drop
    Then the piece moves immediately to its lowest valid position and locks
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ROT-001
title: Rotate 90 degrees about pivot
category: Rotation
priority: must
source: §3.6.5
requirement: >
  When the user rotates the active piece, the game shall rotate it 90 degrees in the
  requested direction about its standard pivot.
acceptance:
  - |
    Given an active piece with room to rotate
    When the user rotates clockwise or counter-clockwise
    Then the piece's orientation advances 90 degrees about its pivot
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ROT-002
title: SRS wall kicks
category: Rotation
priority: should
source: §3.6.6
requirement: >
  When a rotation would collide with a wall, floor, or stack, the game shall apply the
  first valid SRS kick-table offset that yields a non-colliding position.
acceptance:
  - |
    Given a rotation that collides in place but has a valid SRS kick
    When the user rotates
    Then the piece is offset per the SRS kick table to a valid position
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ROT-003
title: Impossible rotation rejected
category: Rotation
priority: must
source: §3.6.5, §3.6.6, §8.3
requirement: >
  If a rotation would collide and no valid wall-kick offset exists, then the game shall
  reject the rotation and leave the piece unchanged.
acceptance:
  - |
    Given a rotation that collides and has no valid kick
    When the user rotates
    Then the rotation is rejected and the piece state is unchanged
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-COL-001
title: Collision integrity invariant
category: Collision
priority: must
source: §3.6.7, §3.10.3
requirement: >
  The game shall never allow any active-piece cell to overlap an occupied cell or exit
  the playfield's left, right, or bottom bounds.
acceptance:
  - |
    Given any sequence of moves, rotations, and drops
    When the active piece's cells are evaluated at every step
    Then no cell overlaps an occupied cell and none exits the playfield bounds
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-LOCK-001
title: Lock on landing and spawn next
category: Locking
priority: must
source: §3.6.8
requirement: >
  When the active piece can no longer move down, the game shall lock it into the board
  and then spawn a new piece.
acceptance:
  - |
    Given a piece resting on the floor or stack
    When it can move no further down
    Then its cells become part of the board
    And a new piece spawns
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-LOCK-002
title: Bounded lock delay
category: Locking
priority: should
source: §3.6.9
requirement: >
  When a piece lands, the game shall allow movement and rotation during a bounded lock
  delay (about 500 ms) without permitting indefinite stalling.
acceptance:
  - |
    Given a piece that has just landed
    When the user moves or rotates within the lock delay
    Then the action is allowed
    And the piece still locks within a bounded time without infinite stalling
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-GHOST-001
title: Ghost piece matches landing
category: Movement
priority: should
source: §3.6.10
requirement: >
  The game shall display a ghost piece indicating the hard-drop landing position that
  matches where the active piece actually lands.
acceptance:
  - |
    Given a falling piece
    When the ghost is displayed
    Then the ghost marks the exact cells where a hard drop would land the piece
verify_method: llm-judge
quality_check: [singular, verifiable]
```

---

## F. Line clearing  *(source §3.7)*

```yaml
id: FR-CLEAR-001
title: Single line clear
category: Line clearing
priority: must
source: §3.7.1
requirement: >
  When the active piece locks and exactly one row is fully filled, the game shall remove
  that row and shift all rows above it down by one.
acceptance:
  - |
    Given a board with exactly one fully-filled row
    When the active piece locks
    Then that row is removed
    And all rows above shift down by one
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-CLEAR-002
title: Double line clear
category: Line clearing
priority: must
source: §3.7.2
requirement: >
  When the active piece locks and exactly two rows are simultaneously full, the game
  shall clear both rows in a single step.
acceptance:
  - |
    Given two simultaneously fully-filled rows
    When the active piece locks
    Then both rows clear together in one step
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-CLEAR-003
title: Triple line clear
category: Line clearing
priority: must
source: §3.7.3
requirement: >
  When the active piece locks and exactly three rows are simultaneously full, the game
  shall clear all three rows in a single step.
acceptance:
  - |
    Given three simultaneously fully-filled rows
    When the active piece locks
    Then all three rows clear together in one step
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-CLEAR-004
title: Tetris (quad) clear
category: Line clearing
priority: must
source: §3.7.4
requirement: >
  When the active piece locks and exactly four rows are simultaneously full, the game
  shall clear all four rows in a single step.
acceptance:
  - |
    Given four simultaneously fully-filled rows
    When the active piece locks
    Then all four rows clear together in one step
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-CLEAR-005
title: Non-contiguous clears preserve gaps
category: Line clearing
priority: must
source: §3.7.5
requirement: >
  When filled rows separated by partial rows clear, the game shall remove only the
  filled rows and let remaining blocks fall so existing gaps are preserved.
acceptance:
  - |
    Given filled rows separated by partial rows
    When the filled rows clear
    Then only the filled rows are removed
    And remaining blocks settle correctly, preserving the partial-row gaps
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-CLEAR-006
title: No false clear
category: Line clearing
priority: must
source: §3.7.6
requirement: If a row contains any empty cell, then the game shall not clear that row.
acceptance:
  - |
    Given a row with at least one empty cell
    When the active piece locks
    Then that row is not cleared
verify_method: llm-judge
quality_check: [singular, verifiable]
```

---

## G. Score, level, progression  *(source §3.8)*

```yaml
id: FR-SCORE-001
title: Score monotonic and non-negative
category: Scoring
priority: must
source: §3.8.1
requirement: The game shall keep the score monotonically non-decreasing and never negative.
acceptance:
  - |
    Given any sequence of play
    When the score changes
    Then it never decreases and never becomes negative
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-SCORE-002
title: Line-clear scoring scale
category: Scoring
priority: must
source: §3.8.2, §3.8 table
requirement: >
  When lines are cleared on a lock, the game shall award 100×level for 1 line,
  300×level for 2, 500×level for 3, and 800×level for 4, so per-line reward increases
  with the number of lines cleared.
acceptance:
  - |
    Given the current level L
    When 1/2/3/4 lines clear on a lock
    Then the score increases by 100×L / 300×L / 500×L / 800×L respectively
verify_method: llm-judge
quality_check: [singular, verifiable, unambiguous]
```

```yaml
id: FR-SCORE-003
title: Lines counter increments exactly
category: Scoring
priority: must
source: §3.8.3
requirement: >
  When rows are cleared on a lock, the game shall increase the lines-cleared counter by
  exactly the number of rows cleared.
acceptance:
  - |
    Given N rows clear on a single lock
    When the lines counter updates
    Then it increases by exactly N
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-SCORE-004
title: Soft/hard drop points
category: Scoring
priority: should
source: §3.8.5
requirement: >
  The game shall award 1 point per cell dropped via soft drop and 2 points per cell
  dropped via hard drop.
acceptance:
  - |
    Given a piece dropped D cells
    When it falls via soft drop / hard drop
    Then the score increases by 1×D / 2×D respectively
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-SCORE-005
title: High score persists across reloads
category: Scoring
priority: should
source: §3.8.6
requirement: >
  The game shall persist the high score via localStorage so it survives a page reload.
acceptance:
  - |
    Given a high score achieved in a session
    When the page is reloaded
    Then the persisted high score is restored from localStorage
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-LEVEL-001
title: Level increases every 10 lines
category: Progression
priority: must
source: §3.8.4, §4
requirement: >
  When 10 lines have been cleared since the last level-up, the game shall increase the
  level by one.
acceptance:
  - |
    Given the current level
    When the cumulative cleared lines cross the next multiple of 10
    Then the level increments by one
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-LEVEL-002
title: Gravity speeds up with level
category: Progression
priority: must
source: §3.8.4, §3.8 formula
requirement: >
  When the level increases, the game shall set the gravity interval to
  max(50, 500 / (level + 1)) ms.
acceptance:
  - |
    Given a new level value
    When the gravity interval is recomputed
    Then it equals max(50, 500 / (level + 1)) ms
verify_method: llm-judge
quality_check: [singular, verifiable, unambiguous]
```

---

## H. Game over  *(source §3.9)*

```yaml
id: FR-OVER-001
title: Block-out ends game
category: Game over
priority: must
source: §3.9.1, §8.11
requirement: >
  When a newly spawned piece immediately collides with the existing stack, the game
  shall set status to gameover and stop the gravity loop.
acceptance:
  - |
    Given the stack reaches the spawn area
    When a new piece spawns and immediately collides
    Then status becomes 'gameover' and the gravity loop stops
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-OVER-002
title: Game-over screen with score and restart
category: Game over
priority: must
source: §3.9.2
requirement: >
  When game over occurs, the game shall display a game-over screen showing the final
  score and a Restart action.
acceptance:
  - |
    Given a game-over state
    When the game-over screen is shown
    Then it displays the final score and a Restart control
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-OVER-003
title: No board mutation after game over
category: Game over
priority: must
source: §3.9.3
requirement: >
  While in the game-over state, the game shall ignore gameplay input that would mutate
  the board.
acceptance:
  - |
    Given a game-over state
    When the user presses gameplay controls
    Then the board does not change (no zombie movement)
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-OVER-004
title: No spawn after game over until restart
category: Game over
priority: must
source: §3.9.4
requirement: >
  While in the game-over state, the game shall not spawn a new piece until the user
  restarts.
acceptance:
  - |
    Given a game-over state
    When time passes without a Restart
    Then no new piece spawns
verify_method: llm-judge
quality_check: [singular, verifiable]
```

---

## I. Internal logic & architecture  *(source §3.10 — structural, normative)*

```yaml
id: FR-ARCH-001
title: Timer-driven game cycle
category: Architecture
priority: must
source: §3.10.1
requirement: >
  The game shall drive its game cycle with a timer mechanism (setInterval or
  requestAnimationFrame with a time check).
acceptance:
  - |
    Given the running game
    When the update mechanism is inspected
    Then a timer / rAF-with-time-check advances the game state
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ARCH-002
title: 2D array field representation
category: Architecture
priority: should
source: §3.10.2
requirement: >
  The game shall represent the field as a 10×20 two-dimensional array where 0 is empty
  and 1..7 identify the occupying piece color.
acceptance:
  - |
    Given the field data structure
    When inspected
    Then it is a 10×20 array using 0 for empty and 1..7 for piece colors
verify_method: llm-judge
quality_check: [singular, verifiable]
```

---

## J. Controls & input  *(source §5.1, §5.2)*

```yaml
id: FR-CTRL-001
title: Keyboard bindings for must-have actions
category: Controls
priority: must
source: §5.1, §5.2.1
requirement: >
  The game shall bind move left/right to Left/Right arrows, soft drop to Down, hard
  drop to Space, rotate to Up or X (CW) and Z or Ctrl (CCW), Hold to C or Shift,
  Pause to Esc or P, and Restart to R.
acceptance:
  - |
    Given the keyboard control scheme
    When each binding is exercised
    Then it performs its mapped action (move, soft/hard drop, rotate CW/CCW, hold, pause, restart)
verify_method: llm-judge
quality_check: [singular, verifiable, complete]
```

```yaml
id: NFR-CTRL-002
title: Input latency
category: Controls
priority: must
source: §5.2.2, §7.2
requirement: >
  The game shall produce a visible response within 100 ms of a keypress under normal load.
acceptance:
  - |
    Given normal load
    When the user presses a control key
    Then a visible response occurs within 100 ms
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-CTRL-003
title: Deterministic repeat and simultaneous keys
category: Controls
priority: should
source: §5.2.3, §8.1, §8.2
requirement: >
  The game shall handle key repeat without missed or doubled inputs and shall resolve
  simultaneous keys deterministically, keeping collision invariants.
acceptance:
  - |
    Given rapid key repeat or simultaneous keypresses
    When inputs are processed
    Then no input is missed or doubled per intent and the resolution is deterministic
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-CTRL-004
title: Touch controls reachable
category: Controls
priority: should
source: §5.1, §5.2.4
requirement: >
  On touch devices, the game shall provide on-screen controls for all must-have actions
  with touch targets at least 44×44 px.
acceptance:
  - |
    Given a touch device
    When the controls are displayed
    Then every must-have action is reachable and each touch target is at least 44×44 px
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-CTRL-005
title: Suppress browser default gestures
category: Controls
priority: must
source: §5.2.5
requirement: >
  While playing, the game shall suppress browser default behaviors so arrows/Space do
  not scroll the page and touch gestures do not zoom.
acceptance:
  - |
    Given active play
    When arrow/Space keys or pinch/scroll gestures occur
    Then the page does not scroll or zoom
verify_method: llm-judge
quality_check: [singular, verifiable]
```

---

## K. HUD & screen layout  *(source §5.3, §5.5)*

```yaml
id: UI-HUD-001
title: HUD shows and updates score/level/lines
category: HUD
priority: must
source: §5.3, §5.5.1
requirement: >
  While playing, the game shall always display the current score, level, and lines and
  update them immediately when they change.
acceptance:
  - |
    Given an active game
    When score, level, or lines change
    Then the HUD reflects the new values immediately and they are always visible
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: UI-HUD-002
title: Distinguishable piece/ghost/locked visuals
category: HUD
priority: should
source: §5.5.3
requirement: >
  The game shall render the active piece, ghost piece, and locked cells so they are
  visually distinguishable, using standard per-piece colors.
acceptance:
  - |
    Given an active game with a ghost and locked cells
    When the board is rendered
    Then active, ghost, and locked cells are visually distinct
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: UI-HUD-003
title: Visual feedback for clears and game over
category: HUD
priority: should
source: §5.5.4
requirement: >
  The game shall provide clear visual feedback for line clears and for game over.
acceptance:
  - |
    Given a line clear or a game over
    When the event occurs
    Then a visible feedback effect (flash/animation/screen) is shown
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: UI-LAYOUT-001
title: Side panel content
category: Layout
priority: must
source: §5.3
requirement: >
  The game shall present a side panel containing the score, level, lines, a Next
  preview, a New Game/Restart control, and a Game Over indicator.
acceptance:
  - |
    Given the main screen
    When the side panel is displayed
    Then it contains score, level, lines, Next preview, New Game/Restart, and a Game Over indicator
verify_method: llm-judge
quality_check: [singular, verifiable, complete]
```

---

## L. Responsiveness & layout  *(source §5.6)*

```yaml
id: UI-RESP-001
title: Adaptive layout without overflow
category: Responsiveness
priority: must
source: §5.6.1
requirement: >
  The game shall adapt its layout without overflow or clipping from 320 px wide up to
  large desktop, in both portrait and landscape.
acceptance:
  - |
    Given viewports from 320 px wide to large desktop, portrait and landscape
    When the game is displayed
    Then there is no overflow or clipping and the game remains usable
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: UI-RESP-002
title: Playfield aspect ratio preserved
category: Responsiveness
priority: must
source: §5.6.2
requirement: >
  The game shall preserve the playfield's aspect ratio and keep it fully visible at all
  supported sizes.
acceptance:
  - |
    Given any supported viewport size
    When the playfield is rendered
    Then its aspect ratio is correct and no rows are off-screen
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: UI-RESP-003
title: No layout shift or horizontal scroll
category: Responsiveness
priority: should
source: §5.6.3
requirement: >
  The game shall produce no cumulative layout shift after load and no horizontal
  scrollbar during play.
acceptance:
  - |
    Given the loaded game
    When the user plays
    Then CLS is approximately 0 and no horizontal scrollbar appears
verify_method: manual
quality_check: [singular, verifiable]
```

---

## M. Audio  *(source §5.7)*

```yaml
id: FR-AUDIO-001
title: Move/rotate click
category: Audio
priority: could
source: §5.7
requirement: When a piece moves or rotates, the game shall play a short click sound.
acceptance:
  - |
    Given audio is available and enabled
    When the active piece moves or rotates
    Then a short click sound plays
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-AUDIO-002
title: Landing sound
category: Audio
priority: could
source: §5.7
requirement: When a piece locks, the game shall play a soft landing sound.
acceptance:
  - |
    Given audio is available and enabled
    When a piece locks
    Then a soft landing sound plays
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-AUDIO-003
title: Line-clear chime
category: Audio
priority: could
source: §5.7
requirement: When a line clears, the game shall play a chime.
acceptance:
  - |
    Given audio is available and enabled
    When one to three lines clear
    Then a chime plays
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-AUDIO-004
title: Tetris sound
category: Audio
priority: could
source: §5.7
requirement: When four lines clear at once, the game shall play a brighter sound than a normal clear.
acceptance:
  - |
    Given audio is available and enabled
    When four lines clear simultaneously
    Then a brighter sound than the normal clear plays
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-AUDIO-005
title: Game-over sound
category: Audio
priority: could
source: §5.7
requirement: When game over occurs, the game shall play a low signal sound.
acceptance:
  - |
    Given audio is available and enabled
    When game over occurs
    Then a low signal sound plays
verify_method: manual
quality_check: [singular, verifiable]
```

---

## N. Accessibility  *(source §6)*

```yaml
id: NFR-A11Y-001
title: Keyboard-operable menus with focus
category: Accessibility
priority: should
source: §6.1
requirement: >
  The game shall make all interactive menu controls keyboard-reachable and operable
  (tab order, Enter/Space activation) with visible focus states.
acceptance:
  - |
    Given the menus
    When navigating by keyboard
    Then every control is reachable, operable via Enter/Space, and shows a visible focus state
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-A11Y-002
title: Color not the only signal
category: Accessibility
priority: should
source: §6.2
requirement: >
  The game shall not rely on color as the only signal for critical information; state
  shall also be distinguishable by shape, text, or position.
acceptance:
  - |
    Given critical game-state information
    When color is removed or unavailable
    Then the information is still distinguishable by shape/text/position
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-A11Y-003
title: WCAG AA contrast
category: Accessibility
priority: should
source: §6.3
requirement: The game shall meet WCAG AA contrast (at least 4.5:1 for normal text).
acceptance:
  - |
    Given text and UI elements
    When contrast is measured
    Then normal text meets at least a 4.5:1 contrast ratio
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-A11Y-004
title: Accessible names and canvas label
category: Accessibility
priority: should
source: §6.4
requirement: >
  The game shall give interactive elements accessible names/labels and give the canvas
  a meaningful aria-label/role.
acceptance:
  - |
    Given the DOM and canvas
    When inspected
    Then interactive elements have accessible names and the canvas has a meaningful aria-label/role
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: NFR-A11Y-005
title: Respect reduced motion; limit flashing
category: Accessibility
priority: should
source: §6.5
requirement: >
  The game shall respect prefers-reduced-motion by reducing non-essential
  animation/flashing and shall not flash content more than three times per second.
acceptance:
  - |
    Given prefers-reduced-motion is set
    When the game runs
    Then non-essential animation is reduced and no content flashes more than 3 times per second
verify_method: manual
quality_check: [singular, verifiable]
```

---

## O. Performance  *(source §7)*

```yaml
id: NFR-PERF-001
title: Frame rate
category: Performance
priority: must
source: §7.1
requirement: >
  During active play, the game shall sustain at least 60 FPS on desktop and at least
  30 FPS on low-end mobile without sustained drops.
acceptance:
  - |
    Given active play
    When frame rate is measured
    Then it stays at or above 60 FPS desktop / 30 FPS low-end mobile with no sustained drops
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-PERF-002
title: Time to interactive (throttled)
category: Performance
priority: should
source: §7.3
requirement: >
  The game shall reach time-to-interactive within 3 s on mid-tier broadband and within
  5 s on throttled Fast 3G.
acceptance:
  - |
    Given mid-tier broadband / throttled Fast 3G
    When the game loads
    Then it becomes interactive within 3 s / 5 s respectively
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-PERF-003
title: Bundle size
category: Performance
priority: should
source: §7.4
requirement: >
  The game shall keep the total initial gzipped bundle at or below 2 MB, targeting
  500 KB of JavaScript or less.
acceptance:
  - |
    Given a production build
    When the gzipped bundle is measured
    Then it is at most 2 MB total (target ≤ 500 KB JS)
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-PERF-004
title: No memory growth over long session
category: Performance
priority: should
source: §7.5
requirement: >
  Over a sustained 10-minute session, the game shall not exhibit memory growth (stable
  heap after garbage collection).
acceptance:
  - |
    Given a continuous 10-minute session
    When heap usage is monitored
    Then it stabilizes after GC with no continuous growth (no leak)
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-PERF-005
title: No long main-thread tasks
category: Performance
priority: should
source: §7.6
requirement: >
  During steady-state play, the game shall not run tasks longer than 50 ms on the main
  thread.
acceptance:
  - |
    Given steady-state play
    When main-thread tasks are profiled
    Then no task exceeds 50 ms
verify_method: manual
quality_check: [singular, verifiable]
```

---

## P. Compatibility  *(source §3.12)*

```yaml
id: NFR-COMPAT-001
title: Desktop browsers
category: Compatibility
priority: must
source: §3.12.1, §3.12.3
requirement: >
  The game shall be fully playable on the latest two major versions of Chrome, Firefox,
  Safari, and Edge on desktop.
acceptance:
  - |
    Given the latest two major versions of Chrome/Firefox/Safari/Edge on desktop
    When the game is played
    Then it is fully playable on each
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-COMPAT-002
title: Mobile browsers
category: Compatibility
priority: must
source: §3.12.2, §3.12.3
requirement: >
  The game shall be fully playable on the latest two major versions of mobile Safari
  (iOS) and Chrome (Android).
acceptance:
  - |
    Given the latest two major versions of mobile Safari (iOS) and Chrome (Android)
    When the game is played
    Then it is fully playable on each
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: NFR-COMPAT-003
title: Graceful optional-API fallback
category: Compatibility
priority: should
source: §3.12.4
requirement: >
  The game shall not depend on experimental/flagged APIs and shall degrade gracefully
  when an optional API (e.g. audio, vibration) is unavailable.
acceptance:
  - |
    Given an optional API is unavailable
    When the game runs
    Then it remains playable and does not crash, and uses no flagged/experimental APIs
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: NFR-COMPAT-004
title: Static HTTPS hosting
category: Compatibility
priority: must
source: §3.12.5
requirement: >
  The game shall run over plain HTTPS with no server-side runtime dependency
  (static-hosting compatible).
acceptance:
  - |
    Given the production build served from static HTTPS hosting
    When the game is loaded
    Then it runs fully with no server-side runtime dependency
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: NFR-COMPAT-005
title: HiDPI crispness
category: Compatibility
priority: should
source: §3.12.6
requirement: >
  The game shall render crisply at device pixel ratios of 1×, 2×, and 3× (not blurry on
  Retina/HiDPI).
acceptance:
  - |
    Given displays at DPR 1×, 2×, and 3×
    When the game renders
    Then output is crisp, not blurry
verify_method: manual
quality_check: [singular, verifiable]
```

---

## Q. Error handling & resilience  *(source §8)*

```yaml
id: FR-ERR-001
title: Input spam safe
category: Resilience
priority: must
source: §8.1
requirement: >
  When many keys or taps occur within one frame, the game shall not crash, enter an
  illegal state, or perform a double-move per intent, and shall keep collision invariants.
acceptance:
  - |
    Given many inputs within a single frame
    When they are processed
    Then no crash or illegal state occurs and collision invariants hold
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ERR-002
title: Concurrent rotate+move+drop deterministic
category: Resilience
priority: must
source: §8.2
requirement: >
  When rotate, move, and drop are requested together, the game shall resolve them
  deterministically without the piece overlapping or escaping bounds.
acceptance:
  - |
    Given simultaneous rotate, move, and drop inputs
    When resolved
    Then the outcome is deterministic and the piece never overlaps or escapes bounds
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ERR-003
title: Hard drop into full column
category: Resilience
priority: must
source: §8.4
requirement: >
  When a hard drop occurs into a full or near-full column, the game shall lock the piece
  correctly at the top and may legitimately trigger game over, without crashing.
acceptance:
  - |
    Given a full or near-full column
    When the user hard drops into it
    Then the piece locks correctly at the top (possibly triggering game over) and does not crash
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ERR-004
title: Resize / orientation mid-game
category: Resilience
priority: should
source: §8.5
requirement: >
  When the window is resized or the orientation changes mid-game, the game shall
  continue, refit the board, preserve state, and not lose input.
acceptance:
  - |
    Given an active game
    When the window resizes or orientation changes
    Then the game continues, the board refits, state is preserved, and no input is lost
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-ERR-005
title: localStorage unavailable degrades gracefully
category: Resilience
priority: should
source: §8.7
requirement: >
  If localStorage is unavailable, quota-exceeded, or in private mode, then the game
  shall degrade high-score/settings features gracefully and remain playable.
acceptance:
  - |
    Given localStorage is unavailable or throws
    When the game runs
    Then persistence features degrade gracefully and the game stays playable
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ERR-006
title: Corrupt persisted data falls back
category: Resilience
priority: should
source: §8.8
requirement: >
  When persisted data is corrupt or invalid, the game shall validate it and fall back to
  defaults without crashing.
acceptance:
  - |
    Given corrupt or invalid persisted data
    When the game loads it
    Then it validates, falls back to defaults, and does not crash
verify_method: llm-judge
quality_check: [singular, verifiable]
```

```yaml
id: FR-ERR-007
title: Large numbers / long session safe
category: Resilience
priority: could
source: §8.9
requirement: >
  During a very long session or at a very high score, the game shall not overflow
  integers, break the UI with large numbers, or decay frame rate.
acceptance:
  - |
    Given a very long session and a very high score
    When the game continues
    Then no integer overflow, UI breakage, or FPS decay occurs
verify_method: manual
quality_check: [singular, verifiable]
```

```yaml
id: FR-ERR-008
title: Graceful unhandled-error handling
category: Resilience
priority: must
source: §8.10
requirement: >
  When an unhandled error occurs, the game shall catch and surface it gracefully without
  a white-screen-of-death or an infinite console error loop.
acceptance:
  - |
    Given an unexpected runtime error
    When it propagates
    Then it is caught and surfaced gracefully, with no white screen and no infinite error loop
verify_method: llm-judge
quality_check: [singular, verifiable]
```



