/* ============================================================
   Inverted Tetris — Phaser 3
   Figures rise from bottom upward, 3-cell pieces, 15×35 grid.
   ============================================================ */

/* ---------- constants ---------- */
const COLS = 15;
const ROWS = 35;
const BASE_RISE_INTERVAL = 500;
const MIN_RISE_INTERVAL  = 50;
const LINES_PER_LEVEL    = 10;
const LOCK_DELAY_MS      = 500;
const CLEAR_FLASH_MS     = 200;

const SHAPES = {
  I: { color: 0x30b5c5, cells: [[0,0],[0,1],[0,2]], w: 1, h: 3 },
  P: { color: 0xc00000, cells: [[1,0],[0,1],[0,2]], w: 2, h: 3 },
  L: { color: 0xED6D00, cells: [[0,0],[0,1],[1,2]], w: 2, h: 3 },
  C: { color: 0xa0d183, cells: [[0,0],[0,1],[1,1]], w: 2, h: 2 }
};
const SHAPE_NAMES = ['I','P','L','C'];

const WALL_KICKS = [
  [0,0],[1,0],[-1,0],[0,1],[0,-1],
  [2,0],[-2,0],[0,2],[0,-2],
  [1,1],[-1,-1],[1,-1],[-1,1]
];

const LINE_SCORES = [0, 100, 300, 500];

/* ---------- helpers ---------- */
function createGrid() {
  return Array.from({length: ROWS}, () => new Uint8Array(COLS));
}

function rotateCellsCW(cells) {
  return cells.map(([c,r]) => [r, -c]);
}

function getRotatedCells(shapeName, rotation) {
  let cells = SHAPES[shapeName].cells.map(c => [...c]);
  for (let i = 0; i < ((rotation % 4 + 4) % 4); i++) {
    cells = rotateCellsCW(cells);
  }
  const minC = Math.min(...cells.map(c => c[0]));
  const minR = Math.min(...cells.map(c => c[1]));
  cells = cells.map(([c,r]) => [c - minC, r - minR]);
  const w = 1 + Math.max(...cells.map(c => c[0]));
  const h = 1 + Math.max(...cells.map(c => c[1]));
  return { cells, w, h };
}

function collision(grid, cells, offX, offY) {
  for (const [c, r] of cells) {
    const x = offX + c;
    const y = offY + r;
    if (x < 0 || x >= COLS || y < 0 || y >= ROWS) return true;
    if (grid[y][x] !== 0) return true;
  }
  return false;
}

function bagRandomizer() {
  const bag = [...SHAPE_NAMES];
  for (let i = bag.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  return bag;
}

/* ---------- audio ---------- */
class AudioManager {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch(e) { this.enabled = false; }
  }
  resume() {
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }
  playTone(freq, dur, type='square', vol=0.08) {
    if (!this.enabled || !this.ctx) return;
    this.resume();
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(vol, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + dur);
  }
  move()    { this.playTone(600, 0.04, 'square', 0.04); }
  rotate()  { this.playTone(800, 0.06, 'square', 0.05); }
  lock()    { this.playTone(200, 0.12, 'triangle', 0.06); }
  clear(n)  {
    const base = 500 + n * 100;
    for (let i = 0; i < n; i++) {
      setTimeout(() => this.playTone(base + i*150, 0.2, 'sine', 0.1), i * 80);
    }
  }
  triple()  {
    [523, 659, 784].forEach((f,i) => setTimeout(() => this.playTone(f, 0.3, 'sine', 0.12), i*100));
  }
  gameOver(){ this.playTone(120, 0.8, 'sawtooth', 0.08); }
  hardRise(){ this.playTone(400, 0.08, 'triangle', 0.05); }
}

/* ---------- scene ---------- */
class GameScene extends Phaser.Scene {
  constructor() { super({ key: 'GameScene' }); }

  /* ========== create ========== */
  create() {
    const maxH = window.innerHeight;
    const maxW = window.innerWidth;
    let cellSize = Math.floor(Math.min(maxW / (COLS + 8), (maxH - 40) / ROWS));
    cellSize = Math.max(cellSize, 8);
    this.cellSize = cellSize;

    const gameW = COLS * cellSize;
    const gameH = ROWS * cellSize;
    const totalW = Math.min(gameW + 200, maxW);
    const totalH = Math.min(gameH + 40, maxH);
    this.scale.resize(totalW, totalH);

    /* game state */
    this.grid = createGrid();
    this.score = 0;
    this.lines = 0;
    this.level = 1;
    this.status = 'menu';
    this.highScore = this.loadHighScore();

    this.bag = [];
    this.bagIdx = 0;
    this.nextShape = null;
    this.holdShape = null;
    this.holdUsed = false;
    this.activePiece = null;
    this.ghostY = 0;
    this.lockDelayStart = 0;
    this.riseEvent = null;
    this.softRising = false;
    this.softRiseTimer = null;
    this.clearingRows = [];
    this.clearFlashTimer = 0;

    this.audio = new AudioManager();

    /* graphics layers */
    this.gridGraphics = this.add.graphics();
    this.pieceGraphics = this.add.graphics();
    this.ghostGraphics = this.add.graphics();

    /* side panel — persistent text objects */
    this.sideX = COLS * cellSize + 10;
    this.hud = {}; /* text refs for score, level, lines, best, next, hold labels */
    this.createHUD();

    /* overlay containers (menu, pause, gameover) */
    this.overlayObjects = [];

    this.showMenu();

    /* keyboard — proper Phaser 3 API */
    this.cursors = this.input.keyboard.createCursorKeys();
    this.keys = {
      space: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE),
      x: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.X),
      z: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.Z),
      c: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.C),
      shiftL: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SHIFT_LEFT),
      shiftR: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SHIFT_RIGHT),
      ctrl: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.CONTROL),
      p: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.P),
      esc: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESCAPE),
      r: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R),
      enter: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER)
    };
    this.input.on('gameobjectdown', () => this.audio.resume());

    /* visibility */
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.status === 'playing') this.pauseGame();
    });

    /* touch controls */
    this.createTouchControls();

    /* prevent scroll from game keys */
    window.addEventListener('keydown', (e) => {
      const blocked = [32, 37, 38, 39, 40];
      if (blocked.includes(e.keyCode)) e.preventDefault();
    });
  }

  /* ========== high score ========== */
  loadHighScore() {
    try {
      const v = localStorage.getItem('inverted_tetris_highscore');
      return v ? Math.max(0, parseInt(v, 10)) : 0;
    } catch(e) { return 0; }
  }
  saveHighScore() {
    try { localStorage.setItem('inverted_tetris_highscore', String(this.highScore)); }
    catch(e) {}
  }

  /* ========== bag ========== */
  nextFromBag() {
    if (this.bagIdx >= this.bag.length) {
      this.bag = bagRandomizer();
      this.bagIdx = 0;
    }
    return this.bag[this.bagIdx++];
  }

  /* ========== spawn ========== */
  spawnPiece(shapeName) {
    const rot = getRotatedCells(shapeName, 0);
    const x = Math.floor(COLS / 2) - Math.floor(rot.w / 2);
    const y = ROWS - rot.h;
    if (collision(this.grid, rot.cells, x, y)) {
      this.gameOver();
      return null;
    }
    this.activePiece = {
      name: shapeName, rotation: 0, x, y,
      cells: rot.cells, w: rot.w, h: rot.h,
      color: SHAPES[shapeName].color
    };
    this.holdUsed = false;
    this.lockDelayStart = 0;
    this.updateGhost();
    return this.activePiece;
  }

  startNewGame() {
    this.clearOverlay();
    this.grid = createGrid();
    this.score = 0;
    this.lines = 0;
    this.level = 1;
    this.bag = bagRandomizer();
    this.bagIdx = 0;
    this.nextShape = this.nextFromBag();
    this.holdShape = null;
    this.holdUsed = false;
    this.activePiece = null;
    this.status = 'playing';

    this.spawnPiece(this.nextShape);
    this.nextShape = this.nextFromBag();
    this.startRiseTimer();
    this.updateHUD();
    this.audio.resume();
  }

  /* ========== rise timer ========== */
  riseInterval() {
    return Math.max(MIN_RISE_INTERVAL, Math.floor(BASE_RISE_INTERVAL / this.level));
  }
  startRiseTimer() {
    this.stopRiseTimer();
    this.riseEvent = this.time.addEvent({
      delay: this.riseInterval(),
      callback: () => this.riseTick(),
      loop: true
    });
  }
  stopRiseTimer() {
    if (this.riseEvent) { this.riseEvent.remove(); this.riseEvent = null; }
  }

  riseTick() {
    if (this.status !== 'playing' || !this.activePiece) return;
    if (!this.movePiece(0, -1)) {
      if (this.lockDelayStart === 0) this.lockDelayStart = this.time.now;
      if (this.time.now - this.lockDelayStart >= LOCK_DELAY_MS) {
        this.lockPiece();
      }
    } else {
      this.lockDelayStart = 0;
    }
  }

  /* ========== movement ========== */
  movePiece(dx, dy) {
    if (!this.activePiece) return false;
    const { cells, x, y } = this.activePiece;
    if (collision(this.grid, cells, x + dx, y + dy)) return false;
    this.activePiece.x += dx;
    this.activePiece.y += dy;
    this.updateGhost();
    return true;
  }

  /* ========== soft rise ========== */
  startSoftRise() {
    if (this.status !== 'playing' || this.softRising) return;
    this.softRising = true;
    this.stopSoftRise();
    this.softRiseTimer = this.time.addEvent({
      delay: 50,
      callback: () => {
        if (!this.activePiece || this.status !== 'playing') { this.stopSoftRise(); return; }
        if (this.movePiece(0, -1)) {
          this.score += 1;
          this.updateHUD();
        } else {
          this.stopSoftRise();
        }
      },
      loop: true
    });
  }
  stopSoftRise() {
    if (this.softRiseTimer) { this.softRiseTimer.remove(); this.softRiseTimer = null; }
    this.softRising = false;
  }

  /* ========== hard rise ========== */
  hardRise() {
    if (!this.activePiece || this.status !== 'playing') return;
    let cellsRisen = 0;
    while (this.movePiece(0, -1)) cellsRisen++;
    this.score += cellsRisen * 2;
    this.updateHUD();
    this.audio.hardRise();
    this.lockPiece();
  }

  /* ========== rotation ========== */
  rotate(cw) {
    if (!this.activePiece || this.status !== 'playing') return;
    const newRot = ((this.activePiece.rotation + (cw ? 1 : 3)) % 4);
    const rot = getRotatedCells(this.activePiece.name, newRot);
    for (const [kx, ky] of WALL_KICKS) {
      if (!collision(this.grid, rot.cells, this.activePiece.x + kx, this.activePiece.y + ky)) {
        this.activePiece.cells = rot.cells;
        this.activePiece.w = rot.w;
        this.activePiece.h = rot.h;
        this.activePiece.rotation = newRot;
        this.activePiece.x += kx;
        this.activePiece.y += ky;
        this.updateGhost();
        this.audio.rotate();
        return;
      }
    }
  }

  /* ========== hold ========== */
  holdPiece() {
    if (!this.activePiece || this.holdUsed || this.status !== 'playing') return;
    this.holdUsed = true;
    const prev = this.activePiece.name;
    if (this.holdShape) {
      this.spawnPiece(this.holdShape);
    } else {
      this.spawnPiece(this.nextShape);
      this.nextShape = this.nextFromBag();
    }
    this.holdShape = prev;
    this.audio.rotate();
    this.updateHUD();
  }

  /* ========== ghost ========== */
  updateGhost() {
    if (!this.activePiece) return;
    let gy = this.activePiece.y;
    while (!collision(this.grid, this.activePiece.cells, this.activePiece.x, gy - 1)) gy--;
    this.ghostY = gy;
  }

  /* ========== lock ========== */
  lockPiece() {
    if (!this.activePiece) return;
    const { cells, x, y } = this.activePiece;
    const colorId = SHAPE_NAMES.indexOf(this.activePiece.name) + 1;
    for (const [c, r] of cells) {
      const gx = x + c, gy = y + r;
      if (gy >= 0 && gy < ROWS && gx >= 0 && gx < COLS) {
        this.grid[gy][gx] = colorId;
      }
    }
    this.audio.lock();
    this.activePiece = null;
    this.lockDelayStart = 0;
    this.stopSoftRise();
    this.checkLines();
  }

  /* ========== line clearing ========== */
  checkLines() {
    const fullRows = [];
    for (let r = 0; r < ROWS; r++) {
      let full = true;
      for (let c = 0; c < COLS; c++) {
        if (this.grid[r][c] === 0) { full = false; break; }
      }
      if (full) fullRows.push(r);
    }
    if (fullRows.length === 0) {
      this.spawnNext();
      return;
    }

    this.clearingRows = fullRows;
    this.clearFlashTimer = 0;
    this.status = 'clearing';
    this.audio.clear(fullRows.length);
    if (fullRows.length === 3) this.audio.triple();

    this.time.delayedCall(CLEAR_FLASH_MS, () => {
      /* remove rows in descending order to avoid index shift issues */
      const sorted = [...fullRows].sort((a, b) => b - a);
      for (const r of sorted) {
        this.grid.splice(r, 1);
        this.grid.unshift(new Uint8Array(COLS));
      }
      this.clearingRows = [];
      this.lines += fullRows.length;
      this.score += LINE_SCORES[fullRows.length] * this.level;

      const newLevel = Math.floor(this.lines / LINES_PER_LEVEL) + 1;
      if (newLevel > this.level) {
        this.level = newLevel;
        this.startRiseTimer();
      }

      if (this.score > this.highScore) {
        this.highScore = this.score;
        this.saveHighScore();
      }

      this.status = 'playing';
      this.updateHUD();
      this.spawnNext();
    });
  }

  spawnNext() {
    if (this.status === 'gameover') return;
    this.spawnPiece(this.nextShape);
    this.nextShape = this.nextFromBag();
    this.updateHUD();
  }

  /* ========== game over ========== */
  gameOver() {
    this.status = 'gameover';
    this.stopRiseTimer();
    this.stopSoftRise();
    this.activePiece = null;
    if (this.score > this.highScore) {
      this.highScore = this.score;
      this.saveHighScore();
    }
    this.audio.gameOver();
    this.updateHUD();
    this.showGameOver();
  }

  /* ========== pause ========== */
  pauseGame() {
    if (this.status !== 'playing') return;
    this.status = 'paused';
    this.stopRiseTimer();
    this.stopSoftRise();
    this.showPause();
  }
  resumeGame() {
    if (this.status !== 'paused') return;
    this.status = 'playing';
    this.startRiseTimer();
    this.clearOverlay();
  }

  /* ========== keyboard ========== */
  update() {
    const { cursors, keys } = this;
    const JD = Phaser.Input.Keyboard.JustDown;
    const JU = Phaser.Input.Keyboard.JustUp;

    if (this.status === 'menu') {
      if (JD(keys.enter) || JD(keys.space)) {
        this.startNewGame();
      }
      return;
    }

    if (this.status === 'gameover') {
      if (JD(keys.enter) || JD(keys.space) || JD(keys.r)) {
        this.startNewGame();
      }
      return;
    }

    /* pause toggle — always available */
    if (JD(keys.esc) || JD(keys.p)) {
      if (this.status === 'playing') this.pauseGame();
      else if (this.status === 'paused') this.resumeGame();
      return;
    }

    if (this.status === 'paused') return;

    /* restart */
    if (JD(keys.r)) {
      this.startNewGame();
      return;
    }

    if (this.status !== 'playing' || !this.activePiece) return;

    if (JD(cursors.left)) {
      if (this.movePiece(-1, 0)) { this.audio.move(); this.lockDelayStart = 0; }
    }
    if (JD(cursors.right)) {
      if (this.movePiece(1, 0)) { this.audio.move(); this.lockDelayStart = 0; }
    }
    if (JD(cursors.up)) {
      this.startSoftRise();
    }
    if (JU(cursors.up)) {
      this.stopSoftRise();
    }
    if (JD(keys.space)) {
      this.hardRise();
    }
    if (JD(keys.x) || JD(keys.ctrl)) {
      this.rotate(true);
      this.lockDelayStart = 0;
    }
    if (JD(keys.z)) {
      this.rotate(false);
      this.lockDelayStart = 0;
    }
    if (JD(keys.c) || JD(keys.shiftL) || JD(keys.shiftR)) {
      this.holdPiece();
    }
  }

  /* ========== touch controls ========== */
  createTouchControls() {
    const isMobile = window.innerWidth < 600;
    if (!isMobile) return;

    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const btnW = Math.max(44, cs * 2.5);
    const btnH = Math.max(44, cs * 2.5);
    const gap = 4;
    const bottomY = gh + 10;
    const cx = gw / 2;

    const makeBtn = (label, x, y, action) => {
      const g = this.add.graphics();
      g.fillStyle(0x333344, 0.7);
      g.fillRoundedRect(x - btnW/2, y - btnH/2, btnW, btnH, 6);
      g.lineStyle(1, 0x666688, 0.5);
      g.strokeRoundedRect(x - btnW/2, y - btnH/2, btnW, btnH, 6);
      const t = this.add.text(x, y, label, {
        fontSize: `${Math.floor(btnH * 0.45)}px`,
        color: '#ddd',
        fontFamily: 'monospace'
      }).setOrigin(0.5);
      const zone = this.add.zone(x, y, btnW, btnH).setOrigin(0.5).setInteractive();
      zone.on('pointerdown', () => { this.audio.resume(); action(); });
      return { g, t, zone };
    };

    makeBtn('◀', cx - btnW*1.5 - gap, bottomY + btnH, () => {
      if (this.status === 'playing' && this.movePiece(-1, 0)) { this.audio.move(); this.lockDelayStart = 0; }
    });
    makeBtn('▶', cx - gap*0.5, bottomY + btnH, () => {
      if (this.status === 'playing' && this.movePiece(1, 0)) { this.audio.move(); this.lockDelayStart = 0; }
    });
    makeBtn('↻', cx + gap*0.5, bottomY + btnH, () => {
      if (this.status === 'playing') { this.rotate(true); this.lockDelayStart = 0; }
    });
    makeBtn('⇡', cx + btnW*1.5 + gap, bottomY + btnH, () => {
      if (this.status === 'playing') this.hardRise();
    });
    makeBtn('HOLD', cx - btnW, bottomY - btnH*0.5, () => this.holdPiece());
    makeBtn('⏸', cx + btnW, bottomY - btnH*0.5, () => {
      if (this.status === 'playing') this.pauseGame();
      else if (this.status === 'paused') this.resumeGame();
    });
  }

  /* ========== HUD ========== */
  createHUD() {
    const cs = this.cellSize;
    const sx = this.sideX;
    const fontSize = Math.max(12, Math.floor(cs * 0.85));
    const smallFont = Math.max(10, Math.floor(cs * 0.65));

    const mkText = (x, y, text, size, color) =>
      this.add.text(x, y, text, {
        fontSize: `${size}px`,
        color: '#' + color.toString(16).padStart(6, '0'),
        fontFamily: 'monospace',
        fontStyle: 'bold'
      });

    let cy = 10;
    this.hud.scoreLabel = mkText(sx, cy, 'SCORE', fontSize, 0x6666aa);
    cy += fontSize + 2;
    this.hud.scoreValue = this.add.text(sx, cy, '0', {
      fontSize: `${fontSize}px`, color: '#eeeeff', fontFamily: 'monospace'
    });
    cy += fontSize + 20;

    this.hud.levelLabel = mkText(sx, cy, 'LEVEL', fontSize, 0x6666aa);
    cy += fontSize + 2;
    this.hud.levelValue = this.add.text(sx, cy, '1', {
      fontSize: `${fontSize}px`, color: '#eeeeff', fontFamily: 'monospace'
    });
    cy += fontSize + 20;

    this.hud.linesLabel = mkText(sx, cy, 'LINES', fontSize, 0x6666aa);
    cy += fontSize + 2;
    this.hud.linesValue = this.add.text(sx, cy, '0', {
      fontSize: `${fontSize}px`, color: '#eeeeff', fontFamily: 'monospace'
    });
    cy += fontSize + 20;

    this.hud.bestLabel = mkText(sx, cy, 'BEST', smallFont, 0x888899);
    cy += smallFont + 2;
    this.hud.bestValue = this.add.text(sx, cy, '0', {
      fontSize: `${smallFont}px`, color: '#888899', fontFamily: 'monospace'
    });
    cy += smallFont + 20;

    this.hud.nextLabel = mkText(sx, cy, 'NEXT', fontSize, 0x6666aa);
    this.hud.nextY = cy + fontSize + 6;

    this.hud.holdLabel = mkText(sx, cy + 80, 'HOLD', fontSize, 0x6666aa);
    this.hud.holdY = cy + 80 + fontSize + 6;
  }

  updateHUD() {
    this.hud.scoreValue.setText(String(this.score));
    this.hud.levelValue.setText(String(this.level));
    this.hud.linesValue.setText(String(this.lines));
    this.hud.bestValue.setText(String(this.highScore));

    /* draw next preview */
    if (this.hud.nextGraphics) this.hud.nextGraphics.destroy();
    this.hud.nextGraphics = this.add.graphics();
    if (this.nextShape) {
      this.drawPreview(this.hud.nextGraphics, this.nextShape, this.sideX, this.hud.nextY, 0.9);
    }

    /* draw hold preview */
    if (this.hud.holdGraphics) this.hud.holdGraphics.destroy();
    this.hud.holdGraphics = this.add.graphics();
    if (this.holdShape) {
      this.drawPreview(this.hud.holdGraphics, this.holdShape, this.sideX, this.hud.holdY, this.holdUsed ? 0.3 : 0.9);
    }
  }

  drawPreview(g, shapeName, ox, oy, alpha) {
    const cs = Math.max(10, Math.floor(this.cellSize * 0.7));
    const rot = getRotatedCells(shapeName, 0);
    const color = SHAPES[shapeName].color;
    for (const [c, r] of rot.cells) {
      g.fillStyle(color, alpha);
      g.fillRoundedRect(ox + c * (cs + 2), oy + r * (cs + 2), cs, cs, 2);
    }
  }

  /* ========== overlays ========== */
  clearOverlay() {
    for (const obj of this.overlayObjects) obj.destroy();
    this.overlayObjects = [];
  }

  showMenu() {
    this.status = 'menu';
    this.clearOverlay();
    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const cx = gw / 2;
    const cy = gh / 2;

    const bg = this.add.graphics();
    bg.fillStyle(0x0a0a12, 0.92);
    bg.fillRect(0, 0, gw, gh);
    this.overlayObjects.push(bg);

    const title = this.add.text(cx, cy - 80, 'INVERTED\nTETRIS', {
      fontSize: `${Math.max(28, cs * 2.5)}px`, color: '#30b5c5',
      fontFamily: 'monospace', fontStyle: 'bold', align: 'center', lineSpacing: 4
    }).setOrigin(0.5);

    const sub = this.add.text(cx, cy + 20, 'Figures rise from below.\nClear lines. Survive.', {
      fontSize: `${Math.max(12, cs * 0.8)}px`, color: '#6666aa',
      fontFamily: 'monospace', align: 'center'
    }).setOrigin(0.5);

    const start = this.add.text(cx, cy + 100, '[ PRESS ENTER / SPACE ]', {
      fontSize: `${Math.max(14, cs * 1)}px`, color: '#aabbcc', fontFamily: 'monospace'
    }).setOrigin(0.5);

    const ctrls = this.add.text(cx, cy + 160,
      '← →  Move    ↑  Soft Rise    Space  Hard Rise\nX  CW    Z  CCW    C  Hold    Esc  Pause', {
      fontSize: `${Math.max(10, cs * 0.65)}px`, color: '#444466',
      fontFamily: 'monospace', align: 'center', lineSpacing: 2
    }).setOrigin(0.5);

    this.overlayObjects.push(title, sub, start, ctrls);
  }

  showPause() {
    this.clearOverlay();
    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const cx = gw / 2;
    const cy = gh / 2;

    const bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.6);
    bg.fillRect(0, 0, gw, gh);

    const txt = this.add.text(cx, cy, 'PAUSED', {
      fontSize: `${Math.max(28, cs * 2.5)}px`, color: '#aabbcc',
      fontFamily: 'monospace', fontStyle: 'bold'
    }).setOrigin(0.5);

    const sub = this.add.text(cx, cy + 50, 'Press Esc / P to resume', {
      fontSize: `${Math.max(12, cs * 0.8)}px`, color: '#6666aa', fontFamily: 'monospace'
    }).setOrigin(0.5);

    this.overlayObjects.push(bg, txt, sub);
  }

  showGameOver() {
    this.clearOverlay();
    const cs = this.cellSize;
    const gw = COLS * cs;
    const gh = ROWS * cs;
    const cx = gw / 2;
    const cy = gh / 2;

    const bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.7);
    bg.fillRect(0, 0, gw, gh);

    const go = this.add.text(cx, cy - 60, 'GAME OVER', {
      fontSize: `${Math.max(28, cs * 2.2)}px`, color: '#c00000',
      fontFamily: 'monospace', fontStyle: 'bold'
    }).setOrigin(0.5);

    const sc = this.add.text(cx, cy, `Score: ${this.score}`, {
      fontSize: `${Math.max(16, cs * 1.2)}px`, color: '#ccccdd', fontFamily: 'monospace'
    }).setOrigin(0.5);

    const lv = this.add.text(cx, cy + 30, `Level ${this.level}  ·  ${this.lines} lines`, {
      fontSize: `${Math.max(12, cs * 0.9)}px`, color: '#8888aa', fontFamily: 'monospace'
    }).setOrigin(0.5);

    const restart = this.add.text(cx, cy + 90, '[ PRESS ENTER / R ]', {
      fontSize: `${Math.max(14, cs * 0.9)}px`, color: '#aabbcc', fontFamily: 'monospace'
    }).setOrigin(0.5);

    this.overlayObjects.push(bg, go, sc, lv, restart);
  }

  /* ========== rendering ========== */
  drawCell(g, x, y, color, alpha = 1, size = null) {
    const s = size || this.cellSize;
    const pad = 1;
    g.fillStyle(color, alpha);
    g.fillRoundedRect(x * s + pad, y * s + pad, s - pad*2, s - pad*2, 2);
    g.fillStyle(0xffffff, alpha * 0.12);
    g.fillRect(x * s + pad, y * s + pad, s - pad*2, 2);
  }

  render() {
    if (this.status === 'menu') return;

    const cs = this.cellSize;

    /* grid */
    this.gridGraphics.clear();
    this.gridGraphics.fillStyle(0x111118, 1);
    this.gridGraphics.fillRect(0, 0, COLS * cs, ROWS * cs);

    /* grid lines */
    this.gridGraphics.lineStyle(1, 0x1a1a2a, 0.5);
    for (let r = 0; r <= ROWS; r++)
      this.gridGraphics.strokeRect(0, r * cs, COLS * cs, 0);
    for (let c = 0; c <= COLS; c++)
      this.gridGraphics.strokeRect(c * cs, 0, 0, ROWS * cs);

    /* locked cells */
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (this.grid[r][c] !== 0) {
          const sn = SHAPE_NAMES[this.grid[r][c] - 1];
          const color = SHAPES[sn].color;
          if (this.clearingRows.includes(r)) {
            const flash = Math.sin(this.time.now * 0.02) > 0;
            this.drawCell(this.gridGraphics, c, r, flash ? 0xffffff : color, 0.6);
          } else {
            this.drawCell(this.gridGraphics, c, r, color, 0.85);
          }
        }
      }
    }

    /* ghost */
    this.ghostGraphics.clear();
    if (this.activePiece && this.status === 'playing') {
      const { cells, x } = this.activePiece;
      for (const [c, r] of cells)
        this.drawCell(this.ghostGraphics, x + c, this.ghostY + r, this.activePiece.color, 0.18);
    }

    /* active piece */
    this.pieceGraphics.clear();
    if (this.activePiece) {
      const { cells, x, y, color } = this.activePiece;
      for (const [c, r] of cells)
        this.drawCell(this.pieceGraphics, x + c, y + r, color, 1.0);
    }
  }
}

/* ========== phaser config ========== */
const config = {
  type: Phaser.AUTO,
  parent: 'game-container',
  width: window.innerWidth,
  height: window.innerHeight,
  backgroundColor: '#0a0a0f',
  scene: GameScene,
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH
  },
  render: {
    antialias: false,
    pixelArt: false,
    roundPixels: true,
    antialiasGL: false
  },
  input: {
    keyboard: true,
    touch: true,
    mouse: true
  }
};

const game = new Phaser.Game(config);

window.addEventListener('resize', () => {
  game.scale.resize(window.innerWidth, window.innerHeight);
});
